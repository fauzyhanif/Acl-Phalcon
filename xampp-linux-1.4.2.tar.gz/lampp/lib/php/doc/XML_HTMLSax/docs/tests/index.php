<?php
/**
* @package XML
* @version $Id: index.php,v 1.4 2003/08/14 01:54:58 lastcraft Exp $
*/
if (!defined('SIMPLE_TEST')) {
    define('SIMPLE_TEST', '/www/simpletest/');
}
include('unit_tests.php');
?>