<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="author" content="Laurent Laville" />
<title>PEAR/HTML/Progress-Class ViewCode</title>
<style type="text/css">
<!--
body { 
	font-family: Verdana, Arial, Helvetica, sans-serif; 
	}
img { 
	border: 0; 
}
h1, h2 {
	border: 1px solid yellow; 
}
h1 {
	background-color: #006600; 
	color: white; 
	font-family: Arial, Helvetica, sans-serif; 
	padding: 4px; 
	text-align: center;
}
h2 {
	background-color: #e4e4e4; 
	color: black; 
	padding: 2px;
}
h1 span.chapter {
	font-size: 48px; 
}
pre.code { 
	font-family: courier, Verdana; 
	font-size: 12px;
	background-color: #EEEEEE; 
	color: black; 
	padding: 4px; 
	border: 1px solid red;
}
-->
</style>
</head>
<body bgcolor="lightgrey">


<h1><img src="docs/pear-power.png"> :: HTML_Progress
<br /><span class="chapter">Source code of <?php echo $_GET['f'] ?>.php</span>
</h1>

<p><< <a href="javascript:history.go(-1);">Back documentation</a></p>
<pre class="code">
<?php
highlight_file ($_GET['f'].".php");
?>
</pre>

</body>
</html>