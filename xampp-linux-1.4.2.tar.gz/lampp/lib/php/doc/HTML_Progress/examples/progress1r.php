<?php 
/**
 * Display a horizontal loading bar with background image, 
 * filled in reverse order (right to left)
 * from 0 to 100% increase by step of 10%
 * with default colors, and javascript override.
 * 
 * @version    $Id: progress1r.php,v 1.3 2003/08/27 18:24:48 Farell Exp $
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @package    HTML_Progress
 */

require_once ('HTML/Progress/BarHorizontal.php');

$p = new HTML_Page();
$p->setTitle("PEAR::HTML_Progress - Example 1r");
$p->setMetaData("author", "Laurent Laville");

$options = array(
    'background-color'  => '#EBEBEB',
    'border-width'      => 1,
    'border-style'      => 'inset',
    'border-color'      => 'white',
    'cell-width'        => 25,
    'cell-spacing'      => 0,
    'active-color'      => '#000084',
    'inactive-color'    => '#3A6EA5'
);

$bar = new HTML_Progress_Bar_Horizontal('reverse', $p, $options);

$css = $bar->getStyle();
$css->setStyle('body', 'background-color', '#c3c6c3');
$css->setStyle('body', 'font-family', 'Verdana, Arial');
$css->setStyle('a:link', 'color', 'navy');
$css->setSameStyle('a:visited, a:active', 'a:link');
$css->setStyle('div.col1', 'float', 'left');
$css->setStyle('div.col1', 'width', '25%');
$css->setStyle('div.col2', 'margin-left', '30%');
$css->setStyle('div.col2', 'border', '1px solid red');
$css->setStyle('div.col2', 'padding', '1em');
$css->setStyle('div.col2', 'height', '80%');
$css->setStyle('.cell1', 'background-image', 'url("download.gif")');
$css->setStyle('.cell1', 'background-repeat', 'no-repeat');

$p->addStyleDeclaration($css);
$p->addScriptDeclaration( $bar->getScript() );
$p->addBodyContent('<div class="col1">'.$bar->toHTML().'</div>');
$p->addBodyContent('<div class="col2">');
$p->addBodyContent('<h1>Example 1 reverse</h1>');
$p->addBodyContent('<p><i><b>Laurent Laville, August 2003</b></i></p>');

$note = <<< TEXT
<p><i>Image <img src="download.gif"/> in cells are made by background-image property of CSS cell1 class</i>
<br/>This example show you how to customize a progress bar by stylesheet properties.</p>
TEXT;

$p->addBodyContent($note);
$p->addBodyContent('</div>');
$p->display();

for ($i=0; $i<10; $i++) {
    $bar->display(10);
}

echo '<p>&lt;&lt; <a href="index.html">Back documentation</a></p>';

?>