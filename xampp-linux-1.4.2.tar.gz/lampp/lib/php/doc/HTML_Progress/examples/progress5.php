<?php 
/**
 * Display a horizontal loading bar setting at different steps
 * in natural order with custom colors.
 * 
 * @version    $Id: progress5.php,v 1.4 2003/08/27 18:24:48 Farell Exp $
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @package    HTML_Progress
 */

require_once ('HTML/Progress/BarHorizontal.php');

$p = new HTML_Page();
$p->setTitle("PEAR::HTML_Progress - Example 5");
$p->setMetaData("author", "Laurent Laville");

$options = array(
    'background-color'  => '#EBEBEB',
    'border-width'      => 1,
    'border-style'      => 'inset',
    'border-color'      => 'white',
    'cell-width'        => 20,
    'cell-spacing'      => 0,
    'active-color'      => '#000084',
    'inactive-color'    => '#3A6EA5'
);

$bar = new HTML_Progress_Bar_Horizontal('natural', $p, $options);

$text = array(
    'size' => 14,
    'background-color' => '#c3c6c3',  // same color as body background, make it transparent
    'v-align' => 'top'
);
$bar->setText(true, $text);

$css = $bar->getStyle();
$css->setStyle('body', 'background-color', '#c3c6c3');
$css->setStyle('body', 'font-family', 'Verdana, Arial');
$css->setStyle('a:link', 'color', 'navy');
$css->setSameStyle('a:visited, a:active', 'a:link');
$css->setStyle('div.col1', 'float', 'left');
$css->setStyle('div.col1', 'width', '25%');
$css->setStyle('div.col2', 'margin-left', '30%');
$css->setStyle('div.col2', 'border', '1px solid navy');
$css->setStyle('div.col2', 'padding', '1em');
$css->setStyle('div.col2', 'height', '80%');

$p->addStyleDeclaration($css);
$p->addScriptDeclaration( $bar->getScript() );
$p->addBodyContent('<div class="col1">'.$bar->toHTML().'</div>');
$p->addBodyContent('<div class="col2">');
$p->addBodyContent('<h1>Example 5</h1>');
$p->addBodyContent('<p><i><b>Laurent Laville, August 2003</b></i></p>');

$note = <<< TEXT
<p><i>plain bar</i><br />
Display horizontal loading bar setting at 3 different steps (25%, 50% 75%)
TEXT;

$p->addBodyContent($note);
$p->addBodyContent('</div>');
$p->display();

/*  Progress Start */
$bar->display(0,"set");
/*  You have to do something here at 25% */
sleep(1);
$bar->display(25,"set");
/*  You have to do something here at 50% */
sleep(1);
$bar->display(50,"set");
/*  You have to do something here at 75% */
sleep(1);
$bar->display(75,"set");
/*  Progress End */
sleep(1);
$bar->display(100,"set");

echo '<p>&lt;&lt; <a href="index.html">Back documentation</a></p>';

?>