<?php 
/**
 * Display a horizontal loading bar with percent info, 
 * filled in natural order (left to right)
 * from 0 to 100% increase by step of 10%
 * with default colors.
 * Text will be display on each sides of progress bar.
 * 
 * @version    $Id: progress8bg.php,v 1.2 2003/08/27 18:25:02 Farell Exp $
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @package    HTML_Progress
 */

require_once ('HTML/Progress/BarHorizontal.php');

$p = new HTML_Page();
$p->setTitle("PEAR::HTML_Progress - Example 8bg");
$p->setMetaData("author", "Laurent Laville");

$bar = new HTML_Progress_Bar_Horizontal('natural', $p);

$text = array(
    'size'  => 14,
    'color' => 'black', 
    'background-color' => '#e0e0e0',
    'v-align' => $_GET['align']
);
if ($_GET['align'] == 'left' || $_GET['align'] == 'right') {
    $text['width'] = 100;
} else {
    $text['h-align'] = 'center';
}
if ($_GET['align'] == 'left') {
    $text['h-align'] = 'left';
}
if ($_GET['align'] == 'right') {
    $text['h-align'] = 'right';
}
$bar->setText(true, $text);

$css = $bar->getStyle();
$css->setStyle('body', 'background-color', 'lightblue');
$css->setStyle('body', 'color', '#006600');
$css->setStyle('body', 'font-family', 'Verdana, Arial');
$css->setStyle('a:link', 'color', 'navy');
$css->setSameStyle('a:visited, a:active', 'a:link');
$css->setStyle('div.col1', 'float', 'left');
$css->setStyle('div.col1', 'width', '25%');
$css->setStyle('div.col2', 'margin-left', '30%');
$css->setStyle('div.col2', 'border', '3px solid silver');
$css->setStyle('div.col2', 'padding', '1em');
$css->setStyle('div.col2', 'height', '80%');

$p->addStyleDeclaration($css);
$p->addScriptDeclaration( $bar->getScript() );
$p->addBodyContent('<div class="col1">'.$bar->toHTML().'</div>');
$p->addBodyContent('<div class="col2">');
$p->addBodyContent('<h1>Example 8bg</h1>');
$p->addBodyContent('<p><i>Laurent Laville, August 2003 </i></p>');

$note = <<< TEXT
<p>Properties <b>h-align</b> (lef, right, center) and <b>background-color</b> (= #e0e0e0) into attributes parameter of API setText.</p>
<p>Look out the percent info legend will be shown on each sides of progress bar. Legend is now independent of progress bar!</p>
TEXT;

$p->addBodyContent($note);
$p->addBodyContent('<p>v-align <a href="progress8bg.php?align=top">Top</a> with h-align center</p>');
$p->addBodyContent('<p>v-align <a href="progress8bg.php?align=bottom">Bottom</a> with h-align center</p>');
$p->addBodyContent('<p>v-align <a href="progress8bg.php?align=left">Left</a> with h-align left</p>');
$p->addBodyContent('<p>v-align <a href="progress8bg.php?align=right">Right (default)</a> with h-align right</p>');
$p->addBodyContent('</div>');
$p->display();

for ($i=0; $i<10; $i++) {
/*  You have to do something here  */
    $bar->display(10);
}

echo '<p>&lt;&lt; <a href="index.html">Back documentation</a></p>';

?>