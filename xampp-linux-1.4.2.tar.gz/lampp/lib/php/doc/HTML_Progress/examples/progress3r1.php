<?php 
/**
 * Display a horizontal loading bar with percent info, 
 * filled in reverse order (right to left)
 * from 0 to 100% increase by step 5%
 * with custom configuration and javascript override.
 * 
 * @version    $Id: progress3r1.php,v 1.1 2003/08/27 18:24:48 Farell Exp $
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @package    HTML_Progress
 */

require_once ('HTML/Progress/BarHorizontal.php');

$p = new HTML_Page();
$p->setTitle("PEAR::HTML_Progress - Example 3r1");
$p->setMetaData("author", "Laurent Laville");

$options = array(
    'border-width'  => 1,
    'border-color'  => 'navy',
    'cell-height'   => 20,
    'cell-width'    => 20,
    'active-color'  => '#3874B4',
    'inactive-color'=> '#EEEECC'
);

$bar = new HTML_Progress_Bar_Horizontal('reverse', $p, $options);
$bar->setText(true, array('size' => 14, 'width' => 60, 'background-color' => '#eeeeee'));
$bar->setCell(range(0,2), array('color' => 'silver', 'size' => 10));
$bar->setCell(range(3,6), array('color' => 'yellow', 'size' => 10));
$bar->setCell(range(7,9), array('color' => 'orange'));

$css = $bar->getStyle();
$css->setStyle('body', 'background-color', '#eeeeee');
$css->setStyle('body', 'font-family', 'Verdana, Arial');
$css->setStyle('a:link', 'color', 'navy');
$css->setSameStyle('a:visited, a:active', 'a:link');
$css->setStyle('div.col1', 'float', 'left');
$css->setStyle('div.col1', 'width', '25%');
$css->setStyle('div.col2', 'margin-left', '30%');
$css->setStyle('div.col2', 'border', '1px solid red');
$css->setStyle('div.col2', 'padding', '1em');
$css->setStyle('div.col2', 'height', '80%');

$p->addStyleDeclaration($css);
$p->addScript('progress3.js');
$p->addBodyContent('<div class="col1">'.$bar->toHTML().'</div>');
$p->addBodyContent('<div class="col2">');
$p->addBodyContent('<h1>Example 3 reverse 1</h1>');
$p->addBodyContent('<p><i><b>Laurent Laville, August 2003</b></i></p>');

$note = <<< TEXT
<p><i>Numbers in cells are made by javascript file <b>progress3.js</b></i>
<br/>This example show you how to customize cell font size/color.</p>
TEXT;

$p->addBodyContent($note);
$p->addBodyContent('</div>');
$p->display();

for ($i=0; $i<20; $i++) {
/*  You have to do something here  */
    $bar->display(5);
}

echo '<p>&lt;&lt; <a href="index.html">Back documentation</a></p>';

?>