<?php 
/**
 * @version    $Id: iframe2.php,v 1.1 2003/09/24 22:17:29 Farell Exp $
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @package    HTML_Progress
 */

require_once ('HTML/Progress/BarHorizontal.php');

$iframe = new HTML_Page();

$bar = new HTML_Progress_Bar_Horizontal('natural', $iframe);

$text = array(
    'width' => 100, 
    'size'  => 14,
    'color' => 'yellow',
    'background-color' => '#996',
    'h-align' => 'center',
    'v-align' => 'right'   
);
$bar->setText(true, $text);

$css = $bar->getStyle();
$css->setStyle('body', 'background-color', '#996');

$iframe->addStyleDeclaration($css);
$iframe->addScriptDeclaration( $bar->getScript() );
$iframe->addBodyContent( $bar->toHTML() );
$iframe->display();

for ($i=0; $i<20; $i++) {
/*  You have to do something here  */
    $bar->display(5);
}

?>