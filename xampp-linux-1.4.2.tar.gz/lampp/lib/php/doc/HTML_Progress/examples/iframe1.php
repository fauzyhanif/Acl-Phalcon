<?php 
/**
 * @version    $Id: iframe1.php,v 1.1 2003/09/24 22:17:29 Farell Exp $
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @package    HTML_Progress
 */

require_once ('HTML/Progress/BarHorizontal.php');

$iframe = new HTML_Page();

$options = array(
    'border-width'  => 1,
    'border-color'  => 'navy',
    'cell-width'    => 10,
    'active-color'  => '#3874B4',
    'inactive-color'=> '#EEEECC'
);

$bar = new HTML_Progress_Bar_Horizontal('natural', $iframe, $options);

$text = array(
    'width' => 60, 
    'size'  => 14,
    'color' => 'navy',
    'background-color' => '#eeeeee',
    'h-align' => 'center',
    'v-align' => 'right'   
);
$bar->setText(true, $text);

$css = $bar->getStyle();
$css->setStyle('body', 'background-color', '#eeeeee');

$iframe->addStyleDeclaration($css);
$iframe->addScriptDeclaration( $bar->getScript() );
$iframe->addBodyContent( $bar->toHTML() );
$iframe->display();

for ($i=0; $i<10; $i++) {
/*  You have to do something here  */
    $bar->display(10);
}

?>