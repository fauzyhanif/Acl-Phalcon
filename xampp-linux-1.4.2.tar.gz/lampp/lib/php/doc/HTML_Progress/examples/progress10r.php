<?php

/**
 * Display a vertical loading bar from 0 to 100% step 10% 
 * filled in reverse order, with custom colors.
 * 
 * @version    $Id: progress10r.php,v 1.4 2003/08/27 22:07:27 Farell Exp $
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @package    HTML_Progress
 */

require_once 'HTML/Progress/BarVertical.php';

$p = new HTML_Page();
$p->setTitle("PEAR::HTML_Progress - Example 10r");
$p->setMetaData("author", "Laurent Laville");

$options = array(
    'height'            => 160,
    'background-color'  => '#EBEBEB',
    'cell-width'        => 40,
    'cell-spacing'      => 0,
    'active-color'      => '#000084',
    'inactive-color'    => '#3A6EA5'
);

$bar = new HTML_Progress_Bar_Vertical('reverse', $p, $options);
$text = array(
    'height' => 20,
    'size'   => 10,
    'background-color'  => '#EBEBEB',
    'h-align' => 'center'
);
$bar->setText(true, $text);

$css = $bar->getStyle();
$css->setStyle('body', 'background-color', '#c3c6c3');
$css->setStyle('body', 'font-family', 'Verdana, Arial');
$css->setStyle('a:link', 'color', 'navy');
$css->setSameStyle('a:visited, a:active', 'a:link');
$css->setStyle('div.col1', 'float', 'left');
$css->setStyle('div.col1', 'width', '25%');
$css->setStyle('div.col2', 'margin-left', '30%');
$css->setStyle('div.col2', 'border', '1px solid navy');
$css->setStyle('div.col2', 'padding', '1em');
$css->setStyle('div.col2', 'height', '80%');

$p->addStyleDeclaration($css);
$p->addScriptDeclaration( $bar->getScript() );
$p->addBodyContent('<div class="col1">'.$bar->toHTML().'</div>');
$p->addBodyContent('<div class="col2">');
$p->addBodyContent('<h1>Example 10 reverse</h1>');
$p->addBodyContent('<p><i><b>Laurent Laville, August 2003</b></i></p>');
$p->addBodyContent('</div>');
$p->display();

for ($i=0; $i<10; $i++) {
/*  You have to do something here  */
    $bar->display(10);
}

echo '<p>&lt;&lt; <a href="index.html">Back documentation</a></p>';

?>