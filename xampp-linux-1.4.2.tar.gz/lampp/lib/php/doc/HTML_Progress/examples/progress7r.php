<?php

/**
 * Display a horizontal loading bar set to 60% 
 * filled in reverse order, with default colors.
 * 
 * @version    $Id: progress7r.php,v 1.3 2003/08/27 18:25:01 Farell Exp $
 * @author     Laurent Laville <laurent.laville@worldonline.fr>
 * @package    HTML_Progress
 */

require_once 'HTML/Progress/BarHorizontal.php';

$bar = new HTML_Progress_Bar_Horizontal('reverse', null);
$bar->setText(true, array('width' => 70));
$bar->display(60,"set");

echo '<h1>Example 7 reverse</h1>';
echo '<p><i><b>Laurent Laville, August 2003</b></i></p>';
echo '<br /><hr noshade />';
echo '<p>&lt;&lt; <a href="index.html">Back documentation</a></p>';

?>