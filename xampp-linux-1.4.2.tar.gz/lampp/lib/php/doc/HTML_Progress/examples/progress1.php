<?php 
/**
 * Display a horizontal loading bar with percent info, 
 * filled in natural order (left to right)
 * from 0 to 100% increase by step of 10%
 * with all default attributes (color, size, ...)
 * 
 * @version    $Id: progress1.php,v 1.4 2003/08/25 23:11:14 Farell Exp $
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @package    HTML_Progress
 */

require_once ('HTML/Progress/BarHorizontal.php');

$pkg = array('PEAR', 'Archive_Tar', 'Config', 
    'HTML_QuickForm', 'HTML_CSS', 'HTML_Page', 'HTML_Template_Sigma', 
    'Log', 'MDB', 'PHPUnit');

$bar = new HTML_Progress_Bar_Horizontal();

for ($i=0; $i<10; $i++) {
    $bar->display(10);
    echo "installing package ... : ". $pkg[$i] ."<br /> \n";
}

echo '<p>&lt;&lt; <a href="index.html">Back documentation</a></p>';

?>