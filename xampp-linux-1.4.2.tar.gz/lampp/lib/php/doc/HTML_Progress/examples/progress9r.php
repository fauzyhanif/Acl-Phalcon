<?php

/**
 * Display a vertical loading bar set to 80% 
 * filled in reverse order, with default colors.
 * 
 * @version    $Id: progress9r.php,v 1.3 2003/08/27 18:25:02 Farell Exp $
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @package    HTML_Progress
 */

require_once 'HTML/Progress/BarVertical.php';

$bar = new HTML_Progress_Bar_Vertical('reverse');
$text = array(
    'width'   => 60,
    'height'  => 30,
    'h-align' => 'left',
);
$bar->setText(true, $text);
$bar->display(80,"set");

echo '<h1>Example 9 reverse</h1>';
echo '<p><i><b>Laurent Laville, August 2003</b></i></p>';
echo '<br /><hr noshade />';
echo '<p>&lt;&lt; <a href="index.html">Back documentation</a></p>';

?>