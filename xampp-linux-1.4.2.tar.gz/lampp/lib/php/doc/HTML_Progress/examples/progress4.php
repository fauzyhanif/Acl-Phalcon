<?php 
/**
 * Display a loading bar from 0 to 100% increase by step of 10%
 * in natural order with custom configuration.
 * 
 * @version    $Id: progress4.php,v 1.4 2003/08/27 18:24:48 Farell Exp $
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @package    HTML_Progress
 */

require_once ('HTML/Progress/BarHorizontal.php');

$options = array(
    'border-width'  => 1,
    'cell-width'    => 20,
    'active-color'  => '#970038',
    'inactive-color'=> '#FFDDAA'
);

$bar = new HTML_Progress_Bar_Horizontal('natural', null, $options);

$text = array(
    'size'    => 14,
    'color'   => 'red',
    'v-align' => 'bottom',
    'h-align' => 'center'
);
$bar->setText(true, $text);

for ($i=0; $i<10; $i++) {
    $bar->display(10);

    if ($bar->getProgress() == 20) {
        echo '<h1>Example 4 natural</h1>';
        echo '<p><i><b>Laurent Laville, August 2003</b></i></p>';
        echo '<br /><hr noshade />';
    }
}

echo '<p>&lt;&lt; <a href="index.html">Back documentation</a></p>';

?>