<?php 
/**
 * Display a horizontal loading bar with percent info, 
 * filled in natural order (left to right)
 * from 0 to 100% increase by step of 10%
 * with all default attributes (color, size, ...)
 * and a message line.
 * 
 * @version    $Id: progress1m.php,v 1.2 2003/08/27 18:24:48 Farell Exp $
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @package    HTML_Progress
 */

require_once ('HTML/Progress/BarHorizontal.php');

$pkg = array('PEAR', 'Archive_Tar', 'Config', 
    'HTML_QuickForm', 'HTML_CSS', 'HTML_Page', 'HTML_Template_Sigma', 
    'Log', 'MDB', 'PHPUnit');

$bar = new HTML_Progress_Bar_Horizontal();

$bar->setMessageLine(true, array('width' => 300, 'font' => 'Arial, Helvetica'));

for ($i=0; $i<10; $i++) {
    $bar->setMessage("installing package ... : ". $pkg[$i]);
    $bar->display(10);
}

echo '<p>&lt;&lt; <a href="index.html">Back documentation</a></p>';

?>