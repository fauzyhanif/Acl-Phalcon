<?php 
/**
 * Display two horizontal loading bars using inline frames
 * 
 * @version    $Id: progress1f.php,v 1.1 2003/09/24 22:17:29 Farell Exp $
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @package    HTML_Progress
 */

require_once ('HTML/Progress/BarHorizontal.php');

$p = new HTML_Page();
$p->setTitle("PEAR::HTML_Progress - Example 1f");
$p->setMetaData("author", "Laurent Laville");

$css = new HTML_CSS();
$css->setStyle('body', 'background-color', '#444444');
$css->setStyle('body', 'color', 'white');
$css->setStyle('body', 'font-family', 'Verdana, Arial');
$css->setStyle('a:link', 'color', 'yellow');
$css->setSameStyle('a:visited, a:active', 'a:link');

$p->addStyleDeclaration($css);
$p->addBodyContent('<iframe width=300 height=100 src="iframe1.php"></iframe><br />');
$p->addBodyContent('<iframe width=300 height=100 src="iframe2.php"></iframe>');
$p->addBodyContent('<h1>Example 1f</h1>');
$p->addBodyContent('<p><i><b>Laurent Laville, September 2003</b></i></p>');

$note = <<< TEXT
<p>ProgressBar is displayed inside a frame.</p>
TEXT;

$p->addBodyContent($note);
$p->display();


echo '<p>&lt;&lt; <a href="index.html">Back documentation</a></p>';

?>