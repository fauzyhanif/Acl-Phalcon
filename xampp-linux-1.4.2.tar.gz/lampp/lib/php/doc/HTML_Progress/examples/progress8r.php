<?php 
/**
 * Display a horizontal loading bar with percent info, 
 * filled in reverse order (right to left)
 * from 0 to 100% increase by step of 10%
 * with default colors.
 * Message will be display on top or bottom (side) of progress bar.
 * 
 * @version    $Id: progress8r.php,v 1.2 2003/08/27 18:25:02 Farell Exp $
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @package    HTML_Progress
 */

require_once ('HTML/Progress/BarHorizontal.php');

	
$p = new HTML_Page();
$p->setTitle("PEAR::HTML_Progress - Example 8r");
$p->setMetaData("author", "Laurent Laville");

$bar = new HTML_Progress_Bar_Horizontal('reverse', $p);

$text = array(
    'size'  => 14, 
    'width' => 60, 
    'color' => 'white', 
    'background-color' => '#444444',
    'h-align' => 'center'
);
$bar->setText(true, $text);

$message = array(
    'font'  => 'Arial', 
    'size'  => 16, 
    'color' => 'lightyellow', 
    'background-color' => '#444444',
    'h-align' => 'left',
    'v-align' => $_GET['align']
);
$bar->setMessageLine(true, $message);

$css = $bar->getStyle();
$css->setStyle('body', 'background-color', '#444444');
$css->setStyle('body', 'color', 'white');
$css->setStyle('body', 'font-family', 'Verdana, Arial');
$css->setStyle('a:link', 'color', 'yellow');
$css->setSameStyle('a:visited, a:active', 'a:link');
$css->setStyle('div.col1', 'float', 'left');
$css->setStyle('div.col1', 'width', '25%');
$css->setStyle('div.col2', 'margin-left', '30%');
$css->setStyle('div.col2', 'border', '3px solid silver');
$css->setStyle('div.col2', 'padding', '1em');
$css->setStyle('div.col2', 'height', '80%');

$p->addStyleDeclaration($css);
$p->addScriptDeclaration( $bar->getScript() );
$p->addBodyContent('<div class="col1">'.$bar->toHTML().'</div>');
$p->addBodyContent('<div class="col2">');
$p->addBodyContent('<h1>Example 8r</h1>');
$p->addBodyContent('<p><i>Laurent Laville, August 2003 </i></p>');

$note = <<< TEXT
<p>Property <b>v-align</b> (top, bottom) into attributes parameter of API setMessageLine.</p>
<p>Look out the message text will be shown up or down the progress bar.</p>
TEXT;

$p->addBodyContent($note);
$p->addBodyContent('<p><a href="progress8r.php?align=top">Top</a></p>');
$p->addBodyContent('<p><a href="progress8r.php?align=bottom">Bottom (default)</a></p>');
$p->addBodyContent('</div>');
$p->display();

$bar->setMessage('running ...');

for ($i=0; $i<10; $i++) {
/*  You have to do something here  */
    $bar->display(10);
    if ($bar->getProgress() >= 50) {
        $bar->setMessage('half done');
    }
}
$bar->setMessage('done!');
$bar->display(100,"set");

echo '<p>&lt;&lt; <a href="index.html">Back documentation</a></p>';

?>