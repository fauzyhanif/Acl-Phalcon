<?php

/**
 * Display a smaller vertical loading bar from 0 to 100% step 10% 
 * filled in natural order, with custom colors.
 * 
 * @version    $Id: progress13v.php,v 1.1 2003/08/27 18:24:48 Farell Exp $
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @package    HTML_Progress
 */

require_once 'HTML/Progress/BarVertical.php';

$p = new HTML_Page();
$p->setTitle("PEAR::HTML_Progress - Example 13");
$p->setMetaData("author", "Laurent Laville");

$options = array(
    'border-width'  => 1,
    'cell-height'   => 12,
    'cell-width'    => 7,
    'active-color'  => '#970038',
    'inactive-color'=> '#FFDDAA'
);

$bar = new HTML_Progress_Bar_Vertical('natural', $p, $options);
$text = array(
    'background-color' => '#c3c6c3',
    'height'  => 20,
    'size'    => 8,
    'h-align' => 'center'
);
$bar->setText(true, $text);

$css = $bar->getStyle();
$css->setStyle('body', 'background-color', '#c3c6c3');
$css->setStyle('body', 'font-family', 'Verdana, Arial');
$css->setStyle('a:link', 'color', '#006600');
$css->setSameStyle('a:visited, a:active', 'a:link');
$css->setStyle('div.col1', 'float', 'left');
$css->setStyle('div.col1', 'width', '25%');
$css->setStyle('div.col2', 'margin-left', '30%');
$css->setStyle('div.col2', 'border', '1px solid red');
$css->setStyle('div.col2', 'padding', '1em');
$css->setStyle('div.col2', 'height', '80%');

$p->addStyleDeclaration($css);
$p->addScriptDeclaration( $bar->getScript() );
$p->addBodyContent('<div class="col1">'.$bar->toHTML().'</div>');
$p->addBodyContent('<div class="col2">');
$p->addBodyContent('<h1>Example 13v</h1>');
$p->addBodyContent('<p><i><b>Laurent Laville, August 2003</b></i></p>');

$note = <<< TEXT
<p><i>minimal bar</i><br />
In this example we will attempt to make a progress bar (width=7px, height=12px)
that is smaller than minimal size (width=8px, height=13px)
<br />
Progress bar created will have finally a minimal size (8 x 13).</p>
TEXT;

$p->addBodyContent($note);
$p->addBodyContent('</div>');
$p->display();

for ($i=0; $i<10; $i++) {
/*  You have to do something here  */
    $bar->display(10);
}

echo '<p>&lt;&lt; <a href="index.html">Back documentation</a></p>';

?>