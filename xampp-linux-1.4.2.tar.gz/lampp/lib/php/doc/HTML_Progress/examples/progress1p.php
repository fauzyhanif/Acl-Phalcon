<?php 
/**
 * Display a horizontal loading bar with percent info, 
 * filled in natural order (left to right)
 * from 0 to 100% increase by step of 10%
 * with all default attributes (color, size, ...)
 * Default page is generated with most common options
 * and a custom title.
 * 
 * @version    $Id: progress1p.php,v 1.1 2003/09/24 22:17:29 Farell Exp $
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @package    HTML_Progress
 */

require_once ('HTML/Progress/BarHorizontal.php');

$pkg = array('PEAR', 'Archive_Tar', 'Config', 
    'HTML_QuickForm', 'HTML_CSS', 'HTML_Page', 'HTML_Template_Sigma', 
    'Log', 'MDB', 'PHPUnit');

$page = array (
    'charset'  => 'utf-8',
    'lineend'  => 'unix',
    'tab'      => '  ',
    'doctype'  => "XHTML 1.0 Strict",
    'language' => 'fr',
    'cache'    => 'true',
    'title'    => 'My ProgressBar'
);

$bar = new HTML_Progress_Bar_Horizontal();
$bar->setPage(null,$page);

for ($i=0; $i<10; $i++) {
    $bar->display(10);
    echo "installing package ... : ". $pkg[$i] ."<br /> \n";
}

echo '<p>&lt;&lt; <a href="index.html">Back documentation</a></p>';

?>