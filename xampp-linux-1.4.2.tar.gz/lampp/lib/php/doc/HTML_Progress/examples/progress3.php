<?php 
/**
 * Display a horizontal loading bar with percent info, 
 * filled in natural order (left to right)
 * from 0 to 100% increase by step of 16%
 * with custom configuration.
 * 
 * @version    $Id: progress3.php,v 1.4 2003/08/27 18:24:48 Farell Exp $
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @package    HTML_Progress
 */

require_once ('HTML/Progress/BarHorizontal.php');

$p = new HTML_Page();
$p->setTitle("PEAR::HTML_Progress - Example 3n");
$p->setMetaData("author", "Laurent Laville");

$options = array(
    'border-width'  => 1,
    'border-color'  => 'navy',
    'cell-width'    => 10,
    'active-color'  => '#3874B4',
    'inactive-color'=> '#EEEECC'
);

$bar = new HTML_Progress_Bar_Horizontal('natural', $p, $options);

$text = array(
    'width' => 60,
    'size'  => 14,
    'background-color' => '#eeeeee',  // same color as body background, make it transparent
    'h-align' => 'center',
    'v-align' => $_GET['align']   
);
$bar->setText(true, $text);

$css = $bar->getStyle();
$css->setStyle('body', 'background-color', '#eeeeee');
$css->setStyle('body', 'font-family', 'Verdana, Arial');
$css->setStyle('a:link', 'color', 'navy');
$css->setSameStyle('a:visited, a:active', 'a:link');
$css->setStyle('div.col1', 'float', 'left');
$css->setStyle('div.col1', 'width', '25%');
$css->setStyle('div.col2', 'margin-left', '30%');
$css->setStyle('div.col2', 'border', '1px solid red');
$css->setStyle('div.col2', 'padding', '1em');
$css->setStyle('div.col2', 'height', '80%');

$p->addStyleDeclaration($css);
$p->addScriptDeclaration( $bar->getScript() );
$p->addBodyContent('<div class="col1">'.$bar->toHTML().'</div>');
$p->addBodyContent('<div class="col2">');
$p->addBodyContent('<h1>Example 3 natural</h1>');
$p->addBodyContent('<p><i><b>Laurent Laville, August 2003</b></i></p>');

$note = <<< TEXT
<p>Usage of property <b>v-align</b> into attributes parameter of API setText.</p>
TEXT;

$p->addBodyContent($note);
$p->addBodyContent('<p><a href="progress3.php?align=top">Top</a></p>');
$p->addBodyContent('<p><a href="progress3.php?align=bottom">Bottom</a></p>');
$p->addBodyContent('<p><a href="progress3.php?align=left">Left</a></p>');
$p->addBodyContent('<p><a href="progress3.php?align=right">Right (default)</a></p>');
$p->addBodyContent('</div>');
$p->display();

for ($i=0; $i<10; $i++) {
/*  You have to do something here  */
    $bar->display(16);
}

echo '<p>&lt;&lt; <a href="index.html">Back documentation</a></p>';

?>