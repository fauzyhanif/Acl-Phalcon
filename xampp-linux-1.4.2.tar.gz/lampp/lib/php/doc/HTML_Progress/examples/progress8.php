<?php 
/**
 * Display a horizontal loading bar with percent info, 
 * filled in natural order (left to right)
 * from 0 to 100% increase by step of 10%
 * with default colors.
 * Text will be display on each sides of progress bar.
 * 
 * @version    $Id: progress8.php,v 1.2 2003/08/27 18:25:02 Farell Exp $
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @package    HTML_Progress
 */

require_once ('HTML/Progress/BarHorizontal.php');

	
$p = new HTML_Page();
$p->setTitle("PEAR::HTML_Progress - Example 8");
$p->setMetaData("author", "Laurent Laville");


$bar = new HTML_Progress_Bar_Horizontal('natural', $p);

$text = array(
    'size'  => 14, 
    'text'  => '%', 
    'width' => 60, 
    'color' => 'white', 
    'background-color' => '#444444',
    'h-align' => 'center',
    'v-align' => $_GET['align']
);
if ($text['v-align'] == 'top' || $text['v-align'] == 'bottom') {
    $text['width'] = 172;  // size of progress bar = 10*(cell-width + cell-spacing) + cell-spacing
}
$bar->setText(true, $text);

$css = $bar->getStyle();
$css->setStyle('body', 'background-color', '#444444');
$css->setStyle('body', 'color', 'white');
$css->setStyle('body', 'font-family', 'Verdana, Arial');
$css->setStyle('a:link', 'color', 'yellow');
$css->setSameStyle('a:visited, a:active', 'a:link');
$css->setStyle('div.col1', 'float', 'left');
$css->setStyle('div.col1', 'width', '25%');
$css->setStyle('div.col2', 'margin-left', '30%');
$css->setStyle('div.col2', 'border', '3px solid silver');
$css->setStyle('div.col2', 'padding', '1em');
$css->setStyle('div.col2', 'height', '80%');

$p->addStyleDeclaration($css);
$p->addScriptDeclaration( $bar->getScript() );
$p->addBodyContent('<div class="col1">'.$bar->toHTML().'</div>');
$p->addBodyContent('<div class="col2">');
$p->addBodyContent('<h1>Example 8</h1>');
$p->addBodyContent('<p><i><b>Laurent Laville, August 2003</b></i></p>');

$note = <<< TEXT
<p>Usage of property <b>v-align</b> (top, bottom, left, right) into attributes parameter of API setText.</p>
<p>Look out the percent info legend will be shown on each sides of progress bar.</p>
TEXT;

$p->addBodyContent($note);
$p->addBodyContent('<p><a href="progress8.php?align=top">Top</a></p>');
$p->addBodyContent('<p><a href="progress8.php?align=bottom">Bottom</a></p>');
$p->addBodyContent('<p><a href="progress8.php?align=left">Left</a></p>');
$p->addBodyContent('<p><a href="progress8.php?align=right">Right (default)</a></p>');
$p->addBodyContent('</div>');
$p->display();

for ($i=0; $i<10; $i++) {
/*  You have to do something here  */
    $bar->display(10);
}

echo '<p>&lt;&lt; <a href="index.html">Back documentation</a></p>';

?>