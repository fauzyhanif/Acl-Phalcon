<?php

/**
 * Display a vertical loading bar set to 20% 
 * filled in natural order, with default colors.
 * 
 * @version    $Id: progress9.php,v 1.3 2003/08/27 18:25:02 Farell Exp $
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @package    HTML_Progress
 */

require_once 'HTML/Progress/BarVertical.php';

$bar = new HTML_Progress_Bar_Vertical();
$text = array(
    'width'   => 60,
    'height'  => 10,
    'h-align' => 'left',
);
$bar->setText(true, $text);
$bar->display(20,"set");

echo '<h1>Example 9</h1>';
echo '<p><i><b>Laurent Laville, August 2003</b></i></p>';
echo '<br /><hr noshade />';
echo '<p>&lt;&lt; <a href="index.html">Back documentation</a></p>';

?>