<?php
// +----------------------------------------------------------------------+
// | PHP Version 4                                                        |
// +----------------------------------------------------------------------+
// | Copyright (c) 1997-2003 The PHP Group                                |
// +----------------------------------------------------------------------+
// | This source file is subject to version 3.0 of the PHP license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available at through the world-wide-web at                           |
// | http://www.php.net/license/3_0.txt.                                  |
// | If you did not receive a copy of the PHP license and are unable to   |
// | obtain it through the world-wide-web, please send a note to          |
// | license@php.net so we can mail you a copy immediately.               |
// +----------------------------------------------------------------------+
// | Author: Laurent Laville <pear@laurent-laville.org>                   |
// +----------------------------------------------------------------------+
//
// $Id: Progress.php,v 1.14 2003/09/24 22:04:09 Farell Exp $

/**
 * The HTML_Progress class allow you to add a loading bar
 * to any of your xhtml document.
 * You should have a browser that accept DHTML feature.
 *
 * @version    0.6.2
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @access     public
 * @package    HTML_Progress
 * @category   HTML
 * @license    http://www.php.net/license/3_0.txt  PHP License 3.0
 */

require_once ('HTML/CSS.php');
require_once ('HTML/Page.php');

/**#@+
 * Progress Bar shape types
 *
 * @var        integer
 * @since      0.6
 */
define ('HTML_PROGRESS_BAR_HORIZONTAL', 1);
define ('HTML_PROGRESS_BAR_VERTICAL',   2);
/**#@-*/

class HTML_Progress {

    /**
     * Current progress value 
     *
     * @var        integer
     * @since      0.2
     * @access     public
     */
    var $progress;

    /**
     * Progress_Bar main properties
     *
     * <ul>
     * <li>since 0.1 : 'width'    =  bar width
     * <li>since 0.1 : 'height'   =  bar height
     * <li>since 0.1 : 'bgcolor'  =  bar background color
     * <li>since 0.5 : 'way'      =  bar way 
     *   <ul>
     *     <li>with Progress Bar Horizontal, 
     *              natural way is : left to right
     *        <br />reverse way is : right to left
     *     <li>with Progress Bar Vertical, 
     *              natural way is : down to up
     *        <br />reverse way is : up to down
     *   </ul>
     * <li>since 0.6 : 'scale'    =  bar scale
     * </ul>
     *
     * @var        array
     * @since      0.6
     * @access     public
     */
    var $bar = array();

    /**
     * Progress_Bar border properties
     *
     * - since 0.1 : 'width'    =  border width
     * - since 0.1 : 'style'    =  border style
     * - since 0.1 : 'color'    =  border color
     *
     * @var        array
     * @since      0.1
     * @access     public
     */
    var $bar_border = array();

    /**
     * Progress_Bar cell properties
     *
     * - since 0.1 : 'width'    =  width
     * - since 0.1 : 'height'   =  height
     * - since 0.1 : 'active'   =  active color
     * - since 0.1 : 'inactive' =  inactive color
     * - since 0.1 : 'spacing'  =  cell spacing
     * - since 0.6 : 'color'    =  foreground color
     * - since 0.6 : 'size'     =  font size
     *
     * @var        array
     * @since      0.6
     * @access     public
     */
    var $bar_cell = array();

    /**
     * Progress_Bar text properties
     *
     * - since 0.1 : 'font'     =  font family
     * - since 0.1 : 'size'     =  font size
     * - since 0.1 : 'color'    =  font color
     * - since 0.2 : 'visible'  =  show or hide the progress info area
     * - since 0.6 : 'width'    =  with of progress info area
     * - since 0.6 : 'height'   =  height of progress info area
     * - since 0.6 : 'bgcolor'  =  background color
     * - since 0.6 : 'text'     =  unit (%, s., ...)
     * - since 0.6 : 'valign'   =  vertical align  (top, bottom, left, right)
     * - since 0.6 : 'halign'   =  horizontal align  (left, center, right, justify)
     *
     * @var        array
     * @since      0.6
     * @access     public
     */
    var $bar_text = array();
 
    /**
     * Progress_Bar message properties
     *
     * - since 0.6 : 'visible'  =  show or hide the message area
     * - since 0.6 : 'width'    =  with of message area
     * - since 0.6 : 'font'     =  font family
     * - since 0.6 : 'size'     =  font size
     * - since 0.6 : 'color'    =  font color
     * - since 0.6 : 'bgcolor'  =  background color
     * - since 0.6 : 'valign'   =  vertical align  (top, bottom)
     * - since 0.6 : 'halign'   =  horizontal align  (left, center, right, justify)
     *
     * @var        array
     * @since      0.6
     * @access     public
     */
    var $bar_message = array();

    /**
     * External Javascript file to override internal default code
     *
     * @var        string
     * @since      0.5.0
     * @access     public
     */
    var $script;

    /**
     * Page where progress bar is included
     *
     * @var        object
     * @since      0.1
     * @access     private
     */
    var $_page;
  
    /**
     * Contains the line end string
     *
     * @var        string
     * @since      0.2
     * @access     private
     */
    var $_lineEnd;

    /**
     * Shape identifier of Progress Bar
     *
     * @var        int
     * @since      0.5.0
     * @access     private
     * @see        HTML_PROGRESS_BAR_HORIZONTAL, HTML_PROGRESS_BAR_VERTICAL
     */
    var $_progress_shape;


    /**
     * Class constructor
     *
     * @param      mixed     $self          (optional) Progress Bar is integrated on existing HTML Page
     * @param      array     $attributes    (optional) Associative array of HTML tag attributes
     * @param      mixed     $script        (optional) URL to the linked Progress JavaScript            
     *
     * @since      0.1
     * @access     public
     */
    function HTML_Progress($self = null, $attributes = array(), $script = null)
    {
        // Define Line End string
        $style = (OS_WINDOWS) ? 'win' : 'unix';
        HTML_Common::setLineEnd($style);
        $this->_lineEnd = HTML_Common::_getLineEnd();
        
        $this->setPage($self, $attributes); 

        /*
         - since version 0.5.0,
         - default javascript code comes from getScript() method
         - may be overrided by external file. 
        */
        $this->script = $script;
        
        // Apply default bar styles
        $this->bar['width']   = $attributes['width'];
        $this->bar['height']  = $attributes['height'];
        $this->bar['bgcolor'] = isset($attributes['background-color']) ? $attributes['background-color'] : "white";
        
        $this->bar_border['width'] = isset($attributes['border-width']) ? $attributes['border-width'] : "0";
        $this->bar_border['style'] = isset($attributes['border-style']) ? $attributes['border-style'] : "solid";
        $this->bar_border['color'] = isset($attributes['border-color']) ? $attributes['border-color'] : "black";
        
        // Apply default cell styles
        $this->bar_cell['width']    = $attributes['cell-width'];
        $this->bar_cell['height']   = $attributes['cell-height'];
        $this->bar_cell['spacing']  = $attributes['cell-spacing'];
        $this->bar_cell['active']   = isset($attributes['active-color']) ? $attributes['active-color'] : "#006600";
        $this->bar_cell['inactive'] = isset($attributes['inactive-color']) ? $attributes['inactive-color'] : "#CCCCCC";
        $this->setCell();

        // Apply default percent text styles
        $this->bar['scale'] = isset($attributes['scale']) ? $attributes['scale'] : "100";
        $this->setText();

        // Apply default message styles
        $this->setMessageLine();
        $this->setMessage();

        // to fix a potential php config problem with PHP 4.2.0 : turn 'implicit_flush' ON
        ob_implicit_flush(1);
    }

    /**
     * Returns the current API version
     *
     * @return     float
     * @since      0.1
     * @access     public
     */
    function apiVersion()
    {
        return 0.6;
    }

    /**
     * Define or create a new XHTML page
     *
     * @param      mixed     $self          (optional) Progress Bar is integrated on existing HTML Page
     * @param      mixed     $attributes    (optional) Associative array of table tag attributes
     *
     * @return     void
     * @since      0.6
     * @access     public
     */
    function setPage($self, $attributes = array())
    {
        if ( is_object($self) &&
            (get_class($self) == 'html_page' || is_subclass_of($self, 'html_page'))) {
            $this->_page = $self; 
        } else {
            $this->_page = new HTML_Page($attributes);
            if (isset($attributes['title'])) {
            	$this->_page->setTitle($attributes['title']);
            }
        }
    }

    /**
     * Returns current percent number of progress bar
     *
     * @return     integer                  percent number
     * @since      0.2
     * @access     public
     */
    function getProgress()
    {
        return $this->progress;
    }

    /**
     * Define look and feel of percent text info in progress bar
     *
     * @param      boolean   $visible       (optional) show or hide the percent text info tag
     * @param      array     $attributes    (optional) Associative array of HTML tag attributes
     *
     * @return     void
     * @since      0.1
     * @access     public
     */
    function setText($visible = false, $attributes = array())
    {
        $this->bar_text['visible'] = $visible;
        
        if ($visible) {
            if (isset($attributes['height'])) {
                $this->bar_text['height'] = $attributes['height'];
            } else {
                $this->bar_text['height'] = $this->bar['height'] + 2*$this->bar_border['width'];
            }
            $this->bar_text['width']   = isset($attributes['width']) ? $attributes['width'] : $this->bar['width'];
            $this->bar_text['font']    = isset($attributes['font']) ? $attributes['font'] : "Verdana, Arial, Helvetica, sans-serif";
            $this->bar_text['size']    = isset($attributes['size']) ? $attributes['size'] : "12";
            $this->bar_text['color']   = isset($attributes['color']) ? $attributes['color'] : "black";
            $this->bar_text['bgcolor'] = isset($attributes['background-color']) ? $attributes['background-color'] : "white";
            $this->bar_text['text']    = isset($attributes['text']) ? $attributes['text'] : "%";

            if (isset($attributes['v-align'])) {
            	$this->bar_text['valign'] = $attributes['v-align'];
            } else {
                if ($this->_progress_shape == HTML_PROGRESS_BAR_HORIZONTAL) {
                    $this->bar_text['valign'] = "right";
                }
                if ($this->_progress_shape == HTML_PROGRESS_BAR_VERTICAL) {
                    $this->bar_text['valign'] = "bottom";
                }
            }
            $this->bar_text['halign'] = isset($attributes['h-align']) ? $attributes['h-align'] : "right";
        }
    }

    /**
     * Display a message on side (top, bottom) of progress bar.
     *
     * @param      mixed     $text          (optional) message contents
     *
     * @return     void
     * @since      0.6
     * @access     public
     */
    function setMessage($text = null)
    {
        $this->bar_message['text'] = $text;
    }

    /**
     * Set line definition of Progress Bar message area.
     *
     * @param      boolean   $visible       (optional) show or hide the message bar area
     * @param      array     $attributes    (optional) Associative array of HTML tag attributes
     *
     * @return     void
     * @since      0.6
     * @access     public
     */
    function setMessageLine($visible = false, $attributes = array())
    {
        $this->bar_message['visible'] = $visible;
        
        if ($visible) {
            $this->bar_message['width']   = isset($attributes['width']) ? $attributes['width'] : $this->bar['width'];
            $this->bar_message['font']    = isset($attributes['font']) ? $attributes['font'] : "Verdana, Arial, Helvetica, sans-serif";
            $this->bar_message['size']    = isset($attributes['size']) ? $attributes['size'] : "12";
            $this->bar_message['color']   = isset($attributes['color']) ? $attributes['color'] : "black";
            $this->bar_message['bgcolor'] = isset($attributes['background-color']) ? $attributes['background-color'] : "white";
            $this->bar_message['valign']  = isset($attributes['v-align']) ? $attributes['v-align'] : "bottom";
            $this->bar_message['halign']  = isset($attributes['h-align']) ? $attributes['h-align'] : "left";
        }
    }

    /**
     * Define look and feel of text inside each cell of progress bar
     *
     * @param      int       $position      (optional) cell position(s), relative to progress way 
     * @param      array     $attributes    (optional) Associative array of HTML tag attributes
     *
     * @return     void
     * @since      0.6
     * @access     public
     */
    function setCell($range = array(), $attributes = array())
    {
        $this->_defaultCell = (count($range) == 0 && count($attributes) == 0) ? true : false;

        if (count($range) == 0) {
            $range = range(0,9);   // all cell by default
        }
        $margin = ($this->_progress_shape == HTML_PROGRESS_BAR_HORIZONTAL) ? 0 : 3;
        
        foreach ($range as $position) {
            $this->bar_cell['color'][$position] = isset($attributes['color']) ? $attributes['color'] : "black";

            if (isset($attributes['size']) && 
               ($attributes['size'] <= min($this->bar_cell['width'],$this->bar_cell['height'])- $margin)) {
                $this->bar_cell['size'][$position] = $attributes['size'];
            } else {
                $this->bar_cell['size'][$position] = min($this->bar_cell['width'],$this->bar_cell['height']) - $margin;
	    }
        }
    }

    /**
     * Generates and returns the complete Progress Bar as a string
     *
     * @return     string                   HTML Progress bar
     * @since      0.2
     * @access     public
     */
    function toHTML()
    {
        $bar = "";
            
        if ( (($this->_progress_shape == HTML_PROGRESS_BAR_HORIZONTAL) && ($this->bar['way'] == 'reverse')) ||
           (($this->_progress_shape == HTML_PROGRESS_BAR_VERTICAL) && ($this->bar['way'] == 'natural')) ) {

            if ($this->_progress_shape == HTML_PROGRESS_BAR_HORIZONTAL) {
                $pos = $this->bar_cell['spacing'];
                for ($i=9; $i>=0; $i--) {
                    $bar .= $this->_lineEnd;
                    $bar .= "<div id=\"progressCell".$i."i\" class=\"cell0\" style=\"position:absolute;top:".$this->bar_cell['spacing']."px;left:".$pos."px\">&nbsp;</div>";
                    $pos += ($this->bar_cell['width'] + $this->bar_cell['spacing']);
                }
                $pos = $this->bar_cell['spacing'];
                for ($i=9; $i>=0; $i--) {
                    $bar .= $this->_lineEnd;
                    $bar .= "<div id=\"progressCell".$i."a\" class=\"cell1\" style=\"position:absolute;top:".$this->bar_cell['spacing']."px;left:".$pos."px\">&nbsp;</div>";
                    $pos += ($this->bar_cell['width'] + $this->bar_cell['spacing']);
                }
            }

            if ($this->_progress_shape == HTML_PROGRESS_BAR_VERTICAL) {
                $pos = $this->bar_cell['spacing'];
                for ($i=9; $i>=0; $i--) {
                    $bar .= $this->_lineEnd;
                    $bar .= "<div id=\"progressCell".$i."i\" class=\"cell0\" style=\"position:absolute;left:".$this->bar_cell['spacing']."px;top:".$pos."px\">&nbsp;</div>";
                    $pos += ($this->bar_cell['height'] + $this->bar_cell['spacing']);
                }
                $pos = $this->bar_cell['spacing'];
                for ($i=9; $i>=0; $i--) {
                    $bar .= $this->_lineEnd;
                    $bar .= "<div id=\"progressCell".$i."a\" class=\"cell1\" style=\"position:absolute;left:".$this->bar_cell['spacing']."px;top:".$pos."px\">&nbsp;</div>";
                    $pos += ($this->bar_cell['height'] + $this->bar_cell['spacing']);
                }
            }

        } else {

            if ($this->_progress_shape == HTML_PROGRESS_BAR_HORIZONTAL) {
                $pos = $this->bar_cell['spacing'];
                for ($i=0; $i<10; $i++) {
                    $bar .= $this->_lineEnd;
                    $bar .= "<div id=\"progressCell".$i."i\" class=\"cell0\" style=\"position:absolute;top:".$this->bar_cell['spacing']."px;left:".$pos."px\">&nbsp;</div>";
                    $pos += ($this->bar_cell['width'] + $this->bar_cell['spacing']);
                }
                $pos = $this->bar_cell['spacing'];
                for ($i=0; $i<10; $i++) {
                    $bar .= $this->_lineEnd;
                    $bar .= "<div id=\"progressCell".$i."a\" class=\"cell1\" style=\"position:absolute;top:".$this->bar_cell['spacing']."px;left:".$pos."px\">&nbsp;</div>";
                    $pos += ($this->bar_cell['width'] + $this->bar_cell['spacing']);
                }
            }

            if ($this->_progress_shape == HTML_PROGRESS_BAR_VERTICAL) {
                $pos = $this->bar_cell['spacing'];
                for ($i=0; $i<10; $i++) {
                    $bar .= $this->_lineEnd;
                    $bar .= "<div id=\"progressCell".$i."i\" class=\"cell0\" style=\"position:absolute;left:".$this->bar_cell['spacing']."px;top:".$pos."px\">&nbsp;</div>";
                    $pos += ($this->bar_cell['height'] + $this->bar_cell['spacing']);
                }
                $pos = $this->bar_cell['spacing'];
                for ($i=0; $i<10; $i++) {
                    $bar .= $this->_lineEnd;
                    $bar .= "<div id=\"progressCell".$i."a\" class=\"cell1\" style=\"position:absolute;left:".$this->bar_cell['spacing']."px;top:".$pos."px\">&nbsp;</div>";
                    $pos += ($this->bar_cell['height'] + $this->bar_cell['spacing']);
                }
            }
        }

        /**
         *  Progress Bar (3) alignment rules:
         *  - text legend/number area (1)
         *  - message area            (2)
         *
         *  +---------------------------------------+
         *  |         +m1---+                       |
         *  |         | (2) |                       |
         *  |         +-----+                       |
         *  |         +t1---+                       |
         *  |         | (1) |                       |
         *  |         +-----+                       |
         *  | +t2---+ +-------------------+ +t3---+ |
         *  | | (1) | | | | | (3) | | | | | | (1) | |
         *  | +-----+ +-------------------+ +-----+ |
         *  |         +t4---+                       |
         *  |         | (1) |                       |
         *  |         +-----+                       |
         *  |         +m2---+                       |
         *  |         | (2) |                       |
         *  |         +-----+                       |
         *  +---------------------------------------+
         */ 
        $info  = "<div id=\"installationProgress\" style=\"position:relative;left:0px;top:0px\">";
        $info .= "&nbsp;</div>";
        $message  = "<div id=\"progressMessage\">&nbsp;</div>";;

        $str = "";
        
        // m1 - message rule
        if ($this->bar_message['visible']) {
            if ($this->bar_message['valign'] == 'top') {
                $str = $this->_lineEnd . $message;
            }
        }

        // t1 - text rule
        if ($this->bar_text['visible'] && $this->bar_text['valign'] == 'top') {
            $str .= $this->_lineEnd . $info;
        }       

        // t2 - text rule
        if ($this->bar_text['visible'] && $this->bar_text['valign'] == 'left') {
            $str .= $this->_lineEnd . $info;
            $str .= $this->_lineEnd ."<div class=\"progressBarBorder\" ";
            $str .= "style=\"position:relative;left:".$this->bar_text['width']."px;top:-".$this->bar_text['height']."px\">";
            $str .= $this->_lineEnd ."<div class=\"progressBar\" style=\"position:relative;left:0px;top:0px\">";
        } else {
            $str .= $this->_lineEnd ."<div class=\"progressBarBorder\" style=\"position:relative;left:0px;top:0px\">";
            $str .= $this->_lineEnd ."<div class=\"progressBar\" style=\"position:relative;left:0px;top:0px\">";
        }
        $str .= $this->_lineEnd . $bar;
        $str .= $this->_lineEnd ."</div>";
        $str .= $this->_lineEnd ."</div>";

        // t3 - text rule
        if ($this->bar_text['visible'] && $this->bar_text['valign'] == 'right') {
            $info  = "<div id=\"installationProgress\" ";
            if ($this->bar_border['width'] == 0) {
                $info .= "style=\"position:relative;left:".$this->bar['width']."px;top:-".$this->bar['height']."px\">";
            } else {
                $info .= "style=\"position:relative;left:".($this->bar['width']+2*$this->bar_border['width'])."px;top:-".($this->bar['height']+2*$this->bar_border['width'])."px\">";
            }
            $info .= "&nbsp;</div>";
            $str .= $this->_lineEnd . $info;
        }       

        // t4 - text rule
        if ($this->bar_text['visible'] && $this->bar_text['valign'] == 'bottom') {
            $str .= $this->_lineEnd . $info;
        }       

        // m2 - message rule
        if ($this->bar_message['visible']) {
            if ($this->bar_message['valign'] == 'bottom') {
                $str .= $this->_lineEnd . $message;
            }
        }
        $str .= $this->_lineEnd;

        return $str;
    }

    /**
     * Display progress_bar in current html page
     *
     * @param      integer   $progress      percent step to add, or percent info to set to progress bar
     * @param      string    $method        (optional) method to increase progress bar ('add' or 'set')
     *
     * @return     void
     * @since      0.2
     * @access     public
     */
    function display($progress, $method = "add")
    {
        if (!isset($this->progress) && !headers_sent()) {
            $css = $this->getStyle();
            $this->_page->addStyleDeclaration($css);

            if (!is_null($this->script) && file_exists($this->script)) {
                $this->_page->addScript($this->script);
            } else {
                $script = $this->getScript();
                $this->_page->addScriptDeclaration($script);
            }
            $this->_page->addBodyContent($this->toHTML());
            $this->_page->display();
            $this->progress = 0;
        }

        $method = strtolower($method);

        switch ($method) {
         case 'add':
         case 'set':
             $bar  = ob_get_clean();
             $bar .= $this->_lineEnd;
             if ($method == 'add') {
                 $this->progress += $progress;
                 $bar .= '<script type="text/javascript">self.addprogress('.((int) $progress).'); </script>';
             } else {
                 $this->progress  = $progress;
                 $bar .= '<script type="text/javascript">self.setprogress('.((int) $progress).'); </script>';
             }
             if (!is_null($this->bar_message['text'])) {
                 $bar .= '<script type="text/javascript">self.setmessage("'.$this->bar_message['text'].'"); </script>';
             }
             sleep(1);
             echo $bar;
             ob_start();
             break;
         default:
        }
    }

    /**
     * Get the custom styles sheet to put inline on HTML document
     *
     * @return     object                   HTML_CSS instance
     * @since      0.2
     * @access     public
     * @author     Stefan Neufeind <pear.neufeind@speedpartner.de> Contributor.
     *             See details on thanks section of README file.
     */
    function &getStyle()
    {
        $css = new HTML_CSS();

        $css->setStyle('.progressBar', 'background-color', $this->bar['bgcolor']);
        $css->setStyle('.progressBar', 'width', $this->bar['width'].'px');
        $css->setStyle('.progressBar', 'height', $this->bar['height'].'px');

        $css->setSameStyle('.progressBarBorder', '.progressBar');
        $css->setStyle('.progressBarBorder', 'border-width', $this->bar_border['width'].'px');
        $css->setStyle('.progressBarBorder', 'border-style', $this->bar_border['style']);
        $css->setStyle('.progressBarBorder', 'border-color', $this->bar_border['color']);

        if ($this->bar_text['visible']) {
            $css->setStyle('#installationProgress', 'width', $this->bar_text['width'].'px');
            $css->setStyle('#installationProgress', 'height', $this->bar_text['height'].'px');
            $css->setStyle('#installationProgress', 'text-align', $this->bar_text['halign']);
            $css->setStyle('#installationProgress', 'font-family', $this->bar_text['font']);
            $css->setStyle('#installationProgress', 'font-size', $this->bar_text['size'].'px');
            $css->setStyle('#installationProgress', 'color', $this->bar_text['color']);
            $css->setStyle('#installationProgress', 'background-color', $this->bar_text['bgcolor']);
        } else {
            $css->setStyle('#installationProgress', 'visibility', 'hidden');
        }

        if ($this->bar_message['visible']) {
            $css->setStyle('#progressMessage', 'width', $this->bar_message['width'].'px');
            $css->setStyle('#progressMessage', 'text-align', $this->bar_message['halign']);
            $css->setStyle('#progressMessage', 'font-family', $this->bar_message['font']);
            $css->setStyle('#progressMessage', 'font-size', $this->bar_message['size'].'px');
            $css->setStyle('#progressMessage', 'color', $this->bar_message['color']);
            $css->setStyle('#progressMessage', 'background-color', $this->bar_message['bgcolor']);
        }

        $css->setStyle('.cell0', 'width', $this->bar_cell['width'].'px');
        $css->setStyle('.cell0', 'height', $this->bar_cell['height'].'px');

        if ($this->_progress_shape == HTML_PROGRESS_BAR_HORIZONTAL) {
            $css->setStyle('.cell0', 'float', 'left'); 
        }
        if ($this->_progress_shape == HTML_PROGRESS_BAR_VERTICAL) {
            $css->setStyle('.cell0', 'float', 'none'); 
        }
        $css->setSameStyle('.cell1', '.cell0');

        $css->setStyle('.cell0', 'background-color', $this->bar_cell['inactive']);
        $css->setStyle('.cell1', 'background-color', $this->bar_cell['active']);
        $css->setStyle('.cell1', 'visibility', 'hidden');

        if ($this->_defaultCell) {
            $css->setStyle('.cell1', 'font-family', 'Courier');
            $css->setStyle('.cell1', 'font-size', $this->bar_cell['size'][0].'px');
            $css->setStyle('.cell0', 'font-family', 'Courier');
            $css->setStyle('.cell0', 'font-size', $this->bar_cell['size'][0].'px');
        } else {
            for ($i=0; $i<10; $i++) {
                $css->setStyle('#progressCell'.$i.'a', 'font-family', 'Courier');
                $css->setStyle('#progressCell'.$i.'a', 'font-size', $this->bar_cell['size'][$i].'px');
                $css->setStyle('#progressCell'.$i.'a', 'color', $this->bar_cell['color'][$i]);
                $css->setSameStyle('#progressCell'.$i.'i', '#progressCell'.$i.'a');
            }
        }

        return $css;
    }

    /**
     * Get the default javascript code to manage progress bar.
     *
     * @return     string                   JavaScript code to manage progress bar
     * @since      0.5
     * @access     public
     * @author     Stefan Neufeind <pear.neufeind@speedpartner.de> Contributor.
     *             See details on thanks section of README file.
     * @author     Christian Wenz <wenz@php.net> Helper.
     *             See details on thanks section of README file.
     */
    function getScript()
    {
        $js = <<< JS
var isDom = document.getElementById?true:false;
var isIE  = document.all?true:false;
var isNS4 = document.layers?true:false;

var progress;
progress = 0;

function setprogress(value)
{
	progress = value;

        if (isDom)
            prog = document.getElementById('installationProgress');
        if (isIE)
            prog = document.all['installationProgress'];
        if (isNS4)
            prog = document.layers['installationProgress'];

	if (prog != null) prog.innerHTML = progress + " %";
	progress2 = Math.floor(progress / 10);
	for (i=progress2-1; i >= 0; i--) {
            if (isDom)
                document.getElementById('progressCell'+i+'a').style.visibility = "visible";
            if (isIE)
                document.all['progressCell'+i+'a'].style.visibility = "visible";
            if (isNS4)
                document.layers['progressCell'+i+'a'].style.visibility = "visible";
        }
}

function addprogress(value)
{
        progress += value;
        if (progress > 100) {
            setprogress(100);
        } else {
            setprogress(progress);
        }
}

function setmessage(value)
{
        if (isDom)
            document.getElementById('progressMessage').innerHTML = value;
        if (isIE)
            document.all['progressMessage'].innerHTML = value;
        if (isNS4)
            document.layers['progressMessage'].innerHTML = value;
}
JS;
        if ($this->bar['scale'] != "100") {
            // change default bar scale
            $js = str_replace("100", $this->bar['scale']*10, $js);
            $js = str_replace("/ 10", "/ ".$this->bar['scale'], $js);
        }
        if ($this->bar_text['visible']) {
            if ($this->bar_text['text'] != "%") {
                // change default text legend
                $js = str_replace("%", $this->bar_text['text'], $js);
            }
        }

        return $js;
    }

}

?>