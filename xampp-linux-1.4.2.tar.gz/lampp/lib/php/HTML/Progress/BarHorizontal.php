<?php
// +----------------------------------------------------------------------+
// | PHP Version 4                                                        |
// +----------------------------------------------------------------------+
// | Copyright (c) 1997-2003 The PHP Group                                |
// +----------------------------------------------------------------------+
// | This source file is subject to version 3.0 of the PHP license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available at through the world-wide-web at                           |
// | http://www.php.net/license/3_0.txt.                                  |
// | If you did not receive a copy of the PHP license and are unable to   |
// | obtain it through the world-wide-web, please send a note to          |
// | license@php.net so we can mail you a copy immediately.               |
// +----------------------------------------------------------------------+
// | Author: Laurent Laville <pear@laurent-laville.org>                   |
// +----------------------------------------------------------------------+
//
// $Id: BarHorizontal.php,v 1.8 2003/09/24 22:04:21 Farell Exp $

require_once ('HTML/Progress.php');

/**
 * The HTML_Progress class allow you to add a horizontal loading bar
 * to any of your xhtml document.
 * You should have a browser that accept DHTML feature.
 *
 * @version    0.6.2
 * @author     Laurent Laville <pear@laurent-laville.org>
 * @access     public
 * @package    HTML_Progress
 * @category   HTML
 * @license    http://www.php.net/license/3_0.txt  PHP License 3.0
 */

class HTML_Progress_Bar_Horizontal extends HTML_Progress {

    /**
     * Class constructor
     *
     * @param      string    $way           (optional) Progress Bar filled from left to right or reverse.
     * @param      mixed     $self          (optional) Progress Bar is integrated on HTML Page (current)
     * @param      array     $attributes    (optional) Associative array of HTML tag attributes
     * @param      mixed     $script        (optional) URL to the linked Progress JavaScript            
     *
     * @since      0.5.0
     * @access     public
     */
    function HTML_Progress_Bar_Horizontal($way = 'natural', $self = null, $attributes = array(), $script = null)
    {
        $this->_progress_shape = HTML_PROGRESS_BAR_HORIZONTAL;

        $attribs = $attributes;

        if (!isset($attributes['cell-width'])) {
            $attribs['cell-width'] = 15;         // default cell width if not specified
        } elseif ($attribs['cell-width'] < 8) {
            $attribs['cell-width'] = 8;          // min cell width
        }
        if (!isset($attributes['cell-height'])) {
            $attribs['cell-height'] = 20;        // default cell height if not specified
        } elseif ($attribs['cell-height'] < 13) {
            $attribs['cell-height'] = 13;        // min cell height
        }
        if (!isset($attributes['cell-spacing'])) {
            $attribs['cell-spacing'] = 2;
        }
        if (!isset($attributes['width'])) {
            $attribs['width'] = 10*($attribs['cell-width']+$attribs['cell-spacing']) + $attribs['cell-spacing'];
        }
        if (!isset($attributes['height'])) {
            $attribs['height'] = $attribs['cell-height'] + 2*$attribs['cell-spacing'];
        }
        
        if ((strtolower($way) != 'natural') && (strtolower($way) != 'reverse')) {
            $this->bar['way'] = 'natural';
        } else {
            $this->bar['way'] = strtolower($way);
        }

        parent::HTML_Progress($self, $attribs, $script);
    }

}

?>