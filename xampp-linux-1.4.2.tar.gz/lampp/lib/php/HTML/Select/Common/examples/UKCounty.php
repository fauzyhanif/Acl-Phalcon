<?php
    include('HTML/Select/Common/UKCounty.php');

    $c = new HTML_Select_Common_UKCounty();
?>

<html>
<body>
    <?=$c->toHTML('county')?>
</body>
</html>
