<?php
$ret="";
mysql_connect("localhost","webkeu","keu3375");
mysql_select_db("session2");
$Q="mysql_query";
$R="mysql_fetch_row";

$keu_thn="2010";
$keu_ses_id="1010";

unset($a0);
$A=$Q("select kode_byr, nomor_test, jml_byr  from xocp_akd_keu_trnsctdtl
  where org_id='1' and btl_ind='0' and keu_thn='$keu_thn' and keu_ses_id='$keu_ses_id'
  #group by kode_byr
");
while (list($f0,$f1,$f2)=$R($A)) {
  if ("$f0"=="5003011" or "$f0"=="5003012" or "$f0"=="5003021" or "$f0"=="5003022" or "$f0"=="5003031") { $f0="5003"; } else {
    if ("$f0"=="5004011" or "$f0"=="5004021" or "$f0"=="5004031" or "$f0"=="5004041") { $f0="5004"; } else {
    }
  }
  $a0[$f1][$f0]=$f2;
  //$ret.=$f0."<br>";
}

//$ret.=count($a0);
foreach ($a0 as $k0 => $n0) {
  
}

echo("select nama from xocp_akd_mhs 
  where org_id='1' and nomor_test in (".implode(",",$a1).")
");
while (list($f0)=$R($A)) {
  $ret.=$f0."<br>";
}

echo $ret;
?>
