<?php
//mysql_connect("localhost","root","");

$spp = array("2001" => 500000,"2002" => 600000);
$defcol = array(
             array("NOMAH","C",15),
             array("NAMAMAH","C",25),
             array("NOREK","C",10),
             array("BIAYA1","N",10,2),
             array("BIAYA2","N",10,2),
             array("BIAYA3","N",10,2),
             array("BIAYA4","N",10,2),
             array("BIAYA5","N",10,2)
          );
$sql = "SELECT p.ps_ext_id,m.nomhs,m.nama_mhs,m.angkatan,a.account_no FROM xocp_akd_mhs m "
     . " LEFT JOIN xocp_akd_mhs_account a USING (nomhs) "
     . " LEFT JOIN xocp_akd_ps p ON m.psmhs_id = p.ps_id "
     . "WHERE m.angkatan IN ('2001','2002') AND a.nomhs IS NULL "
     . "ORDER BY p.ps_id,m.angkatan,m.nomhs";
//$result = mysql_db_query("upn",$sql);
$ps = "";
while (list($ps_ext_id,$nomhs,$nama_mhs,$angkatan,$account_no) = mysql_fetch_row($result)) {
   if ($ps != $ps_ext_id) {
      $ps = $ps_ext_id;
      $i = 1;
      $c = 1;
      if ($db) dbase_close($db);
      $db = dbase_create("D:/autodebet/{$ps}{$i}NR.dbf",$defcol);
      if ($db === FALSE) {
         echo "weeekk1";
         die;
      }
   }
   if ($c == 501) {
      $c = 1;
      $i++;
      if ($db) dbase_close($db);
      $db = dbase_create("D:/autodebet/{$ps}{$i}NR.dbf",$defcol);
      if ($db === FALSE) {
         echo "weeekk2";
         die;
      }
   }
   dbase_add_record($db,array($nomhs,$nama_mhs,substr($account_no,4,9),0,$spp[$angkatan],0,0,0));
   $c++;
}
      $db = dbase_create("/tmp/dbase.dbf",$defcol);
      if ($db === FALSE) {
         echo "weeekk2";
         die;
      }

?>