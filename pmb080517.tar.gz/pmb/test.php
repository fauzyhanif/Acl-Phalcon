<?php

// isilah dengan user dan password dari MySQL anda
$host ="192.168.200.4";
$user = "root";
$passwd = "";
$database= "session2";

$connect=mysql_connect($host,$user,$passwd);
if (! $connect)
   {
    echo " TIDAK DAPAT MELAKUKAN KONEKSI ";
   }
        
// memilih database pda server
mysql_select_db($database)
or die ( " DATABASE TIDAK DITEMUKAN ");
           
$query=mysql_query("select * from xocp_akd_mhs where angkatan=2004 && psmhs_id=2",$connect) or die(mysql_error());
           
while ($hasil=mysql_fetch_row($query)){
       $nomhs=$hasil[2];
       $notst=$hasil[3];
       $nama=$hasil[9];
           
       $query1 =mysql_query("select * from xocp_akd_keu_trnsctdtl where nomor_test='$notst' && kwjb_id=1 ",$connect) or die(mysql_error());
       $hasil1 =mysql_fetch_row($query1);
       if (!$hasil1){
           echo"$nomhs,$nama, DPP I belum bayar <br>";
          }
       }
?>
                 