<?php
/*
+---------------------------------------------------------------------------------------+
|	Class MYSQL Utils v1.0																|
|																						|
|	Copyright (c) 2006, Ciprian Voicu													|
|	All rights reserved.																|
|																						|
|	Redistribution and use in source and binary forms, with or without modification, 	|
|	are permitted provided that the following conditions are met:						|
|																						|
|   * Redistributions of source code must retain the above copyright notice, this list 	|
|	of conditions and the following disclaimer.											|
|   * Redistributions in binary form must reproduce the above copyright notice, this 	|
|	list of conditions and the following disclaimer in the documentation and/or other 	|
|	materials provided with the distribution.											|
|   * Neither the name of the Autoportret Media nor the names of its contributors may 	|
|	be used to endorse or promote products derived from this software without specific 	|
|	prior written permission.															|
|																						|
|	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 	|
|	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 		|
|	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 	|
|	IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 	|
|	INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 	|
|	NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 	|
|	PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 	|
|	WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 	|
|	ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 			|
|	POSSIBILITY OF SUCH DAMAGE.															|
|																						|
+---------------------------------------------------------------------------------------+
*/

#---------------------------------------------------------------------------+
# START CLASS																#
#---------------------------------------------------------------------------+
class MYSQL{

	// GENERAL PROPERTIES
	var $host;				 	// 	HOST NAME
	var $user; 					// 	USERNAME
	var $pass; 					// 	PASSWORD
	var $mydb; 					// 	DATABASE NAME
	var $res;					// 	RESOURCE
	var $assoc = MYSQL_ASSOC;	// 	ASSOCIATIVE TYPE
	var $sql;					// 	query RESOURCE
	var $fields;
	var $table;
	
	// TABLE FORMAT PROPERTIES
	var $tb_style=array("font-family"=>"Verdana", "font-size"=>"11px", "border"=>"1px solid #7a7a8a", "cursor"=>"default");			
	var $th_style=array("background"=>"#7a7a8a", "color"=>"#FFFFFF", "border"=>"1px solid #FFFFFF");	
	var $td_style_default=array("text-align"=>"center","border"=>"1px solid #7a7a8a");
	
	var $td_style=array();
	var $tr_style=array();
	var $th_names=array();
	var $classes=array();
	var $dontshowed=array();
	
	// XML PROPERTIES
	var $xml;

	#---------------------------------------------------------------------------+
	# CONSTRUCTOR FUNCTION 														#
	#---------------------------------------------------------------------------+
	function MYSQL($host="192.168.200.4", $user="pmbkeu", $pass="pmbkeu7582", $mydb="session2"){
		$this->host=trim($host);
		$this->user=trim($user);
		$this->pass=trim($pass);
		$this->mydb=trim($mydb);
		
		$this->con=mysql_connect($this->host, $this->user, $this->pass) or die(mysql_error());
		mysql_select_db($this->mydb,$this->con) or die(mysql_error());
	}

	#---------------------------------------------------------------------------+
	# ```query``` FUNCTION														#
	#---------------------------------------------------------------------------+
	function query($query){
		$this->sql=mysql_query($query,$this->con) or die(mysql_error());
	}

	#---------------------------------------------------------------------------+
	# ```INSERT``` WITH ESCAPING THE STRING AGAINST THE SQL INJECTION ATTACK	#
	#---------------------------------------------------------------------------+
	function insert($query, $arr){
		foreach($arr as $value){
			$escaped[]=mysql_real_escape_string($value);
			$pattern[]="/\?\?/";
		}
		$query=preg_replace($pattern, $escaped, $query,1);
		$this->query($query);
	}
	
	#---------------------------------------------------------------------------+
	# THIS FUNCTION GET THE RESULT FROM THE SQL QUERY							#
	#---------------------------------------------------------------------------+
	function fetch(){
		$row=mysql_fetch_array($this->sql, $this->assoc);
		return $row;
	}

	#---------------------------------------------------------------------------+
	# THIS FUNCTION GET THE NUMBER OF RECORDS									#
	#---------------------------------------------------------------------------+
	function numrows(){
		return mysql_num_rows($this->sql);
	}

	#---------------------------------------------------------------------------+
	# THIS FUNCTION GET THE NUMBER OF FIELDS									#
	#---------------------------------------------------------------------------+
	function numfields(){
		return mysql_num_fields($this->sql);;
	}


	function fieldname($field){
		return mysql_field_name($this->sql,$field);
	}

	function row($cmd,$x){
		$q=mysql_query($cmd,$this->con);
//		$this->fetchmode($x);
		$rec=mysql_fetch_array($q,MYSQL_BOTH);
		return $rec[$x];
	}
	#---------------------------------------------------------------------------+
	# THIS FUNCTION GET THE LAST INSERTED ID									#
	#---------------------------------------------------------------------------+
	function lastid(){
		return mysql_insert_id();
	}

	#---------------------------------------------------------------------------+
	# THIS FUNCTION GET THE NUMBER OF AFFECTED ROWS								#
	#---------------------------------------------------------------------------+
	function affected(){
		return mysql_affected_rows($this->con);
	}

	#---------------------------------------------------------------------------+
	# ```COUNT``` RECORDS														#
	#---------------------------------------------------------------------------+
	function count($query){
		$this->query($query);
		$row=mysql_fetch_array($this->sql, MYSQL_NUM);
		return $row[0];
	}

	#---------------------------------------------------------------------------+
	# CHANGE MYSQL RESULT TYPE													#
	#---------------------------------------------------------------------------+
	function fetchmode($value){
		switch($value){
			case 0: 
				$this->assoc=MYSQL_NUM;
				break;
			case 1:
				$this->assoc=MYSQL_ASSOC;
				break;
			case 2:
				$this->assoc=MYSQL_BOTH;
				break;
		}
	}
	
	#---------------------------------------------------------------------------+
	# ```CLOSE``` DATABASE														#
	#---------------------------------------------------------------------------+
	function close(){
		mysql_close($this->con) or die(mysql_error());
	}

	#---------------------------------------------------------------------------+
	# ADD TABLE STYLE															#
	#---------------------------------------------------------------------------+
	function AddTbStyle($style, $value){
		$this->tb_style[$style]=$value;
	}

	#---------------------------------------------------------------------------+
	# ADD TH STYLE																#
	#---------------------------------------------------------------------------+
	function AddThStyle($style, $value){
		$this->th_style[$style]=$value;
	}

	#---------------------------------------------------------------------------+
	# ADD TD STYLE																#
	#---------------------------------------------------------------------------+
	function AddTdStyle($style, $value, $field=""){
		if($field){
			$this->td_style[$field][$style]=$value;
		}else{
			$this->td_style_default[$style]=$value;
		}
	}

	#---------------------------------------------------------------------------+
	# ADD TR STYLE																#
	#---------------------------------------------------------------------------+
	function AddTrBg($color){
		$this->tr_style[]=$color;
	}

	#---------------------------------------------------------------------------+
	# ADD CLASS TO A TABLE ELEMENT												#
	#---------------------------------------------------------------------------+
	function AddClass($element, $class, $subelement=""){
		switch($element){
			case "table":
				$this->classes["table"]=$class;
				break;
			case "th":
				$this->classes["th"]=$class;
				break;
			case "td":
				if($subelement){
					$this->classes["td"][$subelement]=$class;
				}else{
					$this->classes["td"]["default"]=$class;
				}
				break;
			case "tr":
				$this->classes["tr"][]=$class;
				break;
		}
	}

	#---------------------------------------------------------------------------+
	# CHANGE TABLE HEADER NAMES													#
	#---------------------------------------------------------------------------+
	function ThLabels(){
		$arg_list=func_get_args();
		for($a=0; $a<count($arg_list);$a++){
			$this->th_names[]=$arg_list[$a];
		}
	}
	
	#---------------------------------------------------------------------------+
	# GENERATES A TABLE FROM A SELECT QUERY										#
	#---------------------------------------------------------------------------+
	function Table($query,$no=0,$edit=""){
		$this->query($query);

		for($f=0;$f<$this->numfields();$f++){
			$info=mysql_fetch_field($this->sql);
			$this->fields[]=$info->name;
			$this->table=$info->table;
			
		}
		# TABLE STYLE OR CLASS
		if(!$this->classes["table"]){
			$table_style=" style='";
			foreach($this->tb_style as $key=>$value){
				$table_style.=$key.":".$value.";";
			}
			$table_style.="'";
		}else{
			$table_style=" class='".$this->classes['table']."'";
		}
		#
		
		# TH STYLE OR CLASS
		if(!$this->classes["th"]){
			$header_style=" style='";
			foreach($this->th_style as $key=>$value){
				$header_style.=$key.":".$value.";";
			}
			$header_style.="'";
		}else{
			$header_style=" class='".$this->classes['th']."'";
		}
		#
		
		# TD STYLES OR CLASSES
		foreach($this->fields as $name){
			foreach($this->td_style_default as $stylename=>$stylevalue){
				if(strlen($this->td_style[$name][$stylename])==0){
					$this->td_style[$name][$stylename]=$stylevalue;
				}
			}
		}
		foreach($this->td_style as $field=>$value){
			$td_local_style[$field]="";
			foreach($value as $style=>$property){
				$td_local_style[$field].=$style.":".$property.";";
			}
		}
		#
		
		$table="<table cellpadding='4' cellspacing='0' border='0'".$table_style.">\n";
		
		$table.="<tr>\n";
		
		if($no==1)$nox=1;
		$f=0;
		for($f=0; $f<count($this->fields); $f++){
			if(strlen($this->th_names[$f])==0){
				$name=$this->fields[$f];
			}else{
				$name=$this->th_names[$f];
			}
			if($nox==1){
				$table.="<th".$header_style.">No</th>\n";
				$nox=2;
				}
			
			$table.="<th".$header_style.">".ucfirst(strtolower($name))."</th>\n";
		}
//		if($no==1)$nox=1;
		$table.="</tr>\n";
		
		$bg_nr=0;
		while($row=$this->fetch()){
			# TR BACKGROUND
			$i++;
			if(!$this->classes["tr"]){
				if(count($this->tr_style)>0){
					$tr_style=" style='background:".$this->tr_style[$bg_nr].";'";
				}else{
					$tr_style="";
				}
				$bg_nr++;
				if($bg_nr==count($this->tr_style)){
					$bg_nr=0;
				}
			}else{
				if(strlen($this->classes["tr"])>0){
					$tr_style=" class='".$this->classes["tr"][$bg_nr]."'";
				}
				$bg_nr++;
				if($bg_nr==count($this->classes["tr"])){
					$bg_nr=0;
				}
			}
			#
			
			$table.="<tr".$tr_style.">\n";

			foreach($row as $key=>$value){
				if(strlen(trim(stripslashes($value)))==0) {
					$value="&nbsp;";
				}
				if(!$this->classes['td'][$key]){
					if(!$this->classes['td']['default']){
						if(!$td_local_style[$key]){
							$local_style=" style='".$td_local_style[0]."'";
						}else{
							$local_style=" style='".$td_local_style[$key]."'";
						}
					}else{
						$local_style=" class='".$this->classes['td']['default']."'";
					}
				}else{
					$local_style=" class='".$this->classes['td'][$key]."'";
				}
				if($nox==2){
					$table.="<td".$local_style.">";
					if($edit<>"") $table.="<a href=$_SERVER[PHP_SELF]?$edit>";
					$table.="$i</td>\n";
					$nox=0;
					}
				$table.="<td".$local_style.">".$value."</td>\n";
			}
			$table.="</tr>\n";
			if($no==1)$nox=2;
		}
		$table.="</table>\n";
		print $table;
	}
	

  function addkey($field){
  $this->addedkey=1;
  $this->field_key[]=$field;
  if($field=="off") {
    $this->addedkey=false;
    $this->field_key=false;
    }
  }

function addedit($url=""){
    $this->edit=1;
    if($url=="" or $url=="off")$this->url=$_SERVER[PHP_SELF]; else $this->url=$url;
    if($url=="off")    $this->edit=false;
}

function adddel($url="",$del=1){
    $this->del=$del;
    if($url=="" or $url=="off")$this->url=$_SERVER[PHP_SELF]; else $this->url=$url;    
    if($url=="off")    $this->del=false;
}

function addlink($field,$url="#"){
    $this->addlink=1;
    $this->addedlink[$field]=$url;
//    if($url=="" or $url=="off")$this->url=$_SERVER[PHP_SELF]; else $this->url=$url;    
    if($field=="off")    $this->addlink=false;
}

function addlimit($rowperpage=5,$pagenum="",$navlimit=10,$url_embel=""){
    $this->limit=1;
    $this->rowperpage=$rowperpage;
    $this->navlimit=$navlimit;
    if ($pagenum=="")$this->pagenum=1; else $this->pagenum=$pagenum;
    if($url_embel<>"")$this->url_embel=$url_embel;
    if($rowperpage=="off")    $this->limit=false;
}


function addjudul($judul){
    $this->pkjudul=1;
    $arg = func_get_args();
    $count=count($arg);
    for($i=0;$i<$count;$i++){
    $this->judul[]=$arg[$i];

    }
    
    if($judul=="off")    $this->pkjudul=false;
/*    print $this->judul[0]." xxx ";
    foreach($this->judul as $key=>$value){
	print "xx $key => $value <br>";
    }
    */
}

function addwidth($width){
//    $this->width=1;
    $arg = func_get_args();
    $count=count($arg);
    for($i=0;$i<$count;$i++){
    $this->width[]=$arg[$i];
    }
}

function dontshow($field){
    $this->dontshowx=1;
    $this->dontshowed[]=$field;
    if($field=="off")   {
	 $this->dontshowx=false;
	 $this->dontshowed="";
	 }
}

function addbelang($warna1="#eeeeee",$warna2="#dddddd"){
    $this->belang=1;
    $this->warna1=$warna1;
    $this->warna2=$warna2;    
    if($judul==1)$this->belang=false;
}

function formatrow($field,$format,$embelformat=""){
    $this->formatrow=1;
    $this->formatedrow[]=$field;
    $this->formatedrowf[$field]=$format;
    if($embelformat<>"")$this->formatededrowembf[$field]=$embelformat;
    if($format=="off")$this->formatedrow=false; 
}

function addrow($field,$format="##",$embelformat=""){
    $this->addrow=1;
    $this->addedrow[]=$field;
//    $this->addedrowf[$field]=$format;
	$pos=strpos($format,"##");
	$jchar=strlen($format);
	$this->a[$field]=substr($format,0,$pos);
	$this->b[$field]=substr($format,$pos+2,$jchar);

    if($embelformat<>"")$this->addedrowembf[$field]=$embelformat;
    if($format=="off")$this->addedrow=false; 
}

function addingrow($format,$content,$embel=""){
//    if($embel<>"")$contentx=$format($content.$embel);

//     $contentx=
     if($format=="number_format"){
     $contentx="Rp ".number_format($content,2,",",".");
     }else{
    $contentx=$format($content.$embel);
    }
//    if($content=="new")   $contentx=$format;
    return $contentx;
}
function addtotal($field){
    $this->addtotal=1;
    $this->addedtotal[]=$field;
    if($field=="off"){
	$this->addtotal=false;
	$this->addedtotal="";
	}
}

function rettotal($value){
//    $this->addreturn=1;
    return $this->ret_total[$value];
//print "xxx".$this->ret_total[$value]." cc ".$value." vv ".$this->ret_total["thn_akd"];
}

function addarray($field,$arr){
    $this->addarray=1;
    $this->addedarray[$field]=$arr;
//    print_r ($this->addedarray);
    if($field=="off"){
	$this->addarray=false;
	$this->addedarray="";
    }
}


function viewtable($sql,$no=0,$mode=1){
$edit=$this->edit;
$field_key=$this->field_key;
$url=$this->url;
$del=$this->del;
$limit=$this->limit;
	if($limit==1){
	        $rowperpage=$this->rowperpage;
        	$pagenum=$this->pagenum;
		$q=mysql_query($sql,$this->con);
		$numrows_no_limit=mysql_num_rows($q);	

		$offset=($pagenum - 1) * $rowperpage;
//		if($this->page<>"") $pagenum=$this->page;
		$sql.="  limit $offset,$rowperpage";
		$ii=$offset++;
	}
	
//	$table.="$sql<br>";
//	print "$sql";
	$q=mysql_query($sql,$this->con) or die (mysql_error());
	$num_rows=mysql_num_rows($q);
	$num_field=mysql_num_fields($q);
///print "numrows $num_rows numfild $num_field";
//	$this->query($sql);
//	$num_rows=$this->numrows();
//	$num_field=$this->numfields();

	if($num_rows<1){
	    print "<br>No Data Here<br>";
	}else{
	
	if($this->classes["table"]){
	    $tb_style=" class='".$this->classes["table"]."'";
	}else{
	$tb_style="style='";
	foreach($this->tb_style as $key=>$value){
	    $tb_style.=$key.":".$value.";";
	    	}
	$tb_style.="'";
	}
	
	if($this->classes["th"]){
	    $th_style=" class='".$this->classes["th"]."'";
	}else{
	$th_style="style='";
	foreach($this->th_style as $key=>$value){
	    $th_style.=$key.":".$value.";";
	    	}
	$th_style.="'";
	}

	if($this->classes["tr"]){
	    $tr_style=" class='".$this->classes["tr"][0]."'";
	}else{
	$tr_style="style='";
	foreach($this->tr_style as $key=>$value){
	    $tr_style.=$key.":".$value.";";
	    	}
	$tr_style.="'";

	}

//	print_r($this->classes['tr']);
			
	$table.="<table cellpadding='4' cellspacing='0' border='1' ".$tb_style."><tr>\n";
	if($mode==1)	if($no==1) $table.="<Th ".$th_style.">No</th>\n";


	for($i=0;$i<$num_field;$i++){
		$field[$i]=mysql_field_name($q,$i);
		if($this->pkjudul==1){
		    $name[$i]=$this->judul[$i];
		    }else{
		    $name[$i]=$field[$i];
		    }
		    
	if(!(in_array($field[$i],$this->dontshowed))){    	    
	        if($mode==1)	$table.="<th ".$th_style.">".ucfirst($name[$i])."</th>\n";    
	}
	
	    foreach($this->td_style_default as $stylename=>$stylevalue){
		if(strlen($this->td_style[$field[$i]][$stylename])==0)
		    $this->td_style[$field[$i]][$stylename]=$stylevalue;
	    }
	}
	
	foreach($this->td_style as $f=>$v){
	    $td_local_style[$f]="";
	    foreach($v as $style=>$property){
		$td_local_style[$f].=$style.":".$property.";";
	    }
	}    

	for($j=0;$j<$num_field;$j++){
	    if(!$this->classes['td'][$field[$j]]){
			if(!$this->classes['td']['default']){
			    if(!$td_local_style[$field[$j]]){
				$td_style=" style='".$td_local_style[0]."'";
			    }else{
				$td_style=" style='".$td_local_style[$field[$j]]."'";
			    }
			}else{
			    $td_style=" class='".$this->classes['td']['default']."'";
			}	
		    }else{
			$td_style=" class='".$this->classes['td'][$field[$j]]."'";	
		    }
	}

	    
	$table.="</tr>\n";
	while($tmp=mysql_fetch_array($q)){
//	while($tmp=$this->fetch()){
	$fieldx="";
//	if($tmp[2]<>1){
		if($this->belang==1){
		    $urutbelang++;
		    $warna1="bgcolor='".$this->warna1."'";
		    $warna2="bgcolor='".$this->warna2."'";
		    $warna=($urutbelang%2==0)?"bgcolor='".$this->warna1."'":"bgcolor='".$this->warna2."'";
		}

		$table.="<tr $warna ".$tr_style.">\n";

		if($edit==1 or $del>0 or $this->addlink==1){
			if($this->addedkey==1){
			    foreach($field_key as $value){
				$fieldx.="&".$value."=".$tmp[$value];
				}
			}else{
				for($j=0;$j<$num_field;$j++){
 				$fieldx.="&".$field[$j]."=".$tmp[$field[$j]];
				}
			}
		}
		$ii++;
		if($edit==1){
			$href="<a href=$url?act=edit$fieldx>";
			$hrefx="</a>";
			}
		

		if($mode==1) if($no==1) $table.="<td ".$td_style.">$href $ii $hrefx</td>\n";
		if($mode==2) if($no==1) $table.="<tr $warna ".$tr_style.">
			<td><b>No</b></td><td>$ii</td></tr>\n";
		for($j=0;$j<$num_field;$j++){
		$content=$tmp[$field[$j]];
		    if($this->addarray==1){
			if(array_key_exists($field[$j],$this->addedarray)){
			    $content=$this->addedarray[$field[$j]][$content];
//			    print "x ".$field[$j]." b ".$content." v ".$this->addedarray[periode][25]." n ".$content ."<br> ";
			}    
		    }

		    
		    if($this->formatrow==1){
			if(in_array($field[$j],$this->formatedrow)){
			    //if($this->addedrowembf[$field[$j]]<>"") 
			    $content=$this->addingrow($this->formatedrowf[$field[$j]],$content,$this->formatedrowembf[$field[$j]]);
			}
		    }
		    
		    if($this->addlink==1){
			if(array_key_exists($field[$j],$this->addedlink)){
			    $content="<a href='".$this->addedlink[$field[$j]]."$fieldx'>$content</a>";
			}
		    }
			if($edit==1){
				if($no==0 and $j==0){
					//$table.="<td>$href".$content."$hrefx</td>\n";
					$content=$href.$content.$hrefx;
				}else{
					//$table.="<td>".$content."</td>\n";
					$content=$content;
				}
			}else{
			//$table.="<td>".$content."</td>\n";
			    $content=$content;			
			    }
		    
		    $content=($content=="")?"-":$content;	    
			    
		if(!(in_array($field[$j],$this->dontshowed))){    
		    if($mode==1)$table.="<td ".$td_style." width=".$this->width[$j].">".$content."</td>\n";	
		    elseif($mode==2) $table.="<tr $warna ".$tr_style."><td valign=top>
			<b>".$name[$j]."</b></td><td>".$content."</td></tr>\n";
		    }
		}
		
		if($this->addtotal==1){
		    foreach($this->addedtotal as $fieldx=>$valuex){
//		    $this->ret_total[$this->addedtotal]=$this->ret_total[$this->addedtotal]+$tmp[$this->addedtotal];
		    $this->ret_total[$valuex]=$this->ret_total[$valuex]+$tmp[$valuex];
		    }
//		    print "xxxxxxxx".$ret_total[$this->addedtotal]."<br>";
		}
		
		if($this->addrow==1){
		    for($k=0;$k<count($this->addedrow);$k++){
			    if(in_array($this->addedrow[$k],$field)) $content=$tmp[$this->addedrow[$k]];
			    $content=$this->a[$this->addedrow[$k]].$content.$this->b[$this->addedrow[$k]];;
			}
		    if($mode==1)$table.="<td ".$td_style.">".$content."</td>\n";	
		    elseif($mode==2) $table.="<tr $warna ".$tr_style."><td valign=top>
			<b>".$name[$j]."</b></td><td>".$content."</td></tr>\n";

		    }
		    
	    if($mode==2) {
		$table.="<tr>\n";
		if($edit==1)$table.="<td>$href Edit $hrefx</td>\n";		    		
		}
				if($this->del==1){
		    $table.="<td><a href=$url?act=del$fieldx>Delete</a></td>\n";
		    }
			$table.="</tr>\n";
		if($mode==2)    $table.="<tr><td colspan=2>&nbsp</td></tr>\n";

	}	

if($limit==1){
// Pagination

    $numrows = $numrows_no_limit;
    $maxpage = ceil($numrows/$rowperpage);
    $navlimit=$this->navlimit;
    $minpage_show=1;
    
    if($pagenum>($minpage_show+$navlimit)){
	 $minpage_show=$pagenum-($navlimit);
	 $first="<a href='$url?page=1".$this->url_embel."'> 1 </a>...\n";
    }

    $mbuh=($maxpage-($navlimit*2));
//    print "$minpage_show xx $maxpage cc $navlimit xx $mbuh";    
    if($minpage_show<$mbuh) $end="...<a href='$url?page=$maxpage".$this->url_embel."'> $maxpage </a>\n";

    $maxpage_show=$pagenum+($navlimit);
    if($maxpage_show>$maxpage) $maxpage_show=$maxpage;

    //$pagex=$
    $nav = '';
    $nav.=$first;
    for($page = $minpage_show; $page <= $maxpage_show; $page++)
    {
	if($page == $pagenum)
        {
    	    $nav .= " $page \n";
	}else{
	    $nav .= "<a href='$url?page=$page".$this->url_embel."'> $page </a>\n";
        }
    }

    if ($pagenum > 1)
    {
	$page = $pagenum - 1;
	$prev = " <a href='$url?page=$page".$this->url_embel."'><strong>&laquo;</strong></a>\n";
	$first = " <a href='$url?page=1".$this->url_embel."'><strong>&laquo;&laquo;</strong></a>\n";
    }else{
	$prev = '';
	$first = '';
    }

    if ($pagenum < $maxpage)
    {
	$page = $pagenum + 1;
        $next = " <a href='$url?page=$page".$this->url_embel."'><strong>&raquo;</strong></a>\n";
	$last = " <a href='$url?page=$maxpage".$this->url_embel."'><strong>&raquo;&raquo;</strong></a>\n";
    }else{
	$next = '';
        $last = '';
    }
    
    $nav.=$end;
    if($no==1) $j++;
    if($numrows>$num_rows){
	$table.= "<tr bgcolor=''>\n
        <td align='center' bgcolor='' colspan=$j>
        <font color=''>
	$first  &nbsp; $prev  &nbsp; $nav &nbsp; $next &nbsp; $last
        </font></td>\n</tr>\n";
    }

}
$table.="</table>\n";

//$this->addreturn($ret_total);
print $table;
    } //DAta ada======
//return $ret_total;
}

function addelm($field,$type="man",$sql="",$v="",$f=""){
    $this->addelm=1;
    $this->addedelm[]=$field;
    $this->addedelmtype[$field]=$type;
    
	 $this->addedelmsql[$field]=$sql;
	 $this->addedelmv[$field]=$v;
	 $this->addedelmf[$field]=$f;
if ($field=="off")    $this->addelm=false;
/*    if($type=="hidden"){
	$script0="<input type=hidden name=$field "; 	
	$script1="
    }
*/
//    $this->addelmscript[$field]=$script;
}

function addvalue($value){
    $this->addvalue=1;
    $this->addedvalue=$value;
    if ($value=="off")    $this->addvalue=false;
}

function addhidden($field,$name){
    $this->addhidden=1;
    $this->addedhidden[$field]=$name;
    if($field=="off")    $this->addhidden=false;
}

function printform($sql,$form="add",$url="",$method="post"){
$url=($url=="")?$_SERVER[PHP_SELF]:$url;

$sql.=" limit 1";
$q=mysql_query($sql);
$numfield=mysql_num_fields($q);

    if($form=="add"){
    //========nothing====//
	$elm.="<input type=hidden name=act value='insert'>";    
    }elseif($form=="edit"){
        $value=mysql_fetch_row($q);
	$elm.="<input type=hidden name=act value='update'>";
    }

    if ($this->addvalue==1){
	$value=$this->addedvalue;
    }

for($i=0;$i<$numfield;$i++){
    $field[$i]=mysql_field_name($q,$i);
    $v[$field[$i]]=$value[$i];
    
    if($this->pkjudul==1){
	$judul[$i]=$this->judul[$i];
    }else{
	$judul[$i]=$field[$i];
    }
    $judul[$i]=ucfirst($judul[$i]);
    if($this->addelm==1){
	if(in_array($field[$i],$this->addedelm)) {
	    if($this->addedelmtype[$field[$i]]=="hidden"){
		$elm.="<input type=hidden name=".$field[$i]." value='".$value[$i]."'>";
	    }elseif($this->addedelmtype[$field[$i]]=="none"){
		$elm.="";
	    }else{	    
		$elm.="<tr><td>".$judul[$i]."</td><td>&nbsp</td><td>";
		if($this->addedelmtype[$field[$i]]=="select"){
		    $elm.="<select name=".$field[$i].">";
//		    print $this->addedelmv[$field[$i]];
		    $q_elm=mysql_query($this->addedelmsql[$field[$i]]);
		    $elm.="<option value=''></option>";
		    while($tmp=mysql_fetch_row($q_elm)){
			if($tmp[$this->addedelmv[$field[$i]]]==$value[$i]){
			    $elm.="<option value=$value[$i] selected>".$tmp[$this->addedelmf[$field[$i]]]."</option>";
			}else{
			    $elm.="<option value=".$tmp[$this->addedelmv[$field[$i]]].">".$tmp[$this->addedelmf[$field[$i]]]."</option>";
			}
		    }
		}elseif($this->addedelmtype[$field[$i]]=="man"){
		    $elm.=$this->addedelmsql[$field[$i]];
		}
		$elm.="</td></tr>";
	    }
//	    $elm.=$this->addelmscript[$field[$i]];
	
        }else{
	    $elm.="<tr><td>".$judul[$i]."</td><td>&nbsp</td>
	        <td><input type=text name=".$field[$i]." value='".$value[$i]."'>
		</td</tr>";
	    }
    }else{
    $elm.="<tr><td>".$judul[$i]."</td><td>&nbsp</td>
	    <td><input type=text name=".$field[$i]." value='".$value[$i]."'>
	    </td</tr>";
    }    

}
        
    if($this->addhidden==1){
	foreach($this->addedhidden as $f=>$val){
	    $elm.="<input type=hidden name=$val value=$v[$f]>";
	}
    }
    $form="";
	$form.="<form action=$url method=$method><table>";
	$form.=$elm;
	$form.="<tr><td colspan=3 align=center><input type=reset value=Reset>
		<input type=submit value=Submit></td></tr>";
	$form.="</table></form>";
    
print $form;
}

function listmenu($name,$query="man",$val_id=0,$value=1,$sel_value=""){
    $list.="<select name=$name>";
    $list.="<option selected></option>";
    if($query=="man"){
	for ($i=$val_id;$i<$value;$i++){
	    if($i==$sel_value){
		$list.="<option value=$i selected>$i</option>";
	    }else{
		$list.="<option value=$i>$i</option>";
	    }
	}
    }else{	
	$this->query($query);
	$this->fetchmode(0);

	while ($row=$this->fetch()){
		if($row[$val_id]==$sel_value){
		$list.="<option value=$row[$val_id] selected>$row[$value]</option>";
		}else{
		$list.="<option value=$row[$val_id]>$row[$value]</option>";
		}
	}
    }
    
    $list.="</select>";
    return $list;
}

function tanggal($tgl){
	$bulan=array(01=>"Januari","February","Maret","April","Mei","Juni","Juli","Agustus",
			"September","Oktober","November","Desember");
	$thn=substr($tgl,0,4);
	$tanggal=substr($tgl,-2,2);
	$bln=intval(substr($tgl,5,2));
	$tgl=$tanggal." ".$bulan[$bln]." ".$thn;
	return $tgl;
}

function redir($url){
    $x=1/1000;
    echo "<meta http-equiv='refresh' content='$x;url=$url' />";
}






	#---------------------------------------------------------------------------+
	# RETURN A SELECT RESULT IN XML FORMAT										#
	#---------------------------------------------------------------------------+
	function XML($query, $mode=""){
		$this->query($query);
		$string="<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n";
		$string.="<".$this->table.">\n";
		while($row=$this->fetch()){
			if($mode==1 || strlen($mode)==0){
				$string.="<record";
				foreach($row as $key=>$value){
					$string.=" ".$key."=\"".htmlspecialchars(stripslashes($value))."\"";
				}
				$string.="></record>\n";
			}elseif($mode==2){
				$string.="<record>\n";
				foreach($row as $key=>$value){
					$string.="<".$key.">".htmlentities(stripslashes($value))."</".$key.">\n";
				}
				$string.="</record>\n";
				$string.="\n";
			}
		}
		$string.="</".$this->table.">\n";
		$this->xml=$string;
	}

	#---------------------------------------------------------------------------+
	# WRITE XML TO FILE															#
	#---------------------------------------------------------------------------+
	function XMLSave($path){
		$this->Save($path, utf8_encode($this->xml));
	}

	#---------------------------------------------------------------------------+
	# GET THE XML FILE															#
	#---------------------------------------------------------------------------+
	function XMLGet($mode){
		header("Content-type: text/xml", true);
		switch($mode){
			case 1:
				echo utf8_encode($this->xml);
				break;
			case NULL:
				echo utf8_encode($this->xml);
				break;
			case 2:
				header('Content-Disposition: attachment; filename="'.$this->table.'.xml"');
				echo utf8_encode($this->xml);
				break;
		}
	}
	
	#---------------------------------------------------------------------------+
	# SAVE FILES TO PATH														#
	#---------------------------------------------------------------------------+
	function Save($path, $data){
		if(!function_exists("file_put_contents")){
	    	function file_put_contents($path,$data){
		    	$handle=@fopen($path,"w");
				if(!$handle){
					return false;
         		}
		        fwrite($handle,$data);
        		fclose($handle);
				return true;
			}
		}
		$dirname=dirname($path);
		$filename=basename($path);
		if(strlen($dirname)>0){
			$dirs=explode("/", $dirname);
			if(!is_dir($dirname)){
				for($d=0;$d<count($dirs);$d++){
					if($d==0){
						mkdir($dirs[0]);
						$newpath=$dirs[0];
					}else{
						mkdir($newpath."/".$dirs[$d]);
						$newpath.="/".$dirs[$d];
					}
				}
				
			}
		}
		file_put_contents($path, $data);
	}
}

#---------------------------------------------------------------------------+
# END CLASS																	#
#---------------------------------------------------------------------------+

?>