drop database if exists xocp;
create database xocp;
use xocp;


# KALO DOWNLOAD INI HARUS DOWNLOAD YANG LAINNYA
# SOALNYA YANG LAMA BEDA STRUKTUR UNTUK HTMLNYA
#
# 
#
# X Open Community Portal
#--------------------------------------------------------
# 
CREATE TABLE portals (
  pid int(10) unsigned NOT NULL default '0',       # portal id
  portal_nm char(100) NOT NULL default '',
  login_ext char(5) NOT NULL default '',           # login extension in case multiple portal 
                                                   # in single site/server.
  host char(200) binary NOT NULL default '',       # ip address atau url portal
  PRIMARY KEY  (pid) 
) TYPE=MyISAM;


CREATE TABLE orgs (
  org_id int(10) unsigned NOT NULL auto_increment,
  org_nm text NOT NULL,
  addr_txt text NOT NULL,
  telecom text NOT NULL,
  begin_dttm datetime default NULL,
  end_dttm datetime default NULL,
  orgclass_id int(10) unsigned NOT NULL default '0',
  status_cd enum('active','inactive','normal','nullified') NOT NULL default 'active',
  parent_id int(10) unsigned NOT NULL default '0',  # parent organization.
                                                    # 1 organisasi hanya bisa punya 1 parent.
                                                    # kalo definisi akses ke multiple
                                                    # organisasi akan ditangani oleh tabel
                                                    # org_ access oleh masing-masing module.
  description text NOT NULL,
  PRIMARY KEY  (org_id)
) TYPE=MyISAM;

CREATE TABLE orgclass (
  orgclass_id int(10) unsigned NOT NULL auto_increment,
  orgclass_nm text NOT NULL,
  PRIMARY KEY  (orgclass_id)
) TYPE=MyISAM;

# table org_resolve adalah table untuk
# menterjemahkan organisasi non lokal portal ke lokal portal
CREATE TABLE org_resolve (
  pid int(10) unsigned NOT NULL default '0',         # portal asal
  org_id int(10) unsigned NOT NULL default '0',      # id org di portal asal
  local_id int(10) unsigned NOT NULL default '0',    # id org di portal lokal
  PRIMARY KEY (pid,org_id)
);



######################################################
# below these are portal independent table
######################################################

CREATE TABLE modules (
  module_id char(50) NOT NULL default '',
  isactive enum('n','y') NOT NULL default 'y',
  del_ind enum('n','y') NOT NULL default 'y',
  PRIMARY KEY  (module_id)
) TYPE=MyISAM;

CREATE TABLE blocks (
  module_id char(50) NOT NULL default '0',
  class_nm char(60) NOT NULL default '',
  file_nm char(100) NOT NULL default '',
  catchvar char(5) NOT NULL default '',
  isactive enum('n','y') NOT NULL default 'y',
  side_allow char(30) NOT NULL default '',
  PRIMARY KEY  (module_id,class_nm)
) TYPE=MyISAM;

CREATE TABLE pages (
  page_no int(10) unsigned NOT NULL auto_increment,
  page_id char(50) NOT NULL default '',
  guest_dfl enum('n','y') NOT NULL default 'n',
  user_dfl enum('n','y') NOT NULL default 'n',
  PRIMARY KEY (page_no),
  UNIQUE KEY (page_id)
);

CREATE TABLE pages2areas (
  page_id char(50) NOT NULL default '',
  area_id tinyint(3) NOT NULL default '0',
  rowspan tinyint(3) unsigned NOT NULL default '0',
  valign char(6) NOT NULL default 'top',
  area_type char(4) NOT NULL default '',
  PRIMARY KEY (page_id,area_id)
);

CREATE TABLE areas2blocks (
  page_id char(50) NOT NULL default '',
  area_id tinyint(3) unsigned NOT NULL default '0',
  block_id int(10) unsigned NOT NULL default '0',
  module_id char(50) NOT NULL default '',
  class_nm char(60) NOT NULL default '',
  weight int(10) unsigned NOT NULL default '0',
  align char(6) NOT NULL default 'left',
  PRIMARY KEY (block_id,area_id,page_id)
);

######################################################
# above these are portal independent table
######################################################


CREATE TABLE groups2pages (
  group_id int(10) unsigned NOT NULL default '0',
  page_id char(50) NOT NULL default '0',
  grant_priv enum('n','y') NOT NULL default 'n',
  passwd enum('n','y') NOT NULL default 'n',
  PRIMARY KEY (group_id,page_id)
);

CREATE TABLE groups2blocks (
  group_id int(10) unsigned NOT NULL default '0',
  module_id char(50) NOT NULL default '0',
  class_nm char(60) NOT NULL default '',
  grant_priv enum('n','y') NOT NULL default 'n',
  passwd enum('n','y') NOT NULL default 'n',
  PRIMARY KEY (group_id,module_id,class_nm)
);

CREATE TABLE custompages (
  cpage_id int(10) unsigned NOT NULL default '0',
  cpage_nm char(100) NOT NULL default '',
  user_id int(10) unsigned NOT NULL default '0',
  PRIMARY KEY (cpage_id,user_id)
);

CREATE TABLE custompages2blocks (
  user_id int(10) unsigned NOT NULL default '0',
  cpage_id int(10) unsigned NOT NULL default '0',
  module_id char(50) NOT NULL default '0',
  class_nm char(60) NOT NULL default '0',
  weight int(10) unsigned NOT NULL default '0',
  side char(4) NOT NULL default '',
  rowspan tinyint(3) unsigned NOT NULL default '1',
  align char(6) NOT NULL default 'left',
  valign char(6) NOT NULL default 'top',
  PRIMARY KEY (cpage_id,module_id,class_nm)
);










# table : groups in the portal
CREATE TABLE pgroups (
  pgroup_id int(10) unsigned NOT NULL auto_increment,
  pgroup_cd char(50) NOT NULL default '',
  description char(250) NOT NULL default '',
  startpage char(50) NOT NULL default '',
  PRIMARY KEY (pgroup_id),
  UNIQUE KEY (pgroup_cd)
) TYPE=MyISAM;

# Tiap portal punya pgroup, pgroup adalah kelompok-kelompok menu
# yang berlaku untuk suatu portal. Masalah akses ke organisasi
# akan ditangani oleh modul yang bersangkutan atau suatu modul
# khusus yang akan menset session variabel tertentu untuk
# mengenali organisasi yang sedang diakses. Dong?

CREATE TABLE menuitems (
  menuitem_id int(10) unsigned NOT NULL default '0',
  parent_id int(10) unsigned NOT NULL default '0',
  pgroup_id int(10) unsigned NOT NULL default '0',
  weight int(10) unsigned NOT NULL default '0',
  menu_nm char(100) NOT NULL default '',
  param0 char(255) NOT NULL default '',
  param1 char(255) NOT NULL default '',
  PRIMARY KEY  (menuitem_id,pgroup_id)
) TYPE=MyISAM;












# table : users
# 
CREATE TABLE users (
  user_id int(10) unsigned NOT NULL auto_increment,
  person_id int(10) unsigned NOT NULL default '0',
  user_nm char(30) NOT NULL default '',
  pwd0 char(32) NOT NULL default '',            # encrypted password.
  pwd1 char(32) NOT NULL default '',            # plain password (reset).
  language char(32) NOT NULL default '',
  avatar char(30) NOT NULL default '',
  regdate int(10) unsigned NOT NULL default '0',
  icq char(15) NOT NULL default '',
  viewemail enum('n','y') NOT NULL default 'n',
  aim char(18) NOT NULL default '',
  yim char(25) NOT NULL default '',
  msnm char(25) NOT NULL default '',
  startpage char(50) NOT NULL default '',
  user_theme enum('n','y') NOT NULL default 'y', # user may use theme other than system default.
  theme char(250) NOT NULL default '',           # theme selected.
  sig char(250) NOT NULL default '',            # signature text in e-mail.
  attachsig enum('n','y') NOT NULL default 'n', # attach signature in e-mail.
  tz_offset tinyint(3) NOT NULL default '0',    # time zone offset.
  popmsgon enum('n','y') NOT NULL default 'y',  # pop message is on.
  last_login int(10) unsigned NOT NULL default '0',
  pgroup_id int(10) unsigned NOT NULL default '0',    # save default pgroup_id from the last selected
  status_cd enum('active','inactive','nullified') NOT NULL default 'inactive',








  PRIMARY KEY (user_id),
  UNIQUE KEY (person_id),
  UNIQUE KEY (user_nm)
) TYPE=MyISAM;

CREATE TABLE user_pgroup (
  user_id int(10) unsigned NOT NULL default '0',
  pgroup_id int(10) unsigned NOT NULL default '0',
  PRIMARY KEY (user_id,pgroup_id)
) TYPE=MyISAM;

CREATE TABLE persons (
  person_id int(10) unsigned NOT NULL auto_increment,
  ssn char(250) NOT NULL default '',
  ext_id text NOT NULL,
  person_nm text NOT NULL,

  metaphone_nm text NOT NULL,

  ################################################################
  #### START OF MODIFICATION ( from multiunit_doc.sql ) ##########
  ################################################################

  adm_gender_cd enum('m','f') NOT NULL default 'm',
                                              # administrative gender (sex)
                                              # for administrative purpose
                                              # m : male, f : female
  addr_txt text NOT NULL,                     # street address, free text
  zip_cd char(5) NOT NULL default '',         # zip code
  telecom text NOT NULL,                      # telephone and/or fax number
  birth_dttm datetime default NULL,           # birth datetime
  birthplace text NOT NULL,                   # place of birth
  deceased_dttm datetime default NULL,        # deceased date time
  deceased_ind enum('y','n') NOT NULL default 'n',
                                              # an indication that
                                              # the person is dead
  bloodtype_cd enum('A','B','O','AB') default NULL,
                                              # blood type
  religion_cd char(1) NOT NULL default '',    # religious afiliation code
  marital_st enum('y','n') NOT NULL default 'n',
                                              # marital status
  ethnic_cd smallint(5) unsigned NOT NULL default '0', 
                                              # ethnic group
  race_cd int(10) unsigned NOT NULL default '0',       
                                              # race
  educlvl_cd tinyint(3) unsigned NOT NULL default '0',
                                              # education level
  living_arr_cd tinyint(3) unsigned NOT NULL default '0',
                                              # living arrangement
  status_cd enum('active','inactive','normal','nullified') NOT NULL default 'active',

  #################################################################
  #### END OF MODIFICATION ########################################
  #################################################################

  del_ind enum('n','y') NOT NULL default 'y',
  PRIMARY KEY  (person_id)
) TYPE=MyISAM;


############# DHS PROJECT #############################      
#######################################################
# INDIKATOR KESEHATAN

# untuk modul indikator kesehatan, tabel-tablenya
# sudah cukup stabil, dan reliable untuk mengatasi
# segala kondisi.

CREATE TABLE ind_groups (
  group_id int(10) unsigned NOT NULL auto_increment,
  parent_id int(10) unsigned NOT NULL default '0',
  group_nm char(200) NOT NULL default '',
  PRIMARY KEY (group_id)
);

CREATE TABLE ind_template (
  tmpl_id int(10) unsigned NOT NULL auto_increment,
  tmpl_nm text NOT NULL,
  tmpl_vars text NOT NULL,
  bl_vars text NOT NULL,
  tmpl_unit text NOT NULL,
  formula text NOT NULL,
  formula_tv text NOT NULL,
  description text NOT NULL,
  target_val char(10) NOT NULL default '',
  PRIMARY KEY (tmpl_id)
);

# formula_tv, untuk hitung target value perdaerah

CREATE TABLE ind_baseline (
  bl_var char(10) NOT NULL,
  bl_nm char(250) NOT NULL,
  bl_unit char(10) NOT NULL,
  description text NOT NULL,
  PRIMARY KEY (bl_var)
);

CREATE TABLE ind_baselinedata (
  org_id int(10) unsigned NOT NULL default '0',
  bl_var char(10) NOT NULL default '',
  valid0 char(10) NOT NULL default '0000-00-00',
  valid1 char(10) NOT NULL default '0000-00-00',
  bl_val char(30) NOT NULL default ''
);

# tambah:
#    srcorg_nm isinya keterangan asal/sumber data, periode survey (i.e. data didapat dari mana)    

CREATE TABLE ind_grouptmpl (
  group_id int(10) unsigned NOT NULL default '0',
  tmpl_id int(10) unsigned NOT NULL default '0',
  PRIMARY KEY (group_id,tmpl_id)
);

CREATE TABLE ind_items (
  org_id int(10) unsigned NOT NULL default '0',
  ind_id int(10) unsigned NOT NULL default '0',

  ind_nm text NOT NULL,
  description text NOT NULL,
  tmpl_id int(10) unsigned NOT NULL default '0',
  ind_vars text NOT NULL,
  ind_value text NOT NULL,
  target_val text NOT NULL,
  periode char(10) NOT NULL default '0000-00-00',
  created datetime NOT NULL default '0000-00-00 00:00:00',
  modified datetime NOT NULL default '0000-00-00 00:00:00',
  publish enum('n','y') NOT NULL default 'y',
  PRIMARY KEY (org_id,ind_id)
);

# target_val, hitung hasil formula_tv dari ind_template

# table : ind_orglink
# dengan table ini, maka wilayah atas (propinsi), bisa
# merekap/merangkum indikator bawah (kabupaten)

CREATE TABLE ind_orglink (
  org_id int(10) unsigned NOT NULL default '0',     # super org.
  sub_id int(10) unsigned NOT NULL default '0',     # sub org.
  PRIMARY KEY  (org_id,sub_id)
) TYPE=MyISAM;

CREATE TABLE ind_pgroup_org (
  pgroup_id int(10) unsigned NOT NULL default '0',
  org_id int(10) unsigned NOT NULL default '0',
  PRIMARY KEY (pgroup_id,org_id)
) TYPE=MyISAM;







