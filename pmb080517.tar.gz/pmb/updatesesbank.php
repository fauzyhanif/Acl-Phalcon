<? mysql_connect("localhost","root","");
   mysql_select_db("session2");

   $A=mysql_query("select keu_thn,keu_ses_id,psmhs_id,kwjbdtl_id from xocp_akd_keu_seskwjbdtl where keu_thn='2009' and keu_ses_id='1010' and psmhs_id='17'");
   while (list($keu_thn,$keu_ses_id,$psmhs_id,$kwjbdtl_id)=mysql_fetch_row($A)) {
    echo "$keu_thn $keu_ses_id $psmhs_id $kwjbdtl_id,a<br>";
   mysql_query("update xocp_akd_keu_sesbank set bank_id='20001' where keu_thn='2009' and keu_ses_id='1010' and kwjbdtl_id='$kwjbdtl_id'");
   }
?>
