<?php
//--------------------------------------------------------------------//
// Filename : include/common.php                                      //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-09                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if (!defined("XOCP_CONFIG_INCLUDED")) {
   exit();
} else {

   ini_set("register_globals",1);
   ini_set("session.serialize_handler", "php");

   function ss_timing_start ($name = 'default') {
      global $ss_timing_start_times;
      $ss_timing_start_times[$name] = explode(' ', microtime());
   }

   function ss_timing_stop ($name = 'default') {
      global $ss_timing_stop_times;
      $ss_timing_stop_times[$name] = explode(' ', microtime());
   }

   function ss_timing_current ($name = 'default') {
      global $ss_timing_start_times, $ss_timing_stop_times;
      if (!isset($ss_timing_start_times[$name])) {
         return 0;
      }
      if (!isset($ss_timing_stop_times[$name])) {
         $stop_time = explode(' ', microtime());
      } else {
         $stop_time = $ss_timing_stop_times[$name];
      }
      // do the big numbers first so the small ones aren't lost
      $current = $stop_time[1] - $ss_timing_start_times[$name][1];
      $current += $stop_time[0] - $ss_timing_start_times[$name][0];
      return $current;
   }

   function ss_timing_result() {
      //$ret = "<div style='font-size: smaller;'>";
      ss_timing_stop();
      $ret .= sprintf("Page took %s seconds to load.",ss_timing_current());
      //$ret .= "</div>\n";
      return $ret; 
   }



   ss_timing_start();


   // A+B+C+D <= 100
   define("XOCP_AREAWIDTH_A",25);
   define("XOCP_AREAWIDTH_B",30);
   define("XOCP_AREAWIDTH_C",25);
   define("XOCP_AREAWIDTH_D",20);

   define("XOCP_AREAWIDTH_AB",XOCP_AREAWIDTH_A+XOCP_AREAWIDTH_B);
   define("XOCP_AREAWIDTH_BC",XOCP_AREAWIDTH_B+XOCP_AREAWIDTH_C);
   define("XOCP_AREAWIDTH_CD",XOCP_AREAWIDTH_C+XOCP_AREAWIDTH_D);
   define("XOCP_AREAWIDTH_ABC",XOCP_AREAWIDTH_A+XOCP_AREAWIDTH_B+XOCP_AREAWIDTH_C);
   define("XOCP_AREAWIDTH_BCD",XOCP_AREAWIDTH_B+XOCP_AREAWIDTH_C+XOCP_AREAWIDTH_D);
   define("XOCP_AREAWIDTH_ABCD",XOCP_AREAWIDTH_A+XOCP_AREAWIDTH_B+XOCP_AREAWIDTH_C+XOCP_AREAWIDTH_D);
   
   define("XOCP_AREATYPE_A","A");
   define("XOCP_AREATYPE_B","B");
   define("XOCP_AREATYPE_C","C");
   define("XOCP_AREATYPE_D","D");
   define("XOCP_AREATYPE_AB","AB");
   define("XOCP_AREATYPE_BC","BC");
   define("XOCP_AREATYPE_CD","CD");
   define("XOCP_AREATYPE_ABC","ABC");
   define("XOCP_AREATYPE_BCD","BCD");
   define("XOCP_AREATYPE_ABCD","ABCD");

   define("XOCP_USERNOTFOUND",0);
   define("XOCP_WRONGPASSWORD",1);
   define("XOCP_USEROK",2);
   define("XOCP_USERINACTIVE",3);

   define("XOCP_BLOCK_INVISIBLE",0);
   define("XOCP_BLOCK_VISIBLE",1);

   // ############## Include common object class definition file ##############
   include_once(XOCP_DOC_ROOT."/class/xocpobject.php");
   include_once(XOCP_DOC_ROOT."/class/xocpuser.php");
   include_once(XOCP_DOC_ROOT."/class/xocpblock.php");

   // ############## Include common functions file ##############
   include_once(XOCP_DOC_ROOT."/include/functions.php");

   // #################### Include site-wide lang file ##################
   if ( file_exists(XOCP_DOC_ROOT."/language/".$xocpConfig['language'].".php") ) {
      include_once(XOCP_DOC_ROOT."/language/".$xocpConfig['language'].".php");
   } else {
      include_once(XOCP_DOC_ROOT."/language/english.php");
   }

   $xocp_vars['month_year'] = array('',_JAN, _FEB, _MAR, _APR, _MAY, _JUN, _JUL, _AUG, _SEP, _OCT, _NOV, _DEC);
   $xocp_vars['dayofweek'] = array(1 => _SUN, 2 => _MON, 3 => _TUE, 4 => _WED, 5 => _THU, 6 => _FRI, 7 => _SAT);
   $xocp_vars['gender'] = array('m' => _MALE, 'f' => _FEMALE);

   // #################### Connect to DB ##################
   include_once(XOCP_DOC_ROOT."/class/database/".$xocpConfig['database'].".php");

   if ( $xocpConfig['dbhost'] && isset($xocpConfig['dbuname']) && isset($xocpConfig['dbpass']) && $xocpConfig['dbname'] ) {
      $xocp_db = new Database();
//      if ( $xocpConfig['debug_mode'] ==1 ) {
//         $xocp_db->setDebug(true); 
//      }
      $xocp_db->setPrefix(XOCP_PREFIX);
      $xocp_db->connect($xocpConfig['dbhost'], $xocpConfig['dbuname'], $xocpConfig['dbpass'], $xocpConfig['dbname'], $xocpConfig['db_pconnect']);
   }


   // ############## Include common functions file ##############
   include_once(XOCP_DOC_ROOT."/class/textsanitizer.php");
   include_once(XOCP_DOC_ROOT."/class/xocpdatapage.php");

   // ############## Include html class generator file ##############
   include_once(XOCP_DOC_ROOT."/class/xocphtml.php");
   include_once(XOCP_DOC_ROOT."/class/form/xocpform.php");
   include_once(XOCP_DOC_ROOT."/class/xocplist.php");


   // ############## Include theme file ##############
   $xocp_theme = getTheme();
   include_once(XOCP_DOC_ROOT."/themes/".$xocp_theme."/theme.php");
   
   session_name("XOCPSID");
   session_save_path(XOCP_SESSION_SAVEPATH);
   session_start();
   session_register("xocp_user");
   session_register("xocp_page_id");
   session_register("xocp_groupname");
   


}

?>