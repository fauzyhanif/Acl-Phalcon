#!/usr/bin/perl

$tmpdir = "/var/www/html/xocp/cache/tmpdata";
$fileage = 3600;

opendir(DIR, "$tmpdir") or die "tmpdir error";
while (defined($file = readdir(DIR)))
{
   if((grep { /^\./ } $file) eq 0)
   {
      ($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,
      $atime,$mtime,$ctime,$blksize,$blocks) = lstat("$tmpdir/$file");
      $age = (time() - $atime);
#      print "$file - $age\n";
      system("/bin/rm -rf $tmpdir/$file") if ($age > $fileage);
   }
}
closedir(DIR);

exit 0;