<?

//echo "xxx";
$host="localhost";
$user="webkeu";
$pass="keu3375";
$db="session2";

include("class.mysql1.php");
$db=new MYSQL($host, $user, $pass, $db);


//======================MHS TIMOR===================
/*
$sql="select b.thn_akd as angkatan, a. nomhs as 'No Mhs',
    a.nomor_test as 'No Test' , a.nama_mhs as 'Nama Mhs',
    d.ps_ext_id as Jur, b.alamat 
    from xocp_akd_mhs a left join xocp_akd_pmb_cmhs b 
    on (a.nomor_test=b.nomor_test)
    left join xocp_akd_ps d
    on (a.psmhs_id=d.ps_id) 
    where  warganegara=3 
    order by thn_akd, ps_ext_id";
*/


//===========================ANGAKATAN 2004 =======================================
$sql="select s.nomhs, s.nama_mhs,d.ps_ext_id, 
    CASE cx.kelamin when 'm' then 'L' when 'f' then 'P' END, px.prokab_nm,
    concat(mx.alamat, ', ',px2.prokab_nm), s.sppvar 
    FROM xocp_akd_keu_reportall s left join xocp_akd_mhs mx using (nomhs) 
    left join xocp_akd_pmb_cmhs cx using(nomor_test) 
    left join xocp_akd_ps d on (mx.psmhs_id=d.ps_id) 
    left join xocp_akd_smu sx on (cx.asal_smu=sx.smu_cd) 
    left join xocp_akd_prokab px on (cx.almt_prokab=px.prokab_cd && px.prokab_cd!='') 
    left join xocp_akd_prokab px2 on (mx.almt_prokab=px2.prokab_cd && px2.prokab_cd!='') 
    WHERE s.keu_thn='2010' && (s.keu_ses_id='1010' or s.keu_ses_id='11') && 
    s.tetap!='' and mx.angkatan=2004 
    group by s.nomhs 
    ORDER BY s.nomhs asc";

//===================== SPP TETAP -===========================================

$sql="SELECT b.nomhs,b.nama_mhs,d.ps_ext_id as Jur, 
    DATE_FORMAT(a.trnsct_dttm,'%Y-%m-%d %H:%i:%S') AS Hari,a.no_kuitansi,a.jml_uang, 
    CASE tunai WHEN 1 THEN 'Tunai' WHEN 2 THEN 'nt' WHEN 3 THEN 'SPC BNI' ELSE 'Non tunai' END AS asdf 
    FROM xocp_akd_keu_trnsct a LEFT JOIN xocp_akd_mhs b 
    ON b.nomor_test = a.nomor_test AND b.org_id = a.org_id 
    left join xocp_akd_ps d on (b.psmhs_id=d.ps_id) 
    WHERE a.nomor_test IS NOT NULL AND a.org_id = '1' AND a.keu_thn = '2010' 
    AND a.keu_ses_id = '1010' AND a.bank_id = '10002' AND a.btl_ind = '0' 
    ";



$db->viewtable($sql,1);

?>