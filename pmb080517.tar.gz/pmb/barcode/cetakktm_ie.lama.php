<?php
include_once("./../config.php");
    $db = &Database::getInstance();
    $org_id = XOCP_ORGANIZATION_ID;

    $sql = "SELECT m.nomhs, m.nama_mhs, m.angkatan,"
      . " p.nama_fak, p.nama_ps, p.ps_ext_id,"
      . " m.alamat, m.almt_prokab, m.kode_pos,"
      . " concat(k.prokab_nm, ' ', m.kode_pos) AS alamat2"
      . " FROM ".XOCP_PREFIX."akd_mhs m"
//      . " LEFT JOIN ".XOCP_PREFIX."akd_pmb_cmhs c ON concat(c.thn_akd, '-', c.no_test_riil) = m.nomor_test"
      . " LEFT JOIN ".XOCP_PREFIX."akd_ps p ON m.psmhs_id=p.ps_id"
      . " LEFT JOIN ".XOCP_PREFIX."akd_prokab k ON m.almt_prokab=k.prokab_cd"
      . " WHERE m.org_id=$org_id AND m.nomhs='$nomhs'";
    $result = $db->query($sql); //echo $sql;
    list($nomhs,$nama_mhs,$angkatan,$nama_fak,$nama_ps,$ps_ext_id,
      $alamat1,$kode_kab,$kode_pos,$alamat2)=$db->fetchRow($result);
?>
<html>
<head>
<script language="JavaScript">
DA = (document.all) ? 1 : 0

function HandleError()
{
alert("\nNothing was printed. \n\nIf you do want to print this page, then\nclick on the printer icon in the toolbar above.")
return true;
}
</script>
</head>
<body onload="window.print()">
<?php
$w1=80; $w2=400;
$h=18;
echo "
<style>
td { font-family: Arial; font-size: 8pt; }
</style>
<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111'>
  <tr>
    <td width='$w1' height='$h'>&nbsp;</td>
    <td width='$w2' height='$h'>".ucwords(strtolower($nama_mhs))."</td>
  </tr>
  <tr>
    <td width='$w1' height='$h'>&nbsp;</td>
    <td width='$w2' height='$h'>".ucwords(strtolower($nomhs))."</td>
  </tr>
  <tr>
    <td width='$w1' height='$h'>&nbsp;</td>
    <td width='$w2' height='$h'>".ucwords(strtolower($nama_fak))."</td>
  </tr>
  <tr>
    <td width='$w1' height='$h'>&nbsp;</td>
    <td width='$w2' height='$h'>".ucwords(strtolower($nama_ps))."</td>
  </tr>
  <tr>
    <td width='$w1' height='$h'>&nbsp;</td>
    <td width='$w2' height='$h'>".$alamat1."<br>".ucwords(strtolower($alamat2))."</td>
  </tr>
</table>
<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111'>
  <tr>
    <td height='6'></td>
  </tr>
  <tr>
    <td><img src='./image.php?code=$nomhs&style=452&type=C128A&width=160&height=50&xres=1&font=1'></td>
  </tr>
</table>";
?>
<script language="VBScript">

Sub window_onunload()
On Error Resume Next
Set WB = nothing
On Error Goto 0
End Sub

Sub Print()
OLECMDID_PRINT = 6
OLECMDEXECOPT_DONTPROMPTUSER = 2
OLECMDEXECOPT_PROMPTUSER = 1


On Error Resume Next

If DA Then
call WB.ExecWB(OLECMDID_PRINT, OLECMDEXECOPT_DONTPROMPTUSER,1)

Else
call WB.IOleCommandTarget.Exec(OLECMDID_PRINT ,OLECMDEXECOPT_DONTPROMPTUSER,"","","")

End If

If Err.Number <> 0 Then
If DA Then
Alert("Nothing Printed :" & err.number & " : " & err.description)
Else
HandleError()
End if
End If
On Error Goto 0
End Sub

If DA Then
wbvers="8856F961-340A-11D0-A96B-00C04FD705A2"
Else
wbvers="EAB22AC3-30C1-11CF-A7EB-0000C05BAE0B"
End If

document.write "<object ID=""WB"" WIDTH=0 HEIGHT=0 CLASSID=""CLSID:"
document.write wbvers & """> </object>"
</script>
<!--<script>
window.close();
</script>-->

</body>
</html>