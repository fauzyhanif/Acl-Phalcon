<html>
<head>
	<title>Barcode home page</title>
</head>
<body bgcolor="#FFFFCC">
<table align='center'>
 <tr>
  <td><img src="home.png" border="1"></td>
  <td><a href="sample.php"><img src="sample.png" border="0"></a></td>
  <td><a href="download.php"><img src="download.png" border="0"></a></td>
 </tr>
</table>
<br><br>
<table align="center" width="640">
 <tr><td> Barcode is a small implementation of a barcode rendering class using the <a target="_blank" href="http://www.php.net">PHP</a> language and <a target="_blank" href="http://www.boutell.com/gd/">GD graphics library</a>.</td></tr>
 <tr><td><br></td></tr>
 <tr><td><br></td></tr>
 <tr><td>For any question, please send an email to <a href="mailto:barcode@mribti.com">barcode@mribti.com</a></td></tr>
</table>
<br><br>
<table align="center">
<tr>
 <td align="center"><A href="http://sourceforge.net"><IMG src="http://sourceforge.net/sflogo.php?group_id=25228" width="88" height="31" border="0" alt="SourceForge Logo"></A></td>
</tr>
<tr>
 <td></td>
</tr>
</table>
</body>
</html>
