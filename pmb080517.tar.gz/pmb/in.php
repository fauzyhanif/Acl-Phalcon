<?
echo phpinfo();
?>