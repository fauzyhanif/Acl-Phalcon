<?php
//--------------------------------------------------------------------//
// Filename : index.php                                               //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-13                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

//ob_start();

//ini_set("session.auto_start",0);

include_once('config.php');


if(!is_object($xocp_user)) {
   $xocp_user = new XocpUser(0); // set to guest user
   $xocp_page_id = $xocp_user->getVar("startpage");
}

catchPage();

if ($xocp_user->getVar("user_id") == 0) {
//   $xocp_page_id = "";
}

if ( trim($xocp_page_id) == "") {
   $xocp_page_id = $xocpConfig['startpage'];
}

$html = new XocpHTML();

if(!file_exists(XOCP_DOC_ROOT."/cache/pages/".$xocp_page_id.".php")) {
   $html->pageFromDatabase($xocp_page_id);
} else {
   $html->pageFromFile(XOCP_DOC_ROOT."/cache/pages/".$xocp_page_id);
}

//ob_end_clean();

$html->out();

//echo "<pre>";
//echo session_save_path();
//echo "</pre>";

//echo $HTTP_SESSION_VARS["xocp_page_id"];

?>