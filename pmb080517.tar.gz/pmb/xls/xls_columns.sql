-- MySQL dump 10.9
--
-- Host: 192.168.2.3    Database: feupnAKD
-- ------------------------------------------------------
-- Server version	4.1.7-standard

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `xls_columns`
--

DROP TABLE IF EXISTS `xls_columns`;
CREATE TABLE `xls_columns` (
  `db_name` char(50) NOT NULL default '',
  `tbl_name` char(50) NOT NULL default '',
  `col_name` char(50) NOT NULL default '',
  `col_alias` char(255) NOT NULL default '',
  PRIMARY KEY  (`db_name`,`tbl_name`,`col_name`)
) ENGINE=MyISAM;

--
-- Dumping data for table `xls_columns`
--


/*!40000 ALTER TABLE `xls_columns` DISABLE KEYS */;
LOCK TABLES `xls_columns` WRITE;
INSERT INTO `xls_columns` VALUES ('feupnAKD','mhs','nomhs','NIM'),('feupnAKD','ps','ps_id','ps_id'),('feupnAKD','mhs','nama','Nama'),('feupnAKD','ps','nama_ps','Program Studi'),('feupnAKD','mhs','psmhs_id','psmhs_id'),('feupnAKD','krs','nomhs','NIM'),('feupnAKD','krs','psmhs_id','Program Studi'),('feupnAKD','mku','ps_id','ps_id'),('feupnAKD','mku','kode_mk','Kode_MK'),('feupnAKD','krs','nilai','Nilai'),('feupnAKD','krs','thn_akd','Tahun Akademik'),('feupnAKD','krs','session_id','Semester'),('feupnAKD','krs','kode_mk','Kode MK'),('feupnAKD','krs','thn_kur','Kurikulum'),('feupnAKD','mku','thn_kur','Kurikulum'),('feupnAKD','rekapsemester','thn_akd','Thn_Akd'),('feupnAKD','rekapsemester','session_id','Sem'),('feupnAKD','rekapsemester','skssem','Sks_Sem'),('feupnAKD','rekapsemester','sksriil','Sks_Sem_Riil'),('feupnAKD','rekapsemester','skskum','Sks_Kum'),('feupnAKD','rekapsemester','ips','IPS'),('feupnAKD','rekapsemester','ipk','IPK'),('feupnAKD','mhs','kelamin','Kelamin'),('feupnSDM','sdm','nip','NIP'),('feupnSDM','sdm','gelar','Gelar'),('feupnSDM','sdm','nama','Nama'),('feupnSDM','sdm','kelp','Klp'),('feupnSDM','sdm','kelamin','Kelamin'),('feupnSDM','sdm','alias0','Kode_SDM'),('feupnSDM','sdm','kode_agama','Kd_Agama'),('feupnSDM','sdm','gol_darah','Gol_Darah'),('feupnSDM','sdm','alamat','Alamat'),('feupnSDM','sdm','kode_kota','Kota'),('feupnSDM','sdm','kode_prop','Propinsi'),('feupnSDM','sdm','kodepos','Kd_Pos'),('feupnSDM','sdm','telpon','Telpon'),('feupnSDM','sdm','e_mail','email'),('feupnAKD','mku','nama','Nama'),('feupnAKD','mku','sem','Sem'),('feupnAKD','mku','sks','Sks'),('feupnAKD','mku','kelp','Kelompok'),('feupnAKD','mku','jenis','Jenis'),('feupnAKD','mku','kodemk','Kode_Lain');
UNLOCK TABLES;
/*!40000 ALTER TABLE `xls_columns` ENABLE KEYS */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

