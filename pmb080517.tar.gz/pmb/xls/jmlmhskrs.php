<? mysql_connect("192.168.200.110","root","");
   mysql_select_db("ftmupnAKD");
   $A=mysql_query("select  count(distinct(nomhs)) from krsol where thn_akd=2010 && session_id='2r'");
   while (list($jmlmhs)=mysql_fetch_row($A)) {
   echo "jml mhs krs FTM : $jmlmhs ;<br>";
   }
   mysql_connect("192.168.200.120","keuangan","TtjrWyfEApNMAyxG");
   mysql_select_db("tiupnAKD");
   $A=mysql_query("select  count(distinct(nomhs)) from krsol where thn_akd=2010 && session_id='2r'");
   while (list($jmlmhs2)=mysql_fetch_row($A)) {
   echo "jml mhs krs FTI : $jmlmhs2 ;<br>";
   }
   mysql_connect("192.168.200.122","root","");
   mysql_select_db("tiupnAKD");
   $A=mysql_query("select  count(distinct(nomhs)) from krsol where thn_akd=2010 && session_id='2r'");
   while (list($jmlmhs3)=mysql_fetch_row($A)) {
   echo "jml mhs krs FTI2 : $jmlmhs3 ;<br>";
      }
   mysql_connect("192.168.200.130","root","");
   mysql_select_db("fpupnAKD");
   $A=mysql_query("select  count(distinct(nomhs)) from krsol where thn_akd=2010 && session_id='2r'");
   while (list($jmlmhs4)=mysql_fetch_row($A)) {
   echo "jml mhs krs FP : $jmlmhs4 ;<br>";
      }
   mysql_connect("192.168.200.140","root","");
   mysql_select_db("feupnAKD");
   $A=mysql_query("select  count(distinct(nomhs)) from krsol where thn_akd=2010 && session_id='2r'");
   while (list($jmlmhs5)=mysql_fetch_row($A)) {
   echo "jml mhs krs FE : $jmlmhs5 ;<br>";
      }
      
         mysql_connect("192.168.200.150","root","");
   mysql_select_db("fisipupnAKD");
   $A=mysql_query("select  count(distinct(nomhs)) from krsol where thn_akd=2010 && session_id='2r'");
   while (list($jmlmhs6)=mysql_fetch_row($A)) {
   echo "jml mhs krs FISIP : $jmlmhs6 ;<br>";
      }
    echo "selesai!!";
?>