<?php
$ret="";

$Q="mysql_query";
$R="mysql_fetch_row";

$thn_akd="2009";
$session_id="1";

$keu_thn="2009";
$keu_ses_id="1010";
$akode_byr="'5003012'";

if (mysql_connect("192.168.200.110","root","")) {
//echo "Ok"; } else { echo "Fail";
}
mysql_select_db("ftmupnAKD");
$A=$Q("select nomhs,psmhs_id,sum(sks) from krsol
where thn_akd='$thn_akd' and session_id='$session_id' and st_ambil!='w'
group by nomhs, psmhs_id");
while (list($f0,$f1,$f2)=$R($A)) {
  $asks0[$f0]=$f2;
}
//print_r($asks0);


if (mysql_connect("192.168.200.130","root","")) {
//echo "Ok"; } else { echo "Fail";
}
mysql_select_db("fpupnAKD");
$A=$Q("select nomhs,psmhs_id,sum(sks) from krsol
where thn_akd='$thn_akd' and session_id='$session_id' and st_ambil!='w'
group by nomhs, psmhs_id");
while (list($f0,$f1,$f2)=$R($A)) {
  $asks0[$f0]=$f2;
}
//print_r($asks0);

if (mysql_connect("192.168.200.140:33000","root","")) {
//echo "Ok"; } else { echo "Fail";
}
mysql_select_db("feupnAKD");
$A=$Q("select nomhs,psmhs_id,sum(sks) from krsol
where thn_akd='$thn_akd' and session_id='$session_id' and st_ambil!='w'
group by nomhs, psmhs_id");
while (list($f0,$f1,$f2)=$R($A)) {
  $asks0[$f0]=$f2;
}
//print_r($asks0);

if (mysql_connect("192.168.200.150","root","")) {
//echo "Ok"; } else { echo "Fail";
}
mysql_select_db("fisipupnAKD");
$A=$Q("select nomhs,psmhs_id,sum(sks) from krsol
where thn_akd='$thn_akd' and session_id='$session_id' and st_ambil!='w'
group by nomhs, psmhs_id");
while (list($f0,$f1,$f2)=$R($A)) {
  $asks0[$f0]=$f2;
}
//print_r($asks0);

if (mysql_connect("192.168.200.120","keuangan","TtjrWyfEApNMAyxG")) {
//echo "Ok"; } else { echo "Fail";
}
mysql_select_db("tiupnAKD");
$A=$Q("select nomhs,psmhs_id,sum(sks) from krsol
where thn_akd='$thn_akd' and session_id='$session_id' and st_ambil!='w'
group by nomhs, psmhs_id");
while (list($f0,$f1,$f2)=$R($A)) {
  $asks0[$f0]=$f2;
}
//print_r($asks0);

if (mysql_connect("192.168.200.122","root","")) {
//echo "Ok"; } else { echo "Fail";
}
mysql_select_db("tiupnAKD");
$A=$Q("select nomhs,psmhs_id,sum(sks) from krsol
where thn_akd='$thn_akd' and session_id='$session_id' and st_ambil!='w'
group by nomhs, psmhs_id");
while (list($f0,$f1,$f2)=$R($A)) {
  $asks0[$f0]=$f2;
}
//print_r($asks0);



mysql_connect("localhost","root","");
mysql_select_db("session2");
//$Q="mysql_query";
//$R="mysql_fetch_row";
//$keu_thn="2009";
//$keu_ses_id="12%";




unset($a10); unset($a11);
$A=$Q("select psmhs_id, golongan_cd, target_mhs, kode_byr, jml_uang from
xocp_akd_keu_seskwjbdtl
where org_id='1' and keu_thn='$keu_thn' and keu_ses_id like '$keu_ses_id' and
kode_byr in ($akode_byr)");
while (list($f0,$f1,$f2,$f3,$f4)=$R($A)) {
  list($v0,$v1)=explode("/",$f2);
  //echo $v0.",".substr($v0,0,4).",".substr($v0,8,1)."<br>";
  if (substr($v0,0,4)=="-*,(" and substr($v0,8,1)==")") {
    //echo substr($v0,4,4)."<br>";
    $i=substr($v0,4,4);
    //echo "$f0,$f1,$i,$v1,$f3,$f4<br>";
    $a10["$f0|$f1|$i|$v1"][$f3]=$f4;
    $a11[$i]="'$i'";
  } else {
    //echo "$f0,$f1,$v0,$v1,$f3,$f4<br>";
    if (substr($v0,0,4)=="-*,(" and substr($v0,8,2)==".." and
substr($v0,14,1)==")") {
      //echo substr($v0,4,4).",".substr($v0,10,4)."<br>";
      for ($i=substr($v0,4,4); $i<=substr($v0,10,4); $i++) {
        //echo "$f0,$f1,$i,$v1,$f3,$f4<br>";
        $a10["$f0|$f1|$i|$v1"][$f3]=$f4;
        $a11[$i]="'$i'";
      }
    } else {

      //echo "$f0,$f1,$v0,$v1,$f3,$f4<br>";

    }
  }
  //echo "$f0,$f1,$v0,$v1,$f3,$f4<br>";
}

//print_r($a10);




$A=$Q("select keu_ses_nm from xocp_akd_keu_defses where org_id='1' and keu_ses_id
like '$keu_ses_id'");
list($nama_sesi)=$R($A);
//$ret.=$nama_sesi;

unset($a0);
$A=$Q("select kode_byr, nomor_test, jml_byr  from xocp_akd_keu_trnsctdtl
  where org_id='1' and btl_ind='0' and keu_thn='$keu_thn' and keu_ses_id
like '$keu_ses_id'
and jml_byr>0
  #group by kode_byr
");
while (list($f0,$f1,$f2)=$R($A)) {
  if ("$f0"=="5003011" or "$f0"=="5003012" or "$f0"=="5003021" or "$f0"=="5003022" or "$f0"=="5003031") { $f0="5003"; } else {
    if ("$f0"=="5004011" or "$f0"=="5004021" or "$f0"=="5004031" or "$f0"=="5004041") { $f0="5004"; } else {
    }
  }
  $a0[$f1][$f0]=$f2;
  //$ret.=$f0."<br>";
}
//$ret.=count($a0);

$Q("truncate table xocp_akd_keu_mhstemp");
foreach ($a0 as $k0 => $n0) {
  $Q("insert into xocp_akd_keu_mhstemp (nomor_test) values ('$k0')");
}

unset($a1);
$a1["5001001"]="dp";
$a1["5001"]="dpp";
$a1["5001061"]="dppr";
$a1["5002011"]="tetap";
$a1["5002021"]="her";
$a1["5002031"]="upk";
$a1["5003"]="sppvar";
$a1["5005"]="denda";
$a1["5002015"]="kenaikanln";
$a1["5004"]="wisuda";

$Q("delete from xocp_akd_keu_reportall where keu_thn='$keu_thn' and
keu_ses_id like '$keu_ses_id'");

$A=$Q("select a.nomor_test, b.psmhs_id, c.nama_ps, b.nomhs, b.nama_mhs,
b.angkatan, b.golongan_cd, mid(a.nomor_test,7,1),count(nomhs) from xocp_akd_keu_mhstemp a
  left join xocp_akd_mhs b on b.nomor_test=a.nomor_test 
  left join xocp_akd_ps c on c.ps_id=b.psmhs_id
  left join xocp_akd_cetakartu k on k.nomhs=b.nomhs
  where k.keu_thn=$keu_thn && k.keu_ses_id=$keu_ses_id
");

while (list($f1,$f2,$f3,$f4,$f5,
$f6,$f7,$f8,$f9)=$R($A)) {
  //$ret.=$f1."<br>";

$jml_kwjb=0;
if (count($a10["$f2|$f7|$f6|$f8"])>0) {
    foreach ($a10["$f2|$f7|$f6|$f8"] as $k0 => $n0) {
      $jml_kwjb=$n0;
    }
}

  unset($a2); unset($a3);
  foreach ($a0[$f1] as $k0 => $n0) {
    $a2[]=$a1[$k0];
    $a3[]="'$n0'";
  }
  $Q("insert into xocp_akd_keu_reportall
(keu_thn,keu_ses_id,nama_sessi,ktmstatus,psmhs_id,nama_jurusan,nomhs,nomor_test,nama_mhs,angkatan,sks,kwjbvar,golongan_cd,pmbses,".implode(",",$a2).")
  values
('$keu_thn','$keu_ses_id','$nama_sesi','f9','$f2','$f3','$f4','$f1','$f5','$f6','$asks0[$f4]','$jml_kwjb','$f7','$f8',".implode(",",$a3).")");
}

echo $ret;
?>
