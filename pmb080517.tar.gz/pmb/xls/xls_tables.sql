-- MySQL dump 10.9
--
-- Host: 192.168.2.3    Database: feupnAKD
-- ------------------------------------------------------
-- Server version	4.1.7-standard

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `xls_tables`
--

DROP TABLE IF EXISTS `xls_tables`;
CREATE TABLE `xls_tables` (
  `db_name` char(50) NOT NULL default '',
  `tbl_name` char(50) NOT NULL default '',
  `tbl_alias` char(255) NOT NULL default '',
  PRIMARY KEY  (`db_name`,`tbl_name`)
) ENGINE=MyISAM ;

--
-- Dumping data for table `xls_tables`
--


/*!40000 ALTER TABLE `xls_tables` DISABLE KEYS */;
LOCK TABLES `xls_tables` WRITE;
INSERT INTO `xls_tables` VALUES ('feupnAKD','mku','Data Kurikulum'),('feupnAKD','ps','Data Program Studi'),('feupnAKD','mhs','Data Mahasiswa'),('feupnAKD','session','Data Sesi'),('feupnAKD','krs','Data KHS'),('feupnAKD','rekap','Data IPK'),('feupnAKD','rekapsemester','Data Rekap IPS'),('feupnSDM','sdm','Database SDM-Dosen FE');
UNLOCK TABLES;
/*!40000 ALTER TABLE `xls_tables` ENABLE KEYS */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

