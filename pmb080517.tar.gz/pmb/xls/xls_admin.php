<html>
<head>
<link rel=stylesheet type="text/css" href="/style.css">
</head>
<body bgcolor=#ffffff>
<center><font id=f12pt><br><b>
PENGATURAN ALIAS</b></font>
<hr noshade size=1></center>
<?
require('config.inc');

function showdb() {
global $db1,$PHP_SELF;

echo "
<center>
<form action=$PHP_SELF method=post>
DAFTAR BASISDATA<br>
<table border=0 cellpadding=4 cellspacing=1 bgcolor=#ffffff>
   <tr>
      <td id=onblack>&nbsp;</td>
      <td id=onblack>NAMA BASISDATA</td>
      <td id=onblack>ALIAS</td>
      <td id=onblack>JUMLAH TABEL</td>
   </tr>";

$cmd = "select a.db_name,
               a.db_alias,
               count(b.tbl_name)
          from xls_databases a
          left join xls_tables b using (db_name)
          group by a.db_name,a.db_alias";
//echo $cmd;
$result = mysql_db_query($db1,$cmd);
if(mysql_num_rows($result)>0) {
   while(list($db_name,$db_alias,$tbl_count)=mysql_fetch_row($result)) {
      echo "
   <tr bgcolor=#dddddd>
      <td align=right><input type=checkbox name=db_names[] value=$db_name></td>
      <td><a href=$PHP_SELF?editdb=y&db_name=$db_name>$db_name</a></td>
      <td>$db_alias</td>
      <td align=right>$tbl_count</td>
   </tr>";
      $i++;
   }
} else {
   echo "
   <tr bgcolor=#dddddd>
      <td colspan=4>TIDAK ADA DATA</td>
   </tr>";
}
echo "
</table>
<br><input type=submit name=tambdb value=' TAMBAH/UBAH '>&nbsp;
<input type=submit name=hapusdb value=' HAPUS '><br><br>
</form></center>";
}

function adddb($comment = "") {
global $db1,$PHP_SELF;

echo "
<center>
<form action=$PHP_SELF method=post>
TAMBAH/UBAH ALIAS BASISDATA<br>
<table border=0 cellpadding=4 cellspacing=1 bgcolor=#ffffff>
   <tr>
      <td id=onblack align=right>Nama Basisdata:</td>
      <td bgcolor=#dddddd>
         <select name=db_name>";
$result = mysql_list_dbs();
if(($c = mysql_num_rows($result)) > 0) {
   for ($i = 0;$i < $c;$i++) {
      $db_name = mysql_db_name($result,$i);
      echo "
            <option value='$db_name'>$db_name</option>";
   }
}
   echo "
         </select>
      </td>
   </tr>
   <tr>
      <td id=onblack align=right>Alias:</td>
      <td bgcolor=#dddddd><input type=text name=db_alias size=50 maxlength=255></td>
   </tr>
   <tr>
      <td bgcolor=#dddddd colspan=2 align=center>
         <input type=submit name=simpandb value=' SIMPAN '>&nbsp;
         <input type=submit name=bataldb value=' BATAL '>
      </td>
   </tr>";
if ($comment != "") {
   echo "
   <tr>
      <td bgcolor=#dddddd colspan=2 align=left>
         $comment
      </td>
   </tr>";
}
echo "
</table>
</form></center>";
}

function showtbl($db_name = "") {
global $db1,$PHP_SELF;

if ($db_name == "") {
   showdb();
   return;
}

echo "
<center>
<form action=$PHP_SELF method=post>
NAMA BASISDATA: $db_name<br><br>
DAFTAR TABEL<br>
<table border=0 cellpadding=4 cellspacing=1 bgcolor=#ffffff>
   <tr>
      <td id=onblack>&nbsp;</td>
      <td id=onblack>NAMA TABEL</td>
      <td id=onblack>ALIAS</td>
      <td id=onblack>JUMLAH KOLOM</td>
   </tr>";

$cmd = "select a.tbl_name,
               a.tbl_alias,
               count(b.col_name)
          from xls_tables a
          left join xls_columns b using (db_name,tbl_name)
          where a.db_name = '$db_name'
          group by a.tbl_name,a.tbl_alias";

$result = mysql_db_query($db1,$cmd);
if(mysql_num_rows($result)>0) {
   while(list($tbl_name,$tbl_alias,$col_count)=mysql_fetch_row($result)) {
      echo "
   <tr bgcolor=#dddddd>
      <td align=right><input type=checkbox name=tbl_names[] value=$tbl_name></td>
      <td><a href=$PHP_SELF?edittbl=y&db_name=$db_name&tbl_name=$tbl_name>$tbl_name</a></td>
      <td>$tbl_alias</td>
      <td align=right>$col_count</td>
   </tr>";
      $i++;
   }
} else {
   echo "
   <tr bgcolor=#dddddd>
      <td colspan=4>TIDAK ADA DATA</td>
   </tr>";
}
echo "
</table>
<br><input type=submit name=tambtbl value=' TAMBAH/UBAH '>&nbsp;
<input type=submit name=hapustbl value=' HAPUS '>&nbsp;
<input type=submit name=bataldb value=' BATAL '>
<input type=hidden name=db_name value='$db_name'><br><br>
</form></center>";
}

function addtbl($db_name,$comment = "") {
global $db1,$PHP_SELF;

echo "
<center>
<form action=$PHP_SELF method=post>
TAMBAH/UBAH ALIAS TABEL<br>
<table border=0 cellpadding=4 cellspacing=1 bgcolor=#ffffff>
   <tr>
      <td id=onblack align=right>Nama Basisdata:</td>
      <td bgcolor=#dddddd>
         $db_name
         <input type=hidden name=db_name value='$db_name'>
      </td>
   </tr>
   <tr>
      <td id=onblack align=right>Nama Tabel:</td>
      <td bgcolor=#dddddd>
         <select name=tbl_name>";
$result = mysql_list_tables($db_name);
if(($c = mysql_num_rows($result)) > 0) {
   for ($i = 0;$i < $c;$i++) {
      $tbl_name = mysql_tablename($result,$i);
      echo "
            <option value='$tbl_name'>$tbl_name</option>";
   }
}
   echo "
         </select>
      </td>
   </tr>
   <tr>
      <td id=onblack align=right>Alias:</td>
      <td bgcolor=#dddddd><input type=text name=tbl_alias size=50 maxlength=255></td>
   </tr>
   <tr>
      <td bgcolor=#dddddd colspan=2 align=center>
         <input type=submit name=simpantbl value=' SIMPAN '>&nbsp;
         <input type=submit name=bataltbl value=' BATAL '>
      </td>
   </tr>";
if ($comment != "") {
   echo "
   <tr>
      <td bgcolor=#dddddd colspan=2 align=left>
         $comment
      </td>
   </tr>";
}
echo "
</table>
</form></center>";
}

function showcol($db_name = "",$tbl_name = "") {
global $db1,$PHP_SELF;

if ($db_name == "") {
   showdb();
   return;
}

if ($tbl_name == "") {
   showtbl($db_name);
   return;
}

echo "
<center>
<form action=$PHP_SELF method=post>
NAMA BASISDATA: $db_name<br>NAMA TABEL: $tbl_name<br><br>
DAFTAR KOLOM<br>
<table border=0 cellpadding=4 cellspacing=1 bgcolor=#ffffff>
   <tr>
      <td id=onblack>&nbsp;</td>
      <td id=onblack>NAMA KOLOM</td>
      <td id=onblack>ALIAS</td>
   </tr>";

$cmd = "select col_name,
               col_alias
          from xls_columns
          where db_name = '$db_name' and tbl_name = '$tbl_name'";

$result = mysql_db_query($db1,$cmd);
if(mysql_num_rows($result)>0) {
   $i = 1;
   while(list($col_name,$col_alias)=mysql_fetch_row($result)) {
      echo "
   <tr bgcolor=#dddddd>
      <td align=right><input type=checkbox name=col_names[] value=$col_name></td>
      <td><a href=$PHP_SELF?editcol=y&db_name=$db_name&tbl_name=$tbl_name&col_name=$col_name>$col_name</a></td>
      <td>$col_alias</td>
   </tr>";
      $i++;
   }
} else {
   echo "
   <tr bgcolor=#dddddd>
      <td colspan=4>TIDAK ADA DATA</td>
   </tr>";
}
echo "
</table>
<br><input type=submit name=tambcol value=' TAMBAH/UBAH '>&nbsp;
<input type=submit name=hapuscol value=' HAPUS '>&nbsp;
<input type=submit name=bataltbl value=' BATAL '>
<input type=hidden name=db_name value='$db_name'>
<input type=hidden name=tbl_name value='$tbl_name'><br><br>
</form></center>";
}

function addcol($db_name,$tbl_name,$comment = "") {
global $db1,$PHP_SELF;

      $result = mysql_list_fields($db_name,$tbl_name);
      echo "mysql _ list _ fields($db_name,$tbl_name)";
      $d = mysql_num_fields($result);
      echo "$d";

echo "
<center>
<form action=$PHP_SELF method=post>
TAMBAH/UBAH ALIAS KOLOM<br>
<table border=0 cellpadding=4 cellspacing=1 bgcolor=#ffffff>
   <tr>
      <td id=onblack align=right>Nama Basisdata:</td>
      <td bgcolor=#dddddd>
         $db_name
         <input type=hidden name=db_name value='$db_name'>
      </td>
   </tr>
   <tr>
      <td id=onblack align=right>Nama Tabel:</td>
      <td bgcolor=#dddddd>
         $tbl_name
         <input type=hidden name=tbl_name value='$tbl_name'>
      </td>
   </tr>
   <tr>
      <td id=onblack align=right>Nama Kolom:</td>
      <td bgcolor=#dddddd> fdfsd
         <select name=col_name>";

if(($c = mysql_num_fields($result)) > 0) {
   for ($i = 0;$i < $c;$i++) {
      $col_name = mysql_field_name($result,$i);
      echo "
            <option value='$col_name'>$col_name</option>";
   }
}
   print_r($result);
   echo "
         </select>

      </td>
   </tr>
   <tr>
      <td id=onblack align=right>Alias:</td>
      <td bgcolor=#dddddd><input type=text name=col_alias size=50 maxlength=255></td>
   </tr>
   <tr>
      <td bgcolor=#dddddd colspan=2 align=center>
         <input type=submit name=simpancol value=' SIMPAN '>&nbsp;
         <input type=submit name=batalcol value=' BATAL '>
      </td>
   </tr>";
if ($comment != "") {
   echo "
   <tr>
      <td bgcolor=#dddddd colspan=2 align=left>
         $comment
      </td>
   </tr>";
}
echo "
</table>
</form></center>";
}

mysql_connect($dbhost,$dbuser,$dbpassowrd);

if($tambdb != '') {
   adddb();
} elseif ($simpandb != '' || ($db_name != "" && isset($db_alias) && !isset($bataldb))) {
   if ($db_name != '' && $db_alias != '') {
      $sql = "replace into xls_databases (db_name,db_alias) values ('$db_name','$db_alias')";
      $result = mysql_db_query($db1,$sql);
      adddb("Sukses");
   } else {
      adddb("Anda harus memilih basisdata dan mengisikan alias!");
   }
} elseif ($bataldb != '') {
   showdb();
} elseif ($hapusdb != '') {
   if (count($db_names) > 0) {
      $d = implode("','",$db_names);
      $d = "'$d'";
      $sql = "delete from xls_databases where db_name in ($d)";
      mysql_db_query($db1,$sql);
      $sql = "delete from xls_tables where db_name in ($d)";
      mysql_db_query($db1,$sql);
      $sql = "delete from xls_columns where db_name in ($d)";
      mysql_db_query($db1,$sql);
   }
   showdb();
} elseif ($editdb == 'y') {
   showtbl($db_name);
} elseif ($tambtbl != '') {
   addtbl($db_name);
} elseif ($simpantbl != '' || ($db_name != "" && $tbl_name != "" && isset($tbl_alias) && !isset($bataltbl))) {
   if ($db_name != '' && $tbl_name != '' && $tbl_alias != '') {
      $sql = "replace into xls_tables (db_name,tbl_name,tbl_alias) values ('$db_name','$tbl_name','$tbl_alias')";
      $result = mysql_db_query($db1,$sql);
      addtbl($db_name,"Sukses");
   } else {
      addtbl($db_name,"Anda harus memilih tabel dan mengisikan alias!");
   }
} elseif ($bataltbl != '') {
   showtbl($db_name);
} elseif ($hapustbl != '') {
   if (count($tbl_names) > 0) {
      $d = implode("','",$tbl_names);
      $d = "'$d'";
      $sql = "delete from xls_tables where db_name = '$db_name' and tbl_name in ($d)";
      mysql_db_query($db1,$sql);
      $sql = "delete from xls_columns where db_name = '$db_name' and tbl_name in ($d)";
      mysql_db_query($db1,$sql);
   }
   showtbl($db_name);
} elseif ($edittbl == 'y') {
   showcol($db_name,$tbl_name);
} elseif ($tambcol != '') {
   addcol($db_name,$tbl_name);
} elseif ($tambcol != '' && $col_name != '') {
  echo "disini";
} elseif ($simpancol != '' || ($db_name != "" && $tbl_name != "" && $col_name != "" && isset($col_alias) && !isset($batalcol))) {
   if ($db_name != '' && $tbl_name != '' && $col_name != '' && $col_alias != '') {
      $sql = "replace into xls_columns (db_name,tbl_name,col_name,col_alias) values ('$db_name','$tbl_name','$col_name','$col_alias')";
      $result = mysql_db_query($db1,$sql);
      addcol($db_name,$tbl_name,"Sukses");
   } else {
      addcol($db_name,$tbl_name,"Anda harus memilih tabel dan mengisikan alias!");
   }
} elseif ($batalcol != '') {
   showcol($db_name,$tbl_name);
} elseif ($hapuscol != '') {
   if (count($col_names) > 0) {
      $d = implode("','",$col_names);
      $d = "'$d'";
      $sql = "delete from xls_columns where db_name = '$db_name' and tbl_name = '$tbl_name' and col_name in ($d)";
      mysql_db_query($db1,$sql);
   }
   showcol($db_name,$tbl_name);
} else showdb();

?>
</body>
</html>
