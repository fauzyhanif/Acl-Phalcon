<?php

require('config.inc');
require('Workbook.php');
require('Worksheet.php');

// Print HTML header
function printhtmlhead() {
echo "
<html>
<head>
<link rel=stylesheet type=\"text/css\" href=\"/style.css\">
</head>
<body bgcolor=#ffffff>
<center><font id=f12pt><br><b>
QUERY MS-EXCEL</b></font>
<hr noshade size=1></center>";
}

// Pilih basisdata
function selectdb() {
global $db1,$PHP_SELF;

$data = "
<center>
<form action=$PHP_SELF method=post>
PILIH BASISDATA<br>
<table border=0 cellpadding=4 cellspacing=1 bgcolor=#ffffff>
   <tr>
      <td id=onblack>ALIAS</td>
      <td id=onblack>JUMLAH TABEL</td>
   </tr>";

// Tampilkan semua alias basisdata yang mempunyai tabel
$cmd = "select a.db_name,
               a.db_alias,
               count(b.tbl_name)
          from xls_databases a
          left join xls_tables b using (db_name)
          group by a.db_name,a.db_alias
          having count(b.tbl_name) > 0
          order by a.db_name";
//echo $cmd;

$result = mysql_db_query($db1,$cmd);
$c = mysql_num_rows($result);
if ($c == 1) {  // Hanya ada 1 basisdata? Langsung ke pilih tabel
   list($db_name,$db_alias,$tbl_count) = mysql_fetch_row($result);
   selecttbl($db_name);
   return;
} elseif ($c > 0) {
   while(list($db_name,$db_alias,$tbl_count)=mysql_fetch_row($result)) {
      $data .= "
   <tr bgcolor=#dddddd>
      <td><a href=$PHP_SELF?slctbl=y&db_name=$db_name>$db_alias</a></td>
      <td align=right>$tbl_count</td>
   </tr>";
   }
} else {
   $data .= "
   <tr bgcolor=#dddddd>
      <td colspan=4>TIDAK ADA ALIAS BASISDATA</td>
   </tr>";
}
printhtmlhead();
echo "$data
</table>
</form></center>";
}

// Pilih tabel
function selecttbl($db_name = "",$comment = "") {
global $db1,$PHP_SELF;

if ($db_name == "") {
   selectdb();
   return;
}

$cmd = "select a.db_name,
               a.db_alias
          from xls_databases a
          where a.db_name = '$db_name'";
$result = mysql_db_query($db1,$cmd);
list($db_name,$db_alias) = mysql_fetch_row($result);

printhtmlhead();
echo "
<center>
<form action=$PHP_SELF method=post>
ALIAS BASISDATA: $db_alias<br><br>$comment<br>
PILIH TABEL<br>
<table border=0 cellpadding=4 cellspacing=1 bgcolor=#ffffff>
   <tr>
      <td id=onblack>&nbsp;</td>
      <td id=onblack>ALIAS</td>
      <td id=onblack>JUMLAH KOLOM</td>
   </tr>";

// Tampilkan tabel pada basisdata terpilih
$cmd = "select a.tbl_name,
               a.tbl_alias,
               count(b.col_name)
          from xls_tables a
          left join xls_columns b using (db_name,tbl_name)
          where a.db_name = '$db_name'
          group by a.tbl_name,a.tbl_alias
          having count(b.col_name) > 0
          order by a.tbl_name";

$result = mysql_db_query($db1,$cmd);
if(mysql_num_rows($result)>0) {
   while(list($tbl_name,$tbl_alias,$col_count)=mysql_fetch_row($result)) {
      echo "
   <tr bgcolor=#dddddd>
      <td align=right><input type=checkbox name=tbl_names[] value=$tbl_name></td>
      <td>$tbl_alias</td>
      <td align=right>$col_count</td>
   </tr>";
   }
} else {
   echo "
   <tr bgcolor=#dddddd>
      <td colspan=4>TIDAK ADA DATA</td>
   </tr>";
}
echo "
</table>
<br><input type=submit name=slcdb value=' << KEMBALI '>&nbsp;
<input type=submit name=slccol value=' LANJUTKAN >> '>
<input type=hidden name=db_name value='$db_name'><br><br>
</form></center>";
querytemplate($db_name);
}

// Pilih kolom
function selectcol($db_name = "",$tbl_names,$comment = "") {
global $db1,$PHP_SELF;

if ($tbl_names == NULL || count($tbl_names) == 0) {
   selecttbl($db_name,"Anda harus memilih minimal 1 alias tabel!");
   return;
}

$cmd = "select a.db_name,
               a.db_alias
          from xls_databases a
          where a.db_name = '$db_name'";
$result = mysql_db_query($db1,$cmd);
list($db_name,$db_alias) = mysql_fetch_row($result);

printhtmlhead();
echo "
<center>
<form action=$PHP_SELF method=post>
ALIAS BASISDATA: $db_alias<br><br>$comment<br>
PILIH KOLOM<br>
<table border=0 cellpadding=4 cellspacing=1 bgcolor=#ffffff>
   <tr>
      <td id=onblack>&nbsp;</td>
      <td id=onblack>ALIAS</td>
   </tr>";

if (!is_array($tbl_names)) {
   $tbl_names = explode(",",str_replace("\\'","",$tbl_names));
}
$d = implode("','",$tbl_names);
$d = "'$d'";
// Tampilkan semua kolom dari tabel-tabel terpilih
$cmd = "select a.tbl_name,
               a.tbl_alias,
               b.col_name,
               b.col_alias
          from xls_tables a
          inner join xls_columns b using (db_name,tbl_name)
          where a.db_name = '$db_name' and a.tbl_name in ($d)
          order by a.tbl_name,b.col_name";

$result = mysql_db_query($db1,$cmd);
if(mysql_num_rows($result)>0) {
   $tbl_namex = "";
   while(list($tbl_name,$tbl_alias,$col_name,$col_alias)=mysql_fetch_row($result)) {
      if ($tbl_namex != $tbl_name) {
         $tbl_namex = $tbl_name;
         echo "
   <tr bgcolor=#bbbbbb>
      <td colspan=2>$tbl_alias</td>
   </tr>
   <tr bgcolor=#dddddd>
      <td align=right><input type=checkbox name=col_names[] value='$tbl_name.$col_name'></td>
      <td>$col_alias</td>
   </tr>";
      } else {
         echo "
   <tr bgcolor=#dddddd>
      <td align=right><input type=checkbox name=col_names[] value='$tbl_name.$col_name'></td>
      <td>$col_alias</td>
   </tr>";
      }
   }
} else {
   echo "
   <tr bgcolor=#dddddd>
      <td colspan=4>TIDAK ADA DATA</td>
   </tr>";
}
echo "
</table>
<br><input type=submit name=slctbl value=' << KEMBALI '>&nbsp;
<input type=submit name=setcolorder value=' LANJUTKAN >> '>&nbsp;
<input type=hidden name=db_name value='$db_name'>
<input type=hidden name=tbl_names value=\"$d\"><br><br>
</form></center>";
}

// Atur urutan kolom terpilih
function setcolorder($db_name = "",$tbl_names = "",$col_names,$comment = "") {
global $db1,$PHP_SELF;

if ($col_names == NULL || count($col_names) == 0) {
   selectcol($db_name,explode(",",str_replace("\\'","",$tbl_names)),"Anda harus memilih minimal 1 kolom!");
   return;
}

$cmd = "select a.db_name,
               a.db_alias
          from xls_databases a
          where a.db_name = '$db_name'";
$result = mysql_db_query($db1,$cmd);
list($db_name,$db_alias) = mysql_fetch_row($result);

printhtmlhead();
echo "
<center>
<form action=$PHP_SELF method=post>
ALIAS BASISDATA: $db_alias<br><br>$comment<br>
ATUR URUTAN KOLOM<br>
<table border=0 cellpadding=4 cellspacing=1 bgcolor=#ffffff>
   <tr>
      <td id=onblack>URUTAN</td>
      <td id=onblack>ALIAS</td>
   </tr>";

$tbl_names = stripslashes($tbl_names);
if (!is_array($col_names)) {
   $col_names = explode(",",str_replace("\\'","",$col_names));
}
$d = implode("','",$col_names);
$d = "'$d'";

// Tampilkan semua kolom terpilih
$cmd = "select a.tbl_name,
               a.tbl_alias,
               b.col_name,
               b.col_alias
          from xls_tables a
          left join xls_columns b using (db_name,tbl_name)
          where a.db_name = '$db_name' and a.tbl_name in ($tbl_names)
          and concat(a.tbl_name,'.',b.col_name) in ($d)
          order by a.tbl_name,b.col_name";

$result = mysql_db_query($db1,$cmd);
if(mysql_num_rows($result)>0) {
   $i = 1;
   while(list($tbl_name,$tbl_alias,$col_name,$col_alias)=mysql_fetch_row($result)) {
      echo "
   <tr bgcolor=#dddddd>
      <td align=center><input style='text-align:right;' size=3 maxlength=3 type=text name=col_orders[] value='$i'></td>
      <td>$col_alias</td>
   </tr>";
      $i++;
   }
} else {
   echo "
   <tr bgcolor=#dddddd>
      <td colspan=4>TIDAK ADA DATA</td>
   </tr>";
}
echo "
</table>
<br><input type=submit name=slccol value=' << KEMBALI '>&nbsp;
<input type=submit name=settblorder value=' LANJUTKAN >> '>&nbsp;
<input type=hidden name=db_name value='$db_name'>
<input type=hidden name=tbl_names value=\"$tbl_names\">
<input type=hidden name=col_names value=\"$d\"><br><br>
</form></center>";
}

// Atur urutan join dan alias tabel
function settblorder($db_name = "",$tbl_names = "",$col_names = "",$col_orders,$comment = "") {
global $db1,$PHP_SELF;

if (!is_array($col_orders)) {
   $col_orders = explode(",",str_replace("\\'","",$col_orders));
}

// Cek urutan kolom
foreach ($col_orders as $v) {
   if (!is_numeric($v)) {
      setcolorder($db_name,$tbl_names,explode(",",str_replace("\\'","",$col_names)),"Urutan kolom harus berupa angka!");
      return;
   }
}
if (count(array_count_values($col_orders)) != count($col_orders)) {
   setcolorder($db_name,$tbl_names,explode(",",str_replace("\\'","",$col_names)),"Urutan kolom tidak boleh ada yang sama!");
   return;
}

$cmd = "select a.db_name,
               a.db_alias
          from xls_databases a
          where a.db_name = '$db_name'";
$result = mysql_db_query($db1,$cmd);
list($db_name,$db_alias) = mysql_fetch_row($result);

printhtmlhead();
echo "
<center>
<form action=$PHP_SELF method=post>
ALIAS BASISDATA: $db_alias<br><br>$comment<br>
ATUR URUTAN DAN JOIN ALIAS TABEL<br>
<table border=0 cellpadding=4 cellspacing=1 bgcolor=#ffffff>
   <tr>
      <td id=onblack>URUTAN</td>
      <td id=onblack>JOIN ALIAS</td>
      <td id=onblack>ALIAS</td>
   </tr>";

$d = implode(",",$col_orders);

$tbl_names = stripslashes($tbl_names);
$col_names = stripslashes($col_names);

// Tampilkan tabel terpilih
$cmd = "select a.tbl_name,
               a.tbl_alias
          from xls_tables a
          where a.db_name = '$db_name' and a.tbl_name in ($tbl_names)
          order by a.tbl_name";

$result = mysql_db_query($db1,$cmd);
if(mysql_num_rows($result)>0) {
   $i = 1;
   $j = 97;
   while(list($tbl_name,$tbl_alias)=mysql_fetch_row($result)) {
      echo "
   <tr bgcolor=#dddddd>
      <td align=center><input style='text-align:right;' size=3 maxlength=3 type=text name=tbl_orders[] value='$i'></td>
      <td align=center><input size=5 maxlength=10 type=text name=tbl_aliases[] value='".chr($j)."'></td>
      <td>$tbl_alias</td>
   </tr>";
      $i++;
      $j++;
   }
} else {
   echo "
   <tr bgcolor=#dddddd>
      <td colspan=4>TIDAK ADA DATA</td>
   </tr>";
}
echo "
</table>
<br><input type=submit name=setcolorder value=' << KEMBALI '>&nbsp;
<input type=submit name=setjoincond value=' LANJUTKAN >> '>&nbsp;
<input type=hidden name=db_name value='$db_name'>
<input type=hidden name=tbl_names value=\"$tbl_names\">
<input type=hidden name=col_names value=\"$col_names\">
<input type=hidden name=col_orders value=\"$d\"><br><br>
</form></center>";
}

// Atur syarat join
function setjoincondition($db_name = "",$tbl_names = "",$col_names = "",$col_orders = "",$tbl_orders,$tbl_aliases) {
global $db1,$PHP_SELF;

if (!is_array($tbl_orders)) {
   $tbl_orders = explode(",",str_replace("\\'","",$tbl_orders));
}

if (!is_array($tbl_aliases)) {
   $tbl_aliases = explode(",",str_replace("\\'","",$tbl_aliases));
}

// Cek urutan tabel
foreach ($tbl_orders as $v) {
   if (!is_numeric($v)) {
      settblorder($db_name,$tbl_names,$col_names,explode(",",str_replace("\\'","",$col_orders)),"Urutan tabel harus berupa angka!");
      return;
   }
}
if (count(array_count_values($tbl_orders)) != count($tbl_orders)) {
   settblorder($db_name,$tbl_names,$col_names,explode(",",str_replace("\\'","",$col_orders)),"Urutan tabel tidak boleh ada yang sama!");
   return;
}

if (count(array_count_values($tbl_aliases)) != count($tbl_aliases)) {
   settblorder($db_name,$tbl_names,$col_names,explode(",",str_replace("\\'","",$col_orders)),"Join alias tabel tidak boleh ada yang sama!");
   return;
}

$cmd = "select a.db_name,
               a.db_alias
          from xls_databases a
          where a.db_name = '$db_name'";
$result = mysql_db_query($db1,$cmd);
list($db_name,$db_alias) = mysql_fetch_row($result);

printhtmlhead();
echo "
<center>
<form action=$PHP_SELF method=post>
ALIAS BASISDATA: $db_alias<br><br>$comment<br>
ATUR SYARAT QUERY<br>
<table border=0 cellpadding=4 cellspacing=1 bgcolor=#ffffff>";

$d = implode(",",$tbl_orders);
$e = implode("','",$tbl_aliases);
$e = "'$e'";

$f = stripslashes($tbl_names);
$tbl_names = explode(",",str_replace("\\'","",$tbl_names));
$g = stripslashes($col_names);
$col_names = explode(",",str_replace("\\'","",$col_names));
$h = stripslashes($col_orders);
$col_orders = explode(",",str_replace("\\'","",$col_orders));

// Doing magic things.....
// As a magic, you will be surprised by what
// you get here.... alakazam!
foreach ($col_names as $cn) {
   list($tbl,$col) = explode(".",$cn);
   $tblx[] = $tbl;
   $colx[] = $col;
   $tbl_col[$tbl.".".$col] = $col;
}
$tblx = implode("','",$tblx);
$tblx = "'$tblx'";
$colx = implode("','",$colx);
$colx = "'$colx'";

foreach ($tbl_aliases as $k => $ta) {
   $tbl_aka[$tbl_names[$k]] = $ta;
}

foreach ($tbl_col as $tbl => $col) {
   $columns[] = $tbl_aka[substr($tbl,0,strpos($tbl,"."))].".$col";
}

// Swap columns so they fit in order
foreach ($col_orders as $k => $v) {
   $ordered_col[$v] = $columns[$k];
}
ksort($ordered_col);

$cmd = "select a.tbl_name,
               a.tbl_alias,
               b.col_name,
               b.col_alias
          from xls_tables a
          left join xls_columns b using (db_name,tbl_name)
          where a.db_name = '$db_name' and a.tbl_name in ($tblx)
          and b.col_name in ($colx)
          order by a.tbl_name";

$result = mysql_db_query($db1,$cmd);
if(mysql_num_rows($result)>0) {
   while (list($tbl_name,$tbl_alias,$col_name,$col_alias) = mysql_fetch_row($result)) {
      $cols[$tbl_aka[substr("$tbl_name.$col_name",0,strpos("$tbl_name.$col_name","."))].".".$col_name] = "$col_alias";
   }
}
foreach ($ordered_col as $k => $v) {
   $colsx[$k] = $cols[$v];
}
$cols = implode(",",$colsx);
$ordered_col = implode(",",$ordered_col);

echo "
   <tr>
      <td id=onblack>Tampilkan:</td>
      <td bgcolor=#dddddd>
         $cols
         <input type=hidden name=fields value='$ordered_col'>
      </td>
   </tr>";

$cmd = "select a.tbl_name,
               a.tbl_alias
          from xls_tables a
          where a.db_name = '$db_name' and a.tbl_name in ($tblx)
          order by a.tbl_name";

$result = mysql_db_query($db1,$cmd);
if(mysql_num_rows($result)>0) {
   while (list($tbl_name,$tbl_alias) = mysql_fetch_row($result)) {
      $tbls[$tbl_name] = "$tbl_alias (".$tbl_aka[$tbl_name]."):<br> ";
   }
}

reset($tbl_orders);
foreach ($tbl_orders as $k => $v) {
   $ordered_tbl[$v] = $tbl_names[$k]." ".$tbl_aka[$tbl_names[$k]];
   $tblsx[$v] = $tbls[$tbl_names[$k]];
}
ksort($tbls);
ksort($ordered_tbl);

for ($i = 1; $i <= count($ordered_tbl); $i++) {
   $data .= $tblsx[$i]."<br>
         <input type=hidden name=froms[] value='".$ordered_tbl[$i]."'>
         <textarea name=froms[] cols=50 rows=3></textarea><br><br>";
}

echo "
   <tr>
      <td id=onblack>Dari:</td>
      <td bgcolor=#dddddd>
         $data
      </td>
   </tr>
   <tr>
      <td id=onblack>Syarat Lain:</td>
      <td bgcolor=#dddddd>
         <textarea name=conditions cols=50 rows=3></textarea>
      </td>
   </tr>";
   
echo "
</table>
<br><input type=submit name=settblorder value=' << KEMBALI '>&nbsp;
<input type=submit name=doquery value=' LANJUTKAN >> '>&nbsp;
<input type=hidden name=db_name value='$db_name'>
<input type=hidden name=tbl_names value=\"$f\">
<input type=hidden name=col_names value=\"$g\">
<input type=hidden name=col_orders value=\"$h\">
<input type=hidden name=tbl_orders value=\"$d\">
<input type=hidden name=tbl_aliases value=\"$e\">
<input type=hidden name=field_names value=\"$cols\"><br><br>
</form></center>";
}

// Lakukan query sesuai dengan yang diminta
function doquery($db_name,$tbl_names,$col_names,$col_orders,$tbl_orders,$tbl_aliases,$fields,$field_names,$froms,$conditions) {
global $db1,$PHP_SELF;

// Perisapan eh persiapan
foreach ($froms as $k => $v) {
   if (trim($froms[$k]) == "") {
      $froms[$k] = ",";
   }
}
$froms = trim(implode(" ",$froms));
if (substr($froms,-1) == ",") {
   $froms = substr($froms,0,-1);
}

$conditions = trim($conditions);
if ($conditions != "" && strtoupper(substr($conditions,0,5)) != "WHERE") {
   $conditions = "WHERE $conditions";
}

$field_names = explode(",",$field_names);
foreach ($field_names as $v) {
   $head .= "
      <td id=onblack>$v</td>";
}

// Lakukan query
$sql = "SELECT $fields FROM ".stripslashes($froms)." ".stripslashes($conditions);
$result = mysql_db_query($db_name,$sql);

// Tampilkan hasil query
printhtmlhead();
echo "
<center>
<form action=$PHP_SELF method=post>
HASIL QUERY<br>
<table border=0 cellpadding=4 cellspacing=1 bgcolor=#ffffff>
   <tr>$head
   </tr>";

if (($error = mysql_error()) == "") {
   $c = mysql_num_rows($result);
   if ($c > 0) {
      while($row=mysql_fetch_row($result)) {
         $data .= "
      <tr bgcolor=#dddddd>";
         foreach ($row as $v) {
            $data .= "
         <td>$v</td>";
         }
         $data .= "
      </tr>";
      }
   } else {
      $data .= "
      <tr bgcolor=#dddddd>
         <td colspan=".count($field_names).">TIDAK ADA DATA</td>
      </tr>";
   }
} else {
   $data = "
      <tr bgcolor=#dddddd>
         <td colspan=".count($field_names).">Terdapat kesalahan pada query Anda<br>Pesan kesalahan: $error</td>
      </tr>";
}

echo "$data
</table><br>
<input type=submit name=setjoincond value=' << KEMBALI '>&nbsp;
<input type=submit name=download value=' DOWNLOAD '><br><br>
<input type=submit name=savesql value=' SIMPAN SEBAGAI TEMPLATE '>&nbsp;
<input type=hidden name=db_name value='$db_name'>
<input type=hidden name=tbl_names value=\"".stripslashes($tbl_names)."\">
<input type=hidden name=col_names value=\"".stripslashes($col_names)."\">
<input type=hidden name=col_orders value=\"".stripslashes($col_orders)."\">
<input type=hidden name=tbl_orders value=\"".stripslashes($tbl_orders)."\">
<input type=hidden name=tbl_aliases value=\"".stripslashes($tbl_aliases)."\">
<input type=hidden name=field_names value=\"".implode(",",$field_names)."\">
<input type=hidden name=query value=\"".htmlspecialchars($sql)."\"><br><br>
</form></center>";
}

// Download hasil query
function download($db_name,$field_names,$query) {
global $db1,$PHP_SELF;

// Persiapan
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=query.xls" );
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
header("Pragma: public");
// Create
$workbook = new Workbook("-");
// Sheet Data
$worksheet_data =& $workbook->add_worksheet("Hasil Query");
// Dump query result
$field_names = explode(",",stripslashes($field_names));
for ($i = 0; $i < count($field_names); $i++) {
   $worksheet_data->write(0,$i,$field_names[$i]);
}
$result = mysql_db_query($db_name,stripslashes($query));
$i = 1;
while ($row = mysql_fetch_row($result)) {
   for ($j = 0; $j < count($row); $j++) {
      $worksheet_data->write($i,$j,$row[$j]);
   }
   $i++;
}
// Close, send to browser
$workbook->close();
// Die or html content will also be sent
die;
}

function querytemplate($db_name) {
global $db1,$PHP_SELF;

$sql = "SELECT tmpl_id,db_name,tmpl_nm,tmpl_desc FROM xls_templates WHERE db_name = '$db_name'";
$result = mysql_db_query($db1,$sql);
if (mysql_num_rows($result) >  0) {
   echo "
<center>
<form action=$PHP_SELF method=post>
TEMPLATE QUERY<br>
<table border=0 cellpadding=4 cellspacing=1 bgcolor=#ffffff>
   <tr>
      <td id=onblack>NO</td>
      <td id=onblack>NAMA TEMPLATE</td>
      <td id=onblack>AKSI</td>
   </tr>";
   $i = 1;
   while (list($tmpl_id,$db_namex,$tmpl_nm,$tmpl_desc) = mysql_fetch_row($result)) {
      echo "
   <tr bgcolor=#dddddd>
      <td align=right>$i</td>
      <td><a href=$PHP_SELF?edttmpl=y&tmpl_id=$tmpl_id&db_name=$db_namex>$tmpl_nm</a><br>$tmpl_desc</td>
      <td><a href=$PHP_SELF?dotmpl=y&tmpl_id=$tmpl_id>Lakukan Query</a></td>
   </tr>";
      $i++;
   }
   echo "
</table>
<br><input type=submit name=addtmpl value=' TAMBAH '>&nbsp;
<input type=hidden name=db_name value='$db_name'><br><br>
</form></center>";
}
}

function addtemplate ($db_name = "",$tmpl_fn = "",$tmpl_sql = "",$tmpl_nm = "",$tmpl_desc = "",$tmpl_prms = "") {
global $db1,$PHP_SELF;

$cmd = "select a.db_name,
               a.db_alias
          from xls_databases a
          where a.db_name = '$db_name'";
$result = mysql_db_query($db1,$cmd);
list($db_name,$db_alias) = mysql_fetch_row($result);

printhtmlhead();
echo "
<center>
<form action=$PHP_SELF method=post>
TAMBAH TEMPLATE<br>
<table border=0 cellpadding=4 cellspacing=1 bgcolor=#ffffff>
   <tr>
      <td id=onblack align=right>Nama Template:</td>
      <td bgcolor=#dddddd>
         <input type=text name=tmpl_nm size=50>
      </td>
   </tr>
   <tr>
      <td id=onblack align=right>Deskripsi:</td>
      <td bgcolor=#dddddd>
         <textarea name=tmpl_desc rows=3 cols=50></textarea>
      </td>
   </tr>
   <tr>
      <td id=onblack align=right>Alias Basisdata:</td>
      <td bgcolor=#dddddd>
         $db_alias
         <input type=hidden name=db_name value='$db_name'>
      </td>
   </tr>
   <tr>
      <td id=onblack align=right>Nama Kolom:</td>
      <td bgcolor=#dddddd>
         <input type=text name=tmpl_fn size=50 value='$tmpl_fn'>
      </td>
   </tr>
   <tr>
      <td id=onblack align=right>Perintah Query:</td>
      <td bgcolor=#dddddd>
         <textarea name=tmpl_sql rows=5 cols=50>".htmlspecialchars(stripslashes($tmpl_sql))."</textarea>
      </td>
   </tr>
   <tr>
      <td id=onblack align=right>Parameter:</td>
      <td bgcolor=#dddddd>
         <textarea name=tmpl_prms rows=5 cols=50></textarea>
      </td>
   </tr>
   <tr>
      <td bgcolor=#dddddd colspan=2 align=center>
         <input type=submit name=simpantmpl value=' SIMPAN '>&nbsp;
         <input type=submit name=bataltmpl value=' BATAL '>
         <input type=hidden name=savetmpl value=1>
      </td>
   </tr>";
if ($comment != "") {
   echo "
   <tr>
      <td bgcolor=#dddddd colspan=2 align=left>
         $comment
      </td>
   </tr>";
}
echo "
</table>
</form></center>";
}

function edittemplate ($db_name,$tmpl_id) {
global $db1,$PHP_SELF;

$sql = "select tmpl_id,db_name,tmpl_nm,tmpl_desc,tmpl_fn,tmpl_sql,tmpl_prms
        from xls_templates where tmpl_id = '$tmpl_id' and db_name = '$db_name'";
$result = mysql_db_query($db1,$sql);
if (mysql_num_rows($result) <= 0) {
   selecttbl($db_name);
   return;
}
list($tmpl_id,$db_name,$tmpl_nm,$tmpl_desc,$tmpl_fn,$tmpl_sql,$tmpl_prms) = mysql_fetch_row($result);

$cmd = "select a.db_name,
               a.db_alias
          from xls_databases a
          where a.db_name = '$db_name'";
$result = mysql_db_query($db1,$cmd);
list($db_name,$db_alias) = mysql_fetch_row($result);

printhtmlhead();
echo "
<center>
<form action=$PHP_SELF method=post>
UBAH TEMPLATE<br>
<table border=0 cellpadding=4 cellspacing=1 bgcolor=#ffffff>
   <tr>
      <td id=onblack align=right>Nama Template:</td>
      <td bgcolor=#dddddd>
         <input type=text name=tmpl_nm size=50 value='".htmlspecialchars($tmpl_nm)."'>
      </td>
   </tr>
   <tr>
      <td id=onblack align=right>Deskripsi:</td>
      <td bgcolor=#dddddd>
         <textarea name=tmpl_desc rows=3 cols=50>".htmlspecialchars($tmpl_desc)."</textarea>
      </td>
   </tr>
   <tr>
      <td id=onblack align=right>Alias Basisdata:</td>
      <td bgcolor=#dddddd>
         $db_alias
         <input type=hidden name=db_name value='$db_name'>
      </td>
   </tr>
   <tr>
      <td id=onblack align=right>Nama Kolom:</td>
      <td bgcolor=#dddddd>
         <input type=text name=tmpl_fn size=50 value='".htmlspecialchars($tmpl_fn)."'>
      </td>
   </tr>
   <tr>
      <td id=onblack align=right>Perintah Query:</td>
      <td bgcolor=#dddddd>
         <textarea name=tmpl_sql rows=5 cols=50>
".htmlspecialchars(stripslashes($tmpl_sql))."
         </textarea>
      </td>
   </tr>
   <tr>
      <td id=onblack align=right>Parameter:</td>
      <td bgcolor=#dddddd>
         <textarea name=tmpl_prms rows=5 cols=50>".htmlspecialchars($tmpl_prms)."</textarea>
      </td>
   </tr>
   <tr>
      <td bgcolor=#dddddd colspan=2 align=center>
         <input type=submit name=simpantmpl value=' SIMPAN '>&nbsp;
         <input type=submit name=hapustmpl value=' HAPUS '>&nbsp;
         <input type=submit name=bataltmpl value=' BATAL '>
         <input type=hidden name=tmpl_id value=$tmpl_id>
         <input type=hidden name=savetmpl value=1>
      </td>
   </tr>";
if ($comment != "") {
   echo "
   <tr>
      <td bgcolor=#dddddd colspan=2 align=left>
         $comment
      </td>
   </tr>";
}
echo "
</table>
</form></center>";
}

// Lakukan template query sesuai dengan yang diminta
function dotemplate($db_name,$tmpl_fn,$tmpl_sql) {
global $db1,$PHP_SELF;

// Perisapan eh persiapan
$field_names = explode(",",$tmpl_fn);
foreach ($field_names as $v) {
   $head .= "
      <td id=onblack>$v</td>";
}

// Lakukan query
$result = mysql_db_query($db_name,$tmpl_sql);

// Tampilkan hasil query
printhtmlhead();
echo "
<center>
<form action=$PHP_SELF method=post>
HASIL QUERY<br>
<table border=0 cellpadding=4 cellspacing=1 bgcolor=#ffffff>
   <tr>$head
   </tr>";

if (($error = mysql_error()) == "") {
   $c = mysql_num_rows($result);
   if ($c > 0) {
      while($row=mysql_fetch_row($result)) {
         $data .= "
      <tr bgcolor=#dddddd>";
         foreach ($row as $v) {
            $data .= "
         <td>$v</td>";
         }
         $data .= "
      </tr>";
      }
   } else {
      $data .= "
      <tr bgcolor=#dddddd>
         <td colspan=".count($field_names).">TIDAK ADA DATA</td>
      </tr>";
   }
} else {
   $data = "
      <tr bgcolor=#dddddd>
         <td colspan=".count($field_names).">Terdapat kesalahan pada query Anda<br>Pesan kesalahan: $error</td>
      </tr>";
}

echo "$data
</table><br>
<input type=submit name=slctbl value=' << KEMBALI '>&nbsp;
<input type=submit name=download value=' DOWNLOAD '><br><br>
<input type=hidden name=db_name value='$db_name'>
<input type=hidden name=field_names value=\"".htmlspecialchars($tmpl_fn)."\">
<input type=hidden name=query value=\"".htmlspecialchars($tmpl_sql)."\"><br><br>
</form></center>";
}

<!-- mysql_connect($dbhost,$dbuser,$dbpassowrd); -->
mysql_connect('localhost','root','');

if($slcdb != '') {
   selectdb();
} elseif($slctbl != '') {
   selecttbl($db_name);
} elseif($slccol != '') {
   selectcol($db_name,$tbl_names);
} elseif($setcolorder != '') {
   setcolorder($db_name,$tbl_names,$col_names);
} elseif($settblorder != '') {
   settblorder($db_name,$tbl_names,$col_names,$col_orders);
} elseif($setjoincond != '') {
   setjoincondition($db_name,$tbl_names,$col_names,$col_orders,$tbl_orders,$tbl_aliases);
} elseif($doquery != '') {
   doquery($db_name,$tbl_names,$col_names,$col_orders,$tbl_orders,$tbl_aliases,$fields,$field_names,$froms,$conditions);
} elseif($download != '') {
   download($db_name,$field_names,$query);
} elseif($savesql != '') {
   addtemplate($db_name,$field_names,$query);
} elseif ($savetmpl != '') {
   if (!isset($bataltmpl) && !isset($hapustmpl)) {
      if ($tmpl_nm != "" && $tmpl_sql != "") {
         if (!isset($tmpl_id)) {
            $sql = "INSERT INTO xls_templates (db_name,tmpl_nm,tmpl_desc,
                    tmpl_fn,tmpl_sql,tmpl_prms) VALUES ('$db_name','$tmpl_nm',
                    '$tmpl_desc','$tmpl_fn','$tmpl_sql','$tmpl_prms')";
            mysql_db_query($db1,$sql);echo mysql_error();
            addtemplate($db_name);
         } else {
            $sql = "UPDATE xls_templates SET
                    db_name = '$db_name',tmpl_nm = '$tmpl_nm',tmpl_desc = '$tmpl_desc',
                    tmpl_fn = '$tmpl_fn',tmpl_sql = '$tmpl_sql',tmpl_prms = '$tmpl_prms'
                    WHERE tmpl_id = '$tmpl_id'";
            mysql_db_query($db1,$sql);echo mysql_error();
            selecttbl($db_name);
         }
      } else {
         if (!isset($tmpl_id)) {
            addtemplate($db_name,$tmpl_fn,$tmpl_sql);
         } else {
            edittemplate($db_name,$tmpl_id);
         }
      }
   } else {
      if ($hapustmpl != "") {
         $sql = "DELETE FROM xls_templates WHERE tmpl_id = '$tmpl_id'";
         mysql_db_query($db1,$sql);
      }
      selecttbl($db_name);
   }
} elseif ($edttmpl != '') {
   edittemplate($db_name,$tmpl_id);
} elseif ($dotmpl != '') {
   $sql = "select db_name,tmpl_fn,tmpl_sql
           from xls_templates where tmpl_id = '$tmpl_id'";
   $result = mysql_db_query($db1,$sql);
   if (mysql_num_rows($result) <= 0) {
      selecttbl($db_name);
      return;
   }
   list($db_name,$tmpl_fn,$tmpl_sql) = mysql_fetch_row($result);
   dotemplate($db_name,$tmpl_fn,$tmpl_sql);
} elseif ($addtmpl != '') {
   addtemplate($db_name);
} else selectdb();
?>
</body>
</html>
