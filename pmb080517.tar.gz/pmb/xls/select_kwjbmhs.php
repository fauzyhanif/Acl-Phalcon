<? //mysql_connect("localhost","webdb","sc6HMmHbyBewXz4d");
   mysql_connect("localhost","root","");
   mysql_select_db("session2");
    
   $sql = "select nomhs,nomor_test from xocp_akd_keu_trnsctdtl where
keu_thn='2009' and keu_ses_id='1010' && psmhs_id=8 limit $_GET[m],100";
//echo $sql;

   $A=mysql_query($sql);
   while (list($nomhs,$nomor_test)=mysql_fetch_row($A)) {

    $ceksql = "select nomhs from xocp_akd_keu_kwjbmhs where keu_thn=2009 && keu_ses_id='1010' && nomhs='$nomhs'";
//    echo $ceksql."<br />";
    $hasilcek = mysql_query($ceksql);

while(list($dnomhs)=mysql_fetch_row($hasilcek)){
    if($dnomhs) echo $nomhs;
}
    

//    $insert= "insert into xocp_akd_keu_kwjbmhs values('$org_id','$keu_thn', '$keu_ses_id', '$psmhs_id','$nomhs','$nomor_test','$kwjb_id','$kode_byr','$kwjbdtl_id','$jml_kwjb','$jml_byr','0','0')";
//    echo $insert."<br />";
//   mysql_query($insert);
   }
?>
