<?
echo phpinfo();

?>