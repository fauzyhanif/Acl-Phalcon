<? //mysql_connect("localhost","webdb","sc6HMmHbyBewXz4d");
   mysql_connect("localhost","root","");
   mysql_select_db("session2");
    
   if(!$_GET['nomhs']){    
   echo "nomhs please...";
   }else{
   $sql = "select org_id, keu_thn, keu_ses_id,psmhs_id,nomhs,nomor_test,kwjb_id,kode_byr,kwjbdtl_id,jml_kwjbttl,jml_byr from xocp_akd_keu_trnsctdtl where
keu_thn='2009' and keu_ses_id='1010' and nomhs='$_GET[nomhs]'";
//echo $sql;
   $A=mysql_query($sql);
   while (list($org_id,$keu_thn,$keu_ses_id,$psmhs_id,$nomhs,$nomor_test,$kwjb_id,$kode_byr,$kwjbdtl_id,$jml_kwjb,$jml_byr)=mysql_fetch_row($A)) {
//    echo "$org_id $keu_thn $keu_ses_id $psmhs_id $nomhs $nomor_test<br>";
    if($_GET[act]=='up'){
    $insert = "update xocp_akd_keu_kwjbmhs set jml_byr='$jml_byr' where keu_thn='2009' && kode_byr=$kode_byr && keu_ses_id='1010' && nomhs=$nomhs";
    echo $insert.": ";
//     if( mysql_query($insert)){
     echo "berhasil.....<br/>";
//    }

    }elseif ($_GET[act]=='in'){
    $insert= "insert into xocp_akd_keu_kwjbmhs values('$org_id','$keu_thn', '$keu_ses_id', '$psmhs_id','$nomhs','$nomor_test','$kwjb_id','$kode_byr','$kwjbdtl_id','$jml_kwjb','$jml_byr','0','0')";
    echo $insert.": ";
//     if( mysql_query($insert)){
     echo "berhasil.....<br />";
//    }

    }
//echo $insert."<br />";    
   }
   
   }
?>
