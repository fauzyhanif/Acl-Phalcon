<?php
//--------------------------------------------------------------------//
// Filename : class/xocpsession.php                                   //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-15                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('XOCP_SESSION_DEFINED') ) {
   define('XOCP_SESSION_DEFINED', TRUE);

class XocpSESSION {

   // private
   var $sessiondir;
   var $user_id;
   
   function XocpSESSION() {
   }
   
   funciont getUser() {
   }
   
   function getGPCS() {
   }


}

} // XOCP_SESSION_DEFINED
?>