<?php
//--------------------------------------------------------------------//
// Filename : class/xocphtml.php                                      //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-15                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('XOCP_HTML_DEFINED') ) {
   define('XOCP_HTML_DEFINED', TRUE);


class _project_SelectResources {
   var $item_id;
   var $res_org_id;
   var $res_prj_id;
   var $resources_id;
}



class XocpHTML {

   // private
   var $cookie = array();
   var $header = array();
   var $meta = array();
   var $stylesheet = "";
   var $script = "";
   var $bottomscript = "";
   var $title = "";
   var $body = "";
   var $bodyonload = "";
   var $redirect = "";
   var $area_count = 0;
   var $sessionvars = array();
   
   function XocpHTML() {
      global $ss_timing_start_times;
      global $currentHTML;

      $themecss = getcss(getTheme());
      if ( $themecss ) {
         $this->addStyleSheet("<style type='text/css' media='all'><!-- @import url($themecss); --></style>");
      }
      
   }
   
   function setBodyOnload($text) {
      $this->bodyonload = $text;
   }

   function addScript($text) {
      $this->script .= $text . "\n";
   }
   
   function loadScript($filename,$insidetag=TRUE) {
      if(file_exists($filename)) {
         $this->script .= fread(fopen($filename, 'rb'), filesize($filename)) . "\n";
      }
   }

   function addBottomScript($text) {
      $this->bottomscript .= $text . "\n";
   }
   
   function loadBottomScript($filename,$insidetag=TRUE) {
      if(file_exists($filename)) {
         $this->bottomscript .= fread(fopen($filename, 'rb'), filesize($filename)) . "\n";
      }
   }

   function addStyleSheet($text) {
      $this->stylesheet .= $text . "\n";
   }
   
   function loadStyleSheet($filename) {
      if(file_exists($filename)) {
         $this->stylesheet .= fread(fopen($filename, 'rb'), filesize($filename)) . "\n";
      }
   }

   // private
   function pageHeader() {
      global $xocpConfig;
      $myts =& MyTextSanitizer::getInstance();

      $meta = (!empty($xocpConfig['meta']) ? $xocpConfig['meta'] : "");
      $meta = $myts->makeTareaData4InsideQuotes($meta);
      $ret  = "<html>\n";
      $ret .= "<head>\n";
      $ret .= "<meta http-equiv='Content-Type' content='text/html; charset="._CHARSET."' />\n";
      $ret .= "<meta name='author' content='".$xocpConfig['sitename']."' />\n";
      $ret .= "<meta name='copyright' content='Copyright (c) 2002 by ".$xocpConfig['sitename']."' />\n";
      $ret .= "<meta name='keywords' content='".$meta."' />\n";
      $ret .= "<meta name='description' content='".$xocpConfig['slogan']."' />\n";
      $ret .= "<meta name='generator' content='".XOCP_VERSION."' />\n</head>\n";
      $ret .= "<title>".$xocpConfig['sitename']."</title>\n";
      // print scripts
      $ret .= $this->script;

      // print stylesheet
      $ret .= $this->stylesheet;
      $ret .= "\n\n<body ".$this->bodyonload.">\n";
      
      return $ret;
   }

   // private
   function pageFooter(){
      return "\n</body>\n</html>\n";
   }
   
   // public
   function addCookie($name,$value="",$expire=0,$path="",$domain="",$secure=0) {
      $this->cookie[] = array("name"=>$name,"value"=>$value,"expire"=>$expire,"path"=>$path,"domain"=>$domain,"secure"=>$secure);
   }
   
   // public
   function addSessionVar($name) {
      $this->sessionvars[] = $name;
   }
   
   // public
   function addBody($text) {
      $this->body .= $text;
   }
   
   // private
   function endBlock($last_attr) {
         if($last_attr) {
            $cell = $last_attr['type'];
            switch($cell) {
               case XOCP_AREATYPE_A :
                  $this->addBody("\n<td colspan=3 width=75%></td></tr>");
                  break;
               case XOCP_AREATYPE_B :
                  $this->addBody("\n<td colspan=2 width=45%></td></tr>");
                  break;
               case XOCP_AREATYPE_C :
                  $this->addBody("\n<td width=20%></td></tr>");
                  break;
               case XOCP_AREATYPE_AB :
                  $this->addBody("\n<td colspan=2 width=45%></td></tr>");
                  break;
               case XOCP_AREATYPE_BC :
                  $this->addBody("\n<td width=20%></tr></tr>");
                  break;
               case XOCP_AREATYPE_ABC :
                  $this->addBody("\n<td width=20%></tr></tr>");
                  break;
            }
         }
   
   }

   //private
   function createArea($attr,$block_array) {
      global $xocpConfig, $xocp_user;
      $blocks = "";
      
      if($attr['rowspan']>1) {
         $rowspan = " rowspan='".$attr['rowspan']."'";
      } else {
         $rowspan = "";
      }

      if($attr['valign'] != '') {
         $valign = " valign='".$attr['valign']."'";
      } else {
         $valign = "";
      }
      
      $area = "";

      if(is_array($block_array)) {
         $blocks = "";
//         ksort($block_array);
         $c =  count($block_array);

         foreach($block_array as $block_no => $blockattr) {

            if($blockattr['align'] != '') {
               $align = " align='".$blockattr['align']."'";
            } else {
               $align = "";
            }

            if($blockattr['file_nm'] != "" && file_exists(XOCP_DOC_ROOT."/modules/".$blockattr['module_id']."/".$blockattr['file_nm'])) {
               // load the language first, before the module's files
               if(file_exists(XOCP_DOC_ROOT."/modules/".$blockattr['module_id']."/language/".$xocp_user->getVar("language").".php")) {
                  include_once(XOCP_DOC_ROOT."/modules/".$blockattr['module_id']."/language/".$xocp_user->getVar("language").".php");
               } elseif (file_exists(XOCP_DOC_ROOT."/modules/".$blockattr['module_id']."/language/".$xocpConfig['language'].".php")) {
                  include_once(XOCP_DOC_ROOT."/modules/".$blockattr['module_id']."/language/".$xocpConfig['language'].".php");
               }
               include_once(XOCP_DOC_ROOT."/modules/".$blockattr['module_id']."/".$blockattr['file_nm']);
               $class_nm = $blockattr['class_nm'];
               if(class_exists($class_nm)) {
                  $var = catchVar($blockattr['module_id']);
                  $obj = new $class_nm($var);
                  $obj->setHtmlObject($this);
                  $blocks .= "\n<div $align>".$obj->show()."</div>\n";
               }
            }
         }
      }

      $info = "<!-- AREA: ".$this->area_count."-".$attr['type']." -->";

      switch($attr['type']) {

         case XOCP_AREATYPE_A :
            if($this->area_count>0) { $this->addBody("</tr>"); }
            $this->addBody("\n$info<tr><td width=".XOCP_AREAWIDTH_A."%$valign$rowspan>$blocks</td>");
            break;
         case XOCP_AREATYPE_B :
            $this->addBody("\n$info<td width=".XOCP_AREAWIDTH_B."%$valign$rowspan>$blocks</td>");
            break;
         case XOCP_AREATYPE_C :
            $this->addBody("\n$info<td width=".XOCP_AREAWIDTH_C."%$valign$rowspan>$blocks</td>");
            break;
         case XOCP_AREATYPE_D :
            $this->addBody("\n$info<td width=".XOCP_AREAWIDTH_D."%$valign$rowspan>$blocks</td></tr>");
            break;
         case XOCP_AREATYPE_AB :
            if($this->area_count>0) { $this->addBody("</tr>"); }
            $this->addBody("\n$info<tr><td width=".XOCP_AREAWIDTH_AB."% colspan=2$valign$rowspan>$blocks</td>");
            break;
         case XOCP_AREATYPE_BC :
            $this->addBody("\n$info<td width=".XOCP_AREAWIDTH_BC."% colspan=2$valign$rowspan>$blocks</td>");
            break;
         case XOCP_AREATYPE_CD :
            $this->addBody("\n$info<td width=".XOCP_AREAWIDTH_CD."% colspan=2$valign$rowspan>$blocks</td></tr>");
            break;
         case XOCP_AREATYPE_ABC :
            if($this->area_count>0) { $this->addBody("</tr>"); }
            $this->addBody("\n$info<tr><td width=".XOCP_AREAWIDTH_ABC."% colspan=3$valign$rowspan>$blocks</td>");
            break;
         case XOCP_AREATYPE_BCD :
            $this->addBody("\n$info<td width=".XOCP_AREAWIDTH_BCD."% colspan=3$valign$rowspan>$blocks</td></tr>");
            break;
         case XOCP_AREATYPE_ABCD :
            if($this->area_count>0) { $this->addBody("</tr>"); }
            $this->addBody("\n$info<tr><td width=".XOCP_AREAWIDTH_ABCD."% colspan=4$valign$rowspan>$blocks</td></tr>");
            break;
      }

      $this->area_count++;
   
   }
   
   // public
   function pageFromFile($file) {
      include($file.".php");
      $blocks = $xocpPage['block'];
      $areas = $xocpPage['area'];
      if(is_array($areas)) {
         ksort($areas);
         $c =  count($areas);
         $this->addBody(_theme::openPage());
         $last_attr = NULL;;
         foreach($areas as $area_no => $attr) {
            $this->createArea($attr,(!empty($blocks[$area_no]) ? $blocks[$area_no] : NULL));
            $last_attr = $attr;
         }
         
         $this->endBlock($last_attr);
         
         $this->addBody(_theme::closePage());
      }
   }
   
   //public
   function pageFromDatabase($page) {

      $wherequery = "a.page_id = '$page'";

      $db =& Database::getInstance();
      $sql = "SELECT a.area_id,a.block_id,a.module_id,c.file_nm,a.class_nm,a.align,b.valign,b.area_type,b.rowspan"
           . " FROM ".XOCP_PREFIX."areas2blocks a"
           . " LEFT JOIN ".XOCP_PREFIX."pages2areas b USING(page_id,area_id)"
           . " LEFT JOIN ".XOCP_PREFIX."blocks c on c.module_id = a.module_id AND c.class_nm = a.class_nm"
           . " WHERE $wherequery ORDER BY a.area_id, b.area_type,a.weight";
      $result = $db->query($sql);
      if ( $db->getRowsNum($result) ) {
         $this->addBody(_theme::openPage());
         $last_attr = NULL;
         while ( list($area_id,$block_id,$module_id,$file_nm,$class_nm,$align,$valign,$area_type,$rowspan) = $db->fetchRow($result) ) {
            $area_attr[$area_id]['type'] = $area_type;
            $area_attr[$area_id]['rowspan'] = $rowspan;
            $area_attr[$area_id]['valign'] = $valign;
            $block_attr[$area_id][$block_id]['module_id'] = $module_id;
            $block_attr[$area_id][$block_id]['file_nm'] = $file_nm;
            $block_attr[$area_id][$block_id]['class_nm'] = $class_nm;
            $block_attr[$area_id][$block_id]['weight'] = $weight;
            $block_attr[$area_id][$block_id]['align'] = $align;
         }
         foreach($area_attr as $area_no => $attr) {
            $this->createArea($attr,$block_attr[$area_no]);
            $last_attr = $attr;
         }
         $this->endBlock($last_attr);
         $this->addBody(_theme::closePage());
      }
   }

   // public
   function redirect($url) {
      $this->redirect = $url;
   }
   
   // public
   function out() {
      global $ss_timing_start_times, $ss_timing_stop_times, $xocpConfig;
      
      // send cookies first
      if(count($this->cookie)>0) {
         reset($this->cookie);
         foreach ($this->cookie as $c) {
            setcookie($c['name'],$c['value'],$c['expire'],$c['path'],$c['domain'],$c['secure']);
         }
      }
      
      if(count($this->sessionvars)>0) {
         reset($this->sessionvars);
         foreach($this->sessionvars as $s) {
            session_register($s);
         }
      }
      
      if(!empty($this->redirect)) {

         header("Location: ".$this->redirect);

      } else {

         if ( !headers_sent() ) {
            if ( !empty($xocpConfig['gzip_compression']) ) {
               if (extension_loaded("zlib") ) {
                  if ( function_exists('version_compare') ) { // PHP 4.10+ has version_compare
                     if ( version_compare("4.0.5", phpversion(),'le') ) {
                        ob_start("ob_gzhandler");
                     } else {
                        ob_start();
                     }
                  } elseif ( preg_match("/[4-9]\.[0-9]\.[5-9].*/", phpversion()) )  {
                     ob_start("ob_gzhandler");
                  } else {
                     ob_start();
                  }
               } else {
                  ob_start();
               }
            } else {
               ob_start();
            }
            header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
            header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
            header("Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0");
            header("Pragma: no-cache");
         }


         echo $this->pageHeader();
         
         echo _theme::themeHeader();
         echo $this->body;

         // print bottomscripts
         echo $this->bottomscript;
         
         echo _theme::themeFooter();
         echo $this->pageFooter();
         ob_end_flush();
         //echo ss_timing_result();
      }
   }

}


class XocpSimpleTable {
   var $theme;
   var $cols;
   var $rows;
   var $rowsdata = array();
   var $colspan = array();
   var $rowspan = array();
   var $cellalign;
   var $cellvalign;
   var $width = 0;
   
   function XocpSimpleTable($theme=0) {
      $this->rows = 0;
      $this->theme = $theme;
   }
   
   function setWidth($width) {
      $this->width = $width;
   }
   
   function addRow() {
      $arg_list = func_get_args();
      $num_args = func_num_args();
      $this->rows++;
      $this->rowsdata[$this->rows] = array();
      for($i=0;$i<$num_args;$i++) {
         $this->rowsdata[$this->rows] = array_merge($this->rowsdata[$this->rows], $arg_list[$i]);
      }
      return $this->rows;
   }
   
   function setColSpan($rownum) {

      $arg_list = func_get_args();
      $num_args = func_num_args();
      $this->colspan[$rownum] = array();
      for($i=1;$i<$num_args;$i++) {
         $this->colspan[$rownum] = array_merge($this->colspan[$rownum], $arg_list[$i]);
      }

   }

   function setRowSpan($rownum) {

      $arg_list = func_get_args();
      $num_args = func_num_args();
      $this->rowspan[$rownum] = array();
      for($i=1;$i<$num_args;$i++) {
         $this->rowspan[$rownum] = array_merge($this->rowspan[$rownum], $arg_list[$i]);
      }

   }

   function setCellAlign($rownum) {
      $arg_list = func_get_args();
      $num_args = func_num_args();
      $this->cellalign[$rownum] = array();
      for($i=1;$i<$num_args;$i++) {
         $this->cellalign[$rownum] = array_merge($this->cellalign[$rownum], $arg_list[$i]);
      }

   }

   function setCellVAlign($rownum) {
      $arg_list = func_get_args();
      $num_args = func_num_args();
      $this->cellvalign[$rownum] = array();
      for($i=1;$i<$num_args;$i++) {
         $this->cellvalign[$rownum] = array_merge($this->cellvalign[$rownum], $arg_list[$i]);
      }
      
   }

   function render() {
      if($this->width != "") {
         $width = "width='".$this->width."'";
      } else {
         $width = "";
      }
    
      $ret = "<table border=0 cellpadding=0 cellspacing=0 $width>";
      
      // dump rows
      if(count($this->rowsdata)>0) {
         foreach($this->rowsdata as $key => $cellarray) {
            $ret .= "\n<tr>";
            if(!empty($this->colspan[$key])) {
               $colspandata = $this->colspan[$key];
            } else {
               unset($colspandata);
            }
            if(!empty($this->cellalign[$key])) {
               $cellalign = $this->cellalign[$key];
            } else {
               unset($cellalign);
            }
            if(!empty($this->cellvalign[$key])) {
               $cellvalign = $this->cellvalign[$key];
            } else {
               unset($cellvalign);
            }
            foreach($cellarray as $ck => $rowcell) {
               if(!empty($colspandata[$ck]) && $colspandata[$ck]>0) {
                  $colspan = " colspan=".(intval($colspandata[$ck]));
               } else {
                  $colspan = "";
               }
               if(!empty($cellalign[$ck])) {
                  $align = " align='".$cellalign[$ck]."'";
               } else {
                  $align = "";
               }
               if(!empty($cellvalign[$ck])) {
                  $valign = " valign='".$cellvalign[$ck]."'";
               } else {
                  $valign = "";
               }
               $ret .= "<td class=tds".$this->theme."$colspan$valign$align>$rowcell</td>";
            }
            $ret .= "</tr>";
         }
      }
      
      $ret .= "\n</table>";
      return $ret;
   }
}


class XocpTable {
   var $theme;
   var $cols;
   var $rows;
   var $rowsdata = array();
   var $colspan = array();
   var $rowspan = array();
   var $headerdata = array();
   var $footerdata = array();
   var $cellalign;
   var $cellvalign;
   var $width = 0;
   
   function XocpTable($theme=0) {
      $this->rows = 0;
      $this->theme = $theme;
   }
   
   function setWidth($width) {
      $this->width = $width;
   }
   
   function addRow() {
      $arg_list = func_get_args();
      $num_args = func_num_args();
      $this->rows++;
      $this->rowsdata[$this->rows] = array();
      for($i=0;$i<$num_args;$i++) {
         $this->rowsdata[$this->rows] = array_merge($this->rowsdata[$this->rows], $arg_list[$i]);
      }
      return $this->rows;
   }
   
   function addHeader() {
      $arg_list = func_get_args();
      $num_args = func_num_args();
      $this->rows++;
      $this->headerdata[$this->rows] = array();
      for($i=0;$i<$num_args;$i++) {
         $this->headerdata[$this->rows] = array_merge($this->headerdata[$this->rows], $arg_list[$i]);
      }
      return $this->rows;
   }
   
   function addFooter() {
      $arg_list = func_get_args();
      $num_args = func_num_args();
      $this->rows++;
      $this->footerdata[$this->rows] = array();
      for($i=0;$i<$num_args;$i++) {
         $this->footerdata[$this->rows] = array_merge($this->footerdata[$this->rows], $arg_list[$i]);
      }
      return $this->rows;
   }
   
   function setColSpan($rownum) {

      $arg_list = func_get_args();
      $num_args = func_num_args();
      $this->colspan[$rownum] = array();
      for($i=1;$i<$num_args;$i++) {
         $this->colspan[$rownum] = array_merge($this->colspan[$rownum], $arg_list[$i]);
      }

   }

   function setRowSpan($rownum) {

      $arg_list = func_get_args();
      $num_args = func_num_args();
      $this->rowspan[$rownum] = array();
      for($i=1;$i<$num_args;$i++) {
         $this->rowspan[$rownum] = array_merge($this->rowspan[$rownum], $arg_list[$i]);
      }

   }

   function setCellAlign($rownum) {
      $arg_list = func_get_args();
      $num_args = func_num_args();
      $this->cellalign[$rownum] = array();
      for($i=1;$i<$num_args;$i++) {
         $this->cellalign[$rownum] = array_merge($this->cellalign[$rownum], $arg_list[$i]);
      }

   }

   function setCellVAlign($rownum) {
      $arg_list = func_get_args();
      $num_args = func_num_args();
      $this->cellvalign[$rownum] = array();
      for($i=1;$i<$num_args;$i++) {
         $this->cellvalign[$rownum] = array_merge($this->cellvalign[$rownum], $arg_list[$i]);
      }
      
   }

   function render() {
      $ret = _theme::openTable($this->theme,$this->width);
      
      // setup header
      if(count($this->headerdata)>0) {
         foreach($this->headerdata as $key => $headcellarray) {
            $ret .= "<tr>";
            if(!empty($this->colspan[$key])) {
               $colspandata = $this->colspan[$key];
            } else {
               unset($colspandata);
            }
            if(!empty($this->rowspan[$key])) {
               $rowspandata = $this->rowspan[$key];
            } else {
               unset($rowspandata);
            }
            if(!empty($this->cellalign[$key])) {
               $cellalign = $this->cellalign[$key];
            } else {
               unset($cellalign);
            }
            if(!empty($this->cellvalign[$key])) {
               $cellvalign = $this->cellvalign[$key];
            } else {
               unset($cellvalign);
            }
            foreach($headcellarray as $hk => $headcell) {
               if(!empty($colspandata[$hk]) && $colspandata[$hk]>0) {
                  $colspan = " colspan=".(intval($colspandata[$hk]));
               } else {
                  $colspan = "";
               }
               if(!empty($rowspandata[$hk]) && $rowspandata[$hk]>0) {
                  $rowspan = " rowspan=".(intval($rowspandata[$hk]));
               } else {
                  $rowspan = "";
               }
               if(!empty($cellalign[$hk])) {
                  $align = " align='".$cellalign[$hk]."'";
               } else {
                  $align = "";
               }
               if(!empty($cellvalign[$hk])) {
                  $valign = " valign='".$cellvalign[$hk]."'";
               } else {
                  $valign = "";
               }
               $ret .= "<td class=tdh".$this->theme."$rowspan$colspan$align$valign>$headcell".($headcell==""? "&nbsp;" : "")."</td>";
            }
            $ret .= "</tr>\n";
         }
      }

      // setup rows
      if(count($this->rowsdata)>0) {
         foreach($this->rowsdata as $key => $cellarray) {
            $ret .= "<tr>";
            if(!empty($this->colspan[$key])) {
               $colspandata = $this->colspan[$key];
            } else {
               unset($colspandata);
            }
            if(!empty($this->rowspan[$key])) {
               $rowspandata = $this->rowspan[$key];
            } else {
               unset($rowspandata);
            }
            if(!empty($this->cellalign[$key])) {
               $cellalign = $this->cellalign[$key];
            } else {
               unset($cellalign);
            }
            if(!empty($this->cellvalign[$key])) {
               $cellvalign = $this->cellvalign[$key];
            } else {
               unset($cellvalign);
            }
            foreach($cellarray as $ck => $rowcell) {
               if(!empty($colspandata[$ck]) && $colspandata[$ck]>0) {
                  $colspan = " colspan=".(intval($colspandata[$ck]));
               } else {
                  $colspan = "";
               }
               if(!empty($rowspandata[$ck]) && $rowspandata[$ck]>0) {
                  $rowspan = " rowspan=".(intval($rowspandata[$ck]));
               } else {
                  $rowspan = "";
               }
               if(!empty($cellalign[$ck])) {
                  $align = " align='".$cellalign[$ck]."'";
               } else {
                  $align = "";
               }
               if(!empty($cellvalign[$ck])) {
                  $valign = " valign='".$cellvalign[$ck]."'";
               } else {
                  $valign = "";
               }
               $ret .= "<td class=td".$this->theme."$rowspan$colspan$align$valign>$rowcell".($rowcell==""? "&nbsp;" : "")."</td>";
            }
            $ret .= "</tr>\n";
         }
      }
      
      // setup footer
      if(count($this->footerdata)>0) {
         foreach($this->footerdata as $key => $footcellarray) {
            $ret .= "<tr>";
            if(!empty($this->colspan[$key])) {
               $colspandata = $this->colspan[$key];
            } else {
               unset($colspandata);
            }
            if(!empty($this->cellalign[$key])) {
               $cellalign = $this->cellalign[$key];
            } else {
               unset($cellalign);
            }
            if(!empty($this->cellvalign[$key])) {
               $cellvalign = $this->cellvalign[$key];
            } else {
               unset($cellvalign);
            }
            foreach($footcellarray as $fk => $footcell) {
               if(!empty($colspandata) && $colspandata[$fk]>0) {
                  $colspan = " colspan=".(intval($colspandata[$fk]));
               } else {
                  $colspan = "";
               }
               if(!empty($cellalign[$fk])) {
                  $align = " align='".$cellalign[$fk]."'";
               } else {
                  $align = "";
               }
               if(!empty($cellvalign[$fk])) {
                  $valign = " valign='".$cellvalign[$fk]."'";
               } else {
                  $valign = "";
               }
               $ret .= "<td class=tdf".$this->theme."$colspan$align$valign>$footcell".($footcell==""? "&nbsp;" : "")."</td>";
            }
            $ret .= "</tr>\n";
         }
      }
      $ret .= _theme::closeTable();
      return $ret;
   }
}

} // XOCP_HTML_DEFINED
?>