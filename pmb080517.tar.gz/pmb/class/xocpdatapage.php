<?php
//--------------------------------------------------------------------//
// Filename : class/xocpdatapage.php                                  //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-12-05                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('XOCP_DATAPAGE_DEFINED') ) {
   define('XOCP_DATAPAGE_DEFINED', TRUE);

class XocpDataPage {
   var $sql_query;
   var $data;
   var $rows;
   var $pagesize = 10;
   var $offset = 0;
   var $tmpfile;
   
   function XocpDataPage() {
      $this->data = array();
      $this->tmpfile = "f_" . uniqid(rand());
      $this->rows = 0;
   }
   
   function getFile() {
      return $this->tmpfile;
   }
   
   function setFile($filename) {
      $this->tmpfile = $filename;
   }
   
   function addData() {
      $arg_list = func_get_args();
      $num_args = func_num_args();
      $this->rows++;
      $this->data[$this->rows] = array();
      for($i=0;$i<$num_args;$i++) {
         $this->data[$this->rows] = array_merge($this->data[$this->rows], $arg_list[$i]);
      }
      return $this->rows;
   }
   

   function getCount() {
      return count($this->data);
   }
   
   function setOffset($offset = 0) {
      $this->offset = intval($offset);
   }
   
   function getOffset() {
      return $this->offset;
   }
   
   function setPage($page = 0) {
      $this->offset = $page * $this->getPageSize();
   }
   
   function getPage() {
      if($this->getPageSize() == 0) {
         return 0;
      } else {
         return floor($this->getOffset()/$this->getPageSize());
      }
   }
   
   function getNextPage() {
      return ($this->getOffset() + $this->getPageSize() >= count($this->data) ? $this->getPage() : $this->getPage()+1);
   }
   
   function getPrevPage() {
      return ($this->getOffset()-$this->getPageSize() > 0 ? $this->getPage()-1  : 0);
   }
   
   function getNextOffset() {
      return ($this->getOffset() + $this->getPageSize() >= count($this->data) ? $this->getOffset() : $this->getOffset() + $this->getPageSize());
   }
   
   function getPrevOffset() {
      return ($this->getOffset()-$this->getPageSize() > 0 ? $this->getOffset()-$this->getPageSize()  : 0);
   }
   
   function getPageArray($c = 5) {
      $pages = array();
      $pagecount = ceil($this->getCount()/$this->getPageSize()) - 1;
      $cx = min($pagecount,$c-1);
      $s = ($this->getPage() - floor($cx/2) < 0 ? 0 : $this->getPage() - floor($cx/2));
      for($i = $s; $i <= ($cx+$s); $i++ ) {
         if(($s+$cx) >= $pagecount) {
            $p = $i-($s+$cx-$pagecount);
         } else {
            $p = $i;
         }
         $pages[] = $p;
      }
      return $pages;
   }
   
   function getPageLinkArray($xlink = "",$varpage = "p",$varfile = "f",$c = 5) {
      $link = array();
      $pages = $this->getPageArray($c);
      foreach($pages as $p) {
         if($p == $this->getPage()) {
            $link[] = ($p+1);
         } else {
            $link[] = "<a href=$xlink&$varfile=" . $this->getFile(). "&$varpage=$p>" .($p+1) . "</a>";
         }
      }
      return $link;
   }
   
   function getPageLinks($xlink = "",$delimiter = " ",$varpage = "p",$varfile = "f",$c = 5) {
      $link = $this->getPageLinkArray($xlink,$varpage,$varfile,$c);
      $prev = "<a href=$xlink&$varfile=".$this->getFile()."&$varpage=".$this->getPrevPage().">"._PREV."</a>";
      $next = "<a href=$xlink&$varfile=".$this->getFile()."&$varpage=".$this->getNextPage().">"._NEXT."</a>";
      if(count($this->data)<=$this->getPageSize()) {
         return "";
      }
      return "[$prev|".implode($delimiter,$link)."|$next]";
   }
   
   function setPageSize($pagesize = 0) {
      $this->pagesize = $pagesize;
   }
   
   function getPageSize() {
      return $this->pagesize;
   }
   
   function reset() {
      $this->setOffset(0);
   }
   
   function retrieve($offset=NULL,$pagesize=NULL) {
      if($offset != NULL) {
         $this->setOffset($offset);
      }
      if($pagesize != NULL) {
         $this->setPageSize($pagesize);
      }
      if($this->getPageSize() == 0) {
         $ret = $this->data;
      } else {
         $ret = array_slice($this->data,$this->offset,$this->pagesize);
         $this->offset += $this->pagesize;
      }
      return $ret;
   }
   
   function serialize() {
      $s = serialize($this);
      $fp = fopen(XOCP_SESSION_TMPDATA."/".$this->tmpfile, "w");
      fwrite($fp,$s);
      fclose($fp);
      return $this->getFile();
   }
   
   function unserialize($filename) {
      $s = implode("", @file(XOCP_SESSION_TMPDATA."/".$filename));
      return unserialize($s);
   }
   
}

} // XOCP_DATAPAGE_DEFINED
?>