<?php
//--------------------------------------------------------------------//
// Filename : class/xocpblock.php                                     //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-20                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('XOCP_BLOCK_DEFINED') ) {
   define('XOCP_BLOCK_DEFINED', TRUE);

class XocpBlock {
   
   var $catch;
   var $align = "align=left";
   var $html = NULL;
   var $width = "";
   var $catchvar = "X_xocp";
   var $blockID = "";
   
   function XocpBlock($catch=NULL) {
      $this->catch = $catch;
   }
   
   function setHTMLObject(&$obj) {
      if(is_object($obj) && get_class($obj) == "xocphtml") {
         $this->html = &$obj;
      }
   }
   
   function setWidth($width) {
      $this->width = $width;
   }
   
   function main() {
      return "";
   }
   
   function show() {
      return _theme::openBlock($this->width) . $this->main() . _theme::closeBlock();
   }
   
   function varForm() {
      return new XocpFormHidden($this->catchvar,$this->blockID);
   }
   
   function varURL() {
      return $this->catchvar . "=" . $this->blockID;
   }
   
   function blockHREF($script = "/index.php") {
      return XOCP_SERVER_SUBDIR . $script . "?" . $this->varURL();
   }

}

} // XOCP_BLOCK_DEFINED
?>