<?php
//--------------------------------------------------------------------//
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-09                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('XOCP_FORM_DEFINED') ) {
   define('XOCP_FORM_DEFINED', TRUE);

//--------------------------------------------------------------------//
// XocpForm                                                           //
//--------------------------------------------------------------------//

class XocpForm {
   // private
   var $action;

   //private
   var $method;

   //private
   var $name;

   //private
   var $title;

   // private
   // array of form element objects
   var $elements = array();

   // private
   var $extra;

   // private
   // required elements
   var $required = array();

   // public
   function XocpForm($title, $name, $action, $method="post"){
      $this->title = $title;
      $this->name = $name;
      $this->action = $action;
      $this->method = $method;
   }

   // public
   function getTitle(){
      return $this->title;
   }

   function setTitle($title){
      $this->title = $title;
   }

   // public
   function getName(){
      return $this->name;
   }

   // public
   function getAction(){
      return $this->action;
   }

   // public
   function getMethod(){
      return $this->method;
   }

   // public
   function addElement($ele){
      $this->elements[] = $ele;
   }

   // public
   function getElements(){
      return $this->elements;
   }
   
   // public
   function getElementCaption($elementname) {
      $myarray = $this->getElements();
      if(is_array($myarray)) {
         reset($myarray);
         foreach($myarray as $element) {
            if($element->name == $elementname) {
               return $element->caption;
            } 
         }
      }
   }

   function setExtra($extra){
      $this->extra = " ".$extra;
   }

   function getExtra(){
      if (isset($this->extra)) {
         return $this->extra;
      }
   }

   function setRequired($required){
      if ( is_array($required) ) {
         foreach ( $required as $req ) {
            $this->required[] = $req;
         }
      } else {
         $this->required[] = $required;
      }
   }

   function getRequired(){
      return $this->required;
   }

   // public abstract
   // returns renderered form
   function render(){
   }

   // public
   // displays rendered form
   function display(){
      echo $this->render();
   }
}

//--------------------------------------------------------------------//
// XocpFormElement                                                    //
//--------------------------------------------------------------------//

class XocpFormElement {

   // private
   var $name;

   // private
   var $caption;

   // private
   var $hidden = false;

   // private
   var $extra;

   // private
   var $required = false;

   //public
   function XocpFormElement(){
      die("This class cannot be instantiated!");
   }

   // public
   function setName($name) {
      $this->name = $name;
   }

   // public
   function getName($encode=true) {
      if ($encode) {
         return str_replace("&amp;", "&", str_replace("'","&#039;",htmlspecialchars($this->name)));
      }
      return $this->name;
   }

   // public
   function setCaption($caption) {
      $this->caption = $caption;
   }

   // public
   function getCaption() {
      return $this->caption;
   }

   // public
   function setHidden() {
      $this->hidden = true;
   }

   // public
   function isHidden() {
      return $this->hidden;
   }

   // public
   function setExtra($extra){
      $this->extra = " ".$extra;
   }

   // public
   function getExtra(){
      if (isset($this->extra)) {
         return $this->extra;
      }
   }

   // abstract
   function render(){
   }
}

//--------------------------------------------------------------------//
// XocpFormButton                                                     //
//--------------------------------------------------------------------//

class XocpFormButton extends XocpFormElement {

   // private
   var $value;

   // private
   // this could be either "button", "submit", or "reset"
   var $type;

   // public
   function XocpFormButton($caption, $name, $value="", $type="button"){
      $this->setCaption($caption);
      $this->setName($name);
      $this->type = $type;
      $this->value = $value;
   }

   // public
   function getValue(){
      return $this->value;
   }

   // public
   function getType(){
      return $this->type;
   }

   // public
   function render(){
      return "<input type='".$this->getType()."' name='".$this->getName()."' id='".$this->getName()."' value='".$this->getValue()."'".$this->getExtra()." class='bt' />";
   }
}

//--------------------------------------------------------------------//
// XocpFormCheckBox                                                   //
//--------------------------------------------------------------------//

class XocpFormCheckBox extends XocpFormElement {

   // 
   var $nolabel = 0;
   
   // private
   var $options = array();

   // private
   // pre-selected values in array
   var $value = array();
   var $delimiter;

   // public
   function XocpFormCheckBox($caption, $name, $value="",$delimiter="&nbsp;"){
      $this->setCaption($caption);
      $this->setName($name);
      $this->delimiter = $delimiter;
      if ( $value != "" ) {
         if ( is_array($value) ) {
            foreach ( $value as $v ) {
               $this->value[] = $v;
            }
         } else {
            $this->value[] = $value;
         }
      }
   }
   
   function setNoLabel() {
      $this->nolabel = 1;
   }

   // public
   function getValue(){
      return $this->value;
   }

   // public
   function addOption($value, $name=""){
      if ( $name != "" ) {
         $this->options[$value] = $name;
      } else {
         $this->options[$value] = $value;
      }
   }

   // public
   function addOptionArray($arr){
      if ( is_array($arr) ) {
         foreach ( $arr as $k=>$v ) {
            $this->addOption($k, $v);
         }
      }
   }

   // public
   function getOptions(){
      return $this->options;
   }

   // public
   function render(){
      $ret = "";
      if ( count($this->getOptions()) > 1 && substr($this->getName(), -2, 2) != "[]" ) {
         $newname = $this->getName()."[]";
      } else {
         $newname = $this->getName();
      }
      foreach ( $this->getOptions() as $value => $name ) {
         
         $ret .= "<input class='ckb' type='checkbox' name='".$newname."' id='".$this->getName()."$value' value='".$value."'";
         $count = count($this->getValue());
         if ( $count > 0 && in_array($value, $this->getValue()) ) {
            $ret .= " checked='checked'";
         }
         $ret .= $this->getExtra()." />";
         
         if($this->nolabel == 0) {
            $ret .= "<label for=".$this->getName()."$value>".$name."</label>". $this->delimiter . "\n";
         } else {
            $ret .= $this->delimiter . "\n";
         }
      }
      return $ret;
   }
}



//--------------------------------------------------------------------//
// XocpDateTime                                                       //
//--------------------------------------------------------------------//

class XocpDateTime {

   // private
   var $seconds;
   var $minutes;
   var $hours;
   var $mday;
   var $wday;
   var $mon;
   var $year;
   var $yday;
   var $prefix;

   function XocpDateTime($data=NULL) {
      if($data!="") {
         $this->setDatetime($data);
      } else {
         $this->seconds = "";
         $this->minutes = "";
         $this->hours = "";
         $this->mday = "";
         $this->wday = "";
         $this->mon = "";
         $this->year = "";
         $this->yday = "";
      }
   }
   
   // public
   function getPrefix() {
      return $this->prefix;
   }

   // public
   function setPrefix($prefix) {
      $this->prefix = $prefix;
   }
   
   // public
   function eatVars($prefix,$method="post",$arrayvar = NULL) {
      $method = strtolower($method);
      switch($method) {
         case "post" :
            global $HTTP_POST_VARS;
               $this->seconds = $HTTP_POST_VARS[$prefix."_seconds"];
               $this->minutes = $HTTP_POST_VARS[$prefix."_minutes"];
               $this->hours = $HTTP_POST_VARS[$prefix."_hours"];
               $this->mday = $HTTP_POST_VARS[$prefix."_mday"];
               $this->wday = $HTTP_POST_VARS[$prefix."_wday"];
               $this->mon = $HTTP_POST_VARS[$prefix."_mon"];
               $this->year = $HTTP_POST_VARS[$prefix."_year"];
               $this->yday = $HTTP_POST_VARS[$prefix."_yday"];
            break;
         case "get" :
            global $HTTP_GET_VARS;
               $this->seconds = $HTTP_GET_VARS[$prefix."_seconds"];
               $this->minutes = $HTTP_GET_VARS[$prefix."_minutes"];
               $this->hours = $HTTP_GET_VARS[$prefix."_hours"];
               $this->mday = $HTTP_GET_VARS[$prefix."_mday"];
               $this->wday = $HTTP_GET_VARS[$prefix."_wday"];
               $this->mon = $HTTP_GET_VARS[$prefix."_mon"];
               $this->year = $HTTP_GET_VARS[$prefix."_year"];
               $this->yday = $HTTP_GET_VARS[$prefix."_yday"];
            break;
         case "session" :
            global $HTTP_SESSION_VARS;
               $this->seconds = $HTTP_SESSION_VARS[$prefix."_seconds"];
               $this->minutes = $HTTP_SESSION_VARS[$prefix."_minutes"];
               $this->hours = $HTTP_SESSION_VARS[$prefix."_hours"];
               $this->mday = $HTTP_SESSION_VARS[$prefix."_mday"];
               $this->wday = $HTTP_SESSION_VARS[$prefix."_wday"];
               $this->mon = $HTTP_SESSION_VARS[$prefix."_mon"];
               $this->year = $HTTP_SESSION_VARS[$prefix."_year"];
               $this->yday = $HTTP_SESSION_VARS[$prefix."_yday"];
            break;
         case "array" :
            global $HTTP_SESSION_VARS;
               $this->seconds = $arrayvar[$prefix."_seconds"];
               $this->minutes = $arrayvar[$prefix."_minutes"];
               $this->hours = $arrayvar[$prefix."_hours"];
               $this->mday = $arrayvar[$prefix."_mday"];
               $this->wday = $arrayvar[$prefix."_wday"];
               $this->mon = $arrayvar[$prefix."_mon"];
               $this->year = $arrayvar[$prefix."_year"];
               $this->yday = $arrayvar[$prefix."_yday"];
            break;
         default :
            break;
      }
   }

   function setDatetime($data) {
      if(is_array($data)) {
         $this->seconds = $data['seconds'];
         $this->minutes = $data['minutes'];
         $this->hours = $data['hours'];
         $this->mday = $data['mday'];
         $this->wday = $data['wday'];
         $this->mon = $data['mon'];
         $this->year = $data['year'];
         $this->yday = $data['yday'];
         return TRUE;
      } elseif($data != "0000-00-00" && $data != "0000-00-00 00:00:00" && $data != "") {
         list($data0,$data1)= explode(" ",$data);
         if (ereg ("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $data0, $regs0)) {
            $this->year = intval($regs0[1]);
            $this->mon = intval($regs0[2]);
            $this->mday = intval($regs0[3]);
         }
         if (ereg ("([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2})", $data1, $regs1)) {
            $this->hours = intval($regs1[1]);
            $this->minutes = intval($regs1[2]);
            $this->seconds = intval($regs1[3]);
         }
      } else {
         return FALSE;
      }
      
   }
   
   function getDatetime() {
      return $this->year."-".$this->mon."-".$this->mday." ".$this->hours."-".$this->minutes."-".$this->seconds;
   }
   
   function getDate($type=NULL) {
      $type = strtolower($type);
      switch($type) {
         case "y" :
            return $this->year;
         case "m" :
            return $this->mon;
         case "d" :
            return $this->mday;
         default :
            return $this->year."-".$this->mon."-".$this->mday;
      }
   }
   
   function getTime($type=NULL) {
      $type = strtolower($type);
      switch($type) {
         case "h" :
            return $this->hours;
         case "m" :
            return $this->minutes;
         case "s" :
            return $this->seconds;
         default :
            return $this->hours.":".$this->minutes.":".$this->seconds;
      }
   }
   
   function getMySQL($type="date") {
      $type = strtolower($type);
      switch($type) {
         case "time" :
            return sprintf("%02d:%02d:%02d", $this->hours, $this->minutes, $this->seconds);
            break;
         case "datetime" :
            return sprintf("%04d-%02d-%02d %02d:%02d:%02d", $this->year, $this->mon, $this->mday, $this->hours, $this->minutes, $this->seconds);
            break;
         case "date" :
         default :
            return sprintf("%04d-%02d-%02d", $this->year, $this->mon, $this->mday);
            break;
      }
   }
   
   function truncDate() {
      if(intval($this->year) == 0) {
         $this->setDatetime("0000-00-00 00:00:00");
      }
      if(intval($this->mon) == 0) {
         $this->setDatetime($this->year."-00-00 00:00:00");
      }
      if(intval($this->mday) == 0) {
         $this->setDatetime($this->year."-".$this->mon."-00 00:00:00");
      }
   }


}

//--------------------------------------------------------------------//
// XocpFormDateTime                                                   //
//--------------------------------------------------------------------//

class XocpFormDateTime extends XocpFormElement {

   // private
   var $value;
   var $prefix;
   var $type;
   
   // public
   function XocpFormDateTime($caption, $prefix, $value=NULL, $type = "date"){
      $this->setCaption($caption);
      $this->setName($prefix);
      if(is_object($value) && get_class($value) == "xocpdatetime") {
         $this->value = $value;
      } else {
         $this->value = new XocpDatetime();
      }
      $this->setType($type);
      $this->setPrefix($prefix);
   }

   // public
   function getValue(){
      return $this->value;
   }

   // public
   function setValue($value){
      if(is_object($value) && get_class_name($value) == "xocpdatetime") {
         $this->value = $value;
      }
   }

   // public
   function getPrefix() {
      return $this->value->getPrefix();
   }

   // public
   function setPrefix($prefix) {
      $this->value->setPrefix($prefix);
   }

   // public
   function setType($type) {
      $type = strtolower($type);
      if($type == "date") {
         $this->type = "date";
      } elseif ($type == "time") {
         $this->type = "time";
      } elseif ($type == "datetime") {
         $this->type = "datetime";
      } elseif ($type == "month") {
         $this->type = "month";
      } elseif ($type == "year") {
         $this->type = "year";
      } elseif ($type == "yearmonth") {
         $this->type = "yearmonth";
      } else {
         $this->type = "date";
      }
   }

   // public
   function getType() {
      return $this->type;
   }

   // public
   function render(){
      global $xocp_vars;
      
      if($this->getType() == "date") {
         $m = new XocpFormSelect("",$this->getPrefix()."_mon",$this->value->getDate("m"));
         $m->addOptionArray($xocp_vars['month_year']);
         $ret = "<input type='text' size=2 maxlength=2 name='".$this->getPrefix()."_mday' id='".$this->getPrefix()."_mday' value='".$this->value->getDate("d")."' />"
              ."&nbsp;". $m->render() ."&nbsp;"."<input type='text' size=4 maxlength=4 name='".$this->getPrefix()."_year' id='".$this->getPrefix()."_year' value='".$this->value->getDate("y")."' />";
      } else if($this->getType() == "time") {
         $ret = "<input type='text' size=2 maxlength=2 name='".$this->getPrefix()."_hours' id='".$this->getPrefix()."_hours' value='".$this->value->getTime("h")."' />"
              . ":" . "<input type='text' size=2 maxlength=2 name='".$this->getPrefix()."_minutes' id='".$this->getPrefix()."_minutes' value='".$this->value->getTime("m")."' />";
      } else if($this->getType() == "datetime") {
         $m = new XocpFormSelect("",$this->getPrefix()."_mon",$this->value->getDate("m"));
         $m->addOptionArray($xocp_vars['month_year']);
         $ret = "<input type='text' size=2 maxlength=2 name='".$this->getPrefix()."_mday' id='".$this->getPrefix()."_mday' value='".$this->value->getDate("d")."' />"
              . "&nbsp;" . $m->render() . "&nbsp;" . "<input type='text' size=4 maxlength=4 name='".$this->getPrefix()."_year' id='".$this->getPrefix()."_year' value='".$this->value->getDate("y")."' />"
              . "&nbsp;-&nbsp;" . "<input type='text' size=2 maxlength=2 name='".$this->getPrefix()."_hours' id='".$this->getPrefix()."_hours' value='".$this->value->getTime("h")."' />"
              . ":" . "<input type='text' size=2 maxlength=2 name='".$this->getPrefix()."_minutes' id='".$this->getPrefix()."_minutes' value='".$this->value->getTime("m")."' />";
      } else if($this->getType() == "month") {
         $m = new XocpFormSelect("",$this->getPrefix()."_mon",$this->value->getDate("m"));
         $m->addOptionArray($xocp_vars['month_year']);
         $ret = $m->render() ."&nbsp;"."<input type='text' size=4 maxlength=4 name='".$this->getPrefix()."_year' id='".$this->getPrefix()."_year' value='".$this->value->getDate("y")."' />";
      } else if($this->getType() == "year") {
         $ret = "<input type='text' size=4 maxlength=4 name='".$this->getPrefix()."_year' id='".$this->getPrefix()."_year' value='".$this->value->getDate("y")."' />";
      } else if($this->getType() == "yearmonth") {
         $m = new XocpFormSelect("",$this->getPrefix()."_mon",$this->value->getDate("m"));
         $m->addOptionArray($xocp_vars['month_year']);
         $ret = $m->render() ."&nbsp;"."<input type='text' size=4 maxlength=4 name='".$this->getPrefix()."_year' id='".$this->getPrefix()."_year' value='".$this->value->getDate("y")."' />";
      }
      return $ret;
   }
}



//--------------------------------------------------------------------//
// XocpFormElementTray                                                //
//--------------------------------------------------------------------//

class XocpFormElementTray extends XocpFormElement {

   // private
   // array of form element objects
   var $elements = array();

   // private
   var $delimiter;

   // public
   function XocpFormElementTray($caption, $delimiter="&nbsp;"){
      $this->setCaption($caption);
      $this->delimiter = $delimiter;
   }

   // public
   function addElement($ele){
      $this->elements[] = $ele;
   }

   // public
   function getElements(){
      return $this->elements;
   }

   // public
   function getDelimiter(){
      return $this->delimiter;
   }

   // public
   function render(){
      $count = 0;
      $ret = "";
      foreach ( $this->getElements() as $ele ) {
         if ( $count > 0 ) {
            $ret .= $this->getDelimiter();
         }
         $ret .= $ele->getCaption()."".$ele->render()."\n";
         $count++;
      }
      return $ret ."&nbsp;";
   }
}


//--------------------------------------------------------------------//
// XocpFormFile                                                       //
//--------------------------------------------------------------------//

class XocpFormFile extends XocpFormElement {

   //private
   var $maxFileSize;

   // public
   function XocpFormFile($caption, $name, $maxfilesize){
      $this->setCaption($caption);
      $this->setName($name);
      $this->maxFileSize = intval($maxfilesize);
   }

   // public
   function getMaxFileSize(){
      return $this->maxFileSize;
   }

   // public
   function render(){
      return "<input type='hidden' name='MAX_FILE_SIZE' value='".$this->getMaxFileSize()."' /><input type='file' name='".$this->getName()."' id='".$this->getName()."'".$this->getExtra()." /><input type='hidden' name='xocp_upload_file[]' id='xocp_upload_file[]' value='".$this->getName()."' />";
   }
}


//--------------------------------------------------------------------//
// XocpFormHidden                                                     //
//--------------------------------------------------------------------//

class XocpFormHidden extends XocpFormElement {

   // private
   var $value;

   // public
   function XocpFormHidden($name, $value){
      $this->setName($name);
      $this->setHidden();
      $this->value = $value;
      $this->setCaption("");
   }

   // public
   function getValue(){
      return $this->value;
   }

   // public
   function render($value=""){
      return "<input type='hidden' name='".$this->getName()."' id='".$this->getName()."' value='".$this->getValue()."' />";
   }
}


//--------------------------------------------------------------------//
// XocpFormLabel                                                      //
//--------------------------------------------------------------------//

class XocpFormLabel extends XocpFormElement {

   // private
   var $value;

   function XocpFormLabel($caption="", $value=""){
      $this->setCaption($caption);
      $this->value = $value;
   }

   // public
   function getValue(){
      if($this->value == '') {
         $space = "&nbsp;";
      } else {
         $space = "";
      }
      return $this->value.$space;
   }

   function render(){
      return $this->getValue();
   }
}


//--------------------------------------------------------------------//
// XocpFormPassword                                                   //
//--------------------------------------------------------------------//

class XocpFormPassword extends XocpFormElement {

   // private
   var $size;

   //private
   var $maxlength;

   //private
   var $value;

   // public
   function XocpFormPassword($caption, $name, $size, $maxlength, $value=""){
      $this->setCaption($caption);
      $this->setName($name);
      $this->size = intval($size);
      $this->maxlength = intval($maxlength);
      $this->value = $value;
   }

   // public
   function getSize(){
      return $this->size;
   }

   // public
   function getMaxlength(){
      return $this->maxlength;
   }

   // public
   function getValue(){
      return $this->value;
   }

   // public
   function render(){
      return "<input type='password' name='".$this->getName()."' id='".$this->getName()."' size='".$this->getSize()."' maxlength='".$this->getMaxlength()."' value='".$this->getValue()."'".$this->getExtra()." />";
   }
}


//--------------------------------------------------------------------//
// XocpFormRadio                                                      //
//--------------------------------------------------------------------//

class XocpFormRadio extends XocpFormElement {

   // private
   var $options = array();
   var $delimiter;

   // private
   // pre-selected value
   var $value;

   // public
   function XocpFormRadio($caption, $name, $value=NULL, $delimiter = "&nbsp;"){
      $this->setCaption($caption);
      $this->setName($name);
      $this->value = $value;
      $this->delimiter = $delimiter;
   }

   // public
   function getValue(){
      return $this->value;
   }

   // public
   function addOption($value, $name=""){
      if ( $name != "" ) {
         $this->options[$value] = $name;
      } else {
         $this->options[$value] = $value;
      }
   }

   // public
   function addOptionArray($arr){
      if ( is_array($arr) ) {
         foreach ( $arr as $k=>$v ) {
            $this->addOption($k, $v);
         }
      }
   }

   // public
   function getOptions(){
      return $this->options;
   }

   // public
   function getDelimiter(){
      return $this->delimiter;
   }

   // public
   function render(){
      $ret = "";
      foreach ( $this->getOptions() as $value => $name ) {
         $ret .= "<input class='rdb' type='radio' name='".$this->getName()."' id='".$this->getName()."$value' value='".$value."'";
         $selected = $this->getValue();
         if ( isset($selected) && ($value == $selected) ) {
            $ret .= " checked='checked'";
         }
         $ret .= $this->getExtra()." /><label for='".$this->getName()."$value'>".$name."</label>"
              .  $this->getDelimiter();
      }
      return $ret;
   }
}

//--------------------------------------------------------------------//
// XocpFormRadioYN                                                    //
//--------------------------------------------------------------------//

class XocpFormRadioYN extends XocpFormRadio {

   function XocpFormRadioYN($caption, $name, $value=NULL, $yes=_YES, $no=_NO){
      $this->XocpFormRadio($caption, $name, $value);
      $this->addOption(1, $yes);
      $this->addOption(0, $no);
   }
}

//--------------------------------------------------------------------//
// XocpFormSelect                                                     //
//--------------------------------------------------------------------//

class XocpFormSelect extends XocpFormElement {

   // private
   var $options = array();

   // private
   var $multiple = false;

   // private
   var $size;

   // private
   // pre-selected values in array
   var $value = array();

   // public
   function XocpFormSelect($caption, $name, $value="", $size=1, $multiple=false){
      $this->setCaption($caption);
      $this->setName($name);
      $this->multiple = $multiple;
      $this->size = intval($size);
      if ( $value != "" ) {
         if ( is_array($value) ) {
            foreach ( $value as $v ) {
               $this->value[] = $v;
            }
         } else {
            $this->value[] = $value;
         }
      }
   }

   // public
   function isMultiple(){
      return $this->multiple;
   }

   // public
   function getSize(){
      return $this->size;
   }

   // public
   function getValue(){
      return $this->value;
   }

   // public
   function addOption($value, $name=""){
      $this->options[$value] = $name;
   }

   // public
   function addOptionArray($arr){
      if ( is_array($arr) ) {
         foreach ( $arr as $k=>$v ) {
            $this->addOption($k, $v);
         }
      }
   }

   // public
   function getOptions(){
      return $this->options;
   }

   // public
   function render(){
      $ret = "<select  size='".$this->getSize()."'".$this->getExtra()."";
      if ( $this->isMultiple() != false ) {
         $ret .= " name='".$this->getName()."[]' id='".$this->getName()."[]' multiple='multiple'>\n";
      } else {
         $ret .= " name='".$this->getName()."' id='".$this->getName()."'>\n";
      }
      foreach ( $this->getOptions() as $value => $name ) {
         $ret .= "<option value='".htmlspecialchars($value, ENT_QUOTES)."'";
         $count = count($this->getValue());
         if ( $count > 0 && in_array($value, $this->getValue()) ) {
               $ret .= " selected='selected'";
         }
         $ret .= ">".$name."</option>\n";
      }
      $ret .= "</select>";
      return $ret;
   }
}


//--------------------------------------------------------------------//
// XocpFormText                                                       //
//--------------------------------------------------------------------//

class XocpFormText extends XocpFormElement {

   // private
   var $size;

   //private
   var $maxlength;

   //private
   var $value;
   
   //private
   var $align;

   // public
   function XocpFormText($caption, $name, $size, $maxlength, $value="",$align="left"){
      $this->setCaption($caption);
      $this->setName($name);
      $this->size = intval($size);
      $this->maxlength = intval($maxlength);
      $this->value = $value;
      $this->align = $align;
   }

   // public
   function getSize(){
      return $this->size;
   }

   // public
   function getMaxlength(){
      return $this->maxlength;
   }

   // public
   function getValue(){
      return $this->value;
   }

   // public
   function render(){
      return "<input style='text-align:".$this->align.";' type='text' name='".$this->getName()."' id='".$this->getName()."' size='".$this->getSize()."' maxlength='".$this->getMaxlength()."' value='".$this->getValue()."'".$this->getExtra()." />";
   }
}


//--------------------------------------------------------------------//
// XocpFormTextArea                                                   //
//--------------------------------------------------------------------//

class XocpFormTextArea extends XocpFormElement {
   // private
   var $cols;

   //private
   var $rows;

   //private
   var $value;

   // public
   function XocpFormTextArea($caption, $name, $value="", $rows=5, $cols=50){
      $this->setCaption($caption);
      $this->setName($name);
      $this->rows = intval($rows);
      $this->cols = intval($cols);
      $this->value = $value;
   }

   // public
   function getRows(){
      return $this->rows;
   }

   // public
   function getCols(){
      return $this->cols;
   }

   // public
   function getValue(){
      return $this->value;
   }

   // public
   function render($value=""){
      return "<textarea name='".$this->getName()."' id='".$this->getName()."' rows='".$this->getRows()."' cols='".$this->getCols()."'".$this->getExtra().">".$this->getValue()."</textarea>";
   }
}

////////////////////////////////////////////////////////////////////////

//--------------------------------------------------------------------//
// XocpSimpleForm                                                     //
//--------------------------------------------------------------------//

class XocpSimpleForm extends XocpForm {

   function XocpSimpleForm($title, $name, $action, $method="post"){
      $this->XocpForm($title, $name, $action, $method);
   }

   function render(){
      $ret = "\n<form class=simpleform name='".$this->getName()."' id='".$this->getName()."' action='".$this->getAction()."' method='".$this->getMethod()."'".$this->getExtra().">\n";
      foreach ( $this->getElements() as $ele ) {
         if ( !$ele->isHidden() ) {
            $ret .= $ele->render()."\n";
         } else {
            $ret .= $ele->render()."\n";
         }
      }
      $ret .= "</form>\n";
      return $ret;
   }
}


//--------------------------------------------------------------------//
// XocpTableForm                                                      //
//--------------------------------------------------------------------//

class XocpTableForm extends XocpForm {

   function XocpTableForm($title, $name, $action, $method="post"){
      $this->XocpForm($title, $name, $action, $method);
   }

   function render(){
      $ret = $this->getTitle()."\n<form name='".$this->getName()."' id='".$this->getName()."' action='".$this->getAction()."' method='".$this->getMethod()."'".$this->getExtra().">\n<table border='0' width='100%'>\n";
      $hidden = "";
      foreach ( $this->getElements() as $ele ) {
         if ( !$ele->isHidden() ) {
            $ret .= "<tr valign='top' align='right'><td nowrap='nowrap'>".$ele->getCaption()."</td><td>".$ele->render()."</td></tr>\n";
         } else {
            $hidden .= $ele->render()."\n";
         }
      }
      $ret .= "</table>\n".$hidden."\n</form>\n";
      return $ret;
   }
}


//--------------------------------------------------------------------//
// XocpThemeForm                                                      //
//--------------------------------------------------------------------//

class XocpThemeForm extends XocpForm {
   var $comment;
   var $js = FALSE;
   var $theme;
   var $width = "";
   
   function XocpThemeForm($caption, $name, $action, $method="post", $js=FALSE){
      $this->XocpForm($caption, $name, $action, $method);
      $this->js = $js;
      if($this->js) {
         $this->setExtra("onsubmit='return xocpFormValidate_".$this->getName()."();'");
      }
      $this->theme = "0";
   }
   
   function setWidth($width=0) {
      $this->width = $width;
   }
   
   function setTheme($theme=0) {
      $this->theme = intval($theme);
   }
   
   function setComment($text) {
      $this->comment = $text;
   }

   function render($value=""){
      $required = $this->getRequired();
      $ret = "\n<!-- OpenForm --><form class='myform' name='".$this->getName()."' id='".$this->getName()."' action='".$this->getAction()."' method='".$this->getMethod()."'".$this->getExtra().">\n";
      $ret .= _theme::openTable($this->theme,$this->width);
      $ret .= "<tr><td colspan=2 class='tdh".$this->theme."'>".$this->getTitle()."</td></tr>\n";
      $hidden = "";
      foreach ( $this->getElements() as $ele ) {
         if ( !$ele->isHidden() ) {
            $ret .= "<tr valign='top'><td class='td".$this->theme."'>&nbsp;".$ele->getCaption()."</td><td class='td".$this->theme."'>".$ele->render()."</td></tr>\n";
         } else {
            $hidden .= $ele->render()."\n";
         }
      }
      
      if($this->comment != '') {
         $ret .= "<tr><td colspan=2 class='cm".$this->theme."'>".$this->comment."</td></tr>\n";
      }
      
      $js = "
      <script language='javascript'>
      <!--
      function xocpFormValidate_".$this->getName()."(){";
      foreach ( $required as $req ) {
         $caption = $this->getElementCaption($req);
         $js .= "if ( document.".$this->getName().".".$req.".value == \"\" ){alert( \"".sprintf(_FORM_ENTER, $caption)."\" );document.".$this->getName().".".$req.".focus();return false;}";
      }
      $js .= "}
      //--->
      </script>";
      $ret .= _theme::closeTable().$hidden."\n<!-- CloseForm --></form>\n";
      if($this->js) {
         return $js.$ret;
      } else {
         return $ret;
      }
   }
}


} // XOCP_FORM_DEFINED
?>