<?php
//--------------------------------------------------------------------//
// Filename : class/xocptheme.php                                     //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-17                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('XOCP_THEME_DEFINED') ) {
   define('XOCP_THEME__DEFINED', TRUE);

class XocpTheme {

   function openPage() {
      $ret = "\n<!-- OpenPage --><table border=0 width=100% cellpadding=0 cellspacing=0>";
      return $ret;
   }

   function closePage() {
      $ret = "\n<!-- ClosePage --></table>\n";
      return $ret;
   }

   function openBlock($width=NULL) {
      if($width != "") {
         $width = "width='".$width."'";
      } else {
         $width = "";
      }
      $ret = "\n<!-- OpenBlock --><table border='0' $width cellspacing='0' cellpadding='0'><tr><td>";
      $ret .= "<table width=100% border='0' cellspacing='2' cellpadding='4' ><tr><td class='block'>\n";
      return $ret;
   }

   function closeBlock() {
      $ret = "\n<!-- CloseBlock --></td></tr></table></td></tr></table>\n";
      return $ret;
   }

   function openForm() {
      $ret = "\n<table border='1' cellspacing='0' cellpadding='3' class='frm'>\n";
      return $ret;
   }

   function closeForm() {
      $ret = "</table>\n";
      return $ret;
   }

   function openV() {
      $ret = "\n<table border='1' cellspacing='0' cellpadding='2' class='vw'><tr><td class='v'>\n";
      return $ret;
   }
   
   function openRowV() {
      return "<tr class='v'>";
   }

   function closeRowV() {
      return "</tr>";
   }

   function closeV() {
      $ret = "</td></tr></table>\n";
      return $ret;
   }


   function openTable($theme_no="0",$width=NULL) {
      if($width != "") {
         $width = "width='".$width."'";
      } else {
         $width = "";
      }
      $ret = "\n<!-- OpenTable --><table $width border='0' cellspacing='0' cellpadding='2' ><tr><td class='tbl".$theme_no."x'>"; 
      $ret .= "<table border='1' width=100% cellspacing='0' cellpadding='3' class='tbl".$theme_no."'>\n";
      return $ret;
   }

   function closeTable() {
      $ret = "\n<!-- CloseTable --></table></td></tr></table>\n";
      return $ret;
   }



   function themeHeader() {
      $ret  = "\n<!-- OpenTheme --><table width='100%' border='0' cellspacing='0' cellpadding='0'>";
      $ret .= "<tr><td valign='top'>\n";
      return $ret;
   }


   function themeFooter() {
      $ret = "\n<!-- CloseTheme --></td></tr></table>\n";
      return $ret;
   }

}

} // XOCP_THEME_DEFINED
?>