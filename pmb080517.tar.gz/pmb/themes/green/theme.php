<?php
//--------------------------------------------------------------------//
// Filename : themes/plain/theme.php                                  //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-17                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

// To create theme, just define class named _theme that extends XocpTheme.
// Overwrite some function if necessary. For documentation, please read
// xocptheme.php and xocphtml.php in class directory.

if ( !defined('THEME_X_DEFINED') ) {
   define('THEME_X_DEFINED', TRUE);

include_once(XOCP_DOC_ROOT."/class/xocptheme.php");

class _theme extends XocpTheme {

   function openPage() {
      $ret = "\n<!-- OpenPage --><table border=0 width=770 align=center cellpadding=0 cellspacing=0>";
      return $ret;
   }

   function closePage() {
      global $ss_timing_start_times, $ss_timing_stop_times, $xocpConfig;
      
      $result = ss_timing_result();
      $ret = "<tr><td colspan=4 style='font:11px Arial;color:#aaaaaa;' align=center>"
           . "<hr noshade color=#cccccc size=1>STIE SEMARANG<br/>"
           . "Jl. Menoreh Utara Raya No.11 Semarang - Jawa Tengah - Indonesi<br/>"
           . " Telp.(024) 850 9906, 0857 1200 0606, Fax.(024) 850 6802, email: pmb@stiesemarang.ac.id<br/>"
           . "$result</td></tr>"
           . "\n<!-- ClosePage --></table>\n";
      return $ret;
   }
   
}

} // THEME_X_DEFINED
?>