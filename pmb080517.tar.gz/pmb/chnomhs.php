<?php
mysql_connect("localhost","root","");
$sql = "SELECT a.nomor_test,b.nomhs FROM xocp_akd_mhs a left join xocp_akd_mhs_tmp b using(nomor_test) WHERE length(a.nomhs)=10";
$result = mysql_db_query("session2",$sql);
while (list($nomor_test,$nomhs) = mysql_fetch_row($result)) {
   $a[] = array($nomor_test,$nomhs);
}
foreach ($a as $v) {
   if ($v[1] == "") continue;
   $sql = "UPDATE xocp_akd_mhs SET nomhs = '{$v[1]}' WHERE nomor_test = '{$v[0]}';\n";
   echo "$sql";
   //mysql_db_query("session2",$sql);
   //echo mysql_error()."<br />";
}
?>