<?php
//header('Content-type: application/msexcel');
//header('Content-Disposition: attachment; filename="downloaded.xls"');

$Q="mysql_query";
$R="mysql_fetch_row";

$thn_akd="2010";
$session_id="1";

$keu_thn="2010";
$keu_ses_id="1010";
$akode_byr="'5003012'";

unset($asks0);


if (mysql_connect("192.168.200.110","root","")) { 
//echo "Ok"; } else { echo "Fail"; 
}
mysql_select_db("ftmupnAKD");
$A=$Q("select a.nomhs,a.psmhs_id,sum(a.sks) from krsol a
left join mhs b on b.nomhs=a.nomhs and b.psmhs_id=a.psmhs_id 
where a.thn_akd='$thn_akd' and a.session_id='$session_id' and a.st_ambil!='w' and b.angkatan!='2009'
group by a.nomhs, a.psmhs_id");
while (list($f0,$f1,$f2)=$R($A)) {
  $asks0[$f0]=$f2;
}
//print_r($asks0);


if (mysql_connect("192.168.200.130","root","")) { 
//echo "Ok"; } else { echo "Fail"; 
}
mysql_select_db("fpupnAKD");
$A=$Q("select nomhs,psmhs_id,sum(sks) from krsol
where thn_akd='$thn_akd' and session_id='$session_id' and st_ambil!='w'
group by nomhs, psmhs_id");
while (list($f0,$f1,$f2)=$R($A)) {
  $asks0[$f0]=$f2;
}
//print_r($asks0);

if (mysql_connect("192.168.200.140:33000","root","")) { 
//echo "Ok"; } else { echo "Fail";
}
mysql_select_db("feupnAKD");
$A=$Q("select nomhs,psmhs_id,sum(sks) from krsol
where thn_akd='$thn_akd' and session_id='$session_id' and st_ambil!='w'
group by nomhs, psmhs_id");
while (list($f0,$f1,$f2)=$R($A)) {
  $asks0[$f0]=$f2;
}
//print_r($asks0);

if (mysql_connect("192.168.200.150","root","")) { 
//echo "Ok"; } else { echo "Fail"; 
}
mysql_select_db("fisipupnAKD");
$A=$Q("select nomhs,psmhs_id,sum(sks) from krsol
where thn_akd='$thn_akd' and session_id='$session_id' and st_ambil!='w'
group by nomhs, psmhs_id");
while (list($f0,$f1,$f2)=$R($A)) {
  $asks0[$f0]=$f2;
}
//print_r($asks0);

if (mysql_connect("192.168.200.120","keuangan","TtjrWyfEApNMAyxG")) { 
//echo "Ok"; } else { echo "Fail"; 
}
mysql_select_db("tiupnAKD");
$A=$Q("select nomhs,psmhs_id,sum(sks) from krsol
where thn_akd='$thn_akd' and session_id='$session_id' and st_ambil!='w'
group by nomhs, psmhs_id");
while (list($f0,$f1,$f2)=$R($A)) {
  $asks0[$f0]=$f2;
}
//print_r($asks0);

if (mysql_connect("192.168.200.122","root","")) { 
//echo "Ok"; } else { echo "Fail"; 
}
mysql_select_db("tiupnAKD");
$A=$Q("select nomhs,psmhs_id,sum(sks) from krsol
where thn_akd='$thn_akd' and session_id='$session_id' and st_ambil!='w'
group by nomhs, psmhs_id");
while (list($f0,$f1,$f2)=$R($A)) {
  $asks0[$f0]=$f2;
}
//print_r($asks0);



$link=mysql_connect("localhost","root","0365gand");
mysql_select_db("session2");


unset($a0); unset($a1);
$A=$Q("select psmhs_id, golongan_cd, target_mhs, kode_byr, jml_uang from xocp_akd_keu_seskwjbdtl
where org_id='1' and keu_thn='$keu_thn' and keu_ses_id='$keu_ses_id' and kode_byr in ($akode_byr)");
while (list($f0,$f1,$f2,$f3,$f4)=$R($A)) {
  list($v0,$v1)=explode("/",$f2);
  //echo $v0.",".substr($v0,0,4).",".substr($v0,8,1)."<br>";
  if (substr($v0,0,4)=="-*,(" and substr($v0,8,1)==")") {
    //echo substr($v0,4,4)."<br>";
    $i=substr($v0,4,4);
    //echo "$f0,$f1,$i,$v1,$f3,$f4<br>";
    $a0["$f0|$f1|$i|$v1"][$f3]=$f4;
    $a1[$i]="'$i'";
  } else {
    //echo "$f0,$f1,$v0,$v1,$f3,$f4<br>";
    if (substr($v0,0,4)=="-*,(" and substr($v0,8,2)==".." and substr($v0,14,1)==")") {
      //echo substr($v0,4,4).",".substr($v0,10,4)."<br>";
      for ($i=substr($v0,4,4); $i<=substr($v0,10,4); $i++) {
        //echo "$f0,$f1,$i,$v1,$f3,$f4<br>";
        $a0["$f0|$f1|$i|$v1"][$f3]=$f4;
        $a1[$i]="'$i'";
      }
    } else {

      //echo "$f0,$f1,$v0,$v1,$f3,$f4<br>";

    }
  }
  //echo "$f0,$f1,$v0,$v1,$f3,$f4<br>";
}

//print_r($a0);




unset($a2); unset($a3); unset($anomhs);
$A=$Q("select nomhs, nama_mhs, psmhs_id, golongan_cd, angkatan, mid(nomor_test,7,1) from xocp_akd_mhs
  where org_id='1' and angkatan in (".implode(",",$a1).")
  order by psmhs_id, angkatan, nomhs");
while (list($f0,$f1,$f2,$f3,$f4,$f5)=$R($A)) {
  //echo "$f0,$f1,$f2,$f3,$f4,$f5<br>";
  if (count($a0["$f2|$f3|$f4|$f5"])>0) {
    foreach ($a0["$f2|$f3|$f4|$f5"] as $k0 => $n0) {
      //echo "$f0,$f2,$f1,$k0,$n0<br>";
      $a2[$k0]=$k0;
      $a3["$f0|$f2|$f1"][$k0]=$n0;
            
      $anomhs[$f0]=1;
      
    }
  } else {
    if ($f3==1 or $f3==2 or $f3==3 or $f3==4 or $f3==6 or ($f3==8 and $f4>=2007)) {
    if ($asks0[$f0]!="") {
    echo "$f0,$f1,$f2,$f3,$f4,$f5<br>";
    }
    }
  }
}

//$no=0;
//foreach ($asks0 as $k0 => $n0) {
  //if ($anomhs[$k0]==1) {
    //$no++; 
    //echo "$no,$k0<br>";
  //} else {
    //$no++;
    //echo "$no,$k0<br>";
  //}
//}



unset($a2a);
foreach ($a2 as $k0 => $n0) {
  $a2a[]="'$k0'";
}

unset($a4);
$A=$Q("select kode_byr, nama_byr from xocp_akd_keu_defkwjb
  where kode_byr in (".implode(",",$a2a).")
  order by kode_byr asc
");
while (list($f0,$f1)=$R($A)) {
  $a4[$f0]=$f1;
}
/*
?>
<html xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:x="urn:schemas-microsoft-com:office:excel"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=ProgId content=Excel.Sheet>
<meta name=Generator content="Microsoft Excel 10">
<link rel=File-List href="format_excel_files/filelist.xml">
<link rel=Edit-Time-Data href="format_excel_files/editdata.mso">
<link rel=OLE-Object-Data href="format_excel_files/oledata.mso">
<!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Author>oracle</o:Author>
  <o:LastAuthor>oracle</o:LastAuthor>
  <o:Created>2009-07-08T02:43:24Z</o:Created>
  <o:LastSaved>2009-07-08T02:44:45Z</o:LastSaved>
  <o:Company>UGM</o:Company>
  <o:Version>10.2625</o:Version>
 </o:DocumentProperties>
 <o:OfficeDocumentSettings>
  <o:DownloadComponents/>
  <o:LocationOfComponents HRef="file:///F:\office%20xp\"/>
 </o:OfficeDocumentSettings>
</xml><![endif]-->
<style>
<!--table
  {mso-displayed-decimal-separator:"\,";
  mso-displayed-thousand-separator:"\.";}
@page
  {margin:1.0in .75in 1.0in .75in;
  mso-header-margin:.5in;
  mso-footer-margin:.5in;}
tr
  {mso-height-source:auto;}
col
  {mso-width-source:auto;}
br
  {mso-data-placement:same-cell;}
.style0
  {mso-number-format:General;
  text-align:general;
  vertical-align:bottom;
  white-space:nowrap;
  mso-rotate:0;
  mso-background-source:auto;
  mso-pattern:auto;
  color:windowtext;
  font-size:10.0pt;
  font-weight:400;
  font-style:normal;
  text-decoration:none;
  font-family:Arial;
  mso-generic-font-family:auto;
  mso-font-charset:1;
  border:none;
  mso-protection:locked visible;
  mso-style-name:Normal;
  mso-style-id:0;}
td
  {mso-style-parent:style0;
  padding-top:1px;
  padding-right:1px;
  padding-left:1px;
  mso-ignore:padding;
  color:windowtext;
  font-size:10.0pt;
  font-weight:400;
  font-style:normal;
  text-decoration:none;
  font-family:Arial;
  mso-generic-font-family:auto;
  mso-font-charset:1;
  mso-number-format:General;
  text-align:general;
  vertical-align:bottom;
  border:none;
  mso-background-source:auto;
  mso-pattern:auto;
  mso-protection:locked visible;
  white-space:nowrap;
  mso-rotate:0;}
-->
</style>
<!--[if gte mso 9]><xml>
 <x:ExcelWorkbook>
  <x:ExcelWorksheets>
   <x:ExcelWorksheet>
    <x:Name>Sheet1</x:Name>
    <x:WorksheetOptions>
     <x:Selected/>
     <x:ProtectContents>False</x:ProtectContents>
     <x:ProtectObjects>False</x:ProtectObjects>
     <x:ProtectScenarios>False</x:ProtectScenarios>
    </x:WorksheetOptions>
   </x:ExcelWorksheet>
   <x:ExcelWorksheet>
    <x:Name>Sheet2</x:Name>
    <x:WorksheetOptions>
     <x:ProtectContents>False</x:ProtectContents>
     <x:ProtectObjects>False</x:ProtectObjects>
     <x:ProtectScenarios>False</x:ProtectScenarios>
    </x:WorksheetOptions>
   </x:ExcelWorksheet>
   <x:ExcelWorksheet>
    <x:Name>Sheet3</x:Name>
    <x:WorksheetOptions>
     <x:ProtectContents>False</x:ProtectContents>
     <x:ProtectObjects>False</x:ProtectObjects>
     <x:ProtectScenarios>False</x:ProtectScenarios>
    </x:WorksheetOptions>
   </x:ExcelWorksheet>
  </x:ExcelWorksheets>
  <x:WindowHeight>9210</x:WindowHeight>
  <x:WindowWidth>11355</x:WindowWidth>
  <x:WindowTopX>480</x:WindowTopX>
  <x:WindowTopY>30</x:WindowTopY>
  <x:ProtectStructure>False</x:ProtectStructure>
  <x:ProtectWindows>False</x:ProtectWindows>
 </x:ExcelWorkbook>
</xml><![endif]-->
</head>

<body link=blue vlink=purple>

<table x:str border=0 cellpadding=0 cellspacing=0 width=128 style='border-collapse:collapse;table-layout:fixed;width:96pt'>
<?php

$ret="
  <tr>
    <td>No</td>
    <td>No Mhs</td>
    <td>Psmhs Id</td>
    <td>Nama</td>
    <td>SKS</td>
    ";
    foreach ($a4 as $k0 => $n0) {
      $ret.="<td>$a4[$k0]</td>";
    }
  $ret.="
    <td>Jumlah</td>    
  </tr>";
  $no=0;
  foreach ($a3 as $k1 => $n1) {
    list($v0,$v1,$v2)=explode("|",$k1);
    $no++;
  $ret.="
  <tr>
    <td>$no</td>
    <td>$v0</td>
    <td>$v1</td>
    <td>$v2</td>
    <td x:num>".$asks0[$v0]."</td>
    ";
    $nilai=0;
    foreach ($a4 as $k0 => $n0) {
      $nilai=$n1[$k0];
      $ret.="<td x:num>".$n1[$k0]."</td>";
    }
  $ret.="    
    <td x:num>".($asks0[$v0]*$nilai)."</td>
  </tr>";
  }
$ret.="  
</table>";

echo $ret;
*/
?>