<?php
$ret="";
mysql_connect("localhost","webkeu","keu3375");
mysql_select_db("session2");
$Q="mysql_query";
$R="mysql_fetch_row";

$keu_thn="2010";
$keu_ses_id="12%";
/*
$keu_ses_id="1010%";
$keu_ses_id="1020%";
$keu_ses_id="11%";
$keu_ses_id="12%";
*/

$A=$Q("select keu_ses_nm from xocp_akd_keu_defses where org_id='1' and keu_ses_id
like '$keu_ses_id'");
list($nama_sesi)=$R($A);
//$ret.=$nama_sesi;

unset($a0);
$A=$Q("select kode_byr, nomor_test, jml_byr  from xocp_akd_keu_trnsctdtl
  where org_id='1' and btl_ind='0' and keu_thn='$keu_thn' and keu_ses_id
like '$keu_ses_id'
and jml_byr>0
  #group by kode_byr
");
while (list($f0,$f1,$f2)=$R($A)) {
  if ("$f0"=="5003011" or "$f0"=="5003012" or "$f0"=="5003021" or "$f0"=="5003022" or "$f0"=="5003031") { $f0="5003"; } else {
    if ("$f0"=="5004011" or "$f0"=="5004021" or "$f0"=="5004031" or "$f0"=="5004041") { $f0="5004"; } else {
    }
  }
  $a0[$f1][$f0]=$f2;
  //$ret.=$f0."<br>";
}
//$ret.=count($a0);

$Q("truncate table xocp_akd_keu_mhstemp");
foreach ($a0 as $k0 => $n0) {
  $Q("insert into xocp_akd_keu_mhstemp (nomor_test) values ('$k0')");
}

unset($a1);
$a1["5001001"]="dp";
$a1["5001"]="dpp";
$a1["5001061"]="dppr";
$a1["5002011"]="tetap";
$a1["5002021"]="her";
$a1["5002031"]="upk";
$a1["5003"]="sppvar";
$a1["5005"]="denda";
$a1["5002015"]="kenaikanln";
$a1["5004"]="wisuda";

$Q("delete from xocp_akd_keu_reportall where keu_thn='$keu_thn' and
keu_ses_id like '$keu_ses_id'");

$A=$Q("select a.nomor_test, b.psmhs_id, c.nama_ps, b.nomhs, b.nama_mhs, b.angkatan from xocp_akd_keu_mhstemp a
  left join xocp_akd_mhs b on b.nomor_test=a.nomor_test 
  left join xocp_akd_ps c on c.ps_id=b.psmhs_id
");

while (list($f1,$f2,$f3,$f4,$f5,$f6)=$R($A)) {
  //$ret.=$f1."<br>";
  unset($a2); unset($a3);
  foreach ($a0[$f1] as $k0 => $n0) {
    $a2[]=$a1[$k0];
    $a3[]="'$n0'";
  }
  

  $Q("insert into xocp_akd_keu_reportall
(keu_thn,keu_ses_id,nama_sessi,psmhs_id,nama_jurusan,nomhs,nomor_test,nama_mhs,angkatan,".implode(",",$a2).")
  values
('$keu_thn','$keu_ses_id','$nama_sesi','$f2','$f3','$f4','$f1','$f5','$f6',".implode(",",$a3).")");
}
echo $ret;

?>