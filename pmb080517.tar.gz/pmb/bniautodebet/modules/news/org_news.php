<?php
//--------------------------------------------------------------------//
// Filename : modules/system/uploadcache.php                          //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-20                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('ADVERTISING_NEWS_DEFINED') ) {
   define('ADVERTISING_NEWS_DEFINED', TRUE);

class _news_Display extends XocpBlock {

   function show() {

      $ret = <<<EOD
<H3>Selamat Datang di Acara Workshop Sistem Kesehatan Wilayah dan Keterkaitannya dengan Sistem Informasi Kesehatan <p>
    Jakarta, 27 November 2002</H3><p>
<b>Narasumber:</b><br>
Tim dari Pusat Manajemen Pelayanan Kesehatan FK-UGM<br>
Kepala Pusat Data dan Informasi Kesehatan<br>
R. Indrawan SN (PT Bhakti Wasantara-Net)    
EOD;
      
      
       
      
      return $ret;
   }

}

} // ADVERTISING_NEWS_DEFINED
?>