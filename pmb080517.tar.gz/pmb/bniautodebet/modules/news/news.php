<?php
//--------------------------------------------------------------------//
// Filename : modules/system/uploadcache.php                          //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-20                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('ADVERTISING_NEWS_DEFINED') ) {
   define('ADVERTISING_NEWS_DEFINED', TRUE);

class _news_Display extends XocpBlock {

   function show() {
      $db =& Database::getInstance();
      $sql = "SELECT COUNT(*) FROM ".XOCP_PREFIX."orgs";
      $result = $db->query($sql);
      list($count) = $db->fetchRow($result);
      $sql = "SELECT org_nm FROM ".XOCP_PREFIX."orgs";
      $result = $db->query($sql);
      while (list($org_nm) = $db->fetchRow($result)) {
         $list .= "<tr><td>$org_nm</td></tr>";
      }

      $ret = <<<EOD
<center><h2>Welcome to Internet based<br />Health Information System</H3><p>
<h4>This website contains health profiles from $count districts/organizations<p>
<table>
$list
</table>

</center>
EOD;
      
      
       
      
      return $ret;
   }

}

} // ADVERTISING_NEWS_DEFINED
?>