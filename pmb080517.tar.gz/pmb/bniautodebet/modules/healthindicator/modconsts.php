<?php
if ( !defined('HEALTHINDICATOR_MODULECONSTS_DEFINED') ) {
   define('HEALTHINDICATOR_MODULECONSTS_DEFINED', TRUE);
   
// Defines catch variable name
define("_HIND_CATCH_VAR","X_healthindicator");

// Defines block registration number
define("_HIND_TEMPLATE_BLOCK","1");
define("_HIND_INDICATOR_BLOCK","2");
define("_HIND_GROUP_BLOCK","3");
define("_HIND_BASELINE_BLOCK","4");
define("_HIND_BASELINEDATA_BLOCK","5");
define("_HIND_SELECTORG_BLOCK","6");
define("_HIND_VIEWGROUP_BLOCK","10");

} // HEALTHINDICATOR_MODULECONSTS_DEFINED
?>