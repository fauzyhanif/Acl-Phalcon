<?php
// Block register
$hidden_blockreg = new XocpFormHidden("X_healthindicator","2");

// Form elements
$select_place_id = new XocpFormSelect(_HIND_PLACEID,"place_id",$HTTP_POST_VARS["place_id"]);
$result = $db->query("SELECT place_id,place_nm FROM ".XOCP_PREFIX."places ORDER BY place_nm");
$mycount = $db->getRowsNum($result);
$select_place_id->addOption("","");
while(list($place_id,$place_nm)=$db->fetchRow($result)) {
   $select_place_id->addOption($place_id,$place_nm);
}
$text_tmpl_nm = new XocpFormText(_HIND_INDICATORNAME,"ind_nm",30,512,$HTTP_POST_VARS["ind_nm"]);
$textarea_description = new XocpFormTextArea(_HIND_INDICATORDESCRIPTION,"description",$HTTP_POST_VARS["description"]);
$submit_searchind = new XocpFormButton("","searchind",_HIND_SEARCHINDICATOR,"submit");
$submit_newind = new XocpFormButton("","newind",_HIND_NEWINDICATOR,"submit");
$elementtray_buttons = new XocpFormElementTray("");
$elementtray_buttons->addElement($submit_searchind);
$elementtray_buttons->addElement($submit_newind);

// Constructing a form
$form = new XocpThemeForm(_HIND_SEARCHINDICATORTITLE,"fsearchind","index.php");
$form->addElement($hidden_blockreg);
$form->addElement($text_tmpl_nm);
$form->addElement($textarea_description);
$form->addElement($select_place_id);
$form->addElement($elementtray_buttons);
?>