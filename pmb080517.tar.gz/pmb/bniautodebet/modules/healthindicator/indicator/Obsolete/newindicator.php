<?php
// Block register
$hidden_blockreg = new XocpFormHidden("X_healthindicator","2");

// Form elements
// Template infos
if (!empty($datarec)) {
   $tmpl_id = $datarec["tmpl_id"];
   $tmpl_vars = $datarec["tmpl_vars"];
   $tmpl_nm = $datarec["tmpl_nm"];
   $tmpl_unit = $datarec["tmpl_unit"];
   $description = $datarec["tmpl_desc"];
   $HTTP_POST_VARS["place_id"] = $datarec["place_id"];
   $HTTP_POST_VARS["description"] = $datarec["ind_desc"];
   $HTTP_POST_VARS["publish"] = $datarec["publish"] == "y" ? "1" : "0";
   if (trim($datarec["tmpl_vars"]) != "") {
      $template_vars = explode("|",str_replace("$","",$datarec["tmpl_vars"]));
      $ind_vals = explode("|",str_replace("$","",$datarec["ind_vars"]));
      foreach ($ind_vals as $key => $val) {
         $HTTP_POST_VARS[$template_vars[$key]] = $val;
      }
   } else {
      $template_vars = array();
   }
   $HTTP_POST_VARS["ind_value"] = $datarec["ind_value"];
   
   // Form element
   $hidden_ind_id = new XocpFormHidden("ind_id",$datarec["ind_id"]);
   $hidden_old_place_id = new XocpFormHidden("old_place_id",$datarec["place_id"]);
   $edit = "y";
}
$hidden_tmpl_id = new XocpFormHidden("tmpl_id","$tmpl_id");
$hidden_tmpl_vars = new XocpFormHidden("tmpl_vars","$tmpl_vars");
$label_tmpl_nm = new XocpFormLabel(_HIND_TEMPLATENAME,"$tmpl_nm");
$label_tmpl_unit = new XocpFormLabel(_HIND_TEMPLATEUNIT,"$tmpl_unit");
$label_description = new XocpFormLabel(_HIND_TEMPLATEDESCRIPTION,nl2br($description));
$label_formula = new XocpFormLabel(_HIND_TEMPLATEFORMULA,"$formula");
// Indicator attributes
//if ($HTTP_POST_VARS["ind_nm"] == "") {
//   $HTTP_POST_VARS["ind_nm"] = $tmpl_nm;
//}
//if ($HTTP_POST_VARS["description"] == "") {
//   $HTTP_POST_VARS["description"] = $description;
//}
//$text_ind_nm = new XocpFormText(_HIND_INDICATORNAME,"ind_nm",30,512,$HTTP_POST_VARS["ind_nm"]);
$hidden_ind_nm = new XocpFormHidden("ind_nm","$tmpl_nm");
$select_place_id = new XocpFormSelect(_HIND_PLACEID,"place_id",$HTTP_POST_VARS["place_id"]);
$result = $db->query("SELECT place_id,place_nm FROM ".XOCP_PREFIX."places ORDER BY place_nm");
$mycount = $db->getRowsNum($result);
$select_place_id->addOption("","");
while(list($place_id,$place_nm)=$db->fetchRow($result)) {
   $select_place_id->addOption($place_id,$place_nm);
}
$textarea_description = new XocpFormTextArea(_HIND_INDICATORDESCRIPTION,"description",$HTTP_POST_VARS["description"]);
$elementtray_vars = new XocpFormElementTray(_HIND_INDICATORVARS);
foreach ($template_vars as $a_var) {
   $varname = "text_".$a_var;
   $$varname = new XocpFormText($a_var." = ",$a_var,5,20,$HTTP_POST_VARS[$a_var]);
   $elementtray_vars->addElement($$varname);
}
$text_ind_value = new XocpFormText(_HIND_INDICATORVALUE,"ind_value",5,20,$HTTP_POST_VARS["ind_value"]);
if ($edit == "y") {
   $my_dt = explode("-",$datarec["periode"]);
   $arr_dt["year"] = $my_dt[0];
   $arr_dt["mon"] = $my_dt[1];
   $arr_dt["mday"] = $my_dt[2];
} else {
   $arr_dt = getdate(time());
}
$sampl_dt = new XocpDateTime($arr_dt["year"]."-".$arr_dt["mon"]."-".$arr_dt["mday"]);
$date_period = new XocpFormDateTime(_HIND_INDICATORPERIODE,"sampl",$sampl_dt);
if ($HTTP_POST_VARS["publish"] == "") {
   $HTTP_POST_VARS["publish"] = "1";
}
$radioyesno_publish = new XocpFormRadioYN(_HIND_PUBLISHINDICATOR,"publish",$HTTP_POST_VARS["publish"]);
$submit_saveind = new XocpFormButton("", "savenewind", _HIND_SAVEINDICATOR, "submit");
$submit_cancel = new XocpFormButton("", "cancel", _HIND_CANCEL, "submit");
$elementtray_buttons = new XocpFormElementTray("");
$elementtray_buttons->addElement($submit_saveind);
$elementtray_buttons->addElement($submit_cancel);

// Constructing a form
if ($edit == "y") {
   $form = new XocpThemeForm(_HIND_EDITINDICATORTITLE, "fsaveeditind", "index.php");
   $form->addElement($hidden_ind_id);
   $form->addElement($hidden_old_place_id);
} else {
   $form = new XocpThemeForm(_HIND_NEWINDICATORTITLE, "fsavenewind", "index.php");
}
$form->addElement($hidden_blockreg);
$form->addElement($hidden_tmpl_id);
$form->addElement($hidden_tmpl_vars);
$form->addElement($hidden_ind_nm);
$form->addElement($label_tmpl_nm);
$form->addElement($label_tmpl_unit);
$form->addElement($label_description);
//$form->addElement($label_formula);
//$form->addElement($text_ind_nm);
$form->addElement($select_place_id);
$form->addElement($elementtray_vars);
$form->addElement($text_ind_value);
$form->addElement($date_period);
$form->addElement($textarea_description);
$form->addElement($radioyesno_publish);
$form->addElement($elementtray_buttons);
?>