<?php
if ( !defined('HEALTHINDICATOR_INDICATORS_DEFINED') ) {
   define('HEALTHINDICATOR_INDICATORS_DEFINED', TRUE);

if ( !defined('HEALTHINDICATOR_MODULECONSTS_DEFINED') ) {
   include_once(XOCP_DOC_ROOT."/modules/healthindicator/modconsts.php");
}

class _healthindicator_Indicators extends XocpBlock {
   // Set block width
   var $width = "100%";
   // Catch variable for get method -- See below
   var $getparam;
   // Catch variable for post method -- See below
   var $postparam;

   function main() {
      $db =& Database::getInstance();
      $this->getparam = _HIND_CATCH_VAR."="._HIND_INDICATORS_BLOCK;
      $this->postparam = new XocpFormHidden(_HIND_CATCH_VAR,_HIND_INDICATORS_BLOCK);
      switch ($this->catch) {
         case _HIND_INDICATORS_BLOCK:
            global $HTTP_POST_VARS,$HTTP_GET_VARS;
            if ((($HTTP_POST_VARS["ind_nm"] != "" || $HTTP_POST_VARS["description"] != "" ||
                  $HTTP_POST_VARS["place_id"] != "") && $HTTP_POST_VARS["cancel"] == "" &&
                 $HTTP_POST_VARS["newind"] == "" && $HTTP_POST_VARS["savenewind"] == "") ||
                $HTTP_POST_VARS["searchind"] != "") {
               // Search procedure
               $nm = $HTTP_POST_VARS["ind_nm"];
               $nm = str_replace("*","%",$nm);
               $desc = $HTTP_POST_VARS["description"];
               $desc = str_replace("*","%",$desc);
               $place = $HTTP_POST_VARS["place_id"];
               $sql = "SELECT i.ind_id,i.place_id,i.ind_nm,i.description,o.place_nm
                       FROM ind_items i, places o
                       WHERE i.place_id = o.place_id";
               if ($nm != "") {
                  $sql .= " AND i.ind_nm LIKE '$nm'";
               }
               if ($desc != "") {
                  $sql .= " AND i.description LIKE '$desc'";
               }
               if ($place != "") {
                  $sql .= " AND i.place_id = '$place'";
               }
               $sql .= " ORDER BY i.ind_nm";
               $result = $db->query($sql);
               if ($db->getRowsNum($result) > 0) {
                  $myts =& MyTextSanitizer::getInstance();
                  $ret = _theme::OpenTable();
                  $i = 1;
                  while (list($ind_id,$place_id,$ind_nm,$description,$place_nm) = $db->fetchRow($result)) {
                     $ret .= "<b>$i</b> :: <a href='".XOCP_SERVER_SUBDIR."/index.php?X_healthindicator=2&edit=y&x=$ind_id&y=$place_id'>$ind_nm</a> :: $place_nm<br>".nl2br($description)."<br>";
                     $i++;
                  }
                  $ret .= _theme::CloseTable();
               }
               include_once(XOCP_DOC_ROOT."/modules/healthindicator/indicator/searchindicator.php");
            } elseif ($HTTP_POST_VARS["newind"] != "") {
               // Select template
               include_once(XOCP_DOC_ROOT."/modules/healthindicator/indicator/selecttemplate.php");
            } elseif ($HTTP_POST_VARS["createind"] != "") {
               // New indicator
               if ($HTTP_POST_VARS["tmpl_id"] == "") {
                  include_once(XOCP_DOC_ROOT."/modules/healthindicator/indicator/selecttemplate.php");
                  $form->setComment(_HIND_SELECTTEMPLATE);
               } else {
                  $result = $db->query("SELECT tmpl_id,tmpl_nm,tmpl_vars,tmpl_unit,formula,description
                                        FROM ".XOCP_PREFIX."ind_template
                                        WHERE tmpl_id = '$HTTP_POST_VARS[tmpl_id]'");
                  list($tmpl_id,$tmpl_nm,$tmpl_vars,$tmpl_unit,$formula,$description) = $db->fetchRow($result);
                  if (trim($tmpl_vars) != "") {
                     $template_vars = explode("|",str_replace("$","",$tmpl_vars));
                  } else {
                     unset($template_vars);
                  }
                  include_once(XOCP_DOC_ROOT."/modules/healthindicator/indicator/newindicator.php");
               }
            } elseif ($HTTP_POST_VARS["cancel"] != "") {
               // Cancel
               $HTTP_POST_VARS["ind_nm"] = "";
               $HTTP_POST_VARS["description"] = "";
               $HTTP_POST_VARS["place_id"] = "";
               include_once(XOCP_DOC_ROOT."/modules/healthindicator/indicator/searchindicator.php");
            } elseif (($HTTP_POST_VARS["cancel"] == "" && trim($HTTP_POST_VARS["ind_nm"]) != "" &&
                       $HTTP_POST_VARS["tmpl_id"] != "" && trim($HTTP_POST_VARS["ind_value"] &&
                       $HTTP_POST_VARS["place_id"] != "") != "") || $HTTP_POST_VARS["savenewind"] != "") {
               // Save indicator
               if (trim($HTTP_POST_VARS["tmpl_vars"]) != "") {
                  $filled_vars = TRUE;
                  $ind_vars = explode("|",str_replace("$","",$HTTP_POST_VARS["tmpl_vars"]));
                  foreach ($ind_vars as $a_var) {
                     if (trim($HTTP_POST_VARS[$a_var]) == "") {
                        $filled_vars = FALSE;
                     }
                  }
               } else {
                 $filled_vars = TRUE;
               }
               if (trim($HTTP_POST_VARS["ind_nm"]) != "" && $HTTP_POST_VARS["tmpl_id"] != "" &&
                   $HTTP_POST_VARS["place_id"] != "" && $filled_vars) {
                  if (trim($HTTP_POST_VARS["tmpl_vars"]) != "") {
                     $ind_vars = explode("|",str_replace("$","",$HTTP_POST_VARS["tmpl_vars"]));
                     foreach ($ind_vars as $a_var) {
                        $arr_ind_vars[] = $HTTP_POST_VARS[$a_var];
                     }
                     $ind_vars = implode("|",$arr_ind_vars);
                  }
                  $sql = "SELECT MAX(ind_id) FROM ind_items WHERE place_id = '".$HTTP_POST_VARS["place_id"]."'";
                  $result = $db->query($sql);
                  list($ind_id) = $db->fetchRow($result);
                  if ($ind_id == "") {
                    $ind_id = 1;
                  } else {
                    $ind_id++;
                  }
                  $period = new XocpDateTime();
                  $period->eatVars("sampl");
                  $period->truncDate();
                  if ($HTTP_POST_VARS["publish"] == "0") {
                     $publish = "n";
                  } else {
                     $publish = "y";
                  }
                  if ($HTTP_POST_VARS["ind_id"] == "") {
                     $sql = "INSERT INTO ind_items (place_id,ind_id,ind_nm,description,tmpl_id,
                                                       ind_vars,ind_value,periode,created,
                                                       modified,publish)
                                VALUES (".$HTTP_POST_VARS["place_id"].",".
                                        $ind_id.",'".
                                        $HTTP_POST_VARS["ind_nm"]."','".
                                        $HTTP_POST_VARS["description"]."','".
                                        $HTTP_POST_VARS["tmpl_id"]."','".
                                        $ind_vars."','".
                                        $HTTP_POST_VARS["ind_value"]."','".
                                        $period->getMySQL("date")."',NOW(),NOW(),'".
                                        $publish."')";
                  } else {
                     $sql = "UPDATE ind_items
                                SET place_id = ".$HTTP_POST_VARS["place_id"].",
                                    ind_nm = '".$HTTP_POST_VARS["ind_nm"]."',
                                    description = '".$HTTP_POST_VARS["description"]."',
                                    ind_vars = '$ind_vars',
                                    ind_value = '".$HTTP_POST_VARS["ind_value"]."',
                                    periode = '".$period->getMySQL("date")."',
                                    modified = NOW(),
                                    publish = '$publish'
                                WHERE ind_id = ".$HTTP_POST_VARS["ind_id"]." AND place_id = ".$HTTP_POST_VARS["old_place_id"];
                  }
                  $result = $db->query($sql);
                  $HTTP_POST_VARS["ind_nm"] = "";
                  $HTTP_POST_VARS["description"] = "";
                  $HTTP_POST_VARS["place_id"] = "";
                  if (($error = $db->error()) != "") {
                     include_once(XOCP_DOC_ROOT."/modules/healthindicator/indicator/searchindicator.php");
                     $form->setComment(_HIND_INDICATORSAVEFAIL."<br>$error");
                  } else {
                     include_once(XOCP_DOC_ROOT."/modules/healthindicator/indicator/searchindicator.php");
                     $form->setComment(_HIND_INDICATORSAVESUCCESS);
                  }
               } else {
                  $result = $db->query("SELECT tmpl_id,tmpl_nm,tmpl_vars,tmpl_unit,formula,description
                                        FROM ".XOCP_PREFIX."ind_template
                                        WHERE tmpl_id = '$HTTP_POST_VARS[tmpl_id]'");
                  list($tmpl_id,$tmpl_nm,$tmpl_vars,$tmpl_unit,$formula,$description) = $db->fetchRow($result);
                  if (trim($tmpl_vars) != "") {
                     $template_vars = explode("|",str_replace("$","",$tmpl_vars));
                  } else {
                     unset($template_vars);
                  }
                  include_once(XOCP_DOC_ROOT."/modules/healthindicator/indicator/newindicator.php");
                  $form->setComment(_HIND_INDICATORSAVEERROR);
               }
            } elseif ($HTTP_GET_VARS["edit"] == "y" && $HTTP_GET_VARS["x"] != "" &&
                      $HTTP_GET_VARS["y"] != "") {
               // Edit indicator
               $sql = "SELECT t.tmpl_nm,t.tmpl_unit,t.description as tmpl_desc,t.tmpl_vars,
                                 t.tmpl_id,i.ind_vars,i.ind_value,i.description as ind_desc,
                                 i.periode,i.ind_id,i.place_id,i.publish
                       FROM ind_items i, ind_template t
                       WHERE i.ind_id = '".$HTTP_GET_VARS["x"]."' AND
                             i.place_id = '".$HTTP_GET_VARS["y"]."' AND i.tmpl_id = t.tmpl_id";
               $result = $db->query($sql);
               if ($db->getRowsNum($result) > 0) {
                  $datarec = $db->fetchArray($result);
                  include_once(XOCP_DOC_ROOT."/modules/healthindicator/indicator/newindicator.php");
               } else {
                  include_once(XOCP_DOC_ROOT."/modules/healthindicator/indicator/searchindicator.php");
                  $form->setComment(_HIND_INDICATORNOTFOUND);
               }
            }
            break;
         default:
            include_once(XOCP_DOC_ROOT."/modules/healthindicator/indicator/searchindicator.php");
            break;
      }
      return $form->render() . $ret;
   }

}
} // HEALTHINDICATOR_INDICATORS_DEFINED
?>