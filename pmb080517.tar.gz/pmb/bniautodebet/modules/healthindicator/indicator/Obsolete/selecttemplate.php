<?php
// Block register
$hidden_blockreg = new XocpFormHidden("X_healthindicator","2");

// Form elements
$select_tmpl_id = new XocpFormSelect(_HIND_TEMPLATENAME,"tmpl_id",$HTTP_POST_VARS["tmpl_id"]);
$result = $db->query("SELECT tmpl_id,tmpl_nm FROM ".XOCP_PREFIX."ind_template ORDER BY tmpl_nm");
$mycount = $db->getRowsNum($result);
$select_tmpl_id->addOption("","");
while(list($tmpl_id,$tmpl_nm)=$db->fetchRow($result)) {
   $select_tmpl_id->addOption($tmpl_id,$tmpl_nm);
}
$submit_cancel = new XocpFormButton("","cancel",_HIND_CANCEL,"submit");
$submit_createind = new XocpFormButton("","createind",_HIND_CREATEINDICATOR,"submit");
$elementtray_buttons = new XocpFormElementTray("");
$elementtray_buttons->addElement($submit_createind);
$elementtray_buttons->addElement($submit_cancel);

// Constructing a form
$form = new XocpThemeForm(_HIND_SELECTTEMPLATETITLE,"fselecttmpl","index.php");
$form->addElement($hidden_blockreg);
$form->addElement($select_tmpl_id);
$form->addElement($elementtray_buttons);
?>