<?php
if ( !defined('HEALTHINDICATOR_INDICATOR_DEFINED') ) {
   define('HEALTHINDICATOR_INDICATOR_DEFINED', TRUE);
   
include_once(XOCP_DOC_ROOT."/modules/healthindicator/modconsts.php");

function indicatortemp_funccmp($a,$b) {
   if ($a[4] == $b[4]) {
      return strcmp($a[1],$b[1]);
   }
   return ($a[4] > $b[4]) ? -1 : 1;
}

function indicatoritem_funccmp($a,$b) {
   if ($a[6] == $b[6]) {
      if ($a[4] == $b[4]) {
         return strcmp($a[0],$b[0]); 
      }
      return strcmp($a[4],$b[4]);
   }
   return ($a[6] > $b[6]) ? -1 : 1;
}

class _healthindicator_Indicator extends XocpBlock {
   // Set block width
   var $width = "100%";
   // Catch variable for get method -- See below
   var $getparam;
   // Catch variable for post method -- See below
   var $postparam;
   
   // $find: text to search
   // $p: page number
   // $f: data page filename
   // $org_id: organization id
   function templateNavigate($find = "",$p = "0",$f = "",$org_id  = "") {
      $db =& Database::getInstance();
      // Is the data page filename set?
      if (trim($f) != "") {  // Retrieve from a previously made data page
         $dp = XocpDataPage::unserialize($f);
         // Check whether the data page has any data or not
         $dp->reset();
         $dp_data = $dp->retrieve();
         if ($dp_data[0][0] != _HIND_INDICATORNOTFOUND) {
            $found = TRUE;
         } else {
            $found = FALSE;
         }
         // Set back to proper page number
         $dp->setPage($p);
      } else {  // Create a new data page
         if (trim($find) == "") { // Browse
            $sql = "SELECT tmpl.tmpl_id,tmpl.tmpl_nm,tmpl.description,MAX(ind.periode)
                    FROM ".XOCP_PREFIX."ind_items ind,".XOCP_PREFIX."ind_template tmpl
                    WHERE ind.tmpl_id = tmpl.tmpl_id AND ind.org_id = $org_id
                    GROUP BY tmpl.tmpl_id,tmpl.tmpl_nm,tmpl.description";
         } else { // Search
            $sql = "SELECT tmpl_id,tmpl.tmpl_nm,tmpl.description,MAX(ind.periode)
                    FROM ".XOCP_PREFIX."ind_items ind,".XOCP_PREFIX."ind_template tmpl
                    WHERE ind.tmpl_id = tmpl.tmpl_id AND ind.org_id = $org_id AND 
                          (tmpl.nm LIKE '$find' OR tmpl.description LIKE '$find')
                    GROUP BY tmpl.tmpl_id,tmpl.tmpl_nm,tmpl.description";
         }

         $result = $db->query($sql);
         $dp = new XocpDataPage();
         $dp->setPageSize(10);
         if ($db->getRowsNum($result) > 0) {
            $found = TRUE;
            while (list($tmpl_id,$tmpl_nm,$description,$periode) = $db->fetchRow($result)) {
               similar_text($tmpl_nm,str_replace("%","",$find),$score1);
               similar_text($description,str_replace("%","",$find),$score2);
               $dp->addData(array($tmpl_id,$tmpl_nm,$description,$periode,round(((2 * $score1) + $score2) / 3,2)));
            }
            // Sort data
            if (trim($find) != "") {
               usort($dp->data,"indicatortemp_funccmp");
               array_reverse($dp->data);
            }
         } else {
            $found = FALSE;
            $dp->addData(array(_HIND_INDICATORNOTFOUND));
         }
         $dp->serialize();
      }
      
      // Preparing the data page
      if ($found) {
         $dp_found = $dp->getCount();
         $no1 = $dp->getOffset() + 1;
      } else {
         $dp_found = "0";
         $no1 = "0";
      }
      $no2 = $no1 + $dp->getPageSize() - 1;
      if ($dp_found <= $no2) {
         $no2 = $dp_found;
      }
      
      // Creating header
      $dp_header = new XocpSimpleTable();
      // Is it searching? Set for the appropriate title
      if ($find != "") {  // Yes, it'is searching
         $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&type=tmplnav&fi=".urlencode($find));
         $title = "<font class='tdh1'>"._HIND_INDICATORLIST." ["._HIND_SEARCHRESULT." ($no1 - $no2 "._OF." $dp_found)]</font>";
      } else {  // No, it's just retrieving from a previously made data page
         $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&type=tmplnav");
         $title = "<font class='tdh1'>"._HIND_INDICATORLIST." ($no1 - $no2 "._OF." $dp_found)</font>";
      }
      // How many page in data page?
      if ($found && count($dp->getPageArray()) > 1) {  // More than 1, show navigation links
         $hrow = $dp_header->addRow($title,$dp_prevnext);
      } else {
         $hrow = $dp_header->addRow($title);
      }
      $dp_header->setCellAlign($hrow,array("","right"));
      $dp_header->setWidth("100%");

      // Creating search form
      $hdn_type = new XocpFormHidden("type","tmplnav");
      $hdn_state = new XocpFormHidden("state","add");
      $txt_cond = new XocpFormText("","txt_find",20,250,"");
      $btn_find = new XocpFormButton("","btn_find",_SEARCH,"submit");
      $elm_tray_find = new XocpFormElementTray("");
      $elm_tray_find->addElement($txt_cond);
      $elm_tray_find->addElement($btn_find);
      
      $form_find = new XocpSimpleForm("","ffind",XOCP_SERVER_SUBDIR."/index.php");
      $form_find->addElement($this->postparam);
      $form_find->addElement($hdn_type);
      $form_find->addElement($elm_tray_find);

      // Creating button tray form
      $btn_add = new XocpFormButton("","btn_add",_ADD,"submit");
      //$btn_cancel = new XocpFormButton("","btn_cancel",_CANCEL,"submit");
      $elm_tray_add = new XocpFormElementTray("");
      $elm_tray_add->addElement($btn_add);
      //$elm_tray_add->addElement($btn_cancel);
      
      $form_buttons = new XocpSimpleForm("","fbuttons",XOCP_SERVER_SUBDIR."/index.php");
      $form_buttons->addElement($this->postparam);
      $form_buttons->addElement($hdn_type);
      $form_buttons->addElement($hdn_state);
      $form_buttons->addElement($elm_tray_add);

      // Creating footer
      $dp_footer = new XocpSimpleTable();
      $frow = $dp_footer->addRow($form_buttons->render(),$form_find->render());
      $dp_footer->setCellAlign($frow,array("left","right"));
      $dp_footer->setWidth("100%");
                                    
      // Creating data page
      $dp_table = new XocpTable(1);
      $dp_table->setWidth("100%");
      $hrow = $dp_table->addHeader($dp_header->render());
      $dp_table->setColSpan($hrow,2);
      $frow = $dp_table->addFooter($dp_footer->render());
      $dp_table->setColSpan($frow,2);
                                           
      // Populating data page
      $dp_data = $dp->retrieve();
      foreach ($dp_data as $row) {
         list($tmpl_id,$tmpl_nm,$description,$periode,$score) = $row;
         if ($found) {
            $data = "<a href='".XOCP_SERVER_SUBDIR."/index.php?".$this->getparam.
                    "&list=y&x=$tmpl_id'>$tmpl_nm</a>";
            if ($find != "") {
               $data .= " ($score% "._MATCH.")";
            }
            $data .= "<br/>".nl2br($description);
            $drow = $dp_table->addRow($data,sql2ind2($periode));
         } else {
            $drow = $dp_table->addRow($tmpl_id);
            $dp_table->setColSpan($drow,2);
         }
      }
                                                                     
      return $dp_table->render();
   }
   
   // $p: page number
   // $f: data page filename
   // $org_id: organization id
   // $tmpl_id: template id
   function indicatorDataNavigate($p = "0",$f = "",$org_id = "",$tmpl_id = "") {
      $db =& Database::getInstance();
      // Is the data page filename set?
      if (trim($f) != "") {  // Retrieve from a previously made data page
         $dp = XocpDataPage::unserialize($f);
         // Check whether the data page has any data or not
         $dp->reset();
         $dp_data = $dp->retrieve();
         if ($dp_data[0][0] != _HIND_INDICATORDATANOTFOUND) {
            $found = TRUE;
         } else {
            $found = FALSE;
         }
         // Set back to proper page number
         $dp->setPage($p);
      } else {  // Create a new data page
         $sql = "SELECT tmpl.tmpl_nm,ind.ind_id,ind.ind_nm,ind.description,
                        ind.ind_value,ind.periode,tmpl.tmpl_unit
                 FROM ".XOCP_PREFIX."ind_items ind,".XOCP_PREFIX."ind_template tmpl
                 WHERE tmpl.tmpl_id = $tmpl_id AND ind.tmpl_id = tmpl.tmpl_id AND ind.org_id = $org_id
                 ORDER BY ind.periode DESC,ind.ind_nm";
         $result = $db->query($sql);
         $dp = new XocpDataPage();
         $dp->setPageSize(10);
         if ($db->getRowsNum($result) > 0) {
            $found = TRUE;
            list($tmpl_nm,$ind_id,$ind_nm,$description,$ind_value,$periode,$tmpl_unit) = $db->fetchRow($result);
            $dp->addData(array($tmpl_nm,$ind_id,$ind_nm,$description,$ind_value,$periode,$tmpl_unit));
            $title = $tmpl_nm;
            while (list($tmpl_nm,$ind_id,$ind_nm,$description,$ind_value,$periode,$tmpl_unit) = $db->fetchRow($result)) {
               $dp->addData(array($tmpl_nm,$ind_id,$ind_nm,$description,$ind_value,$periode,$tmpl_unit));
            }
         } else {
            $found = FALSE;
            $dp->addData(array(_HIND_INDICATORDATANOTFOUND));
         }
         $dp->serialize();
      }
      
      // Preparing the data page
      if ($found) {
         $dp_found = $dp->getCount();
         $no1 = $dp->getOffset() + 1;
      } else {
         $dp_found = "0";
         $no1 = "0";
      }
      $no2 = $no1 + $dp->getPageSize() - 1;
      if ($dp_found <= $no2) {
         $no2 = $dp_found;
      }
      
      // Creating header
      $dp_header = new XocpSimpleTable();
      $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&type=inddtnav");
      $title = "<font class='tdh1'>$title ($no1 - $no2 "._OF." $dp_found)</font>";
      // How many page in data page?
      if ($found && count($dp->getPageArray()) > 1) {  // More than 1, show navigation links
         $hrow = $dp_header->addRow($title,$dp_prevnext);
      } else {
         $hrow = $dp_header->addRow($title);
      }
      $dp_header->setCellAlign($hrow,array("","right"));
      $dp_header->setWidth("100%");

      // Creating button tray form
      $sql = "SELECT tmpl_id,tmpl_nm,tmpl_vars,bl_vars,description
              FROM ".XOCP_PREFIX."ind_template WHERE tmpl_id = $tmpl_id";
      $result = $db->query($sql);
      list($tmpl_id,$tmpl_nm,$tmpl_vars,$bl_vars,$description) = $db->fetchRow($result);
      $hdn_tmpl_data = new XocpFormHidden("tmpl_data","$tmpl_id;$tmpl_nm;$tmpl_vars;$bl_vars;$description");
      $hdn_type = new XocpFormHidden("type","inddtnav");
      $hdn_state = new XocpFormHidden("state","add");
      $btn_add = new XocpFormButton("","btn_add",_ADD,"submit");
      $btn_cancel = new XocpFormButton("","btn_cancel",_CANCEL,"submit");
      $elm_tray_add = new XocpFormElementTray("");
      $elm_tray_add->addElement($btn_add);
      $elm_tray_add->addElement($btn_cancel);
      
      $form_buttons = new XocpSimpleForm("","fbuttons",XOCP_SERVER_SUBDIR."/index.php");
      $form_buttons->addElement($this->postparam);
      $form_buttons->addElement($hdn_type);
      $form_buttons->addElement($hdn_state);
      $form_buttons->addElement($hdn_tmpl_data);
      $form_buttons->addElement($elm_tray_add);

      // Creating footer
      $dp_footer = new XocpSimpleTable();
      $frow = $dp_footer->addRow($form_buttons->render());
      $dp_footer->setCellAlign($frow,array("left"));
      $dp_footer->setWidth("100%");
                                    
      // Creating data page
      $dp_table = new XocpTable(1);
      $dp_table->setWidth("100%");
      $hrow = $dp_table->addHeader($dp_header->render());
      $dp_table->setColSpan($hrow,3);
      $frow = $dp_table->addFooter($dp_footer->render());
      $dp_table->setColSpan($frow,3);
      $drow = $dp_table->addRow(_HIND_INDICATORDESC,_HIND_INDICATORPERIOD,_HIND_INDICATORVALUE);
      $dp_table->setCellAlign($drow,array("center","center","center"));
                                           
      // Populating data page
      $no = $dp->getOffset() + 1;
      $dp_data = $dp->retrieve();
      foreach ($dp_data as $row) {
         list($tmpl_nm,$ind_id,$ind_nm,$description,$ind_value,$periode,$tmpl_unit) = $row;
         if ($found) {
            $data = "<a href='".XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&show=y&x=$ind_id'>$ind_nm</a><br/>".nl2br($description);
            $drow = $dp_table->addRow($data,sql2ind2($periode),$ind_value." ".$tmpl_unit);
            $dp_table->setCellAlign($drow,array("","","right"));
         } else {
            $drow = $dp_table->addRow($tmpl_nm);
            $dp_table->setColSpan($drow,3);
         }
      }
                                                                     
      return $dp_table->render();
   }

   function orgNavigate($pgroup_id) {
      $db =& Database::getInstance();
      $dp = new XocpDataPage();
      $found = TRUE;
      $sql = "SELECT p.org_id,o.org_nm
              FROM ".XOCP_PREFIX."ind_pgroup_org p,".XOCP_PREFIX."orgs o
              WHERE p.pgroup_id = $pgroup_id AND o.org_id = p.org_id";
      $result = $db->query($sql);
      if ($db->getRowsNum($result) > 0) {
         list($org_id,$org_nm) = $db->fetchRow($result);
         $dp->addData(array($org_id,$org_nm));
         $sql = "SELECT l.sub_id,o.org_nm
                 FROM ".XOCP_PREFIX."ind_orglink l,".XOCP_PREFIX."orgs o
                 WHERE l.org_id = $org_id AND o.org_id = l.sub_id";
         $result = $db->query($sql);
         if ($db->getRowsNum($result) > 0) {
            while (list($org_id,$org_nm) = $db->fetchRow($result)) {
               $dp->addData(array($org_id,$org_nm));
            }
         }
      } else {
         $dp->addData(array(_HIND_BASELINEDATAPGROUPNOTASSIGNED));
         $found = FALSE;
      }
      
      if ($found) {
         $dp_found = $dp->getCount();
      } else {
         $dp_found = "0";
      }
      if ($dp_found == "0") {
         $dp->setPageSize(1);
      } else {
         $dp->setPageSize($dp_found);
      }

      $dp_header = new XocpSimpleTable();
      $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam);
      $title = "<font class='tdh1'>"._HIND_BASELINEDATAORGLIST." ($dp_found)</font>";
      $hrow = $dp_header->addRow($title);
      $dp_header->setWidth("100%");

      // Creating footer
      $dp_footer = new XocpSimpleTable();
      $frow = $dp_footer->addRow("&nbsp;");
      $dp_footer->setWidth("100%");
                                    
      // Creating data page
      $dp_table = new XocpTable(1);
      $dp_table->setWidth("100%");
      $hrow = $dp_table->addHeader($dp_header->render());
      $frow = $dp_table->addFooter($dp_footer->render());
                                           
      // Populating data page
      $dp_data = $dp->retrieve();
      foreach ($dp_data as $row) {
         list($org_id,$org_nm) = $row;
         if ($found) {
            $drow = $dp_table->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&browse=y&x=$org_id'>$org_nm</a>");
         } else {
            $drow = $dp_table->addRow($org_id);
         }
      }
                                                                     
      return $dp_table->render();
   }
   
   function formShowDetail($datarec,$comment = "") {
      // Show indicator item detail
      $hidden_type = new XocpFormHidden("type","show");
      $hidden_state = new XocpFormHidden("state","edit");
      $hidden_tmpl_id = new XocpFormHidden("old_tmpl_id",$datarec["tmpl_id"]);
      $hidden_ind_id = new XocpFormHidden("old_ind_id",$datarec["ind_id"]);
      $hidden_ind_nm = new XocpFormHidden("old_ind_nm",$datarec["ind_nm"]);
      $hidden_description = new XocpFormHidden("old_description",$datarec["description"]);
      $hidden_ind_vars = new XocpFormHidden("old_ind_vars",$datarec["ind_vars"]);
      $hidden_ind_value = new XocpFormHidden("old_ind_value",$datarec["ind_value"]);
      $hidden_target_vars = new XocpFormHidden("old_target_vars",$datarec["target_vars"]);
      $hidden_target_val = new XocpFormHidden("old_target_val",$datarec["target_val"]);
      $hidden_periode = new XocpFormHidden("old_periode",$datarec["periode"]);
      $hidden_publish = new XocpFormHidden("old_publish",$datarec["publish"]);
      
      $db =& Database::getInstance();
      $sql = "SELECT tmpl_vars,bl_vars
              FROM ".XOCP_PREFIX."ind_template
              WHERE tmpl_id = '".$datarec["tmpl_id"]."'";
      $result = $db->query($sql);
      list($tmpl_vars,$bl_vars) = $db->fetchRow($result);

      $label_ind_nm = new XocpFormLabel(_HIND_INDICATORNAME,$datarec["ind_nm"]);
      $hidden_vars = new XocpFormHidden("vars","$tmpl_vars;$bl_vars");
      $label_description = new XocpFormLabel(_HIND_INDICATORDESC,nl2br($datarec["description"]));
      $vars = explode("|",$tmpl_vars);
      $value = explode("|",$datarec["ind_vars"]);
      for ($i = 0; $i < count($vars); $i++) {
         $label .= $vars[$i]." = ".$value[$i]."<br />";
      }
      $label_ind_vars = new XocpFormLabel(_HIND_INDICATORVARS,$label);
      $label_ind_value = new XocpFormLabel(_HIND_INDICATORVALUE,$datarec["ind_value"]);
      $target_vars = explode("|",$datarec["target_vars"]);
      $bl_vars = explode("|",$bl_vars);
      $bl_var = array();
      for ($i = 0; $i < count($bl_vars); $i++) {
         $bl_var[] = "'".$bl_vars[$i]."'";
      }
      $bl_vars = implode(",",$bl_var);
      $sql = "SELECT bl_var,bl_nm FROM ".XOCP_PREFIX."ind_baseline
              WHERE bl_var IN ($bl_vars)
              ORDER BY bl_nm";
      $result = $db->query($sql);
      $lines = "<table>";
      $i = 0;
      while (list($bl_var,$bl_nm) = $db->fetchRow($result)) {
         $lines .= "<tr><td class='td0'>$bl_nm ($bl_var)</td><td class='td0'>: ".sql2ind2($target_vars[$i++])."</td></tr>";
      }
      $lines .= "</table>";
      $label_target_vars = new XocpFormLabel(_HIND_INDICATORTVARS,$lines);
      $label_target_val = new XocpFormLabel(_HIND_INDICATORTVAL,$datarec["target_val"]);
      $label_periode = new XocpFormLabel(_HIND_INDICATORPERIOD,sql2ind2($datarec["periode"]));
      $enum_yn = array("y" => _YES,"n" => _NO,"1" => _YES,"0" => _NO);
      $label_publish = new XocpFormLabel(_HIND_INDICATORPUBLISH,$enum_yn[$datarec["publish"]]);

      $submit_edit = new XocpFormButton("","edit",_EDIT,"submit");
      $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
      $submit_delete = new XocpFormButton("","delete",_DELETE,"submit");
      $elementtray_button = new XocpFormElementTray("");
      $elementtray_button->addElement($submit_edit);
      $elementtray_button->addElement($submit_cancel);
      $elementtray_button->addElement($submit_delete);

      // Constructing a form - Show indicator item detail
      $form = new XocpThemeForm(_HIND_INDICATORSHOWDETAILTITLE,"fshowinditem","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_type);
      $form->addElement($hidden_state);

      $form->addElement($hidden_tmpl_id);
      $form->addElement($hidden_vars);
      $form->addElement($hidden_ind_id);
      $form->addElement($hidden_ind_nm);
      $form->addElement($hidden_description);
      $form->addElement($hidden_ind_vars);
      $form->addElement($hidden_ind_value);
      $form->addElement($hidden_target_vars);
      $form->addElement($hidden_target_val);
      $form->addElement($hidden_periode);
      $form->addElement($hidden_publish);

      $form->addElement($label_ind_nm);
      $form->addElement($label_description);
      $form->addElement($label_ind_vars);
      $form->addElement($label_ind_value);
      $form->addElement($label_target_vars);
      $form->addElement($label_target_val);
      $form->addElement($label_periode);
      $form->addElement($label_publish);
      $form->addElement($elementtray_button);
      if ($comment != "") {
         $form->setComment($comment);
      }

      $this->html->setBodyOnload(" onload='document.fshowinditem.cancel.focus();'");
   
      return $form->render();
   }

   function formSelectTemplate() {
      // Form elements - Select template
      $hidden_type = new XocpFormHidden("type","selecttmpl");
      $hidden_state = new XocpFormHidden("state","add");
      $select_tmpl_nm = new XocpFormSelect(_HIND_TEMPLATENAME,"tmpl_data");
      $db =& Database::getInstance();
      $sql = "SELECT tmpl_id,tmpl_nm,tmpl_vars,bl_vars,description
              FROM ".XOCP_PREFIX."ind_template
              ORDER BY tmpl_nm";
      $result = $db->query($sql);
      while (list($tmpl_id,$tmpl_nm,$tmpl_vars,$bl_vars,$description) = $db->fetchRow($result)) {
         $select_tmpl_nm->addOption("$tmpl_id;$tmpl_nm;$tmpl_vars;$bl_vars;$description",$tmpl_nm);
      }
      $submit_select = new XocpFormButton("","select",_SELECT,"submit");
      $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
      $elementtray_button = new XocpFormElementTray("");
      $elementtray_button->addElement($submit_select);
      $elementtray_button->addElement($submit_cancel);

      // Constructing a form - Select template
      $form = new XocpThemeForm(_HIND_INDICATORSELECTTMPL,"fselecttmpl","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_type);
      $form->addElement($hidden_state);
      $form->addElement($select_tmpl_nm);
      $form->addElement($elementtray_button);
      
      return $form->render();
   }
   
   function formAddEdit($state = "add",$datarec = NULL,$showcancel = TRUE,
                        $org_id = NULL,$tmpl_id = NULL,$comment = "") {
      // Form elements - Add/edit a indicator item
      $hidden_type = new XocpFormHidden("type","addedit");
      $hidden_state = new XocpFormHidden("state",$state);
      if ($state == "edit") {
         $hidden_old_tmpl_id = new XocpFormHidden("old_tmpl_id",$datarec["old_tmpl_id"]);
         $hidden_old_ind_id = new XocpFormHidden("old_ind_id",$datarec["old_ind_id"]);
         $hidden_old_ind_nm = new XocpFormHidden("old_ind_nm",$datarec["old_ind_nm"]);
         $hidden_old_description = new XocpFormHidden("old_description",$datarec["old_description"]);
         $hidden_old_ind_vars = new XocpFormHidden("old_ind_vars",$datarec["old_ind_vars"]);
         $hidden_old_ind_value = new XocpFormHidden("old_ind_value",$datarec["old_ind_value"]);
         $hidden_old_target_vars = new XocpFormHidden("old_target_vars",$datarec["old_target_vars"]);
         $hidden_old_target_val = new XocpFormHidden("old_target_val",$datarec["old_target_val"]);
         $hidden_old_periode = new XocpFormHidden("old_periode",$datarec["old_periode"]);
         $hidden_old_publish = new XocpFormHidden("old_publish",$datarec["old_publish"]);
      }
      if ($state == "add" && $datarec["tmpl_data"] != "") {
         $data = explode(";",$datarec["tmpl_data"]);
         $tmpl_id = $data[0];
         $datarec["ind_nm"] = $data[1];
         $datarec["ind_vars"] = ($data[2] == "") ? array() : explode("|",$data[2]);
         $bl_vars = ($data[3] == "") ? array() : explode("|",$data[3]);
         $datarec["description"] = $data[4];
         $date = getdate(time());
         $date = new XocpDateTime($date["year"]."-".$date["mon"]."-".$date["mday"]);
      } elseif ($datarec["vars"] != "") {
         $value = explode("|",$datarec["ind_vars"]);
         $data = explode(";",$datarec["vars"]);
         $datarec["ind_vars"] = ($data[0] == "") ? array() : explode("|",$data[0]);
         for ($i = 0; $i < count($datarec["ind_vars"]); $i++) {
            $datarec["ind_vars_".$datarec["ind_vars"][$i]] = $value[$i];
         }
         $bl_vars = ($data[1] == "") ? array() : explode("|",$data[1]);
         $target_vars = ($datarec["target_vars"] == "") ? array() : explode("|",$datarec["target_vars"]);
         for ($i = 0; $i < count($bl_vars); $i++) {
            $date = explode("-",$target_vars[$i]);
            $datarec[$bl_vars[$i]."_year"] = $date[0];
            $datarec[$bl_vars[$i]."_mon"] = $date[1];
            $datarec[$bl_vars[$i]."_mday"] = $date[2];
         }
         if (isset($datarec["ok"])) {
            $datarec["ind_nm"] = $datarec["org_ind_nm"];
            $datarec["description"] = $datarec["org_description"];
         }
      }
      $bl_var = array();
      for ($i = 0; $i < count($bl_vars); $i++) {
         $bl_var[] = "'".$bl_vars[$i]."'";
      }
      $bl_vars = implode(",",$bl_var);
      $db =& Database::getInstance();
      $sql = "SELECT bl_var,bl_nm FROM ".XOCP_PREFIX."ind_baseline
              WHERE bl_var IN ($bl_vars)
              ORDER BY bl_nm";
      $result = $db->query($sql);
      $lines = "<table>";
      while (list($bl_var,$bl_nm) = $db->fetchRow($result)) {
         if ($datarec[$bl_var."_mon"] != "") {
            $date = new XocpDateTime($datarec[$bl_var."_year"]."-".$datarec[$bl_var."_mon"]."-".$datarec[$bl_var."_mday"]);
         }
         $temp = new XocpFormDateTime("","$bl_var",$date);
         $lines .= "<tr><td class='td0'>$bl_nm ($bl_var)</td><td class='td0'>".$temp->render()."</td></tr>";
         unset($temp);
      }
      $lines .= "</table>";
      
      if ($datarec["vars"] == "") {
         $datarec["vars"] = $data[2].";".$data[3];
      }
      $hidden_vars = new XocpFormHidden("vars",$datarec["vars"]);
      $hidden_ind_nm = new XocpFormHidden("org_ind_nm",$datarec["ind_nm"]);
      $hidden_description = new XocpFormHidden("org_description",$datarec["description"]);
      $hidden_tmpl_id = new XocpFormHidden("tmpl_id",$tmpl_id);
      $text_ind_nm = new XocpFormText(_HIND_INDICATORNAME,"ind_nm",50,255,$datarec["ind_nm"]);
      $textarea_description = new XocpFormTextArea(_HIND_INDICATORDESC,"description",$datarec["description"]);
      $elementtray_ind_vars = new XocpFormElementTray(_HIND_INDICATORVARS," ");
      for ($i = 0; $i < count($datarec["ind_vars"]); $i++) {
         $temp = new XocpFormText($datarec["ind_vars"][$i]." = ","ind_vars_".$datarec["ind_vars"][$i],10,15,$datarec["ind_vars_".$datarec["ind_vars"][$i]]);
         $elementtray_ind_vars->addElement($temp);
         unset($temp);
      }
      $text_ind_value = new XocpFormText(_HIND_INDICATORVALUE,"ind_value",10,15,$datarec["ind_value"]);
      $label_target_vars = new XocpFormLabel(_HIND_INDICATORTVARS,$lines);
      $text_target_val = new XocpFormText(_HIND_INDICATORTVAL,"target_val",10,15,$datarec["target_val"]);
      if ($datarec["periode"] != "") {
         $date = explode("-",$datarec["periode"]);
         $datarec["periode_year"] = $date[0];
         $datarec["periode_mon"] = $date[1];
         $datarec["periode_mday"] = $date[2];
      } else {
         $date = getdate(time());
         $datarec["periode_year"] = $date["year"];
         $datarec["periode_mon"] = $date["mon"];
         $datarec["periode_mday"] = $date["mday"];
      }
      $periode_dt = new XocpDateTime($datarec["periode_year"]."-".$datarec["periode_mon"]."-".$datarec["periode_mday"]);
      $date_periode = new XocpFormDateTime(_HIND_INDICATORPERIOD,"periode",$periode_dt);
      if ($datarec["publish"] == "") {
         $datarec["publish"] = "1";
      }
      $enum_yn = array("y" => "1","n" => "0","1" => "1","0" => "0");
      $radioyesno_publish = new XocpFormRadioYN(_HIND_INDICATORPUBLISH,"publish",$enum_yn[$datarec["publish"]]);

      $submit_save = new XocpFormButton("","save",_SAVE,"submit");
      $submit_reset = new XocpFormButton("","reset",_RESET,"reset");
      $elementtray_button = new XocpFormElementTray("");
      $elementtray_button->addElement($submit_save);
      $elementtray_button->addElement($submit_reset);
      // Show or hide Cancel button
      if ($showcancel) {
         $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
         $elementtray_button->addElement($submit_cancel);
      }

      // Constructing a form - Add/edit a indicator item
      if ($state == "add") {
         $title = _HIND_INDICATORADDTITLE;
      } else {
         $title = _HIND_INDICATOREDITTITLE;
      }
      $form = new XocpThemeForm($title,"faddeditinditem","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_type);
      $form->addElement($hidden_state);
      if ($state == "edit") {
         $form->addElement($hidden_old_tmpl_id);
         $form->addElement($hidden_old_ind_id);
         $form->addElement($hidden_old_ind_nm);
         $form->addElement($hidden_old_description);
         $form->addElement($hidden_old_ind_vars);
         $form->addElement($hidden_old_ind_value);
         $form->addElement($hidden_old_target_vars);
         $form->addElement($hidden_old_target_val);
         $form->addElement($hidden_old_periode);
         $form->addElement($hidden_old_publish);
      }

      $form->addElement($hidden_vars);
      $form->addElement($hidden_ind_nm);
      $form->addElement($hidden_description);
      $form->addElement($hidden_tmpl_id);
      $form->addElement($text_ind_nm);
      $form->addElement($textarea_description);
      $form->addElement($elementtray_ind_vars);
      $form->addElement($text_ind_value);
      $form->addElement($label_target_vars);
      $form->addElement($text_target_val);
      $form->addElement($date_periode);
      $form->addElement($radioyesno_publish);
      $form->addElement($elementtray_button);
      if ($comment != "") {
         $form->setComment($comment);
      }

      if ($tmpl_id == NULL) {
         $this->html->setBodyOnload(" onload='document.faddeditinditem.ind_nm.focus();'");
      }
   
      return $form->render();
   }
   
   function formConfirm($state = "add",$datarec,$title = "") {
      // Form elements - Confirm indicator item being added/edited/deleted
      $hidden_type = new XocpFormHidden("type","confirm");
      $hidden_state = new XocpFormHidden("state",$state);
      if ($state != "add") {
         $hidden_old_tmpl_id = new XocpFormHidden("old_tmpl_id",$datarec["old_tmpl_id"]);
         $hidden_old_ind_id = new XocpFormHidden("old_ind_id",$datarec["old_ind_id"]);
         $hidden_old_ind_nm = new XocpFormHidden("old_ind_nm",$datarec["old_ind_nm"]);
         $hidden_old_description = new XocpFormHidden("old_description",$datarec["old_description"]);
         $hidden_old_ind_vars = new XocpFormHidden("old_ind_vars",$datarec["old_ind_vars"]);
         $hidden_old_ind_value = new XocpFormHidden("old_ind_value",$datarec["old_ind_value"]);
         $hidden_old_target_vars = new XocpFormHidden("old_target_vars",$datarec["old_target_vars"]);
         $hidden_old_target_val = new XocpFormHidden("old_target_val",$datarec["old_target_val"]);
         $hidden_old_periode = new XocpFormHidden("old_periode",$datarec["old_periode"]);
         $hidden_old_publish = new XocpFormHidden("old_publish",$datarec["old_publish"]);
      }

      $hidden_vars = new XocpFormHidden("vars",$datarec["vars"]);
      $hidden_org_ind_nm = new XocpFormHidden("org_ind_nm",$datarec["org_ind_nm"]);
      $hidden_org_description = new XocpFormHidden("org_description",$datarec["org_description"]);
      $hidden_tmpl_id = new XocpFormHidden("tmpl_id",$datarec["tmpl_id"]);
      $hidden_ind_nm = new XocpFormHidden("ind_nm",$datarec["ind_nm"]);
      $hidden_description = new XocpFormHidden("description",$datarec["description"]);
      $hidden_ind_value = new XocpFormHidden("ind_value",$datarec["ind_value"]);
      $hidden_target_val = new XocpFormHidden("target_val",$datarec["target_val"]);
      if ($state == "delete") {
         $date = explode("-",$datarec["periode"]);
         $datarec["periode_year"] = $date[0];
         $datarec["periode_mon"] = $date[1];
         $datarec["periode_mday"] = $date[2];
      }
      if ($datarec["periode_year"] == "") $datarec["periode_year"] = "0000";
      if ($datarec["periode_mday"] == "") $datarec["periode_mday"] = "00";
      $hidden_periode = new XocpFormHidden("periode",$datarec["periode_year"]."-".
                                                     $datarec["periode_mon"]."-".
                                                     $datarec["periode_mday"]);
      $enum_yn = array("y" => "1","n" => "0","1" => "y","0" => "n");
      $hidden_publish = new XocpFormHidden("publish",$enum_yn[$datarec["publish"]]);

      $label_ind_nm = new XocpFormLabel(_HIND_INDICATORNAME,$datarec["ind_nm"]);
      $label_description = new XocpFormLabel(_HIND_INDICATORDESC,nl2br($datarec["description"]));
      $data = explode(";",$datarec["vars"]);
      $ind_vars = $data[0] == "" ? array() : explode("|",$data[0]);
      $val = explode("|",$datarec["ind_vars"]);
      for ($i = 0;$i < count($ind_vars); $i++) {
         if ($state != "delete") {
            $label .= $ind_vars[$i]." = ".$datarec["ind_vars_".$ind_vars[$i]]."<br />";
            $value .= $datarec["ind_vars_".$ind_vars[$i]]."|";
         } else {
            $label .= $ind_vars[$i]." = ".$val[$i]."<br />";
            $value .= $val[$i]."|";
         }
      }
      $hidden_ind_vars = new XocpFormHidden("ind_vars",substr($value,0,strlen($value) - 1));
      $label_ind_vars = new XocpFormLabel(_HIND_INDICATORVARS,$label);
      $label_ind_value = new XocpFormLabel(_HIND_INDICATORVALUE,$datarec["ind_value"]);
      $target_vars = $data[1] == "" ? array() : explode("|",$data[1]);
      $bl_var = array();
      for ($i = 0; $i < count($target_vars); $i++) {
         $bl_var[] = "'".$target_vars[$i]."'";
      }
      $bl_vars = implode(",",$bl_var);
      $db =& Database::getInstance();
      $sql = "SELECT bl_var,bl_nm FROM ".XOCP_PREFIX."ind_baseline
              WHERE bl_var IN ($bl_vars)
              ORDER BY bl_nm";
      $result = $db->query($sql);
      $label = "<table>";
      $value = "";
      if ($state != "delete") {
         while (list($bl_var,$bl_nm) = $db->fetchRow($result)) {
            $label .= "<tr><td class='td0'>$bl_nm ($bl_var)</td><td class='td0'>: ".
                      sql2ind2($datarec[$bl_var."_year"]."-".$datarec[$bl_var."_mon"]."-".
                               $datarec[$bl_var."_mday"])."</td></tr>";
            if ($datarec[$bl_var."_year"] == "") $datarec["periode_year"] = "0000";
            if ($datarec[$bl_var."_mday"] == "") $datarec["periode_mday"] = "00";
            $value .= $datarec[$bl_var."_year"]."-".
                      $datarec[$bl_var."_mon"]."-".
                      $datarec[$bl_var."_mday"]."|";
         }
      } else {
         $val = explode("|",$datarec["target_vars"]);
         $i = 0;
         while (list($bl_var,$bl_nm) = $db->fetchRow($result)) {
            $label .= "<tr><td class='td0'>$bl_nm ($bl_var)</td><td class='td0'>: ".sql2ind2($val[$i])."</td></tr>";
            $value .= $val[$i++]."|";
         }
      }
      $label .= "</table>";
      $hidden_target_vars = new XocpFormHidden("target_vars",substr($value,0,strlen($value) - 1));
      $label_target_vars = new XocpFormLabel(_HIND_INDICATORTVARS,$label);
      $label_target_val = new XocpFormLabel(_HIND_INDICATORTVAL,$datarec["target_val"]);
      $label_periode = new XocpFormLabel(_HIND_INDICATORPERIOD,
                                         sql2ind2($datarec["periode_year"]."-".
                                                  $datarec["periode_mon"]."-".
                                                  $datarec["periode_mday"]));
      $enum_yn = array("y" => _YES,"n" => _NO,"1" => _YES,"0" => _NO);
      $label_publish = new XocpFormLabel(_HIND_INDICATORPUBLISH,$enum_yn[$datarec["publish"]]);

      $submit_ok = new XocpFormButton("","ok",_OK,"submit");
      if ($state != "delete") {
         $submit_edit = new XocpFormButton("","edit",_EDIT,"submit");
      }
      $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
      $elementtray_button = new XocpFormElementTray("");
      $elementtray_button->addElement($submit_ok);
      if ($state != "delete") {
         $elementtray_button->addElement($submit_edit);
      }
      $elementtray_button->addElement($submit_cancel);

      // Constructing a form - Confirm added/edited indicator item
      $form = new XocpThemeForm($title,"fconfirminditem","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_type);
      $form->addElement($hidden_state);
      if ($state != "add") {
         $form->addElement($hidden_old_tmpl_id);
         $form->addElement($hidden_old_ind_id);
         $form->addElement($hidden_old_ind_nm);
         $form->addElement($hidden_old_description);
         $form->addElement($hidden_old_ind_vars);
         $form->addElement($hidden_old_ind_value);
         $form->addElement($hidden_old_target_vars);
         $form->addElement($hidden_old_target_val);
         $form->addElement($hidden_old_periode);
         $form->addElement($hidden_old_publish);
      }

      $form->addElement($hidden_vars);
      $form->addElement($hidden_org_ind_nm);
      $form->addElement($hidden_org_description);
      $form->addElement($hidden_tmpl_id);
      $form->addElement($hidden_ind_nm);
      $form->addElement($hidden_description);
      $form->addElement($hidden_ind_vars);
      $form->addElement($hidden_ind_value);
      $form->addElement($hidden_target_vars);
      $form->addElement($hidden_target_val);
      $form->addElement($hidden_periode);
      $form->addElement($hidden_publish);

      $form->addElement($label_ind_nm);
      $form->addElement($label_description);
      $form->addElement($label_ind_vars);
      $form->addElement($label_ind_value);
      $form->addElement($label_target_vars);
      $form->addElement($label_target_val);
      $form->addElement($label_periode);
      $form->addElement($label_publish);
      $form->addElement($elementtray_button);
      
      if ($state == "add") {
         $this->html->setBodyOnload(" onload='document.fconfirminditem.ok.focus();'");
      } else {
         $this->html->setBodyOnload(" onload='document.fconfirminditem.cancel.focus();'");
      }

      return $form->render();
   }
   
   function main() {
      $db =& Database::getInstance();
      $this->getparam = _HIND_CATCH_VAR."="._HIND_INDICATOR_BLOCK;
      $this->postparam = new XocpFormHidden(_HIND_CATCH_VAR,_HIND_INDICATOR_BLOCK);
      switch ($this->catch) {
         case _HIND_INDICATOR_BLOCK:
            global $HTTP_POST_VARS,$HTTP_GET_VARS;
            if (trim($HTTP_POST_VARS["txt_find"]) != "") {
               // Search templates
               $nm = trim($HTTP_POST_VARS["txt_find"]);
               if (!eregi("\*",$nm)) {
                  $nm = "%$nm%";
               } else {
                  $nm = str_replace("*","%",$nm);
               }
               global $ses_org_id,$ses_ind_tmpl_id;
               if ($HTTP_POST_VARS["type"] == "blnav") {
                  $ret = $this->templateNavigate($nm,"","",$ses_org_id);
               } else {
                  $ret = $this->indicatorDataNavigate("","",$ses_org_id,$ses_ind_tmpl_id);
               }
            } elseif (isset($HTTP_POST_VARS["type"])) {
               // Form handler a.k.a page script flow
               $state = $HTTP_POST_VARS["state"];  // Preserve state
               //$showcancel = ($state == "edit") ? TRUE : FALSE;  // Show cancel button on add/edit form
               $showcancel = TRUE;  // Always show cancel button on add/edit form
               switch ($HTTP_POST_VARS["type"]) {
                  case "show":  // Show detail form
                     global $ses_ind_tmpl_id,$ses_org_id;
                     if (!isset($HTTP_POST_VARS["cancel"])) {
                        // Initialize values
                        $HTTP_POST_VARS["tmpl_id"] = $HTTP_POST_VARS["old_tmpl_id"];
                        $HTTP_POST_VARS["ind_id"] = $HTTP_POST_VARS["old_ind_id"];
                        $HTTP_POST_VARS["ind_nm"] = $HTTP_POST_VARS["old_ind_nm"];
                        $HTTP_POST_VARS["description"] = $HTTP_POST_VARS["old_description"];
                        $HTTP_POST_VARS["ind_vars"] = $HTTP_POST_VARS["old_ind_vars"];
                        $HTTP_POST_VARS["ind_value"] = $HTTP_POST_VARS["old_ind_value"];
                        $HTTP_POST_VARS["target_vars"] = $HTTP_POST_VARS["old_target_vars"];
                        $HTTP_POST_VARS["target_val"] = $HTTP_POST_VARS["old_target_val"];
                        $HTTP_POST_VARS["periode"] = $HTTP_POST_VARS["old_periode"];
                        $HTTP_POST_VARS["publish"] = $HTTP_POST_VARS["old_publish"];
                     }
                     if (isset($HTTP_POST_VARS["edit"])) {  // Edit
                        $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel,$ses_org_id,$ses_ind_tmpl_id);
                     } elseif (isset($HTTP_POST_VARS["cancel"])) {  // Cancel
                        $ret = $this->indicatorDataNavigate(NULL,NULL,$ses_org_id,$ses_ind_tmpl_id);
                     } else {  // Delete
                        $ret = $this->formConfirm("delete",$HTTP_POST_VARS,_HIND_INDICATORDELCONFIRMTITLE);
                     }
                     break;
                  case "addedit":  // Add/edit form
                     if (isset($HTTP_POST_VARS["save"])) {  // Save
                        if (trim($HTTP_POST_VARS["ind_nm"]) != "") {  // Check for required field
                           if ($state == "add") {
                              $title = _HIND_INDICATORADDCONFIRMTITLE;
                           } else {
                              $title = _HIND_INDICATOREDITCONFIRMTITLE;
                           }
                           $ret = $this->formConfirm($state,$HTTP_POST_VARS,$title);
                        } else {
                           global $ses_org_id,$ses_ind_tmpl_id;
                           if (!isset($ses_ind_tmpl_id)) {
                              $ses_ind_tmpl_id = $HTTP_POST_VARS["tmpl_id"];
                           }
                           $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel,
                                                     $ses_org_id,$ses_ind_tmpl_id,_HIND_INDICATORSAVEERROR);
                        }
                     } elseif (isset($HTTP_POST_VARS["cancel"])) {  // Cancel
                        if ($state == "edit") {
                           // Set back to original values
                           $HTTP_POST_VARS["tmpl_id"] = $HTTP_POST_VARS["old_tmpl_id"];
                           $HTTP_POST_VARS["ind_id"] = $HTTP_POST_VARS["old_ind_id"];
                           $HTTP_POST_VARS["ind_nm"] = $HTTP_POST_VARS["old_ind_nm"];
                           $HTTP_POST_VARS["description"] = $HTTP_POST_VARS["old_description"];
                           $HTTP_POST_VARS["ind_vars"] = $HTTP_POST_VARS["old_ind_vars"];
                           $HTTP_POST_VARS["ind_value"] = $HTTP_POST_VARS["old_ind_value"];
                           $HTTP_POST_VARS["target_vars"] = $HTTP_POST_VARS["old_target_vars"];
                           $HTTP_POST_VARS["target_val"] = $HTTP_POST_VARS["old_target_val"];
                           $HTTP_POST_VARS["periode"] = $HTTP_POST_VARS["old_periode"];
                           $HTTP_POST_VARS["publish"] = $HTTP_POST_VARS["old_publish"];
                           $ret = $this->formShowDetail($HTTP_POST_VARS,_HIND_INDICATORSAVECANCEL);
                        } else {
                           global $ses_org_id,$ses_ind_tmpl_id;
                           if (isset($ses_ind_tmpl_id)) {
                           	$ret = $this->indicatorDataNavigate("","",$ses_org_id,$ses_ind_tmpl_id);
                           } else {
                              session_unregister($ses_ind_tmpl_id);
                              $ret = $this->formSelectTemplate();
                           }
                        }
                     }
                     break;
                  case "confirm":  // Confirmation form
                     global $ses_org_id,$ses_ind_tmpl_id;
                     if (isset($HTTP_POST_VARS["ok"])) {  // Ok, save/delete indicator item
                        if ($state == "delete") {  // Do delete indicator data
                           $sql = "DELETE FROM ".XOCP_PREFIX."ind_items
                                   WHERE org_id = '$ses_org_id' AND
                                         ind_id = '".$HTTP_POST_VARS["old_ind_id"]."'";
                           $result = $db->query($sql);
                           $comment = $db->error();
                           if ($comment == "") {
                              // Warning: this isn't the proper function
                              //if ($db->getRowsNum($result) > 0) {
                              if (mysql_affected_rows() > 0) {
                                 $comment = _HIND_INDICATORDELETESUCCESS;
                              } else {
                                 $comment = _HIND_INDICATORDELETEFAIL;
                              }
                           } else {
                              $comment = _HIND_INDICATORDELETEERROR."<br/>$comment";
                           }
                           $ret = $this->indicatorDataNavigate("","",$ses_org_id,$ses_ind_tmpl_id);
                        } else { // Save indicator data
                           if (isset($ses_ind_tmpl_id)) {
                           	$HTTP_POST_VARS["tmpl_id"] = $ses_ind_tmpl_id;
                           }
                           $date = new XocpDateTime($HTTP_POST_VARS["periode"]);
                           $HTTP_POST_VARS["periode"] = $date->getMySQL("date");
                           // What variables are contained in the indicator?
                           $vars = explode(";",$HTTP_POST_VARS["vars"]);
                           $ind_vars = explode("|",$vars[0]);
                           $bl_vars = explode("|",$vars[1]);
                           // Now fetch the values
                           $ind_vars_value = explode("|",$HTTP_POST_VARS["ind_vars"]);
                           $dates = explode("|",$HTTP_POST_VARS["target_vars"]);
                           $bl_vars_value = array();
                           for ($i = 0;$i < count($dates);$i++) {
                              $date = new XocpDateTime($dates[$i]);
                              $dt = "|".$date->getMySQL("date");
                              $bl_vars_value[] = $date->getMySQL("date");
                           }
                           $HTTP_POST_VARS["target_vars"] = substr($dt,1);
                           for ($i = 0;$i < count($bl_vars_value);$i++) {
                              $date_elem = explode("-",$bl_vars_value[$i]);
                              $dt_patt1 = $date_elem[0]."-".$date_elem[1]."-%";
                              $dt_patt2 = $date_elem[0]."-%-%";
                              $dt_patt3 = ($date_elem[0] + 1)."-".$date_elem[1]."-%";
                              $sql = "SELECT bl_val FROM ".XOCP_PREFIX."ind_baselinedata
                                      WHERE org_id = '$ses_org_id' AND bl_var = '".$bl_vars[$i]."' AND
                                            ((valid0 = '".$bl_vars_value[$i]."' AND valid1 = '".$bl_vars_value[$i]."') OR
                                             (valid0 LIKE '$dt_patt1' AND valid1 LIKE '$dt_patt1') OR
                                             (valid0 LIKE '$dt_patt2' AND valid1 LIKE '$dt_patt2') OR
                                             (valid0 LIKE '$dt_patt1' AND valid1 LIKE '$dt_patt3'))
                                      ORDER BY valid0 DESC,valid1";
                              $result = $db->query($sql);
                              if ($db->getRowsNum($result) > 0) {
                                 list($value) = $db->fetchRow($result);
                                 $bl_vars_value[$i] = $value;
                              } else {
                                 $sql = "SELECT bl_val FROM ".XOCP_PREFIX."ind_baselinedata
                                         WHERE org_id = '$ses_org_id' AND bl_var = '".$bl_vars[$i]."'
                                         ORDER BY valid0 DESC,valid1";
                                 $result = $db->query($sql);
                                 if ($db->getRowsNum($result) > 0) {
                                    list($value) = $db->fetchRow($result);
                                    $bl_vars_value[$i] = $value;
                                 } else {
                                    $bl_vars_value[$i] = "";
                                 }
                              }
                           }
/*                           print_r($ind_vars);
                           echo "<br>";
                           print_r($ind_vars_value);
                           echo "<br>";
                           print_r($bl_vars);
                           echo "<br>";
                           print_r($bl_vars_value);
                           echo "<br>";
                           return;*/
                           if ($state == "add") {  // New indicator item, do add
                              $sql = "SELECT MAX(ind_id) FROM ".XOCP_PREFIX."ind_items
                                      WHERE org_id = '$ses_org_id'";
                              $result = $db->query($sql);
                              list($ind_id) = $db->fetchRow($result);
                              if ($ind_id == "") {
                                 $ind_id = 1;
                              } else {
                                 $ind_id += 1;
                              }
                              $sql = "INSERT INTO ".XOCP_PREFIX."ind_items (org_id,ind_id,
                                             ind_nm,description,tmpl_id,ind_vars,ind_value,
                                             target_vars,target_val,periode,created,modified,
                                             publish)
                                      VALUES ('$ses_org_id','$ind_id','".
                                              $HTTP_POST_VARS["ind_nm"]."','".
                                              $HTTP_POST_VARS["description"]."','".
                                              $HTTP_POST_VARS["tmpl_id"]."','".
                                              $HTTP_POST_VARS["ind_vars"]."','".
                                              $HTTP_POST_VARS["ind_value"]."','".
                                              $HTTP_POST_VARS["target_vars"]."','".
                                              $HTTP_POST_VARS["target_val"]."','".
                                              $HTTP_POST_VARS["periode"]."',NOW(),NOW(),'".
                                              $HTTP_POST_VARS["publish"]."')";
                           } else {  // Old indicator data, do update
                              $sql = "UPDATE ".XOCP_PREFIX."ind_items
                                      SET ind_nm = '".$HTTP_POST_VARS["ind_nm"]."',
                                          description = '".$HTTP_POST_VARS["description"]."',
                                          ind_vars = '".$HTTP_POST_VARS["ind_vars"]."',
                                          ind_value = '".$HTTP_POST_VARS["ind_value"]."',
                                          target_vars = '".$HTTP_POST_VARS["target_vars"]."',
                                          target_val = '".$HTTP_POST_VARS["target_val"]."',
                                          periode = '".$HTTP_POST_VARS["periode"]."',
                                          modified = NOW(),
                                          publish = '".$HTTP_POST_VARS["publish"]."'
                                      WHERE org_id = '$ses_org_id' AND ind_id = '".
                                            $HTTP_POST_VARS["old_ind_id"]."'";
                           }
                           $result = $db->query($sql);
                           $comment = $db->error();
                           if ($comment != "") {
                              if ($state != "add") {  // Set back to original values
                                 $HTTP_POST_VARS["tmpl_id"] = $HTTP_POST_VARS["old_tmpl_id"];
                                 $HTTP_POST_VARS["ind_id"] = $HTTP_POST_VARS["old_ind_id"];
                                 $HTTP_POST_VARS["ind_nm"] = $HTTP_POST_VARS["old_ind_nm"];
                                 $HTTP_POST_VARS["description"] = $HTTP_POST_VARS["old_description"];
                                 $HTTP_POST_VARS["ind_vars"] = $HTTP_POST_VARS["old_ind_vars"];
                                 $HTTP_POST_VARS["ind_value"] = $HTTP_POST_VARS["old_ind_value"];
                                 $HTTP_POST_VARS["target_vars"] = $HTTP_POST_VARS["old_target_vars"];
                                 $HTTP_POST_VARS["target_val"] = $HTTP_POST_VARS["old_target_val"];
                                 $HTTP_POST_VARS["periode"] = $HTTP_POST_VARS["old_periode"];
                                 $HTTP_POST_VARS["publish"] = $HTTP_POST_VARS["old_publish"];
                              }
                              $comment = _HIND_INDICATORSAVEFAIL."<br/>".$comment;
                           } else {
                              if ($state == "add") {
                                 $datarec["tmpl_data"] = $HTTP_POST_VARS["tmpl_id"].";".
                                                         $HTTP_POST_VARS["org_ind_nm"].";".
                                                         $HTTP_POST_VARS["vars"].";".
                                                         $HTTP_POST_VARS["org_description"];
                              }
                              $comment = _HIND_INDICATORSAVESUCCESS;
                           }
                           if ($state == "add") {
                              $ret = $this->formAddEdit($state,$datarec,$showcancel,$ses_org_id,$ses_ind_tmpl_id,$comment);
                           } else {
                              $ret = $this->formShowDetail($HTTP_POST_VARS,$comment);
                           }
                        }
                     } elseif (isset($HTTP_POST_VARS["edit"])) {
                        global $ses_org_id,$ses_ind_tmpl_id;
                        $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel,$ses_org_id,$ses_ind_tmpl_id);
                     } elseif (isset($HTTP_POST_VARS["cancel"])) {  // Cancel
                        if ($state == "add") {
                           $datarec["tmpl_data"] = $HTTP_POST_VARS["tmpl_id"].";".
                                                   $HTTP_POST_VARS["org_ind_nm"].";".
                                                   $HTTP_POST_VARS["vars"].";".
                                                   $HTTP_POST_VARS["org_description"];
                           $ret = $this->formAddEdit($state,$datarec,$showcancel,_HIND_INDICATORSAVECANCEL);
                        } else{
                           if ($state == "edit") {
                              // Set back to original data
                              $comment = _HIND_INDICATORSAVECANCEL;
                              $HTTP_POST_VARS["tmpl_id"] = $HTTP_POST_VARS["old_tmpl_id"];
                              $HTTP_POST_VARS["ind_id"] = $HTTP_POST_VARS["old_ind_id"];
                              $HTTP_POST_VARS["ind_nm"] = $HTTP_POST_VARS["old_ind_nm"];
                              $HTTP_POST_VARS["description"] = $HTTP_POST_VARS["old_description"];
                              $HTTP_POST_VARS["ind_vars"] = $HTTP_POST_VARS["old_ind_vars"];
                              $HTTP_POST_VARS["ind_value"] = $HTTP_POST_VARS["old_ind_value"];
                              $HTTP_POST_VARS["target_vars"] = $HTTP_POST_VARS["old_target_vars"];
                              $HTTP_POST_VARS["target_val"] = $HTTP_POST_VARS["old_target_val"];
                              $HTTP_POST_VARS["periode"] = $HTTP_POST_VARS["old_periode"];
                              $HTTP_POST_VARS["publish"] = $HTTP_POST_VARS["old_publish"];
                           } else {
                              $comment = _HIND_INDICATORDELCANCEL;
                           }
                           $ret = $this->formShowDetail($HTTP_POST_VARS,$comment);
                        }
                     }
                     break;
                  case "selecttmpl":  // Select template
                     global $ses_ind_tmpl_id,$ses_org_id;
                     if (isset($HTTP_POST_VARS["cancel"])) {
                        session_unregister("ses_ind_tmpl_id");
                        $ret = $this->templateNavigate("","","",$ses_org_id);
                     } elseif (isset($HTTP_POST_VARS["select"])) {
                        $tmpl_data = explode(";",$HTTP_POST_VARS["tmpl_data"]);
                        //$ses_ind_tmpl_id = $tmpl_data[0];
                        $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel,$ses_org_id,$tmpl_data[0]);
                     }
                  case "tmplnav":  // Template navigation
                     global $ses_ind_pgroup_id,$ses_org_id;
                     if (isset($HTTP_POST_VARS["btn_cancel"])) {
                        session_unregister("ses_org_id");
                        $ret = $this->orgNavigate($ses_ind_pgroup_id);
                     } elseif (isset($HTTP_POST_VARS["btn_add"])) {
                        $ret = $this->formSelectTemplate();
                     }
                     break;
                  case "inddtnav":  // Indicator navigation
                     global $ses_org_id,$ses_ind_tmpl_id;
                     if (isset($HTTP_POST_VARS["btn_cancel"])) {
                        session_unregister("ses_ind_tmpl_id");
                        $ret = $this->templateNavigate("","","",$ses_org_id);
                     } elseif (isset($HTTP_POST_VARS["btn_add"])) {
                        $tmpl_data = explode(";",$HTTP_POST_VARS["tmpl_data"]);
                        $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel,$ses_org_id,$ses_ind_tmpl_id);
                     }
                     break;
               }
            } elseif ($HTTP_GET_VARS["browse"] == "y" && $HTTP_GET_VARS["x"] != "") {
               // Organization data page
               global $ses_org_id;
               session_register("ses_org_id");
               $ses_org_id = $HTTP_GET_VARS["x"];
               $ret = $this->templateNavigate("","","",$ses_org_id);
            } elseif ($HTTP_GET_VARS["list"] == "y" && $HTTP_GET_VARS["x"] != "") {
               // Navigate indicator item
               global $ses_ind_tmpl_id,$ses_org_id;
               session_register("ses_ind_tmpl_id");
               $ses_ind_tmpl_id = $HTTP_GET_VARS["x"];
               $ret = $this->indicatorDataNavigate("","",$ses_org_id,$ses_ind_tmpl_id);
            } elseif ($HTTP_GET_VARS["show"] == "y" && $HTTP_GET_VARS["x"] != "") {
               // Show indicator data detail
               global $ses_org_id;
               $sql = "SELECT tmpl_id,ind_id,ind_nm,description,ind_vars,ind_value,
                              target_vars,target_val,periode,publish
                       FROM ".XOCP_PREFIX."ind_items
                       WHERE ind_id = ".$HTTP_GET_VARS["x"]." AND org_id = $ses_org_id";
               $result = $db->query($sql);
               if ($db->getRowsNum($result) > 0) {
                  $datarec = $db->fetchArray($result);
                  $ret = $this->formShowDetail($datarec);
               } else {
                  $ret = $this->templateNavigate();
               }
            } elseif ($HTTP_GET_VARS["p"] != "") {
               // Navigate template or indicator item data page
               global $ses_org_id,$ses_ind_tmpl_id;
               if ($HTTP_GET_VARS["type"] == "tmplnav") {
                  $ret = $this->templateNavigate($HTTP_GET_VARS["fi"],$HTTP_GET_VARS["p"],$HTTP_GET_VARS["f"],$ses_org_id);
               } else {
                  $ret = $this->indicatorDataNavigate($HTTP_GET_VARS["p"],$HTTP_GET_VARS["f"],$ses_org_id,$ses_ind_tmpl_id);
               }
            } else {
               // This must be ripped out
               $ret = $this->templateNavigate("","","",$ses_org_id);
            }
            break;
         default:
            // Default handler
            global $ses_ind_pgroup_id,$ses_org_id,$ses_ind_tmpl_id;
            if (isset($ses_ind_tmpl_id)) {
            	$ret = $this->indicatorDataNavigate("","",$ses_org_id,$ses_ind_tmpl_id);
            } elseif (isset($ses_org_id)) {
               $ret = $this->templateNavigate("","","",$ses_org_id);
            } else {
               if (!session_is_registered("ses_ind_pgroup_id")) {
                  session_register("ses_ind_pgroup_id");
                  $ses_ind_pgroup_id = "1";
               }
               $ret = $this->orgNavigate($ses_ind_pgroup_id);
            }
            break;
      }
      return $ret;
   }

}
} // HEALTHINDICATOR_INDICATOR_DEFINED
?>
