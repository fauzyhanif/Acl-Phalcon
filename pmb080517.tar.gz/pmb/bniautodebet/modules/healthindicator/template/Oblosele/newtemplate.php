<?php
// Block register
$hidden_blockreg = new XocpFormHidden("X_healthindicator","1");

// Form elements
if (!empty($datarec)) {
   $tmpl_id = $datarec["tmpl_id"];
   $HTTP_POST_VARS["tmpl_nm"] = $datarec["tmpl_nm"];
   $HTTP_POST_VARS["tmpl_vars"] = $datarec["tmpl_vars"];
   $HTTP_POST_VARS["tmpl_unit"] = $datarec["tmpl_unit"];
   $HTTP_POST_VARS["target_val"] = $datarec["target_val"];
   $HTTP_POST_VARS["description"] = $datarec["description"];
   $HTTP_POST_VARS["formula"] = $datarec["formula"];
}
$text_tmpl_nm = new XocpFormText(_HIND_TEMPLATENAME,"tmpl_nm",30,512,$HTTP_POST_VARS["tmpl_nm"]);
$text_tmpl_vars = new XocpFormText(_HIND_TEMPLATEVARIABLE,"tmpl_vars",49,512,$HTTP_POST_VARS["tmpl_vars"]);
$text_tmpl_unit = new XocpFormText(_HIND_TEMPLATEUNIT,"tmpl_unit",10,512,$HTTP_POST_VARS["tmpl_unit"]);
$text_target_val = new XocpFormText(_HIND_TARGETVAL,"target_val",10,512,$HTTP_POST_VARS["target_val"]);
$textarea_formula = new XocpFormTextArea(_HIND_TEMPLATEFORMULA,"formula",$HTTP_POST_VARS["formula"]);
$textarea_description = new XocpFormTextArea(_HIND_TEMPLATEDESCRIPTION,"description",$HTTP_POST_VARS["description"]);
$submit_savenewtmpl = new XocpFormButton("","savenewtmpl",_HIND_SAVENEWTEMPLATE,"submit");
$submit_cancel = new XocpFormButton("","cancel",_HIND_CANCEL,"submit");
$elementtray_buttons = new XocpFormElementTray("");
$elementtray_buttons->addElement($submit_savenewtmpl);
$elementtray_buttons->addElement($submit_cancel);

// Constructing a form
$form = new XocpThemeForm(_HIND_NEWTEMPLATETITLE,"fsavenewtmpl","index.php","post",TRUE);
$form->addElement($hidden_blockreg);
if ($tmpl_id != "") {
  $hidden_tmpl_id = new XocpFormHidden("tmpl_id",$tmpl_id);
  $form->addElement($hidden_tmpl_id);
}
$form->addElement($text_tmpl_nm);
$form->addElement($textarea_description);
$form->addElement($text_tmpl_vars);
$form->addElement($text_tmpl_unit);
$form->addElement($textarea_formula);
$form->addElement($text_target_val);
$form->addElement($elementtray_buttons);
?>