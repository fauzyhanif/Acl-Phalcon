<?php
// Block register
$hidden_blockreg = new XocpFormHidden("X_healthindicator","1");

// Form elements
$text_tmpl_nm = new XocpFormText(_HIND_TEMPLATENAME,"tmpl_nm",30,512,$HTTP_POST_VARS["tmpl_nm"]);
$textarea_description = new XocpFormTextArea(_HIND_TEMPLATEDESCRIPTION,"description",$HTTP_POST_VARS["description"]);
$submit_searchtmpl = new XocpFormButton("","searchtmpl",_HIND_SEARCHTEMPLATE,"submit");
$submit_newtmpl = new XocpFormButton("","newtmpl",_HIND_NEWTEMPLATE,"submit");
$elementtray_buttons = new XocpFormElementTray("");
$elementtray_buttons->addElement($submit_searchtmpl);
$elementtray_buttons->addElement($submit_newtmpl);

// Constructing a form
$form = new XocpThemeForm(_HIND_SEARCHTEMPLATETITLE,"fsearchtmpl","index.php");
$form->addElement($hidden_blockreg);
$form->addElement($text_tmpl_nm);
$form->addElement($textarea_description);
$form->addElement($elementtray_buttons);

?>