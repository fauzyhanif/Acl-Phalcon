<script language='JavaScript'>
function setBaselineName() {
   obj = document.faddedittemplate.bl_vars;
   document.faddedittemplate.bl_nm.value = obj.options[obj.selectedIndex].text;
   return true;
}
</script>
