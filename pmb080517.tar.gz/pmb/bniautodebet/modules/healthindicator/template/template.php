<?php
if ( !defined('HEALTHINDICATOR_TEMPLATE_DEFINED') ) {
   define('HEALTHINDICATOR_TEMPLATE_DEFINED', TRUE);

include_once(XOCP_DOC_ROOT."/modules/healthindicator/modconsts.php");

// Class XocpFormMultiValue
// Custom class for private use only
class XocpFormMultiValue Extends XocpFormElement {
   // private
   // array of form element objects
   var $elements = array();
   // var temp
   var $temp;
   // mvals_bl_vars;
   var $mvals_bl_vars;

   // public
   function XocpFormMultiValue($caption, $elems = NULL){
      $this->setCaption($caption);
      $this->setName("mvals_bl_vars");
      if (is_array($elems)) {
      	$this->elements = $elems;
      }
   }

   // public
   function addElement($key,$val){
      $this->elements[$key] = $val;
      $this->mvals_bl_vars .= "|$key";
   }

   // public
   function render(){
      $count = 0;
      $ret = "<div name='mvals' id='mvals'>";
      foreach ( $this->elements as $key => $ele ) {
         $temp = new XocpFormCheckBox("","mval_$key");
         $temp->addOption($key,$ele);
         if ( $count > 0 ) {
            $ret .= "<br />";
         }
         $ret .= $temp->render()."\n";
         unset($temp);
         $count++;
      }
      $select_bl_vars = new XocpFormSelect("","bl_vars");
      $select_bl_vars->addOption("","");
      $db =& Database::getInstance();
      $sql = "SELECT bl_var,bl_nm FROM ".XOCP_PREFIX."ind_baseline ORDER BY bl_nm";
      $result = $db->query($sql);
      while (list($bl_var,$bl_nm) = $db->fetchRow($result)) {
         $select_bl_vars->addOption($bl_var,$bl_nm);
      }
      $submit_add = new XocpFormButton("","add",_ADD,"button");
      $submit_add->setExtra("onclick='doAdd(false);'");
      $submit_delete = new XocpFormButton("","delete",_DELETE,"button");
      $submit_delete->setExtra("onclick='doDelete();'");
      $hidden_mvals = new XocpFormHidden($this->getName(),$this->mvals_bl_vars);
      if ($count > 0) {
         $ret .= "<br />&nbsp;" . $submit_delete->render() . "<br /><br />";
      }
      $ret .= "</div>".$select_bl_vars->render() . "&nbsp;" . $submit_add->render() . $hidden_mvals->render();
      return $ret;
   }
}

function template_funccmp($a,$b) {
   if ($a[3] == $b[3]) {
      return strcmp($a[1],$b[1]);
   }
   return ($a[3] > $b[3]) ? -1 : 1;
}

class _healthindicator_Template extends XocpBlock {
   // Set block width
   var $width = "100%";
   // Catch variable for get method -- See below
   var $getparam;
   // Catch variable for post method -- See below
   var $postparam;

   // $find: text to search
   // $p: page number
   // $f: data page filename
   function navigate($find = "",$p = "0",$f = "") {
      $db =& Database::getInstance();
      // Is the data page filename set?
      if (trim($f) != "") {  // Retrieve from a previously made data page
         $dp = XocpDataPage::unserialize($f);
         // Check whether the data page has any data or not
         $dp->reset();
         $dp_data = $dp->retrieve();
         if ($dp_data[0][0] != _HIND_TEMPLATENOTFOUND) {
            $found = TRUE;
         } else {
            $found = FALSE;
         }
         // Set back to proper page number
         $dp->setPage($p);
      } else {  // Create a new data page
         if (trim($find) == "") { // Browse
            $sql = "SELECT tmpl_id,tmpl_nm,description
                    FROM ".XOCP_PREFIX."ind_template
                    ORDER BY tmpl_nm";
         } else { // Search
            $sql = "SELECT tmpl_id,tmpl_nm,description
                    FROM ".XOCP_PREFIX."ind_template
                    WHERE tmpl_nm LIKE '$find' OR description LIKE '$find'
                    ORDER BY tmpl_nm";
         }

         $result = $db->query($sql);
         $dp = new XocpDataPage();
         $dp->setPageSize(5);
         if ($db->getRowsNum($result) > 0) {
            $found = TRUE;
            while (list($tmpl_id,$tmpl_nm,$description) = $db->fetchRow($result)) {
               similar_text($tmpl_nm,str_replace("%","",$find),$score1);
               similar_text($description,str_replace("%","",$find),$score2);
               $dp->addData(array($tmpl_id,$tmpl_nm,$description,round(((2 * $score1) + $score2) / 3,2)));
            }
            // Sort data
            if (trim($find) != "") {
               usort($dp->data,"template_funccmp");
               array_reverse($dp->data);
            }
         } else {
            $found = FALSE;
            $dp->addData(array(_HIND_TEMPLATENOTFOUND));
         }
         $dp->serialize();
      }
      
      // Preparing the data page
      if ($found) {
         $dp_found = $dp->getCount();
         $no1 = $dp->getOffset() + 1;
      } else {
         $dp_found = "0";
         $no1 = "0";
      }
      $no2 = $no1 + $dp->getPageSize() - 1;
      if ($dp_found <= $no2) {
         $no2 = $dp_found;
      }
      
      // Creating header
      $dp_header = new XocpSimpleTable();
      // Is it searching? Set for the appropriate title
      if ($find != "") {  // Yes, it'is searching
         $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&fi=".urlencode($find));
         $title = "<font class='tdh1'>"._HIND_TEMPLATELIST." ["._HIND_SEARCHRESULT." ($no1 - $no2 "._OF." $dp_found)]</font>";
      } else {  // No, it's just retrieving from a previously made data page
         $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam);
         $title = "<font class='tdh1'>"._HIND_TEMPLATELIST." ($no1 - $no2 "._OF." $dp_found)</font>";
      }
      // How many page in data page?
      if ($found && count($dp->getPageArray()) > 1) {  // More than 1, show navigation links
         $hrow = $dp_header->addRow($title,$dp_prevnext);
      } else {
         $hrow = $dp_header->addRow($title);
      }
      $dp_header->setCellAlign($hrow,array("","right"));
      $dp_header->setWidth("100%");

      // Creating search form
      $txt_cond = new XocpFormText("","txt_find",20,50,"");
      $btn_find = new XocpFormButton("","btn_find",_SEARCH,"submit");
      $elm_tray_find = new XocpFormElementTray("");
      $elm_tray_find->addElement($txt_cond);
      $elm_tray_find->addElement($btn_find);
      
      $form_find = new XocpSimpleForm("","ffind",XOCP_SERVER_SUBDIR."/index.php");
      $form_find->addElement($this->postparam);
      $form_find->addElement($elm_tray_find);

      // Creating button tray form
      $hdn_type = new XocpFormHidden("type","tmplnav");
      $hdn_state = new XocpFormHidden("state","add");
      $btn_add = new XocpFormButton("","btn_add",_ADD,"submit");
      $elm_tray_add = new XocpFormElementTray("");
      $elm_tray_add->addElement($btn_add);
      
      $form_buttons = new XocpSimpleForm("","fbuttons",XOCP_SERVER_SUBDIR."/index.php");
      $form_buttons->addElement($this->postparam);
      $form_buttons->addElement($hdn_type);
      $form_buttons->addElement($hdn_state);
      $form_buttons->addElement($elm_tray_add);

      // Creating footer
      $dp_footer = new XocpSimpleTable();
      $frow = $dp_footer->addRow($form_buttons->render(),$form_find->render());
      $dp_footer->setCellAlign($frow,array("left","right"));
      $dp_footer->setWidth("100%");
                                    
      // Creating data page
      $dp_table = new XocpTable(1);
      $dp_table->setWidth("100%");
      $hrow = $dp_table->addHeader($dp_header->render());
      $frow = $dp_table->addFooter($dp_footer->render());
                                           
      // Populating data page
      $dp_data = $dp->retrieve();
      foreach ($dp_data as $row) {
         list($tmpl_id,$tmpl_nm,$description,$score) = $row;
         if ($found) {
            if ($find != "") {
               $drow = $dp_table->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&show=y&x=$tmpl_id'>$tmpl_nm</a> ($score% "._MATCH.")<br/>".nl2br($description));
            } else {
               $drow = $dp_table->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&show=y&x=$tmpl_id'>$tmpl_nm</a><br/>".nl2br($description));
            }
         } else {
            $drow = $dp_table->addRow($tmpl_id);
         }
      }
                                                                     
      return $dp_table->render();
   }

   function formShowDetail($datarec,$comment = "") {
      // Show template detail
      $hidden_type = new XocpFormHidden("type","show");
      $hidden_state = new XocpFormHidden("state","edit");

      $hidden_tmpl_id = new XocpFormHidden("old_tmpl_id",$datarec["tmpl_id"]);
      $hidden_tmpl_nm = new XocpFormHidden("old_tmpl_nm",$datarec["tmpl_nm"]);
      $hidden_tmpl_vars = new XocpFormHidden("old_tmpl_vars",$datarec["tmpl_vars"]);
      $hidden_mvals_bl_vars = new XocpFormHidden("old_mvals_bl_vars",$datarec["mvals_bl_vars"]);
      $hidden_tmpl_unit = new XocpFormHidden("old_tmpl_unit",$datarec["tmpl_unit"]);
      $hidden_formula = new XocpFormHidden("old_formula",$datarec["formula"]);
      $hidden_description = new XocpFormHidden("old_description",$datarec["description"]);
      $hidden_formula_tv = new XocpFormHidden("old_formula_tv",$datarec["formula_tv"]);

      $label_tmpl_nm = new XocpFormLabel(_HIND_TEMPLATENAME,$datarec["tmpl_nm"]);
      $label_tmpl_vars = new XocpFormLabel(_HIND_TEMPLATEVARS,str_replace("|",", ",$datarec["tmpl_vars"]));
      if ($datarec["mvals_bl_vars"] != "") {
         $db =& Database::getInstance();
         $bl_vars = explode("|",$datarec["mvals_bl_vars"]);
         for ($i = 0; $i < count($bl_vars); $i++) {
            $bl_vars[$i] = "'".$bl_vars[$i]."'";
         }
         $bl_vars = implode(",",$bl_vars);
         $sql = "SELECT bl_var,bl_nm FROM ".XOCP_PREFIX."ind_baseline WHERE bl_var IN ($bl_vars)";
         $result = $db->query($sql);
         $count = 0;
         $bl_vars = "";
         while (list($bl_var,$bl_nm) = $db->fetchRow($result)) {
            if ($count > 0) {
               $bl_vars .= "<br />";
            }
            $bl_vars .= "$bl_nm ($bl_var)";
            $count++;
         }
      }
      $label_bl_nm = new XocpFormLabel(_HIND_TEMPLATEBASELINEVARS,$bl_vars);
      $label_tmpl_unit = new XocpFormLabel(_HIND_TEMPLATEUNIT,$datarec["tmpl_unit"]);
      $label_formula = new XocpFormLabel(_HIND_TEMPLATEFORMULA,nl2br($datarec["formula"]));
      $label_description = new XocpFormLabel(_HIND_TEMPLATEDESC,nl2br($datarec["description"]));
      $label_formula_tv = new XocpFormLabel(_HIND_TEMPLATETARGET,nl2br($datarec["formula_tv"]));

      $submit_edit = new XocpFormButton("","edit",_EDIT,"submit");
      $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
      $submit_delete = new XocpFormButton("","delete",_DELETE,"submit");
      $elementtray_button = new XocpFormElementTray("");
      $elementtray_button->addElement($submit_edit);
      $elementtray_button->addElement($submit_cancel);
      $elementtray_button->addElement($submit_delete);

      // Constructing a form - Show template detail
      $form = new XocpThemeForm(_HIND_TEMPLATESHOWDETAILTITLE,"fshowtemplate","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_type);
      $form->addElement($hidden_state);
      
      $form->addElement($hidden_tmpl_id);
      $form->addElement($hidden_tmpl_nm);
      $form->addElement($hidden_tmpl_vars);
      $form->addElement($hidden_mvals_bl_vars);
      $form->addElement($hidden_tmpl_unit);
      $form->addElement($hidden_formula);
      $form->addElement($hidden_description);
      $form->addElement($hidden_formula_tv);
      
      $form->addElement($label_tmpl_nm);
      $form->addElement($label_tmpl_vars);
      $form->addElement($label_bl_nm);
      $form->addElement($label_tmpl_unit);
      $form->addElement($label_formula);
      $form->addElement($label_formula_tv);
      $form->addElement($label_description);

      $form->addElement($elementtray_button);
      
      if ($comment != "") {
         $form->setComment($comment);
      }
   
      $this->html->setBodyOnload(" onload='document.fshowtemplate.cancel.focus();'");

      return $form->render();
   }

   function formAddEdit($state = "add",$datarec = NULL,$showcancel = TRUE,$comment = "") {
      // Form elements - Add/edit a template
      $hidden_type = new XocpFormHidden("type","addedit");
      $hidden_state = new XocpFormHidden("state",$state);
      if ($state == "edit") {
         $hidden_old_tmpl_id = new XocpFormHidden("old_tmpl_id",$datarec["old_tmpl_id"]);
         $hidden_old_tmpl_nm = new XocpFormHidden("old_tmpl_nm",$datarec["old_tmpl_nm"]);
         $hidden_old_tmpl_vars = new XocpFormHidden("old_tmpl_vars",$datarec["old_tmpl_vars"]);
         //$hidden_old_bl_nm = new XocpFormHidden("old_bl_nm",$datarec["old_bl_nm"]);
         $hidden_old_mvals_bl_vars = new XocpFormHidden("old_mvals_bl_vars",$datarec["old_mvals_bl_vars"]);
         $hidden_old_tmpl_unit = new XocpFormHidden("old_tmpl_unit",$datarec["old_tmpl_unit"]);
         $hidden_old_formula = new XocpFormHidden("old_formula",$datarec["old_formula"]);
         $hidden_old_description = new XocpFormHidden("old_description",$datarec["old_description"]);
         $hidden_old_formula_tv = new XocpFormHidden("old_formula_tv",$datarec["old_formula_tv"]);
      }

      $text_tmpl_nm = new XocpFormText(_HIND_TEMPLATENAME,"tmpl_nm",30,512,$datarec["tmpl_nm"]);
      $text_tmpl_vars = new XocpFormText(_HIND_TEMPLATEVARS,"tmpl_vars",49,512,$datarec["tmpl_vars"]);
      //$hidden_bl_nm = new XocpFormHidden("bl_nm",$datarec["bl_nm"]);
      $multivalue_bl_vars = new XocpFormMultiValue(_HIND_TEMPLATEBASELINEVARS);
      if ($datarec["mvals_bl_vars"] != "") {
         $db =& Database::getInstance();
         $bl_vars = explode("|",$datarec["mvals_bl_vars"]);
         for ($i = 0; $i < count($bl_vars); $i++) {
            $bl_vars[$i] = "'".$bl_vars[$i]."'";
         }
         $bl_vars = implode(",",$bl_vars);
         $sql = "SELECT bl_var,bl_nm FROM ".XOCP_PREFIX."ind_baseline WHERE bl_var IN ($bl_vars)";
         $result = $db->query($sql);
         while (list($bl_var,$bl_nm) = $db->fetchRow($result)) {
            $multivalue_bl_vars->addElement($bl_var,"$bl_nm ($bl_var)");
            $name[] = "\"mval_$bl_var\"";
            $value[] = "\"$bl_var\"";
            $label[] = "\"$bl_nm\"";
         }
         $script = "<script language='JavaScript'>
                    var mvals_name = new Array(".implode(",",$name).");
                    var mvals_value = new Array(".implode(",",$value).");
                    var mvals_label = new Array(".implode(",",$label).");
                    </script>";
      } else {
         $script = "<script language='JavaScript'>
                    var mvals_name = new Array();
                    var mvals_value = new Array();
                    var mvals_label = new Array();
                    </script>";
      }
      $text_tmpl_unit = new XocpFormText(_HIND_TEMPLATEUNIT,"tmpl_unit",10,512,$datarec["tmpl_unit"]);
      $textarea_formula = new XocpFormTextArea(_HIND_TEMPLATEFORMULA,"formula",$datarec["formula"]);
      $textarea_description = new XocpFormTextArea(_HIND_TEMPLATEDESC,"description",$datarec["description"]);
      $textarea_formula_tv = new XocpFormTextArea(_HIND_TEMPLATETARGET,"formula_tv",$datarec["formula_tv"]);

      $submit_save = new XocpFormButton("","save",_SAVE,"submit");
      //$submit_reset = new XocpFormButton("","reset",_RESET,"reset");
      //$submit_reset->setExtra("onclick='doReset();'");
      $elementtray_button = new XocpFormElementTray("");
      $elementtray_button->addElement($submit_save);
      //$elementtray_button->addElement($submit_reset);
      // Show or hide Cancel button
      if ($showcancel) {
         $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
         $elementtray_button->addElement($submit_cancel);
      }

      // Constructing a form - Add/edit a template
      if ($state == "add") {
         $title = _HIND_TEMPLATEADDTITLE;
      } else {
         $title = _HIND_TEMPLATEEDITTITLE;
      }
      $form = new XocpThemeForm($title,"faddedittemplate","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_type);
      $form->addElement($hidden_state);
      if ($state == "edit") {
         $form->addElement($hidden_old_tmpl_id);
         $form->addElement($hidden_old_tmpl_nm);
         $form->addElement($hidden_old_tmpl_vars);
         //$form->addElement($hidden_old_bl_nm);
         $form->addElement($hidden_old_mvals_bl_vars);
         $form->addElement($hidden_old_tmpl_unit);
         $form->addElement($hidden_old_formula);
         $form->addElement($hidden_old_description);
         $form->addElement($hidden_old_formula_tv);
      }
      $form->addElement($text_tmpl_nm);
      $form->addElement($text_tmpl_vars);
      //$form->addElement($hidden_bl_nm);
      //$form->addElement($select_bl_vars);
      //$form->addElement($elementtray_bl_vars);
      $form->addElement($multivalue_bl_vars);
      $form->addElement($text_tmpl_unit);
      $form->addElement($textarea_formula);
      $form->addElement($textarea_formula_tv);
      $form->addElement($textarea_description);
      $form->addElement($elementtray_button);
      if ($comment != "") {
         $form->setComment($comment);
      }
      //$form->setExtra("onsubmit='return setBaselineName();'");

      //$this->html->loadScript(XOCP_DOC_ROOT."/modules/healthindicator/template/template.js");
      $this->html->addScript($script);
      $this->html->loadScript(XOCP_DOC_ROOT."/modules/healthindicator/template/multivalue.js");
      $this->html->setBodyOnload(" onload='document.faddedittemplate.tmpl_nm.focus();'");

      return $form->render();
   }

   function formConfirm($state = "add",$datarec,$title = "") {
      // Form elements - Confirm Added/edited baseline
      $hidden_type = new XocpFormHidden("type","confirm");
      $hidden_state = new XocpFormHidden("state",$state);
      if ($state == "edit") {
         $hidden_old_tmpl_id = new XocpFormHidden("old_tmpl_id",$datarec["old_tmpl_id"]);
         $hidden_old_tmpl_nm = new XocpFormHidden("old_tmpl_nm",$datarec["old_tmpl_nm"]);
         $hidden_old_tmpl_vars = new XocpFormHidden("old_tmpl_vars",$datarec["old_tmpl_vars"]);
         //$hidden_old_bl_nm = new XocpFormHidden("old_bl_nm",$datarec["old_bl_nm"]);
         $hidden_old_mvals_bl_vars = new XocpFormHidden("old_mvals_bl_vars",$datarec["old_mvals_bl_vars"]);
         $hidden_old_tmpl_unit = new XocpFormHidden("old_tmpl_unit",$datarec["old_tmpl_unit"]);
         $hidden_old_formula = new XocpFormHidden("old_formula",$datarec["old_formula"]);
         $hidden_old_description = new XocpFormHidden("old_description",$datarec["old_description"]);
         $hidden_old_formula_tv = new XocpFormHidden("old_formula_tv",$datarec["old_formula_tv"]);
      }
      $hidden_tmpl_id = new XocpFormHidden("tmpl_id",$datarec["old_tmpl_id"]);
      $hidden_tmpl_nm = new XocpFormHidden("tmpl_nm",$datarec["tmpl_nm"]);
      $hidden_tmpl_vars = new XocpFormHidden("tmpl_vars",$datarec["tmpl_vars"]);
      //$hidden_bl_nm = new XocpFormHidden("bl_nm",$datarec["bl_nm"]);
      $data_vars = explode("|",$datarec["mvals_bl_vars"]);
      sort($data_vars,SORT_STRING);
      $datarec["mvals_bl_vars"] = implode("|",$data_vars);
      $hidden_mvals_bl_vars = new XocpFormHidden("mvals_bl_vars",$datarec["mvals_bl_vars"]);
      $hidden_tmpl_unit = new XocpFormHidden("tmpl_unit",$datarec["tmpl_unit"]);
      $hidden_formula = new XocpFormHidden("formula",$datarec["formula"]);
      $hidden_description = new XocpFormHidden("description",$datarec["description"]);
      $hidden_formula_tv = new XocpFormHidden("formula_tv",$datarec["formula_tv"]);

      $label_tmpl_nm = new XocpFormLabel(_HIND_TEMPLATENAME,$datarec["tmpl_nm"]);
      $label_tmpl_vars = new XocpFormLabel(_HIND_TEMPLATEVARS,str_replace("|",", ",$datarec["tmpl_vars"]));
      if ($datarec["mvals_bl_vars"] != "") {
         $db =& Database::getInstance();
         $bl_vars = explode("|",$datarec["mvals_bl_vars"]);
         for ($i = 0; $i < count($bl_vars); $i++) {
            $bl_vars[$i] = "'".$bl_vars[$i]."'";
         }
         $bl_vars = implode(",",$bl_vars);
         $sql = "SELECT bl_var,bl_nm FROM ".XOCP_PREFIX."ind_baseline WHERE bl_var IN ($bl_vars)";
         $result = $db->query($sql);
         $count = 0;
         $bl_vars = "";
         while (list($bl_var,$bl_nm) = $db->fetchRow($result)) {
            if ($count > 0) {
               $bl_vars .= "<br />";
            }
            $bl_vars .= "$bl_nm ($bl_var)";
            $count++;
         }
      }
      $label_bl_nm = new XocpFormLabel(_HIND_TEMPLATEBASELINEVARS,$bl_vars);
      $label_tmpl_unit = new XocpFormLabel(_HIND_TEMPLATEUNIT,$datarec["tmpl_unit"]);
      $label_formula = new XocpFormLabel(_HIND_TEMPLATEFORMULA,nl2br($datarec["formula"]));
      $label_description = new XocpFormLabel(_HIND_TEMPLATEDESC,nl2br($datarec["description"]));
      $label_formula_tv = new XocpFormLabel(_HIND_TEMPLATETARGET,nl2br($datarec["formula_tv"]));
      $submit_ok = new XocpFormButton("","ok",_OK,"submit");
      if ($state != "delete") {
         $submit_edit = new XocpFormButton("","edit",_EDIT,"submit");
      }
      $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
      $elementtray_button = new XocpFormElementTray("");
      $elementtray_button->addElement($submit_ok);
      if ($state != "delete") {
         $elementtray_button->addElement($submit_edit);
      }
      $elementtray_button->addElement($submit_cancel);

      // Constructing a form - Confirm Added/edited baseline
      $form = new XocpThemeForm($title,"fconfirmtemplate","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_type);
      $form->addElement($hidden_state);
      if ($state == "edit") {
         $form->addElement($hidden_old_tmpl_id);
         $form->addElement($hidden_old_tmpl_nm);
         $form->addElement($hidden_old_tmpl_vars);
         //$form->addElement($hidden_old_bl_nm);
         $form->addElement($hidden_old_mvals_bl_vars);
         $form->addElement($hidden_old_tmpl_unit);
         $form->addElement($hidden_old_formula);
         $form->addElement($hidden_old_description);
         $form->addElement($hidden_old_formula_tv);
      }

      $form->addElement($hidden_tmpl_id);
      $form->addElement($hidden_tmpl_nm);
      $form->addElement($hidden_tmpl_vars);
      //$form->addElement($hidden_bl_nm);
      $form->addElement($hidden_mvals_bl_vars);
      $form->addElement($hidden_tmpl_unit);
      $form->addElement($hidden_formula);
      $form->addElement($hidden_description);
      $form->addElement($hidden_formula_tv);
      
      $form->addElement($label_tmpl_nm);
      $form->addElement($label_tmpl_vars);
      $form->addElement($label_bl_nm);
      $form->addElement($label_tmpl_unit);
      $form->addElement($label_formula);
      $form->addElement($label_formula_tv);
      $form->addElement($label_description);

      $form->addElement($elementtray_button);
   
      if ($state != "add") {
         $this->html->setBodyOnload(" onload='document.fconfirmtemplate.cancel.focus();'");
      } else {
         $this->html->setBodyOnload(" onload='document.fconfirmtemplate.ok.focus();'");
      }

      return $form->render();
   }

   function main() {
      $db =& Database::getInstance();
      $this->getparam = _HIND_CATCH_VAR."="._HIND_TEMPLATE_BLOCK;
      $this->postparam = new XocpFormHidden(_HIND_CATCH_VAR,_HIND_TEMPLATE_BLOCK);
      switch ($this->catch) {
         case _HIND_TEMPLATE_BLOCK:
            global $HTTP_POST_VARS,$HTTP_GET_VARS;
            if (trim($HTTP_POST_VARS["txt_find"]) != "") {
               // Search templates
               $nm = trim($HTTP_POST_VARS["txt_find"]);
               if (!eregi("\*",$nm)) {
                  $nm = "%$nm%";
               } else {
                  $nm = str_replace("*","%",$nm);
               }
               $ret = $this->navigate($nm);
            } elseif (isset($HTTP_POST_VARS["type"])) {
               // Form handler a.k.a page script flow
               $state = $HTTP_POST_VARS["state"];  // Preserve state
               //$showcancel = ($state == "edit") ? TRUE : FALSE;  // Show cancel button on add/edit form
               $showcancel = TRUE;  // Always show cancel button on add/edit form
               switch ($HTTP_POST_VARS["type"]) {
                  case "show":  // Show detail form
                     if (!isset($HTTP_POST_VARS["cancel"])) {
                        // Initialize values
                        $HTTP_POST_VARS["tmpl_id"] = $HTTP_POST_VARS["old_tmpl_id"];
                        $HTTP_POST_VARS["tmpl_nm"] = $HTTP_POST_VARS["old_tmpl_nm"];
                        $HTTP_POST_VARS["tmpl_vars"] = $HTTP_POST_VARS["old_tmpl_vars"];
                        $HTTP_POST_VARS["bl_nm"] = $HTTP_POST_VARS["old_bl_nm"];
                        $HTTP_POST_VARS["mvals_bl_vars"] = $HTTP_POST_VARS["old_mvals_bl_vars"];
                        $HTTP_POST_VARS["tmpl_unit"] = $HTTP_POST_VARS["old_tmpl_unit"];
                        $HTTP_POST_VARS["formula"] = $HTTP_POST_VARS["old_formula"];
                        $HTTP_POST_VARS["description"] = $HTTP_POST_VARS["old_description"];
                        $HTTP_POST_VARS["formula_tv"] = $HTTP_POST_VARS["old_formula_tv"];
                     }
                     if (isset($HTTP_POST_VARS["edit"])) {  // Edit
                        $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel);
                     } elseif (isset($HTTP_POST_VARS["cancel"])) {  // Cancel
                        $ret = $this->navigate();
                     } else {  // Delete
                        $ret = $this->formConfirm("delete",$HTTP_POST_VARS,_HIND_TEMPLATEDELCONFIRMTITLE);
                     }
                     break;
                  case "addedit":  // Add/edit form
                     if (isset($HTTP_POST_VARS["save"])) {  // Save
                        if (trim($HTTP_POST_VARS["tmpl_nm"]) != "") {  // Check for required field
                           if ($state == "add") {
                              $title = _HIND_TEMPLATEADDCONFIRMTITLE;
                           } else {
                              $title = _HIND_TEMPLATEEDITCONFIRMTITLE;
                           }
                           $ret = $this->formConfirm($state,$HTTP_POST_VARS,$title);
                        } else {
                           $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel,_HIND_TEMPLATESAVEERROR);
                        }
                     } elseif (isset($HTTP_POST_VARS["cancel"])) {  // Cancel
                        if ($state == "add") {
                        	$ret = $this->navigate();
                        } else {
                           // Set back to original values
                           $HTTP_POST_VARS["tmpl_id"] = $HTTP_POST_VARS["old_tmpl_id"];
                           $HTTP_POST_VARS["tmpl_nm"] = $HTTP_POST_VARS["old_tmpl_nm"];
                           $HTTP_POST_VARS["tmpl_vars"] = $HTTP_POST_VARS["old_tmpl_vars"];
                           $HTTP_POST_VARS["bl_nm"] = $HTTP_POST_VARS["old_bl_nm"];
                           $HTTP_POST_VARS["mvals_bl_vars"] = $HTTP_POST_VARS["old_mvals_bl_vars"];
                           $HTTP_POST_VARS["tmpl_unit"] = $HTTP_POST_VARS["old_tmpl_unit"];
                           $HTTP_POST_VARS["formula"] = $HTTP_POST_VARS["old_formula"];
                           $HTTP_POST_VARS["description"] = $HTTP_POST_VARS["old_description"];
                           $HTTP_POST_VARS["formula_tv"] = $HTTP_POST_VARS["old_formula_tv"];
                           $ret = $this->formShowDetail($HTTP_POST_VARS,_HIND_TEMPLATESAVECANCEL);
                        }
                     } elseif (isset($HTTP_POST_VARS["add"])) {
                        $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel);
                     } elseif (isset($HTTP_POST_VARS["delete"])) {
                        $HTTP_POST_VARS["bl_nm"] = "";
                        $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel);
                     }
                     break;
                  case "confirm":  // Confirmation form
                     if (isset($HTTP_POST_VARS["ok"])) {  // Ok, save/delete template
                        if ($state == "delete") {  // Do delete template
                           $sql = "DELETE FROM ".XOCP_PREFIX."ind_template
                                   WHERE tmpl_id = ".$HTTP_POST_VARS["tmpl_id"];
                           $result = $db->query($sql);
                           $comment = $db->error();
                           if ($comment == "") {
                              // Warning: this isn't the proper function
                              //if ($db->getRowsNum($result) > 0) {
                              if (mysql_affected_rows() > 0) {
                                 $comment = _HIND_TEMPLATEDELETESUCCESS;
                              } else {
                                 $comment = _HIND_TEMPLATEDELETEFAIL;
                              }
                           } else {
                              $comment = _HIND_TEMPLATEDELETEERROR."<br/>$comment";
                           }
                           $ret = $this->navigate();
                        } else {
                           if ($state == "add") {  // New template, do add
                              $sql = "INSERT INTO ".XOCP_PREFIX."ind_template (tmpl_nm,tmpl_vars,bl_vars,tmpl_unit,formula,description,formula_tv)
                                      VALUES ('".trim($HTTP_POST_VARS["tmpl_nm"])."','".trim($HTTP_POST_VARS["tmpl_vars"])."',
                                              '".trim(substr($HTTP_POST_VARS["mvals_bl_vars"],1))."','".trim($HTTP_POST_VARS["tmpl_unit"])."',
                                              '".trim($HTTP_POST_VARS["formula"])."','".trim($HTTP_POST_VARS["description"])."',
                                              '".trim($HTTP_POST_VARS["formula_tv"])."')";
                           } else {  // Old template, do update
                              $sql = "UPDATE ".XOCP_PREFIX."ind_template
                                      SET tmpl_nm = '".trim($HTTP_POST_VARS["tmpl_nm"])."',
                                          tmpl_vars = '".trim($HTTP_POST_VARS["tmpl_vars"])."',
                                          bl_vars = '".trim(substr($HTTP_POST_VARS["mvals_bl_vars"],1))."',
                                          tmpl_unit = '".trim($HTTP_POST_VARS["tmpl_unit"])."',
                                          formula = '".trim($HTTP_POST_VARS["formula"])."',
                                          description = '".trim($HTTP_POST_VARS["description"])."',
                                          formula_tv = '".trim($HTTP_POST_VARS["formula_tv"])."'
                                      WHERE tmpl_id = ".$HTTP_POST_VARS["old_tmpl_id"];
                           }
                           $result = $db->query($sql);
                           $comment = $db->error();
                           if ($comment != "") {
                              if ($state != "add") {  // Set back to original values
                                 $HTTP_POST_VARS["tmpl_id"] = $HTTP_POST_VARS["old_tmpl_id"];
                                 $HTTP_POST_VARS["tmpl_nm"] = $HTTP_POST_VARS["old_tmpl_nm"];
                                 $HTTP_POST_VARS["tmpl_vars"] = $HTTP_POST_VARS["old_tmpl_vars"];
                                 $HTTP_POST_VARS["bl_nm"] = $HTTP_POST_VARS["old_bl_nm"];
                                 $HTTP_POST_VARS["mvals_bl_vars"] = $HTTP_POST_VARS["old_mvals_bl_vars"];
                                 $HTTP_POST_VARS["tmpl_unit"] = $HTTP_POST_VARS["old_tmpl_unit"];
                                 $HTTP_POST_VARS["formula"] = $HTTP_POST_VARS["old_formula"];
                                 $HTTP_POST_VARS["description"] = $HTTP_POST_VARS["old_description"];
                                 $HTTP_POST_VARS["formula_tv"] = $HTTP_POST_VARS["old_formula_tv"];
                              }
                              $comment = _HIND_TEMPLATESAVEFAIL."<br/>".$comment;
                           } else {
                              if ($state == "add") {
                                 unset($HTTP_POST_VARS);
                              }
                              $comment = _HIND_TEMPLATESAVESUCCESS;
                           }
                           if ($state == "add") {
                              $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel,$comment);
                           } else {
                              $ret = $this->formShowDetail($HTTP_POST_VARS,$comment);
                           }
                        }
                     } elseif (isset($HTTP_POST_VARS["edit"])) {
                         $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel);
                     } elseif (isset($HTTP_POST_VARS["cancel"])) {  // Cancel
                        if ($state == "add") {
                           unset($HTTP_POST_VARS);
                           $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel,_HIND_TEMPLATESAVECANCEL);
                        } else{
                           if ($state == "edit") {
                              // Set back to original data
                              $comment = _HIND_TEMPLATESAVECANCEL;
                              $HTTP_POST_VARS["tmpl_id"] = $HTTP_POST_VARS["old_tmpl_id"];
                              $HTTP_POST_VARS["tmpl_nm"] = $HTTP_POST_VARS["old_tmpl_nm"];
                              $HTTP_POST_VARS["tmpl_vars"] = $HTTP_POST_VARS["old_tmpl_vars"];
                              $HTTP_POST_VARS["bl_nm"] = $HTTP_POST_VARS["old_bl_nm"];
                              $HTTP_POST_VARS["mvals_bl_vars"] = $HTTP_POST_VARS["old_mvals_bl_vars"];
                              $HTTP_POST_VARS["tmpl_unit"] = $HTTP_POST_VARS["old_tmpl_unit"];
                              $HTTP_POST_VARS["formula"] = $HTTP_POST_VARS["old_formula"];
                              $HTTP_POST_VARS["description"] = $HTTP_POST_VARS["old_description"];
                              $HTTP_POST_VARS["formula_tv"] = $HTTP_POST_VARS["old_formula_tv"];
                           } else {
                              $comment = _HIND_TEMPLATEDELCANCEL;
                           }
                           $ret = $this->formShowDetail($HTTP_POST_VARS,$comment);
                        }
                     }
                     break;
                  case "tmplnav":
                     if (isset($HTTP_POST_VARS["btn_add"])) {
                        $ret = $this->formAddEdit($state,NULL,$showcancel);
                     }
                     break;
               }
            } elseif ($HTTP_GET_VARS["show"] == "y" && $HTTP_GET_VARS["x"] != "") {
               // Show template detail
               $sql = "SELECT t.tmpl_id,t.tmpl_nm,t.tmpl_vars,t.bl_vars,t.tmpl_unit,t.formula,t.description,t.formula_tv,b.bl_nm
                       FROM ".XOCP_PREFIX."ind_template t LEFT JOIN ".XOCP_PREFIX."ind_baseline b ON (b.bl_var = t.bl_vars)
                       WHERE tmpl_id = ".$HTTP_GET_VARS["x"];
               $result = $db->query($sql);
               if ($db->getRowsNum($result) > 0) {
                  $datarec = $db->fetchArray($result);
                  $datarec["mvals_bl_vars"] = $datarec["bl_vars"];
                  $ret = $this->formShowDetail($datarec);
               } else {
                  $ret = $this->navigate();
               }
            } elseif ($HTTP_GET_VARS["p"] != "") {
               // Navigate data page
               $ret = $this->navigate($HTTP_GET_VARS["fi"],$HTTP_GET_VARS["p"],$HTTP_GET_VARS["f"]);
            }
            break;
         default:
            $ret = $this->navigate();
            break;
      }
      return $ret;
   }
}
} // HEALTHINDICATOR_TEMPLATE_DEFINED
?>