<script language='JavaScript'>
function doAdd() {
   obj = document.faddedittemplate.bl_vars;
   if (obj.options[obj.selectedIndex].text == '' ||
       document.faddedittemplate.mvals_bl_vars.value.indexOf(obj.options[obj.selectedIndex].value) > -1) return true;
   name = "mval_" + obj.options[obj.selectedIndex].value;
   i = mvals_name.length;
   mvals_name[i] = name;
   mvals_value[i] = obj.options[obj.selectedIndex].value;
   mvals_label[i] = obj.options[obj.selectedIndex].text;
   document.faddedittemplate.mvals_bl_vars.value += "|" + mvals_value[i];
   mvals.innerHTML = "";
   for (i = 0; i < mvals_name.length; i++) {
      mvals.innerHTML += "<input class='ckb' type='checkbox' name='" +
                         mvals_name[i] + "' id='" + mvals_name[i] + "' value='" +
                         mvals_value[i] + "' /><label for='" + mvals_name[i] + "'>" +
                         mvals_label[i] + " (" + mvals_value[i] + ")" + "</label><br />";
   }
   mvals.innerHTML = mvals.innerHTML + "&nbsp;<input type='button' name='delete' id='delete' " +
                     "value='Delete' onclick='doDelete();' class='bt' /><br /><br />";
   return true;
}

function doDelete() {
   i = 0;
   l = mvals_name.length;
   while (i < l) {
      if (eval("document.faddedittemplate." + mvals_name[i] + ".checked")) {
         j = i;
         for (d = i + 1; d < l; d++) {
            mvals_name[j] = mvals_name[d];
            mvals_value[j] = mvals_value[d];
            mvals_label[j] = mvals_label[d];
            j++;
         }
         l--;
      } else {
         i++;
      }
   }
   mvals_name.length = l;
   mvals_value.length = l;
   mvals_label.length = l;
   document.faddedittemplate.mvals_bl_vars.value = "";
   for (i = 0; i < mvals_name.length; i++) {
      document.faddedittemplate.mvals_bl_vars.value += "|" + mvals_value[i];
   }
   mvals.innerHTML = "";
   for (i = 0; i < mvals_name.length; i++) {
      mvals.innerHTML += "<input class='ckb' type='checkbox' name='" +
                         mvals_name[i] + "' id='" + mvals_name[i] + "' value='" +
                         mvals_value[i] + "' /><label for='" + mvals_name[i] + "'>" +
                         mvals_label[i] + " (" + mvals_value[i] + ")" + "</label><br />";
   }
   if (mvals_name.length > 0)
      mvals.innerHTML = mvals.innerHTML + "&nbsp;<input type='button' name='delete' " +
                        "id='delete' " +"value='Delete' onclick='doDelete();' " +
                        "class='bt' /><br /><br />";
   return true;
}
</script>
