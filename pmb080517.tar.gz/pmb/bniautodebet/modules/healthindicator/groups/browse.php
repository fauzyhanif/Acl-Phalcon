<?php
// Parent of the parents?
if (!(($HTTP_GET_VARS["x"] == "0" || $HTTP_GET_VARS["x"] == "") &&
      ($HTTP_GET_VARS["y"] == "0" || $HTTP_GET_VARS["y"] == ""))) {  // No, show the edit form
   // Form elements - Edit parent group
   $label_group_nm = new XocpFormLabel(_HIND_GROUPNAME,$datarec["group_nm"]);
   $hidden_group_nm = new XocpFormHidden("group_nm",$datarec["group_nm"]);
   $submit_edit = new XocpFormButton("","edit",_EDIT,"submit");
   $submit_delete = new XocpFormButton("","delete",_DELETE,"submit");
   $elementtray_button = new XocpFormElementTray("");
   $elementtray_button->addElement($submit_edit);
   $elementtray_button->addElement($submit_delete);
   
   $url = "index.php?edit=y&x=".$HTTP_GET_VARS["x"].
          "&y=".$HTTP_GET_VARS["y"]."&m=".$HTTP_GET_VARS["m"]."&mn=".urlencode($HTTP_GET_VARS["mn"]);

   // Constructing a form - Edit parent group
   $form = new XocpThemeForm(_HIND_EDITGROUPTITLE,"feditgroup","$url","post");
   $form->addElement($this->postparam);
   $form->addElement($hidden_group_nm);
   $form->addElement($label_group_nm);
   $form->addElement($elementtray_button);
   if ($comment != "" && $HTTP_POST_VARS["parent_group_nm"] == "" && $HTTP_POST_VARS["tmpl_id"] == "") {
      $form->setComment($comment);
   }
   
   // Form elements - Add template to group
   $hidden_parent_group_nm0 = new XocpFormHidden("parent_group_nm",$datarec["group_nm"]);
   $select_tmpl_nm = new XocpFormSelect("Template Indicator","tmpl_id");
   $db =& Database::getInstance();
   $sql = "SELECT tmpl_id,tmpl_nm FROM ".XOCP_PREFIX."ind_template ORDER BY tmpl_nm";
   $result = $db->query($sql);
   while (list($tmpl_id,$tmpl_nm) = $db->fetchRow($result)) {
      $select_tmpl_nm->addOption($tmpl_id,$tmpl_nm);
   }
   $submit_add = new XocpFormButton("","add",_ADD,"submit");

   // Constructing a form - Add template to group
   $form1 = new XocpThemeForm("Add Template to Group ".$datarec["group_nm"],"faddtmpl",$url,"post");
   $form1->addElement($this->postparam);
   $form1->addElement($hidden_parent_group_nm0);
   $form1->addElement($select_tmpl_nm);
   $form1->addElement($submit_add);
   if ($comment != "" && $HTTP_POST_VARS["tmpl_id"] != "") {
      $form1->setComment($comment);
   }

   $ret = $form->render()."<br />".$form1->render()."<br />".$ret;
   unset($form);
}

// Form elements - Add group/subgroup
if (($HTTP_GET_VARS["y"] == "" || $HTTP_GET_VARS["y"] == "0") &&
    ($HTTP_GET_VARS["x"] == "" || $HTTP_GET_VARS["x"] == "0") &&
    ($HTTP_GET_VARS["m"] == "" || $HTTP_GET_VARS["m"] == "0")) {
   $HTTP_GET_VARS["y"] = "0";
   $HTTP_GET_VARS["x"] = "0";
   $HTTP_GET_VARS["m"] = "0";
   $title = _HIND_NEWGROUPTITLE;
   $caption = _HIND_GROUPNAME;
} else {
   $title = _HIND_NEWSUBGROUPTITLE;
   $caption = _HIND_SUBGROUPNAME;
}
$hidden_parent_group_nm = new XocpFormHidden("parent_group_nm",$datarec["group_nm"]);
$text_group_nm = new XocpFormText($caption,"group_nm",30,200,$HTTP_POST_VARS["group_nm"]);
$submit_save = new XocpFormButton("","save",_SUBMIT,"submit");

// Constructing a form - Add group/subgroup
$form = new XocpThemeForm($title,"fnewgroup","index.php?edit=y&x=".$HTTP_GET_VARS["x"]."&y=".$HTTP_GET_VARS["y"].
                          "&m=".$HTTP_GET_VARS["m"]."&mn=".urlencode($HTTP_GET_VARS["mn"]),"post");
$form->addElement($this->postparam);
$form->addElement($hidden_parent_group_nm);
$form->addElement($text_group_nm);
$form->addElement($submit_save);
if ($comment != "" && (isset($HTTP_POST_VARS["parent_group_nm"]) ||
                       $HTTP_POST_VARS["delete"] != "") & $HTTP_POST_VARS["tmpl_id"] == "") {
   $form->setComment($comment);
}
   
$ret .= $form->render();
?>