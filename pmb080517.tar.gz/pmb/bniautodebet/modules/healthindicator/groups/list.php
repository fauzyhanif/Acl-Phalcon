<?php
//--------------------------------------------------------------------//
// Filename : modules/menu/menu.php                                   //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-20                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('HEALTHINDICATOR GROUPLIST_DEFINED') ) {
   define('HEALTHINDICATOR_GROUPLIST_DEFINED', TRUE);

class _healthindicator_Group extends XocpBlock {
   var $parent;
   var $groupname;
   var $is_parent;
   var $space;
   var $printed;
   var $ret = "";
   
   function printGroup($group_id) {
      $parent = $this->parent;
      
      reset($parent);
   
      if($this->is_parent[$group_id]) { // kalo parent group, recurse ke sub dulu
         $this->ret .= "<nobr>".$this->space[$group_id]."+ ".$this->groupname[$group_id]."</nobr><br>\n";
      
         while(list($group_idx,$parent_idx) = each($parent)) {
            if($parent_idx == $group_id) {
               if(!$this->printed[$group_id]) 
               $this->printGroup($group_idx);
            }
         }
      } else {
         $this->ret .= "<nobr>".$this->space[$group_id]."- ".$this->groupname[$group_id]."</nobr><br>\n";
      }
   
   }
   
   function main() {
      switch($this->catch) {
         default :
            $db =& Database::getInstance();
            $sql = "SELECT group_id,parent_id,group_nm FROM ".XOCP_PREFIX."ind_groups"
                 . " ORDER BY parent_id, group_nm";
            $result = $db->query($sql);
            if($db->getRowsNum($result)>0) {
               while($row=$db->fetchRow($result)) {
                  list($group_id,$parent_id,$group_nm) = $row;
                  $this->parent[$group_id] = $parent_id;
                  $this->groupname[$group_id] = $group_nm;
                  $this->is_parent[$parent_id] = TRUE;
                  if(intval($parent_id) > 0) {
                     $this->space[$group_id] = "&nbsp;&nbsp;&nbsp;" . $this->space[$parent_id];
                  } else {
                     $this->space[$group_id] = "";
                  }
               }

               ksort($this->parent);
               while(list($key,$val) = each($this->parent)) {
                  if($val == 0) {
                     $this->printGroup($key);
                  }
               }
               
               $ret .= $this->ret;


            }
            break;
      }
      return $ret;
   }

}

} // MENU_DEFINED
?>