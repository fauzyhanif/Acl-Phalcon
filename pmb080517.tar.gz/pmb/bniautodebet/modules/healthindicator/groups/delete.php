<?php
// Do delete group
$hidden_group_nm = new XocpFormHidden("old_group_nm",$HTTP_POST_VARS["group_nm"]);
$label_group_nm = new XocpFormLabel(_HIND_GROUPNAME,$HTTP_POST_VARS["group_nm"]);
$submit_delete = new XocpFormButton("","delete",_YES,"submit");
$submit_cancel = new XocpFormButton("","cancel",_NO,"submit");
$elementtray_button = new XocpFormElementTray("");
$elementtray_button->addElement($submit_delete);
$elementtray_button->addElement($submit_cancel);

// Constructing a form - Add group/subgroup
$form = new XocpThemeForm(_HIND_DELETEGROUPTITLE,"fdeletegroup","index.php?delete=y&x=".$HTTP_GET_VARS["x"].
                          "&y=".$HTTP_GET_VARS["y"]."&m=".$HTTP_GET_VARS["m"]."&mn=".urlencode($HTTP_GET_VARS["mn"]),"post");
$form->addElement($this->postparam);
$form->addElement($hidden_group_nm);
$form->addElement($label_group_nm);
$form->addElement($elementtray_button);
   
$ret = $form->render();
?>