<?php
if ( !defined('HEALTHINDICATOR_GROUPS_DEFINED') ) {
   define('HEALTHINDICATOR_GROUPS_DEFINED', TRUE);
   
if ( !defined('HEALTHINDICATOR_MODULECONSTS_DEFINED') ) {
   include_once(XOCP_DOC_ROOT."/modules/healthindicator/modconsts.php");
}

class _healthindicator_Groups extends XocpBlock {
   // Set block width
   var $width = "100%";
   // Catch variable for get method -- See below
   var $getparam;
   // Catch variable for post method -- See below
   var $postparam;
   
   // $x: group id
   // $y: parent id
   // $mothers: list of parents
   // $mn: direct parent's name
   // $find: text to search
   // $p: page number
   // $f: data page filename
   function navigate($x = "0",$y = "0",$mothers = "0",$mn = "",$find = "",$p = "0",$f = "") {
      // Function for comparing score
      function funccmp($a,$b) {
         if ($a[2] == $b[2]) {
            return strcmp($a[1],$b[1]);
         }
         return ($a[2] > $b[2]) ? -1 : 1;
      }
      
      $db =& Database::getInstance();
      // Is the data page filename set?
      if (trim($f) != "") {  // Retrieve from a previously made data page
         $dp = XocpDataPage::unserialize($f);
         // Check whether the data page had any data or not
         $dp->reset();
         $dp_data = $dp->retrieve();
         if ($dp_data[0][0] != _HIND_GROUPNOTFOUND) {
            $found = TRUE;
         } else {
            $found = FALSE;
         }
         // Set back to proper page number
         $dp->setPage($p);
      } else {  // Create a new data page
         if (trim($find) == "") {
            $sql = "SELECT g.group_id,g.group_nm,te.tmpl_nm "
                 . "FROM ".XOCP_PREFIX."ind_groups g LEFT JOIN ".XOCP_PREFIX."ind_grouptmpl t ON (g.group_id = t.group_id) "
                 . "     LEFT JOIN ".XOCP_PREFIX."ind_template te ON (te.tmpl_id = t.tmpl_id) "
                 . "WHERE g.parent_id = $x "
                 . "ORDER BY g.group_nm,g.group_id,te.tmpl_nm";
         } else {
            $sql = "SELECT g.group_id,g.group_nm,te.tmpl_nm "
                 . "FROM ".XOCP_PREFIX."ind_groups g LEFT JOIN ".XOCP_PREFIX."ind_grouptmpl t ON (g.group_id = t.group_id) "
                 . "     LEFT JOIN ".XOCP_PREFIX."ind_template te ON (te.tmpl_id = t.tmpl_id) "
                 . "WHERE (g.group_nm LIKE '$find' OR te.tmpl_nm LIKE '$find') AND g.parent_id = $x "
                 . "ORDER BY g.group_nm,g.group_id,te.tmpl_nm";
         }
         $result = $db->query($sql);
         $dp = new XocpDataPage();
         $dp->setPageSize(10);
         if ($db->getRowsNum($result) > 0) {
            $found = TRUE;
            $grp = "";
            $str = "";
            if (eregi("%.*%",$find)) {
               $find = substr($find,1,strlen($find) - 2);
               $tmp = implode("|",explode("%",$find));
            }
            while (list($group_id,$group_nm,$tmpl_nm) = $db->fetchRow($result)) {
               if ($grp != $group_id && $grp != "") {
                 $drow = $dp->addData(array($str));
               }
               if ($grp != $group_id) {
                  $grp = $group_id;
                  if (trim($find) != "") {
                     if (eregi($tmp,$group_nm)) {
                        similar_text($group_nm,str_replace("%","",$find),$score);
                        $score = round($score,2);
                        $match = " ($score% "._MATCH.")";
                     } else {
                        $match = "";
                     }
                  } else {
                     $match = "";
                  }
                  $str = "<a href='".XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&edit=y&x=$group_id&y=$x&m=$mothers&mn=".urlencode($group_nm)."'>$group_nm</a>$match";
                  if ($tmpl_nm != "") {
                     if (trim($find) != "") {
                        if (eregi($tmp,$tmpl_nm)) {
                           similar_text($tmpl_nm,str_replace("%","",$find),$score);
                           $score = round($score,2);
                           $match = " ($score% "._MATCH.")";
                           $str .= "<br />&nbsp;&nbsp;$tmpl_nm$match<br />";
                        }
                     } else {
                        $str .= "<br />&nbsp;&nbsp;$tmpl_nm<br />";
                     }
                  }
               } else {
                  if (trim($find) != "") {
                     if (eregi($tmp,$tmpl_nm)) {
                        similar_text($tmpl_nm,str_replace("%","",$find),$score);
                        $score = round($score,2);
                        $match = " ($score% "._MATCH.")";
                        $str .= "<br />&nbsp;&nbsp;$tmpl_nm$match";
                     }
                  } else {
                     $str .= "&nbsp;&nbsp;$tmpl_nm<br />";
                  }
               }
            }
            $dp->addData(array($str));
            // Sort data
/*            if (trim($find) != "") {
               usort($dp->data,"funccmp");
               array_reverse($dp->data);
            }*/
         } else {
            $found = FALSE;
            $dp->addData(array(_HIND_GROUPNOTFOUND));
         }
         $dp->serialize();
      }
      
      // Show level
      $sql = "SELECT group_id,group_nm,parent_id FROM ".XOCP_PREFIX."ind_groups WHERE group_id IN ($mothers)";
      $result = $db->query($sql);
      $title = array("<a href='".XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."'>"._HIND_GROUPLIST."</a>");
      $m = array();
      while (list($group_id,$group_nm,$parent_id) = $db->fetchRow($result)) {
         $m[] = $parent_id;
         $mt = implode(",",$m);
         $title[] = "<a href='".XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&edit=y&x=$group_id&y=$parent_id&m=$mt&mn=".urlencode($group_nm)."'>$group_nm</a>";
      }
      $title = implode(" -> ",$title);

      // Preparing the data page
      if ($found) {
         $dp_found = $dp->getCount();
         $no1 = $dp->getOffset() + 1;
      } else {
         $dp_found = "0";
         $no1 = "0";
      }
      $no2 = $no1 + $dp->getPageSize() - 1;
      if ($dp_found <= $no2) {
         $no2 = $dp_found;
      }

      // Creating header
      $dp_header = new XocpSimpleTable();
      // Is it searching? Set for the appropriate title
      if ($find != "") {  // Yes, it'is searching
         $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&edit=y&x=$x&y=$y&m=$mothers&mn=".urlencode($mn)."&fi=".urlencode($find));
         $title = "<font class='tdh1'>".$title." ["._HIND_SEARCHRESULT." ($dp_found)]</font>";
      } else {  // No, it's just retrieving from a previously made data page
         $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&edit=y&x=$x&y=$y&m=$mothers&mn=".urlencode($mn));
         $title = "<font class='tdh1'>".$title." ($dp_found)</font>";
      }
      // How many page in data page?
      if ($found && count($dp->getPageArray()) > 1) {  // More than 1, show navigation links
         $hrow = $dp_header->addRow($title,$dp_prevnext);
      } else {
         $hrow = $dp_header->addRow($title);
      }
      $dp_header->setCellAlign($hrow,array("","right"));
      $dp_header->setWidth("100%");

      // Creating search from
      $txt_cond = new XocpFormText("","txt_find",20,50,"");
      $btn_find = new XocpFormButton("","btn_find",_SEARCH,"submit");
      $elm_tray_find = new XocpFormElementTray("");
      $elm_tray_find->addElement($txt_cond);
      $elm_tray_find->addElement($btn_find);
      
      $form = new XocpSimpleForm("","ffind",XOCP_SERVER_SUBDIR."/index.php?edit=y&x=$x&y=$y&m=$mothers&mn=".urlencode($mn));
      $form->addElement($this->postparam);
      $form->addElement($elm_tray_find);

      // Creating footer
      $dp_footer = new XocpSimpleTable();
      $frow = $dp_footer->addRow($form->render());
      $dp_footer->setCellAlign($frow,array("right"));
      $dp_footer->setWidth("100%");
                                    
      // Creating data page
      $dp_table = new XocpTable(1);
      $dp_table->setWidth("100%");
      $hrow = $dp_table->addHeader($dp_header->render());
      $frow = $dp_table->addFooter($dp_footer->render());
                                           
      // Populating data page
      $dp_data = $dp->retrieve();
      foreach ($dp_data as $row) {
         list($str) = $row;
         if ($found) {
            $drow = $dp_table->addRow($str);
         } else {
            $drow = $dp_table->addRow($str);
         }
      }
                                                                     
      return $dp_table->render()."<br/>";
   }
   
   function main() {
      $db =& Database::getInstance();
      $this->getparam = _HIND_CATCH_VAR."="._HIND_GROUP_BLOCK;
      $this->postparam = new XocpFormHidden(_HIND_CATCH_VAR,_HIND_GROUP_BLOCK);
      switch ($this->catch) {
         case _HIND_GROUP_BLOCK:
            global $HTTP_POST_VARS,$HTTP_GET_VARS;
            if (trim($HTTP_POST_VARS["txt_find"]) != "") {
               // Search group/subgroup
               $nm = trim($HTTP_POST_VARS["txt_find"]);
               if (!eregi("\*",$nm)) {
                  $nm = "%$nm%";
               } else {
                  $nm = str_replace("*","%",$nm);
               }
               $datarec["group_nm"] = $HTTP_GET_VARS["mn"];
               $ret = $this->navigate($HTTP_GET_VARS["x"],$HTTP_GET_VARS["y"],$HTTP_GET_VARS["m"],$HTTP_GET_VARS["mn"],$nm);
               include_once(XOCP_DOC_ROOT."/modules/healthindicator/groups/browse.php");
            } elseif (($HTTP_POST_VARS["group_nm"] != "" && $HTTP_GET_VARS["edit"] == "y" &&
                       $HTTP_POST_VARS["edit"] == "" && $HTTP_POST_VARS["cancel"] == "" &&
                       $HTTP_POST_VARS["delete"] == "" && $HTTP_POST_VARS["add"] == "" && $HTTP_POST_VARS["tmpl_id"] == "") ||
                      $HTTP_POST_VARS["save"] != "") {
               // Save group
               if (trim($HTTP_POST_VARS["group_nm"]) != "") {
                  if ($HTTP_POST_VARS["parent_group_nm"] == "" && $HTTP_GET_VARS["x"] != "0") {
                     $sql = "UPDATE ".XOCP_PREFIX."ind_groups SET group_nm = '".trim($HTTP_POST_VARS["group_nm"])."'
                             WHERE group_id = '".$HTTP_GET_VARS["x"]."'";
                  } else {
                     $sql = "INSERT INTO ".XOCP_PREFIX."ind_groups (parent_id,group_nm)
                             VALUES ('".$HTTP_GET_VARS["x"]."','".$HTTP_POST_VARS["group_nm"]."')";
                  }
                  $result = $db->query($sql);
                  $comment = $db->error();
                  if ($comment != "") {
                     $comment = _HIND_GROUPSAVEFAIL."<br/>$comment";
                  } else {
                     $comment = _HIND_GROUPSAVESUCCESS;
                  }
               } else {
                  $comment = _HIND_GROUPSAVEERROR;
               }
               if ($HTTP_POST_VARS["parent_group_nm"] != "") {
                  $HTTP_POST_VARS["group_nm"] = "";
                  $datarec["group_nm"] = $HTTP_POST_VARS["parent_group_nm"];
               } else {
                  $datarec["group_nm"] = $HTTP_POST_VARS["group_nm"];
                  $HTTP_POST_VARS["group_nm"] = "";
               }
               $ret = $this->navigate($HTTP_GET_VARS["x"],$HTTP_GET_VARS["y"],$HTTP_GET_VARS["m"],$HTTP_GET_VARS["mn"]);
               include_once(XOCP_DOC_ROOT."/modules/healthindicator/groups/browse.php");
            } elseif ($HTTP_POST_VARS["cancel"] != "") {
               // Cancel
               $ret = $this->navigate($HTTP_GET_VARS["x"],$HTTP_GET_VARS["y"],$HTTP_GET_VARS["m"],$HTTP_GET_VARS["mn"]);
               $datarec["group_nm"] = $HTTP_POST_VARS["old_group_nm"];
               $HTTP_POST_VARS["group_nm"] = "";
               include_once(XOCP_DOC_ROOT."/modules/healthindicator/groups/browse.php");
            } elseif ($HTTP_GET_VARS["edit"] == "y" && $HTTP_GET_VARS["p"] == "" &&
                      $HTTP_POST_VARS["edit"] == "" && $HTTP_POST_VARS["delete"] == "" &&
                      $HTTP_POST_VARS["tmpl_id"] == "" && $HTTP_POST_VARS["group_nm"] == "") {
               // Show group detail
               $sql = "SELECT group_id,parent_id,group_nm
                       FROM ".XOCP_PREFIX."ind_groups
                       WHERE group_id = ".$HTTP_GET_VARS["x"];
               $result = $db->query($sql);
               if ($db->getRowsNum($result) > 0) {
                  $datarec = $db->fetchArray($result);
                  $mothers = $HTTP_GET_VARS["m"].",".$HTTP_GET_VARS["x"];
                  $HTTP_GET_VARS["m"] = $mothers;
                  $ret = $this->navigate($HTTP_GET_VARS["x"],$HTTP_GET_VARS["y"],$mothers,$HTTP_GET_VARS["mn"]);
               } else {
                  $comment = _HIND_GROUPNOTFOUND;
               }
              include_once(XOCP_DOC_ROOT."/modules/healthindicator/groups/browse.php");
            } elseif ($HTTP_POST_VARS["edit"] != "") {
               // Edit form
               include_once(XOCP_DOC_ROOT."/modules/healthindicator/groups/edit.php");
            } elseif ($HTTP_POST_VARS["delete"] != "" && $HTTP_GET_VARS["edit"] == "y") {
               // Confirm delete
               include_once(XOCP_DOC_ROOT."/modules/healthindicator/groups/delete.php");
            } elseif ($HTTP_GET_VARS["delete"] == "y" && $HTTP_POST_VARS["delete"] != "" && ($HTTP_GET_VARS["x"] != "0" || $HTTP_GET_VARS["x"] != "")) {
               // Delete group/subgroup
               $sql = "DELETE FROM ".XOCP_PREFIX."ind_groups WHERE group_id = ".$HTTP_GET_VARS["x"];
               $result = $db->query($sql);
               $comment = $db->error();
               if ($comment == "") {
                  // Warning: this isn't the proper function
                  //if ($db->getRowsNum($result) > 0) {
                  if (mysql_affected_rows($result) > 0) {
                     $comment = _HIND_DELETEGROUPSUCCESS;
                  } else {
                     $comment = _HIND_DELETEGROUPFAIL;
                  }
               } else {
                  $comment = _HIND_DELETEGROUPERROR."<br/>$comment";
               }
               $sql = "SELECT group_nm FROM ".XOCP_PREFIX."ind_groups WHERE group_id = ".$HTTP_GET_VARS["y"];
               $result = $db->query($sql);
               $datarec = $db->fetchArray($result);
               $m = explode(",",$HTTP_GET_VARS["m"]);
               $y = $m[count($m) - 3];
               $m = implode(",",array_slice($m,0,-1));
               $HTTP_GET_VARS["m"] = $m;
               $HTTP_GET_VARS["mn"] = $datarec["group_nm"];
               $HTTP_GET_VARS["x"] = $HTTP_GET_VARS["y"];
               $HTTP_GET_VARS["y"] = $y;
               $ret = $this->navigate($HTTP_GET_VARS["x"],$y,$m,$datarec["group_nm"]);
               include_once(XOCP_DOC_ROOT."/modules/healthindicator/groups/browse.php");
            } elseif ($HTTP_GET_VARS["p"] != "") {
               // Navigate data page
               $ret = $this->navigate($HTTP_GET_VARS["x"],$HTTP_GET_VARS["y"],$HTTP_GET_VARS["m"],
                                      $HTTP_GET_VARS["mn"],$HTTP_GET_VARS["fi"],$HTTP_GET_VARS["p"],$HTTP_GET_VARS["f"]);
               $datarec["group_nm"] = $HTTP_GET_VARS["mn"];
               include_once(XOCP_DOC_ROOT."/modules/healthindicator/groups/browse.php");
            } elseif ($HTTP_POST_VARS["btn_back"] != "") {
               $ret = $this->navigate($HTTP_GET_VARS["x"],$HTTP_GET_VARS["y"],$HTTP_GET_VARS["m"],$HTTP_GET_VARS["mn"]);
               include_once(XOCP_DOC_ROOT."/modules/healthindicator/groups/browse.php");
            } elseif (($HTTP_POST_VARS["group_nm"] == "" && $HTTP_GET_VARS["edit"] == "y" &&
                       $HTTP_POST_VARS["edit"] == "" && $HTTP_POST_VARS["cancel"] == "" &&
                       $HTTP_POST_VARS["delete"] == "" && $HTTP_POST_VARS["save"] == "" &&  $HTTP_POST_VARS["tmpl_id"] != "") ||
                      $HTTP_POST_VARS["add"] != "") {
               // Save template to group
               $sql = "INSERT INTO ".XOCP_PREFIX."ind_grouptmpl (group_id,tmpl_id)
                       VALUES ('".$HTTP_GET_VARS["x"]."','".$HTTP_POST_VARS["tmpl_id"]."')";
               $result = $db->query($sql);
               $comment = $db->error();
               if ($comment != "") {
                  $comment = "Failed<br/>$comment";
               } else {
                  $comment = "Template successfully added to group ".$HTTP_POST_VARS["parent_group_nm"];
               }
               if ($HTTP_POST_VARS["parent_group_nm"] != "") {
                  $HTTP_POST_VARS["group_nm"] = "";
                  $datarec["group_nm"] = $HTTP_POST_VARS["parent_group_nm"];
               } else {
                  $datarec["group_nm"] = $HTTP_POST_VARS["group_nm"];
                  $HTTP_POST_VARS["group_nm"] = "";
               }
               $ret = $this->navigate($HTTP_GET_VARS["x"],$HTTP_GET_VARS["y"],$HTTP_GET_VARS["m"],$HTTP_GET_VARS["mn"]);
               include_once(XOCP_DOC_ROOT."/modules/healthindicator/groups/browse.php");
            } else {
               // This must be ripped out
               $ret = $this->navigate();
               include_once(XOCP_DOC_ROOT."/modules/healthindicator/groups/browse.php");
            }
            break;
         default:
            // Default handler
            $ret = $this->navigate();
            include_once(XOCP_DOC_ROOT."/modules/healthindicator/groups/browse.php");
            break;
      }
      return $ret;
   }

}
} // HEALTHINDICATOR_GROUPS_DEFINED
?>