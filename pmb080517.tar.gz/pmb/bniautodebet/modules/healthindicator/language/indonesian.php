<?php
if ( !defined('HEALTHINDICATOR_LANGUAGE_DEFINED') ) {
   define('HEALTHINDICATOR_LANGUAGE_DEFINED', TRUE);

// Template Search Indikator
define("_HIND_SEARCHTEMPLATETITLE","Template Indikator - Cari");
define("_HIND_SEARCHTEMPLATE","Mencari Template");
define("_HIND_NEWTEMPLATE","Template Baru");

// Template Indikator - Baru
define("_HIND_NEWTEMPLATETITLE","Template Indikator - Baru");
define("_HIND_TEMPLATENAME","Nama Template");
define("_HIND_TEMPLATEVARIABLE","Variabel Template");
define("_HIND_TEMPLATEUNIT","Satuan");
define("_HIND_TEMPLATEFORMULA","Formula Template");
define("_HIND_TEMPLATEDESCRIPTION","Deskripsi Template");
define("_HIND_SAVENEWTEMPLATE","Simpan Template");
define("_HIND_TEMPLATESAVESUCCESS","Template telah disimpan");
define("_HIND_TEMPLATESAVEFAIL","Template tidak dapat simpan, ada kesalahan");
define("_HIND_TEMPLATESAVEERROR","Agar dapat menyimpan template, minimal Anda mengisi nama template");
define("_HIND_TARGETVAL","Angka Target");
   
// Mencari Indikator
define("_HIND_SEARCHINDICATORTITLE","Indikator - Cari");
define("_HIND_SEARCHINDICATOR","Mencari Indikator");
define("_HIND_NEWINDICATOR","Indikator Baru");

// Memilih Template untuk Indikator Baru
define("_HIND_SELECTTEMPLATETITLE","Memilih Template");
define("_HIND_CREATEINDICATOR","Membuat Indikator");
define("_HIND_SELECTTEMPLATE","Anda Harus Memilih Template");
define("_HIND_CANCEL","Batal");

// Indikator Baru
define("_HIND_NEWINDICATORTITLE","Indikator - Baru");
define("_HIND_PLACEID","Lingkup");
define("_HIND_INDICATORNAME","Nama Indikator");
define("_HIND_INDICATORDESCRIPTION","Deskripsi Indikator");
define("_HIND_INDICATORVALUE","Angka Indikator");
define("_HIND_INDICATORPOSTDATE","Tanggal Posting");
define("_HIND_INDICATORVARS","Angka Variabel");
define("_HIND_INDICATORPERIODE","Periode");
define("_HIND_PUBLISHINDICATOR","Publikasikan Indikator?");
define("_HIND_SAVEINDICATOR","Simpan Indikator");
define("_HIND_INDICATORSAVESUCCESS","Indikator Telah Disimpan");
define("_HIND_INDICATORSAVEFAIL","Indikator Tidak Dapat Disimpan, Ada Kesalahan");
define("_HIND_INDICATORSAVEERROR","Agar Dapat Menyimpan Indikator, minimal Anda Mengisi Nama Indikator, Nama Tempat, Angka Variabel, dan Angka Indikator");
define("_HIND_EDITINDICATORTITLE", "Indikator - Edit");

} // HEALTHINDICATOR_LANGUAGE_DEFINED
?>