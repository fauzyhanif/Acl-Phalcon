<?php
if ( !defined('HEALTHINDICATOR_LANGUAGE_DEFINED') ) {
   define('HEALTHINDICATOR_LANGUAGE_DEFINED', TRUE);

// Miscellaneous/Common
define("_OF","of");
define("_MATCH"," match");
define("_HIND_SEARCHRESULT","Search Result");

// Baseline
define("_HIND_BASELINELIST","Baselines List");
define("_HIND_BASELINENOTFOUND","Baseline not found");
define("_HIND_BASELINEADDTITLE","Add New Baseline");
define("_HIND_BASELINEEDITTITLE","Edit Baseline");
define("_HIND_BASELINENAME","Name");
define("_HIND_BASELINEVAR","Variable Name");
define("_HIND_BASELINEUNIT","Unit");
define("_HIND_BASELINEDESC","Description");
define("_HIND_BASELINEEDITCONFIRMTITLE","Edit Baseline - Confirm Save");
define("_HIND_BASELINEADDCONFIRMTITLE","Add New Baseline - Confirm Add");
define("_HIND_BASELINESHOWDETAILTITLE","Baseline Detail");
define("_HIND_BASELINEDELCONFIRMTITLE","Baseline Detail - Confirm Delete");
define("_HIND_BASELINESAVESUCCESS","Baseline has been successfully saved");
define("_HIND_BASELINESAVEFAIL","Cannot save baseline, it's probably you're saving an existing variable name");
define("_HIND_BASELINESAVEERROR","You must at least fill baseline's variable name");
define("_HIND_BASELINESAVECANCEL","Save canceled");
define("_HIND_BASELINEDELETESUCCESS","Baseline has been successfully deleted");
define("_HIND_BASELINEDELETEERROR","An error occured");
define("_HIND_BASELINEDELETEFAIL","Cannot delete baseline");
define("_HIND_BASELINEDELETECANCEL","Delete canceled");

// Baseline data
define("_HIND_BASELINEDATANOTFOUND","Baseline data not found");
define("_HIND_BASELINEDATAPGROUPNOTASSIGNED","No portal group assigned yet for this user");
define("_HIND_BASELINEDATAORGLIST","Organization List");
define("_HIND_BASELINEDATAVALIDFROM","Valid From");
define("_HIND_BASELINEDATAVALIDTHRU","Valid Through");
define("_HIND_BASELINEDATAVALUE","Value");
define("_HIND_BASELINEDATASOURCE","Data Source");
//define("_HIND_BASELINESHOWDETAILTITLE","Baseline Data Detail");
define("_HIND_BASELINEDATAADDTITLE","Add New Baseline Data");
define("_HIND_BASELINEDATAEDITTITLE","Edit Baseline Data");
//define("_HIND_BASELINEDELCONFIRMTITLE","Edit Baseline Data - Confirm Delete");
define("_HIND_BASELINEDATAADDCONFIRMTITLE","Add New Baseline Data - Confirm Add");
define("_HIND_BASELINEDATAEDITCONFIRMTITLE","Edit Baseline Data - Confirm Save");
define("_HIND_BASELINEDATASAVEERROR","Check your input, name cannot be empty or you enter invalid date or date range");
define("_HIND_BASELINEDATASAVECANCEL","Save canceled");
define("_HIND_BASELINEDATADELETEFAIL","Cannot delete baseline data");
define("_HIND_BASELINEDATADELETESUCCESS","Baseline data has been successfully deleted");
define("_HIND_BASELINEDATADELETEERROR","An error occured");
define("_HIND_BASELINEDATASAVEFAIL","Cannot save baseline data, an error occured");
define("_HIND_BASELINEDATASAVESUCCESS","Baseline data has been successfully saved");
define("_HIND_BASELINEDATADELCANCEL","Delete canceled");

// Template
define("_HIND_TEMPLATENOTFOUND","Indicator not found");
define("_HIND_TEMPLATELIST","Indicators List");
define("_HIND_TEMPLATENAME","Name");
define("_HIND_TEMPLATEVARS","Indicator Variable Names");
define("_HIND_TEMPLATEBASELINEVARS","Baseline Variables Used");
define("_HIND_TEMPLATEUNIT","Unit");
define("_HIND_TEMPLATEFORMULA","Indicator Formula");
define("_HIND_TEMPLATEDESC","Description");
define("_HIND_TEMPLATETARGET","Target Value Formula");
define("_HIND_TEMPLATESHOWDETAILTITLE","Indicator Detail");
define("_HIND_TEMPLATEADDTITLE","Add New Indicator");
define("_HIND_TEMPLATEEDITTITLE","Edit Indicator");
define("_HIND_TEMPLATEDELCONFIRMTITLE","Indicator Detail - Confirm Delete");
define("_HIND_TEMPLATEADDCONFIRMTITLE","Add New Indicator - Confirm Add");
define("_HIND_TEMPLATEEDITCONFIRMTITLE","Edit Indicator - Confirm Save");
define("_HIND_TEMPLATESAVEERROR","You must at least fill indicator's name");
define("_HIND_TEMPLATESAVECANCEL","Save canceled");
define("_HIND_TEMPLATEDELETESUCCESS","Indicator has been successfully deleted");
define("_HIND_TEMPLATEDELETEFAIL","Cannot delete indicator");
define("_HIND_TEMPLATEDELETEERROR","An error occured");
define("_HIND_TEMPLATESAVEFAIL","Can not add new indicator, an error occured");
define("_HIND_TEMPLATESAVESUCCESS","Indicator has been successfully saved");
define("_HIND_TEMPLATEDELCANCEL","Delete canceled");

// Indicator Item
define("_HIND_INDICATORNOTFOUND","Indicator not found");
define("_HIND_INDICATORLIST","Indicator List");
define("_HIND_INDICATORDATANOTFOUND","Indicator item not found");
define("_HIND_INDICATORNAME","Name");
define("_HIND_INDICATORDESC","Description");
define("_HIND_INDICATORVARS","Variable Values");
define("_HIND_INDICATORVALUE","Value");
define("_HIND_INDICATORTVARS","Baselines Used");
define("_HIND_INDICATORTVAL","Target Value");
define("_HIND_INDICATORPERIOD","Period");
define("_HIND_INDICATORPUBLISH","Published");
define("_HIND_INDICATORSHOWDETAILTITLE","Indicator Item Detail");
define("_HIND_INDICATORSELECTTMPL","Select Template");
define("_HIND_INDICATORADDTITLE","Add New Indicator Item");
define("_HIND_INDICATOREDITTITLE","Edit Indicator Item");
define("_HIND_INDICATORADDCONFIRMTITLE","Add New Indicator Item - Confirm Add");
define("_HIND_INDICATORDELCONFIRMTITLE","Indicator Item Detail - Confirm Delete");
define("_HIND_INDICATOREDITCONFIRMTITLE","Edit Indicator Item -  Confirm Save");
define("_HIND_INDICATORSAVEERROR","Cannot add/save indicator item, you must fill the indicator name");
define("_HIND_INDICATORSAVECANCEL","Save canceled");
define("_HIND_INDICATORDELETESUCCESS","Indicator item has been successfully deleted");
define("_HIND_INDICATORDELETEFAIL","Cannot delete indicator item");
define("_HIND_INDICATORDELETEERROR","An error occured");
define("_HIND_INDICATORSAVEFAIL","An error occured");
define("_HIND_INDICATORDELCANCEL","Delete canceled");

// Report
define("_HIND_REPORTGROUPLIST","Select Indicator Group");
define("_HIND_REPORTINDICATORLIST","Select Indicator");
define("_HIND_REPORTINDICATORTABLE","Indicator List");
define("_HIND_REPORTSELECTINDICATOR","Indicator Name");
define("_HIND_REPORTDATE1","From Date");
define("_HIND_REPORTDATE2","To Date");
define("_HIND_REPORTPROCEED","Proceed");
define("_HIND_REPORTBASELINEUSED","Baselines used");
define("_HIND_REPORTACTUALVALUE","Actual Value");
define("_HIND_REPORTTARGETVALUE","Target Value");
define("_HIND_REPORTGROUPNOINDICATOR","Group has no indicator");
define("_HIND_REPORTNOGROUP","Group not found");
define("_HIND_REPORTNOGRAPH","Cannot create chart");
define("_HIND_REPORTSHOWCHART","Show Chart");
define("_HIND_REPORTCHARTTYPE","Chart Type");
define("_HIND_REPORTCHARTLINE","Line");
define("_HIND_REPORTCHARTBAR","Bar");
define("_HIND_REPORTCHARTPIE","Pie");


// Browse Indicator Group
define("_HIND_NEWGROUPTITLE","Indicator Group - New");
define("_HIND_GROUPNAME","Group Name");

// Edit Indicator Group
define("_HIND_EDITGROUPTITLE","Indicator Group - Edit");
define("_HIND_NEWSUBGROUPTITLE","Indicator Subgroup - New");
define("_HIND_SUBGROUPNAME","Subgroup Name");
define("_HIND_SUBGROUP","Indicator Subgroup");
define("_HIND_SUBGROUPNOTFOUND","Indicator Subgroup Not Found");
define("_HIND_GROUPSAVEFAIL","Cannot save group or subgroup, an error has occured");
define("_HIND_GROUPSAVEERROR","You must fill the group name");
define("_HIND_GROUPSAVESUCCESS","Group or subgroup has been successfully saved");
define("_HIND_GROUPLIST", "Indicator Groups");
define("_HIND_GROUPNOTFOUND","Group/subgroup not found");

// Search Indicator Template
define("_HIND_SEARCHTEMPLATETITLE","Indicator Template - Search");
define("_HIND_SEARCHTEMPLATE","Search Template");
define("_HIND_NEWTEMPLATE","New Template");

// New Indicator Template
define("_HIND_NEWTEMPLATETITLE","Indicator Template - New");
//define("_HIND_TEMPLATENAME","Template Name");
define("_HIND_TEMPLATEVARIABLE","Template Variables");
//define("_HIND_TEMPLATEUNIT","Template Unit");
//define("_HIND_TEMPLATEFORMULA","Template Formula");
define("_HIND_TARGETVAL","Target Value");
define("_HIND_TEMPLATEDESCRIPTION","Template Description");
define("_HIND_SAVENEWTEMPLATE","Save Template");
//define("_HIND_TEMPLATESAVESUCCESS","Template has been successfully saved");
//define("_HIND_TEMPLATESAVEFAIL","Cannot save template, an error has occured");
//define("_HIND_TEMPLATESAVEERROR","In order to save template, you must fill at least the template name");
   
// Search Indicator
define("_HIND_SEARCHINDICATORTITLE","Indicator - Search");
define("_HIND_SEARCHINDICATOR","Search Indicator");
define("_HIND_NEWINDICATOR","New Indicator");

// Select Template for A New Indicator
define("_HIND_SELECTTEMPLATETITLE","Select a Template");
define("_HIND_CREATEINDICATOR","Create Indicator");
define("_HIND_SELECTTEMPLATE","You must select a template");
define("_HIND_CANCEL","Cancel");

// New Indicator
define("_HIND_NEWINDICATORTITLE","Indicator - New");
define("_HIND_EDITINDICATORTITLE","Indicator - Edit");
define("_HIND_PLACEID","Place Name");
//define("_HIND_INDICATORNAME","Indicator Name");
define("_HIND_INDICATORDESCRIPTION","Indicator Description");
//define("_HIND_INDICATORVALUE","Indicator Value");
define("_HIND_INDICATORPOSTDATE","Post Date");
//define("_HIND_INDICATORVARS","Variables Value");
define("_HIND_INDICATORPERIODE","Periode");
define("_HIND_PUBLISHINDICATOR","Publish Indicator");
define("_HIND_SAVEINDICATOR","Save Indicator");
define("_HIND_INDICATORSAVESUCCESS","Indicator has been successfully saved");
//define("_HIND_INDICATORSAVEFAIL","Cannot save indicator, an error has occured");
//define("_HIND_INDICATORSAVEERROR","In order to save indicator, you must fill at least the indicator name, place name, variables value, and indicator value");

// Select Organization
define("_HIND_SELECTORGSELECT","Select organization");
define("_HIND_SELECTORGNOTASSIGNED","No organization assigned yet for this user, ask your Administrator");

} // HEALTHINDICATOR_LANGUAGE_DEFINED
?>