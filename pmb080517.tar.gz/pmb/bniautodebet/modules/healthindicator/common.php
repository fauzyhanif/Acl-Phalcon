<?php
//--------------------------------------------------------------------//
// Filename : modules/healthindicator/common.php                      //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-09                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined("HEALTHINDICATOR_COMMON_INCLUDED") ) {
   define("HEALTHINDICATOR_COMMON_INCLUDED",TRUE);

   define("_HIND_INTERVAL_DAY",1);
   define("_HIND_INTERVAL_WEEK",2);
   define("_HIND_INTERVAL_MONTH",3);
   define("_HIND_INTERVAL_YEAR",4);

} // HEALTHINDICATOR_COMMON_DEFINED

?>