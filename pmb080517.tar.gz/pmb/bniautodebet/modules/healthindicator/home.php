<?php
//--------------------------------------------------------------------//
// Filename : modules/system/uploadcache.php                          //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-20                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('HEALTHINDICATOR_HOME_DEFINED') ) {
   define('HEALTHINDICATOR_HOME_DEFINED', TRUE);

class _healthindicator_Home extends XocpBlock {

   function show() {
      global $ses_org_id;
      $db =& Database::getInstance();
      $sql = "SELECT COUNT(*) FROM ".XOCP_PREFIX."ind_orglink WHERE org_id = $ses_org_id";
      $result = $db->query($sql);
      list($count) = $db->fetchRow($result);
      $sql = "SELECT org_nm FROM ".XOCP_PREFIX."orgs WHERE org_id = $ses_org_id";
      $result = $db->query($sql);
      list($porg_nm) = $db->fetchRow($result);
      if ($count == "0") {
         $secondline = "You are now on $porg_nm";
      } else {
         $secondline = "This website contains health profiles from $count districts";
         $sql = "SELECT org_nm
                 FROM ".XOCP_PREFIX."ind_orglink l, ".XOCP_PREFIX."orgs o
                 WHERE o.org_id = l.sub_id AND l.org_id = $ses_org_id";
         $result = $db->query($sql);
         $secondline .= "<table>";
         while (list($org_nm) = $db->fetchRow($result)) {
            $secondline .= "<tr><td>$org_nm</td></tr>";
         }
         $secondline .= "</table><p>You are now on $porg_nm";
      }

      $ret = <<<EOD
<center><h2>Welcome to Internet based<br />Health Information System</H3><p>
<h4>$secondline<p></center>
EOD;
      
      
       
      
      return $ret;
   }

}

} // HEALTHINDICATOR_HOME_DEFINED
?>