* group -> healthindicator/groups/*.*
80% OK, belum ada add templatenya. tapi bisa jadi kurang dari 80% kalo source code-nya direstrukturisasi lagi. i think that's a good idea. more readable.

* baseline -> healthindicator/baseline/baseline.php
99% OK. ready to test.

* baselinedata -> healthindicator/baseline/baselinedata.*
95% OK, cuman kurang setting place_id/org_id, sementara masih di-hardcode, soalnya masih bingung flow-nya. kalo boleh usul, pgroup & sub-nya (otoritatif place/org) ditaruh aja di menu sebelah kiri. jadi nanti pas klik menu utk suatu place/org, place_id/org_id disertakan lewat get vars & disimpan dalam session vars. (maaf, soalnya aku ngga yakin apakah maksud kita sama, place/org dibuat menu, i.e. apakah menunya di menu sebelah kiri, atau menu yg dibuat sendiri spt pd report?)

* template -> healthindicator/template/template.*
99% OK. ready to test.

* indicator -> healthindicator/indicator/*.*
same old module. has not been touched.

* indicator -> healthindicator/report/*.*
same old module. has not been touched.

* language -> healthindicator/language/*.*
tinggal melengkapi.

* modconsts.php
konstanta modul untuk mendefinisikan block registration number & catch variable-nya.

* common.php
tidak digunakan.

untuk direktori Obsolete di tiap2 blok, hanya untuk histori. tidak dipakai pada struktur kode yang baru.