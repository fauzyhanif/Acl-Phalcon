<?php
//--------------------------------------------------------------------//
// Filename : modules/healthindicator/common.php                      //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-09                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('HEALTHINDICATOR_SELECTORG_DEFINED') ) {
   define('HEALTHINDICATOR_SELECTORG_DEFINED', TRUE);
   
include_once(XOCP_DOC_ROOT."/modules/healthindicator/modconsts.php");

class _healthindicator_SelectOrg extends XocpBlock {
   // Set block width
   var $width = "100%";
   // Catch variable for get method -- See below
   var $getparam;
   // Catch variable for post method -- See below
   var $postparam;

   function formSelectOrg() {
      global $xocp_user;
      $pgroup_id = $xocp_user->getVar("pgroup_id");
      $db =& Database::getInstance();
      $sql = "SELECT o.org_id,o.org_nm FROM ".XOCP_PREFIX."orgs o,".XOCP_PREFIX."ind_pgroup_org p
              WHERE o.org_id = p.org_id AND p.pgroup_id = '$pgroup_id' ORDER BY o.org_nm";
      $result = $db->query($sql);
      while (list($org_id,$org_nm) = $db->fetchRow($result)) {
         $parents["$org_id"] = $org_nm;
      }
      if (count($parents) > 0) {
         $sql = "SELECT ol.org_id,ol.sub_id,o.org_nm FROM ".XOCP_PREFIX."orgs o,".XOCP_PREFIX."ind_orglink ol
                 WHERE ol.sub_id = o.org_id AND ol.org_id IN (".implode(".",array_keys($parents)).") ORDER BY o.org_nm";
         $result = $db->query($sql);
         while (list($org_id,$sub_id,$org_nm) = $db->fetchRow($result)) {
            $children["$org_id"]["$sub_id"] = $org_nm;
         }
      } else {
         $parents["0"] = _HIND_SELECTORGNOTASSIGNED;
      }
      
      $dp_header = new XocpSimpleTable();
      $hrow = $dp_header->addRow("<font class='tdh1'>"._HIND_SELECTORGSELECT."</font>");
      $dp_header->setWidth("100%");
      $dp_table = new XocpTable(1);
      $hrow = $dp_table->addHeader($dp_header->render());
      foreach ($parents as $org_id => $org_nm) {
         if ($org_id != "0") {
            $drow = $dp_table->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?XP_indhome_healthindicator="._HIND_SELECTORG_BLOCK."&org_id=$org_id'>$org_nm</a>");
         } else {
            $drow = $dp_table->addRow($org_nm);
         }
         if(is_array($children["$org_id"])) {
            foreach ($children["$org_id"] as $sub_id => $org_nm) {
               $drow = $dp_table->addRow("&nbsp;&nbsp;<a style='font-weight:normal;' href='".XOCP_SERVER_SUBDIR."/index.php?XP_indhome_healthindicator="._HIND_SELECTORG_BLOCK."&org_id=$sub_id'>$org_nm</a>");
            }
         }
      }
      return $dp_table->render();
   }
   
   function showOrg() {
      global $ses_org_id;
      $db =& Database::getInstance();
      $sql = "SELECT o.org_id,o.org_nm FROM ".XOCP_PREFIX."orgs o
              WHERE o.org_id = $ses_org_id";
      $result = $db->query($sql);
      list($org_id,$org_nm) = $db->fetchRow($result);
      return "<table border=0 width=100% cellpadding=2 cellspacing=0>
              <tr><td bgcolor=#0000aa><b><i>$org_nm</i></b></td>
              <td align=right bgcolor=#0000aa>[<a href='".XOCP_SERVER_SUBDIR."/index.php?XP_indselectorg_healthindicator=".
              _HIND_SELECTORG_BLOCK."&ch=y'>"._HIND_SELECTORGSELECT."</a>]</td></tr></table>";
   }

   function show() {
      global $ses_org_id,$HTTP_GET_VARS,$xocp_page_id;
      $this->getparam = _HIND_CATCH_VAR."="._HIND_SELECTORG_BLOCK;
      switch ($this->catch) {
         case _HIND_SELECTORG_BLOCK:
            if ($HTTP_GET_VARS["org_id"] != "") {
               $ses_org_id = $HTTP_GET_VARS["org_id"];
               $ret = $this->showOrg();
            } elseif ($HTTP_GET_VARS["ch"] == "y") {
               $ret = "<br />".$this->formSelectOrg();
            }
            break;
         default:
            if (!session_is_registered("ses_org_id")) {
               session_register("ses_org_id");
               $ses_org_id = "0";
               $this->width = "";
               $ret = "<br />".$this->formSelectOrg();
            } elseif ($HTTP_GET_VARS["org_id"] != ""){
               $ses_org_id = $HTTP_GET_VARS["org_id"];
               $ret = $this->showOrg();
            } elseif ($HTTP_GET_VARS["ch"] == "y" || $xocp_page_id == "indselectorg") {
               $ret = "<br />".$this->formSelectOrg();
            } else {
               $ret = $this->showOrg();
            }
            break;
      }
      return $ret;
   }
}

}
?>