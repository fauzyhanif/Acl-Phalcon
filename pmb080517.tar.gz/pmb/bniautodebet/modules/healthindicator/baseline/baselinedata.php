<?php
if ( !defined('HEALTHINDICATOR_BASELINEDATA_DEFINED') ) {
   define('HEALTHINDICATOR_BASELINEDATA_DEFINED', TRUE);
   
include_once(XOCP_DOC_ROOT."/modules/healthindicator/modconsts.php");

function baselines_funccmp($a,$b) {
   if ($a[4] == $b[4]) {
      return strcmp($a[1],$b[1]);
   }
   return ($a[4] > $b[4]) ? -1 : 1;
}

function baselinedata_funccmp($a,$b) {
   if ($a[6] == $b[6]) {
      if ($a[4] == $b[4]) {
         return strcmp($a[0],$b[0]); 
      }
      return strcmp($a[4],$b[4]);
   }
   return ($a[6] > $b[6]) ? -1 : 1;
}

class _healthindicator_BaselineData extends XocpBlock {
   // Set block width
   var $width = "100%";
   // Catch variable for get method -- See below
   var $getparam;
   // Catch variable for post method -- See below
   var $postparam;
   
   // $find: text to search
   // $p: page number
   // $f: data page filename
   // $org_id: organization id
   function baselineNavigate($find = "",$p = "0",$f = "",$org_id  = "") {
      $db =& Database::getInstance();
      // Is the data page filename set?
      if (trim($f) != "") {  // Retrieve from a previously made data page
         $dp = XocpDataPage::unserialize($f);
         // Check whether the data page has any data or not
         $dp->reset();
         $dp_data = $dp->retrieve();
         if ($dp_data[0][0] != _HIND_BASELINENOTFOUND) {
            $found = TRUE;
         } else {
            $found = FALSE;
         }
         // Set back to proper page number
         $dp->setPage($p);
      } else {  // Create a new data page
         if (trim($find) == "") { // Browse
            $sql = "SELECT bl.bl_nm,bl.description,dt.bl_var,MAX(dt.valid0)
                    FROM ".XOCP_PREFIX."ind_baselinedata dt,".XOCP_PREFIX."ind_baseline bl
                    WHERE dt.bl_var = bl.bl_var AND dt.org_id = $org_id
                    GROUP BY bl.bl_nm,bl.description,dt.bl_var
                    ORDER BY bl.bl_nm";
         } else { // Search
            $sql = "SELECT bl.bl_nm,bl.description,dt.bl_var,MAX(dt.valid0)
                    FROM ".XOCP_PREFIX."ind_baselinedata dt,".XOCP_PREFIX."ind_baseline bl
                    WHERE dt.bl_var = bl.bl_var AND dt.org_id = $org_id AND
                          (bl.bl_nm LIKE '$find' OR bl.description LIKE '$find)
                    GROUP BY bl.bl_nm,bl.description,dt.bl_var
                    ORDER BY bl.bl_nm";
         }

         $result = $db->query($sql);
         $dp = new XocpDataPage();
         $dp->setPageSize(10);
         if ($db->getRowsNum($result) > 0) {
            $found = TRUE;
            while (list($bl_nm,$description,$bl_var,$valid1) = $db->fetchRow($result)) {
               similar_text($bl_nm,str_replace("%","",$find),$score1);
               similar_text($description,str_replace("%","",$find),$score2);
               $dp->addData(array($bl_nm,$description,$bl_var,$valid1,round(((2 * $score1) + $score2) / 3,2)));
            }
            // Sort data
            if (trim($find) != "") {
               usort($dp->data,"baselines_funccmp");
               array_reverse($dp->data);
            }
         } else {
            $found = FALSE;
            $dp->addData(array(_HIND_BASELINENOTFOUND));
         }
         $dp->serialize();
      }
      
      // Preparing the data page
      if ($found) {
         $dp_found = $dp->getCount();
         $no1 = $dp->getOffset() + 1;
      } else {
         $dp_found = "0";
         $no1 = "0";
      }
      $no2 = $no1 + $dp->getPageSize() - 1;
      if ($dp_found <= $no2) {
         $no2 = $dp_found;
      }
      
      // Creating header
      $dp_header = new XocpSimpleTable();
      // Is it searching? Set for the appropriate title
      if ($find != "") {  // Yes, it'is searching
         $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&type=blnav&fi=".urlencode($find));
         $title = "<font class='tdh1'>"._HIND_BASELINELIST." ["._HIND_SEARCHRESULT." ($no1 - $no2 "._OF." $dp_found)]</font>";
      } else {  // No, it's just retrieving from a previously made data page
         $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&type=blnav");
         $title = "<font class='tdh1'>"._HIND_BASELINELIST." ($no1 - $no2 "._OF." $dp_found)</font>";
      }
      // How many page in data page?
      if ($found && count($dp->getPageArray()) > 1) {  // More than 1, show navigation links
         $hrow = $dp_header->addRow($title,$dp_prevnext);
      } else {
         $hrow = $dp_header->addRow($title);
      }
      $dp_header->setCellAlign($hrow,array("","right"));
      $dp_header->setWidth("100%");

      // Creating search form
      $hdn_type = new XocpFormHidden("type","blnav");
      $hdn_state = new XocpFormHidden("state","add");
      $txt_cond = new XocpFormText("","txt_find",20,250,"");
      $btn_find = new XocpFormButton("","btn_find",_SEARCH,"submit");
      $elm_tray_find = new XocpFormElementTray("");
      $elm_tray_find->addElement($txt_cond);
      $elm_tray_find->addElement($btn_find);
      
      $form_find = new XocpSimpleForm("","ffind",XOCP_SERVER_SUBDIR."/index.php");
      $form_find->addElement($this->postparam);
      $form_find->addElement($hdn_type);
      $form_find->addElement($elm_tray_find);

      // Creating button tray form
      $btn_add = new XocpFormButton("","btn_add",_ADD,"submit");
      //$btn_cancel = new XocpFormButton("","btn_cancel",_CANCEL,"submit");
      $elm_tray_add = new XocpFormElementTray("");
      $elm_tray_add->addElement($btn_add);
      //$elm_tray_add->addElement($btn_cancel);
      
      $form_buttons = new XocpSimpleForm("","fbuttons",XOCP_SERVER_SUBDIR."/index.php");
      $form_buttons->addElement($this->postparam);
      $form_buttons->addElement($hdn_type);
      $form_buttons->addElement($hdn_state);
      $form_buttons->addElement($elm_tray_add);

      // Creating footer
      $dp_footer = new XocpSimpleTable();
      $frow = $dp_footer->addRow($form_buttons->render(),$form_find->render());
      $dp_footer->setCellAlign($frow,array("left","right"));
      $dp_footer->setWidth("100%");
                                    
      // Creating data page
      $dp_table = new XocpTable(1);
      $dp_table->setWidth("100%");
      $hrow = $dp_table->addHeader($dp_header->render());
      $dp_table->setColSpan($hrow,2);
      $frow = $dp_table->addFooter($dp_footer->render());
      $dp_table->setColSpan($frow,2);
                                           
      // Populating data page
      $dp_data = $dp->retrieve();
      foreach ($dp_data as $row) {
         list($bl_nm,$description,$bl_var,$valid1,$score) = $row;
         if ($found) {
            $data = "<a href='".XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&list=y&x=$bl_var'>$bl_nm</a>";
            if ($find != "") {
               $data .= " ($score% "._MATCH.")";
            }
            $data .= "<br/>".nl2br($description);
            $drow = $dp_table->addRow($data,sql2ind($valid1));
         } else {
            $drow = $dp_table->addRow($bl_nm);
            $dp_table->setColSpan($drow,2);
         }
      }
                                                                     
      return $dp_table->render();
   }
   
   // $p: page number
   // $f: data page filename
   // $org_id: organization id
   // $bl_var: baseline variable
   function baselineDataNavigate($p = "0",$f = "",$org_id = "",$bl_var = "") {
      $db =& Database::getInstance();
      // Is the data page filename set?
      if (trim($f) != "") {  // Retrieve from a previously made data page
         $dp = XocpDataPage::unserialize($f);
         // Check whether the data page has any data or not
         $dp->reset();
         $dp_data = $dp->retrieve();
         if ($dp_data[0][0] != _HIND_BASELINEDATANOTFOUND) {
            $found = TRUE;
         } else {
            $found = FALSE;
         }
         // Set back to proper page number
         $dp->setPage($p);
      } else {  // Create a new data page
         $sql = "SELECT bl.bl_nm,bl.bl_unit,dt.org_id,dt.bl_var,dt.valid0,dt.valid1,dt.bl_val,dt.srcorg_nm
                 FROM ".XOCP_PREFIX."ind_baselinedata dt,".XOCP_PREFIX."ind_baseline bl
                 WHERE bl.bl_var = '$bl_var' AND dt.bl_var = bl.bl_var AND dt.org_id = $org_id
                 ORDER BY dt.valid1 DESC,bl.bl_nm";

         $result = $db->query($sql);
         $dp = new XocpDataPage();
         $dp->setPageSize(10);
         if ($db->getRowsNum($result) > 0) {
            $found = TRUE;
            list($bl_nm,$bl_unit,$org_id,$bl_var,$valid0,$valid1,$bl_val,$srcorg_nm) = $db->fetchRow($result);
            $dp->addData(array($bl_nm,$bl_unit,$org_id,$bl_var,$valid0,$valid1,$bl_val,$srcorg_nm));
            $title = $bl_nm;
            while (list($bl_nm,$bl_unit,$org_id,$bl_var,$valid0,$valid1,$bl_val,$srcorg_nm) = $db->fetchRow($result)) {
               $dp->addData(array($bl_nm,$bl_unit,$org_id,$bl_var,$valid0,$valid1,$bl_val,$srcorg_nm));
            }
         } else {
            $found = FALSE;
            $dp->addData(array(_HIND_BASELINEDATANOTFOUND));
         }
         $dp->serialize();
      }
      
      // Preparing the data page
      if ($found) {
         $dp_found = $dp->getCount();
         $no1 = $dp->getOffset() + 1;
      } else {
         $dp_found = "0";
         $no1 = "0";
      }
      $no2 = $no1 + $dp->getPageSize() - 1;
      if ($dp_found <= $no2) {
         $no2 = $dp_found;
      }
      
      // Creating header
      $dp_header = new XocpSimpleTable();
      $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&type=bldtnav");
      $title = "<font class='tdh1'>$title ($no1 - $no2 "._OF." $dp_found)</font>";
      // How many page in data page?
      if ($found && count($dp->getPageArray()) > 1) {  // More than 1, show navigation links
         $hrow = $dp_header->addRow($title,$dp_prevnext);
      } else {
         $hrow = $dp_header->addRow($title);
      }
      $dp_header->setCellAlign($hrow,array("","right"));
      $dp_header->setWidth("100%");

      // Creating button tray form
      $hdn_type = new XocpFormHidden("type","bldtnav");
      $hdn_state = new XocpFormHidden("state","add");
      $btn_add = new XocpFormButton("","btn_add",_ADD,"submit");
      $btn_cancel = new XocpFormButton("","btn_cancel",_CANCEL,"submit");
      $elm_tray_add = new XocpFormElementTray("");
      $elm_tray_add->addElement($btn_add);
      $elm_tray_add->addElement($btn_cancel);
      
      $form_buttons = new XocpSimpleForm("","fbuttons",XOCP_SERVER_SUBDIR."/index.php");
      $form_buttons->addElement($this->postparam);
      $form_buttons->addElement($hdn_type);
      $form_buttons->addElement($hdn_state);
      $form_buttons->addElement($elm_tray_add);

      // Creating footer
      $dp_footer = new XocpSimpleTable();
      $frow = $dp_footer->addRow($form_buttons->render());
      $dp_footer->setCellAlign($frow,array("left"));
      $dp_footer->setWidth("100%");
                                    
      // Creating data page
      $dp_table = new XocpTable(1);
      $dp_table->setWidth("100%");
      $hrow = $dp_table->addHeader($dp_header->render());
      $dp_table->setColSpan($hrow,4);
      $frow = $dp_table->addFooter($dp_footer->render());
      $dp_table->setColSpan($frow,4);
      $drow = $dp_table->addRow(_HIND_BASELINEDATAVALIDTHRU,_HIND_BASELINEDATAVALIDFROM,
                                _HIND_BASELINEDATAVALUE,_HIND_BASELINEDATASOURCE);
      $dp_table->setCellAlign($drow,array("center","center","center","center"));
                                           
      // Populating data page
      $no = $dp->getOffset() + 1;
      $dp_data = $dp->retrieve();
      foreach ($dp_data as $row) {
         list($bl_nm,$bl_unit,$org_id,$bl_var,$valid0,$valid1,$bl_val,$srcorg_nm) = $row;
         if ($found) {
            $data1 = "<a href='".XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&show=y&x=".
                    urlencode(base64_encode("$org_id;$bl_var;$valid0;$valid1;$bl_val;$srcorg_nm"))."'>".sql2ind($valid1)."</a>";
            $data0 = "<a href='".XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&show=y&x=".
                    urlencode(base64_encode("$org_id;$bl_var;$valid0;$valid1;$bl_val;$srcorg_nm"))."'>".sql2ind($valid0)."</a>";
            $drow = $dp_table->addRow($data1,$data0,$bl_val." ".$bl_unit,$srcorg_nm);
            $dp_table->setCellAlign($drow,array("","","right",""));
         } else {
            $drow = $dp_table->addRow($bl_nm);
            $dp_table->setColSpan($drow,4);
         }
      }
                                                                     
      return $dp_table->render();
   }

   function orgNavigate($pgroup_id) {
      $db =& Database::getInstance();
      $dp = new XocpDataPage();
      $found = TRUE;
      $sql = "SELECT p.org_id,o.org_nm
              FROM ".XOCP_PREFIX."ind_pgroup_org p,".XOCP_PREFIX."orgs o
              WHERE p.pgroup_id = $pgroup_id AND o.org_id = p.org_id";
      $result = $db->query($sql);
      if ($db->getRowsNum($result) > 0) {
         list($org_id,$org_nm) = $db->fetchRow($result);
         $dp->addData(array($org_id,$org_nm));
         $sql = "SELECT l.sub_id,o.org_nm
                 FROM ".XOCP_PREFIX."ind_orglink l,".XOCP_PREFIX."orgs o
                 WHERE l.org_id = $org_id AND o.org_id = l.sub_id";
         $result = $db->query($sql);
         if ($db->getRowsNum($result) > 0) {
            while (list($org_id,$org_nm) = $db->fetchRow($result)) {
               $dp->addData(array($org_id,$org_nm));
            }
         }
      } else {
         $dp->addData(array(_HIND_BASELINEDATAPGROUPNOTASSIGNED));
         $found = FALSE;
      }
      
      if ($found) {
         $dp_found = $dp->getCount();
      } else {
         $dp_found = "0";
      }
      if ($dp_found == "0") {
         $dp->setPageSize(1);
      } else {
         $dp->setPageSize($dp_found);
      }

      $dp_header = new XocpSimpleTable();
      $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam);
      $title = "<font class='tdh1'>"._HIND_BASELINEDATAORGLIST." ($dp_found)</font>";
      $hrow = $dp_header->addRow($title);
      $dp_header->setWidth("100%");

      // Creating footer
      $dp_footer = new XocpSimpleTable();
      $frow = $dp_footer->addRow("&nbsp;");
      $dp_footer->setWidth("100%");
                                    
      // Creating data page
      $dp_table = new XocpTable(1);
      $dp_table->setWidth("100%");
      $hrow = $dp_table->addHeader($dp_header->render());
      $frow = $dp_table->addFooter($dp_footer->render());
                                           
      // Populating data page
      $dp_data = $dp->retrieve();
      foreach ($dp_data as $row) {
         list($org_id,$org_nm) = $row;
         if ($found) {
            $drow = $dp_table->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&browse=y&x=$org_id'>$org_nm</a>");
         } else {
            $drow = $dp_table->addRow($org_id);
         }
      }
                                                                     
      return $dp_table->render();
   }
   
   function formShowDetail($datarec,$comment = "") {
      // Show baseline detail
      $hidden_type = new XocpFormHidden("type","show");
      $hidden_state = new XocpFormHidden("state","edit");
      $hidden_bl_nm = new XocpFormHidden("old_bl_nm",$datarec["bl_nm"]);
      $hidden_place_id = new XocpFormHidden("old_place_id",$datarec["place_id"]);
      $hidden_bl_var = new XocpFormHidden("old_bl_var",$datarec["bl_var"]);
      $hidden_valid0 = new XocpFormHidden("old_valid0",$datarec["valid0"]);
      $hidden_valid1 = new XocpFormHidden("old_valid1",$datarec["valid1"]);
      $hidden_bl_val = new XocpFormHidden("old_bl_val",$datarec["bl_val"]);
      $hidden_srcorg_nm = new XocpFormHidden("old_srcorg_nm",$datarec["srcorg_nm"]);
      
      $label_bl_nm = new XocpFormLabel(_HIND_BASELINENAME,$datarec["bl_nm"]);
      $label_valid0 = new XocpFormLabel(_HIND_BASELINEDATAVALIDFROM,sql2ind($datarec["valid0"]));
      $label_valid1 = new XocpFormLabel(_HIND_BASELINEDATAVALIDTHRU,sql2ind($datarec["valid1"]));
      $label_bl_val = new XocpFormLabel(_HIND_BASELINEDATAVALUE,$datarec["bl_val"]);
      $label_srcorg_nm = new XocpFormLabel(_HIND_BASELINEDATASOURCE,$datarec["srcorg_nm"]);
      $submit_edit = new XocpFormButton("","edit",_EDIT,"submit");
      $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
      $submit_delete = new XocpFormButton("","delete",_DELETE,"submit");
      $elementtray_button = new XocpFormElementTray("");
      $elementtray_button->addElement($submit_edit);
      $elementtray_button->addElement($submit_cancel);
      $elementtray_button->addElement($submit_delete);

      // Constructing a form - Show baseline detail
      $form = new XocpThemeForm(_HIND_BASELINESHOWDETAILTITLE,"fshowbaselinedata","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_type);
      $form->addElement($hidden_state);

      $form->addElement($hidden_bl_nm);
      $form->addElement($hidden_place_id);
      $form->addElement($hidden_bl_var);
      $form->addElement($hidden_valid0);
      $form->addElement($hidden_valid1);
      $form->addElement($hidden_bl_val);
      $form->addElement($hidden_srcorg_nm);

      $form->addElement($label_bl_nm);
      $form->addElement($label_valid0);
      $form->addElement($label_valid1);
      $form->addElement($label_bl_val);
      $form->addElement($label_srcorg_nm);
      $form->addElement($elementtray_button);
      if ($comment != "") {
         $form->setComment($comment);
      }

      $this->html->setBodyOnload(" onload='document.fshowbaselinedata.cancel.focus();'");
   
      return $form->render();
   }

   function formAddEdit($state = "add",$datarec = NULL,$showcancel = TRUE,
                        $org_id = NULL,$bl_var = NULL,$comment = "") {
      // Form elements - Add/edit a baseline data
      $hidden_type = new XocpFormHidden("type","addedit");
      $hidden_state = new XocpFormHidden("state",$state);
      if ($state == "edit") {
         $hidden_old_org_id = new XocpFormHidden("old_org_id",$datarec["old_org_id"]);
         $hidden_old_bl_nm = new XocpFormHidden("old_bl_nm",$datarec["old_bl_nm"]);
         $hidden_old_bl_var = new XocpFormHidden("old_bl_var",$datarec["old_bl_var"]);
         $hidden_old_valid0 = new XocpFormHidden("old_valid0",$datarec["old_valid0"]);
         $hidden_old_valid1 = new XocpFormHidden("old_valid1",$datarec["old_valid1"]);
         $hidden_old_bl_val = new XocpFormHidden("old_bl_val",$datarec["old_bl_val"]);
         $hidden_old_srcorg_nm = new XocpFormHidden("old_srcorg_nm",$datarec["old_srcorg_nm"]);
      }
      $db =& Database::getInstance();
      $sql = "SELECT bl_var,bl_nm FROM ".XOCP_PREFIX."ind_baseline ";
      if ($bl_var != NULL) {
      	$sql .= "WHERE bl_var = '$bl_var' ";
      }
      $sql .= "ORDER BY bl_nm";
      $result = $db->query($sql);
      if ($bl_var == NULL) {
         // Select baseline variable
         $hidden_bl_nm = new XocpFormHidden("bl_nm",$datarec["bl_nm"]);
         $select_bl_var = new XocpFormSelect(_HIND_BASELINENAME,"bl_var",$datarec["bl_var"]);
         $select_bl_var->addOption("","");
         while (list($sbl_var,$bl_nm) = $db->fetchRow($result)) {
            $select_bl_var->addOption($sbl_var,$bl_nm);
         }
         // End select
      } else {
         list($sbl_var,$bl_nm) = $db->fetchRow($result);
         $hidden_bl_nm = new XocpFormHidden("bl_nm",$bl_nm);
         $hidden_bl_var = new XocpFormHidden("bl_var",$sbl_var);
         $label_bl_nm = new XocpFormLabel(_HIND_BASELINENAME,$bl_nm);
      }
      $date = getdate(time());
      // Valid0
      if ($datarec["valid0"] != "") {
         $date0 = explode("-",$datarec["valid0"]);
         $valid0 = new XocpDateTime($date0[0]."-".$date0[1]."-".$date0[2]);
      } else {
         $valid0 = new XocpDateTime();
         $valid0->eatVars("valid0","post");
         if ($valid0->getMySQL("date") == "0000-00-00") {
            $valid0 = new XocpDateTime($date["year"]."-".$date["mon"]."-".$date["mday"]);
         }
      }
      $date_valid0 = new XocpFormDateTime(_HIND_BASELINEDATAVALIDFROM,"valid0",$valid0);
      // End Valid0
      // Valid1
      if ($datarec["valid1"] != "") {
         $date1 = explode("-",$datarec["valid1"]);
         $valid1 = new XocpDateTime($date1[0]."-".$date1[1]."-".$date1[2]);
      } else {
         $valid1 = new XocpDateTime();
         $valid1->eatVars("valid1","post");
         if ($valid1->getMySQL("date") == "0000-00-00") {
            $valid1 = new XocpDateTime($date["year"]."-".$date["mon"]."-".$date["mday"]);
         }
      }
      $date_valid1 = new XocpFormDateTime(_HIND_BASELINEDATAVALIDTHRU,"valid1",$valid1);
      // End Valid1
      $text_bl_val = new XocpFormText(_HIND_BASELINEDATAVALUE,"bl_val",30,30,$datarec["bl_val"]);
      $text_srcorg_nm = new XocpFormText(_HIND_BASELINEDATASOURCE,"srcorg_nm",30,255,$datarec["srcorg_nm"]);
      $submit_save = new XocpFormButton("","save",_SAVE,"submit");
      $submit_reset = new XocpFormButton("","reset",_RESET,"reset");
      $elementtray_button = new XocpFormElementTray("");
      $elementtray_button->addElement($submit_save);
      $elementtray_button->addElement($submit_reset);
      // Show or hide Cancel button
      if ($showcancel) {
         $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
         $elementtray_button->addElement($submit_cancel);
      }

      // Constructing a form - Add/edit a baseline data
      if ($state == "add") {
         $title = _HIND_BASELINEDATAADDTITLE;
      } else {
         $title = _HIND_BASELINEDATAEDITTITLE;
      }
      $form = new XocpThemeForm($title,"faddeditbaselinedata","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_type);
      $form->addElement($hidden_state);
      if ($state == "edit") {
         $form->addElement($hidden_old_org_id);
         $form->addElement($hidden_old_bl_nm);
         $form->addElement($hidden_old_bl_var);
         $form->addElement($hidden_old_valid0);
         $form->addElement($hidden_old_valid1);
         $form->addElement($hidden_old_bl_val);
         $form->addElement($hidden_old_srcorg_nm);
      }
      if ($bl_var == NULL) {
         $form->addElement($hidden_bl_nm);
         $form->addElement($select_bl_var);
      } else {
         $form->addElement($hidden_bl_nm);
         $form->addElement($hidden_bl_var);
         $form->addElement($label_bl_nm);
      }
      $form->addElement($date_valid0);
      $form->addElement($date_valid1);
      $form->addElement($text_bl_val);
      $form->addElement($text_srcorg_nm);
      $form->addElement($elementtray_button);
      if ($comment != "") {
         $form->setComment($comment);
      }
      if ($bl_var == NULL) {
         $form->setExtra("onsubmit='return setBaselineName();'");
      }

      $this->html->loadScript(XOCP_DOC_ROOT."/modules/healthindicator/baseline/baselinedata.js");
      if ($bl_var == NULL) {
         $this->html->setBodyOnload(" onload='document.faddeditbaselinedata.bl_var.focus();'");
      } else {
         $this->html->setBodyOnload(" onload='document.faddeditbaselinedata.valid0_mday.focus();'");
      }
   
      return $form->render();
   }
   
   function formConfirm($state = "add",$datarec,$title = "") {
      // Form elements - Confirm baseline data being added/edited/deleted
      $hidden_type = new XocpFormHidden("type","confirm");
      $hidden_state = new XocpFormHidden("state",$state);
      if ($state == "edit") {
         $hidden_old_org_id = new XocpFormHidden("old_org_id",$datarec["old_org_id"]);
         $hidden_old_bl_nm = new XocpFormHidden("old_bl_nm",$datarec["old_bl_nm"]);
         $hidden_old_bl_var = new XocpFormHidden("old_bl_var",$datarec["old_bl_var"]);
         $hidden_old_valid0 = new XocpFormHidden("old_valid0",$datarec["old_valid0"]);
         $hidden_old_valid1 = new XocpFormHidden("old_valid1",$datarec["old_valid1"]);
         $hidden_old_bl_val = new XocpFormHidden("old_bl_val",$datarec["old_bl_val"]);
         $hidden_old_srcorg_nm = new XocpFormHidden("old_srcorg_nm",$datarec["old_srcorg_nm"]);
      }
      $hidden_bl_nm = new XocpFormHidden("bl_nm",$datarec["bl_nm"]);
      $hidden_bl_var = new XocpFormHidden("bl_var",$datarec["bl_var"]);
      if ($datarec["valid0"] != "") {
         $date0 = explode("-",$datarec["valid0"]);
         $valid0 = new XocpDateTime($date0[0]."-".$date0[1]."-".$date0[2]);
      } else {
         $valid0 = new XocpDateTime();
         $valid0->eatVars("valid0","post");
         if ($valid0->getMySQL("date") == "0000-00-00") {
            $valid0 = new XocpDateTime($date["year"]."-".$date["mon"]."-".$date["mday"]);
         }
      }
      $hidden_valid0 = new XocpFormHidden("valid0",$valid0->getMySQL("date"));
      if ($datarec["valid1"] != "") {
         $date1 = explode("-",$datarec["valid1"]);
         $valid1 = new XocpDateTime($date1[0]."-".$date1[1]."-".$date1[2]);
      } else {
         $valid1 = new XocpDateTime();
         $valid1->eatVars("valid1","post");
         if ($valid1->getMySQL("date") == "0000-00-00") {
            $valid1 = new XocpDateTime($date["year"]."-".$date["mon"]."-".$date["mday"]);
         }
      }
      $hidden_valid1 = new XocpFormHidden("valid1",$valid1->getMySQL("date"));
      $hidden_bl_val = new XocpFormHidden("bl_val",$datarec["bl_val"]);
      $hidden_srcorg_nm = new XocpFormHidden("srcorg_nm",$datarec["srcorg_nm"]);
      $label_bl_nm = new XocpFormLabel(_HIND_BASELINENAME,$datarec["bl_nm"]);
      $label_valid0 = new XocpFormLabel(_HIND_BASELINEDATAVALIDFROM,sql2ind($valid0->getMySQL("date")));
      $label_valid1 = new XocpFormLabel(_HIND_BASELINEDATAVALIDTHRU,sql2ind($valid1->getMySQL("date")));
      $label_bl_val = new XocpFormLabel(_HIND_BASELINEDATAVALUE,$datarec["bl_val"]);
      $label_srcorg_nm = new XocpFormLabel(_HIND_BASELINEDATASOURCE,$datarec["srcorg_nm"]);
      $submit_ok = new XocpFormButton("","ok",_OK,"submit");
      if ($state != "delete") {
         $submit_edit = new XocpFormButton("","edit",_EDIT,"submit");
      }
      $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
      $elementtray_button = new XocpFormElementTray("");
      $elementtray_button->addElement($submit_ok);
      if ($state != "delete") {
         $elementtray_button->addElement($submit_edit);
      }
      $elementtray_button->addElement($submit_cancel);

      // Constructing a form - Confirm Added/edited baseline
      $form = new XocpThemeForm($title,"fconfirmbaselinedata","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_type);
      $form->addElement($hidden_state);
      if ($state == "edit") {
         $form->addElement($hidden_old_org_id);
         $form->addElement($hidden_old_bl_nm);
         $form->addElement($hidden_old_bl_var);
         $form->addElement($hidden_old_valid0);
         $form->addElement($hidden_old_valid1);
         $form->addElement($hidden_old_bl_val);
         $form->addElement($hidden_old_srcorg_nm);
      }
      $form->addElement($hidden_bl_nm);
      $form->addElement($hidden_bl_var);
      $form->addElement($hidden_valid0);
      $form->addElement($hidden_valid1);
      $form->addElement($hidden_bl_val);
      $form->addElement($hidden_srcorg_nm);
      $form->addElement($label_bl_nm);
      $form->addElement($label_valid0);
      $form->addElement($label_valid1);
      $form->addElement($label_bl_val);
      $form->addElement($label_srcorg_nm);
      $form->addElement($elementtray_button);
      
      if ($state == "add") {
         $this->html->setBodyOnload(" onload='document.fconfirmbaselinedata.ok.focus();'");
      } else {
         $this->html->setBodyOnload(" onload='document.fconfirmbaselinedata.cancel.focus();'");
      }

      return $form->render();
   }
   
   function main() {
      $db =& Database::getInstance();
      $this->getparam = _HIND_CATCH_VAR."="._HIND_BASELINEDATA_BLOCK;
      $this->postparam = new XocpFormHidden(_HIND_CATCH_VAR,_HIND_BASELINEDATA_BLOCK);
      switch ($this->catch) {
         case _HIND_BASELINEDATA_BLOCK:
            global $HTTP_POST_VARS,$HTTP_GET_VARS;
            if (trim($HTTP_POST_VARS["txt_find"]) != "") {
               // Search baseline datas
               $nm = trim($HTTP_POST_VARS["txt_find"]);
               if (!eregi("\*",$nm)) {
                  $nm = "%$nm%";
               } else {
                  $nm = str_replace("*","%",$nm);
               }
               global $ses_org_id,$ses_bldt_bl_var;
               if ($HTTP_POST_VARS["type"] == "blnav") {
                  $ret = $this->baselineNavigate($nm,"","",$ses_org_id);
               } else {
                  $ret = $this->baselineDataNavigate("","",$ses_org_id,$ses_bldt_bl_var);
               }
            } elseif (isset($HTTP_POST_VARS["type"])) {
               // Form handler a.k.a page script flow
               $state = $HTTP_POST_VARS["state"];  // Preserve state
               //$showcancel = ($state == "edit") ? TRUE : FALSE;  // Show cancel button on add/edit form
               $showcancel = TRUE;  // Always show cancel button on add/edit form
               switch ($HTTP_POST_VARS["type"]) {
                  case "show":  // Show detail form
                     global $ses_bldt_bl_var,$ses_org_id;
                     if (!isset($HTTP_POST_VARS["cancel"])) {
                        // Initialize values
                        $HTTP_POST_VARS["bl_nm"] = $HTTP_POST_VARS["old_bl_nm"];
                        $HTTP_POST_VARS["bl_var"] = $HTTP_POST_VARS["old_bl_var"];
                        $HTTP_POST_VARS["valid0"] = $HTTP_POST_VARS["old_valid0"];
                        $HTTP_POST_VARS["valid1"] = $HTTP_POST_VARS["old_valid1"];
                        $HTTP_POST_VARS["bl_val"] = $HTTP_POST_VARS["old_bl_val"];
                        $HTTP_POST_VARS["srcorg_nm"] = $HTTP_POST_VARS["old_srcorg_nm"];
                     }
                     if (isset($HTTP_POST_VARS["edit"])) {  // Edit
                        $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel,$ses_org_id,$ses_bldt_bl_var);
                     } elseif (isset($HTTP_POST_VARS["cancel"])) {  // Cancel
                        $ret = $this->baselineDataNavigate(NULL,NULL,$ses_org_id,$ses_bldt_bl_var);
                     } else {  // Delete
                        $ret = $this->formConfirm("delete",$HTTP_POST_VARS,_HIND_BASELINEDELCONFIRMTITLE);
                     }
                     break;
                  case "addedit":  // Add/edit form
                     if (isset($HTTP_POST_VARS["save"])) {  // Save
                        if (trim($HTTP_POST_VARS["bl_var"]) != "" &&
                            checkdate($HTTP_POST_VARS["valid0_mon"],$HTTP_POST_VARS["valid0_mday"],$HTTP_POST_VARS["valid0_year"]) &&
                            checkdate($HTTP_POST_VARS["valid1_mon"],$HTTP_POST_VARS["valid1_mday"],$HTTP_POST_VARS["valid1_year"]) &&
                            mktime(0,0,0,$HTTP_POST_VARS["valid1_mon"],$HTTP_POST_VARS["valid1_mday"],$HTTP_POST_VARS["valid1_year"]) >= mktime(0,0,0,$HTTP_POST_VARS["valid0_mon"],$HTTP_POST_VARS["valid0_mday"],$HTTP_POST_VARS["valid0_year"])) {  // Check for required field & validity periode
                           if ($state == "add") {
                              $title = _HIND_BASELINEDATAADDCONFIRMTITLE;
                           } else {
                              $title = _HIND_BASELINEDATAEDITCONFIRMTITLE;
                           }
                           $ret = $this->formConfirm($state,$HTTP_POST_VARS,$title);
                        } else {
                           global $ses_org_id,$ses_bldt_bl_var;
                           $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel,
                                                     $ses_org_id,$ses_bldt_bl_var,_HIND_BASELINEDATASAVEERROR);
                        }
                     } elseif (isset($HTTP_POST_VARS["cancel"])) {  // Cancel
                        if ($state == "edit") {
                           // Set back to original values
                           $HTTP_POST_VARS["bl_nm"] = $HTTP_POST_VARS["old_bl_nm"];
                           $HTTP_POST_VARS["bl_var"] = $HTTP_POST_VARS["old_bl_var"];
                           $HTTP_POST_VARS["valid0"] = $HTTP_POST_VARS["old_valid0"];
                           $HTTP_POST_VARS["valid1"] = $HTTP_POST_VARS["old_valid1"];
                           $HTTP_POST_VARS["bl_val"] = $HTTP_POST_VARS["old_bl_val"];
                           $HTTP_POST_VARS["srcorg_nm"] = $HTTP_POST_VARS["old_srcorg_nm"];
                           $ret = $this->formShowDetail($HTTP_POST_VARS,_HIND_BASELINEDATASAVECANCEL);
                        } else {
                           global $ses_org_id,$ses_bldt_bl_var;
                           if (isset($ses_bldt_bl_var)) {
                           	$ret = $this->baselineDataNavigate("","",$ses_org_id,$ses_bldt_bl_var);
                           } else {
                              $ret = $this->baselineNavigate("","","",$ses_org_id);
                           }
                        }
                     }
                     break;
                  case "confirm":  // Confirmation form
                     global $ses_org_id,$ses_bldt_bl_var;
                     if (isset($HTTP_POST_VARS["ok"])) {  // Ok, save/delete baseline data
                        if ($state == "delete") {  // Do delete baseline data
                           $sql = "DELETE FROM ".XOCP_PREFIX."ind_baselinedata
                                   WHERE org_id = $ses_org_id AND
                                         bl_var = '$ses_bldt_bl_var' AND
                                         valid0 = '".$HTTP_POST_VARS["valid0"]."' AND
                                         valid1 = '".$HTTP_POST_VARS["valid1"]."' AND
                                         bl_val = '".$HTTP_POST_VARS["bl_val"]."' AND
                                         srcorg_nm = '".$HTTP_POST_VARS["srcorg_nm"]."'";
                           $result = $db->query($sql);
                           $comment = $db->error();
                           if ($comment == "") {
                              // Warning: this isn't the proper function
                              //if ($db->getRowsNum($result) > 0) {
                              if (mysql_affected_rows() > 0) {
                                 $comment = _HIND_BASELINEDATADELETESUCCESS;
                              } else {
                                 $comment = _HIND_BASELINEDATADELETEFAIL;
                              }
                           } else {
                              $comment = _HIND_BASELINEDATADELETEERROR."<br/>$comment";
                           }
                           $ret = $this->baselineDataNavigate("","",$ses_org_id,$ses_bldt_bl_var);
                        } else {
                           if (isset($ses_bldt_bl_var)) {
                           	$HTTP_POST_VARS["bl_var"] = $ses_bldt_bl_var;
                           }
                           if ($state == "add") {  // New baseline data, do add
                              $sql = "INSERT INTO ".XOCP_PREFIX."ind_baselinedata (org_id,bl_var,valid0,valid1,bl_val,srcorg_nm)
                                      VALUES ('$ses_org_id','".$HTTP_POST_VARS["bl_var"]."','".
                                              $HTTP_POST_VARS["valid0"]."','".$HTTP_POST_VARS["valid1"]."','".
                                              $HTTP_POST_VARS["bl_val"]."','".$HTTP_POST_VARS["srcorg_nm"]."')";
                           } else {  // Old baseline data, do update
                              $sql = "UPDATE ".XOCP_PREFIX."ind_baselinedata
                                      SET bl_var = '".$HTTP_POST_VARS["bl_var"]."',
                                          valid0 = '".$HTTP_POST_VARS["valid0"]."',
                                          valid1 = '".$HTTP_POST_VARS["valid1"]."',
                                          bl_val = '".$HTTP_POST_VARS["bl_val"]."',
                                          srcorg_nm = '".$HTTP_POST_VARS["srcorg_nm"]."'
                                      WHERE org_id = '$ses_org_id' AND bl_var = '".
                                            $HTTP_POST_VARS["old_bl_var"]."' AND valid0 = '".$HTTP_POST_VARS["old_valid0"].
                                            "' AND valid1 = '".$HTTP_POST_VARS["old_valid1"]."' AND bl_val = '".
                                            $HTTP_POST_VARS["old_bl_val"]."' AND srcorg_nm = '".$HTTP_POST_VARS["old_srcorg_nm"]."'";
                           }
                           $result = $db->query($sql);
                           $comment = $db->error();
                           if ($comment != "") {
                              if ($state != "add") {  // Set back to original values
                                 $HTTP_POST_VARS["bl_nm"] = $HTTP_POST_VARS["old_bl_nm"];
                                 $HTTP_POST_VARS["bl_var"] = $HTTP_POST_VARS["old_bl_var"];
                                 $HTTP_POST_VARS["valid0"] = $HTTP_POST_VARS["old_valid0"];
                                 $HTTP_POST_VARS["valid1"] = $HTTP_POST_VARS["old_valid1"];
                                 $HTTP_POST_VARS["bl_val"] = $HTTP_POST_VARS["old_bl_val"];
                                 $HTTP_POST_VARS["srcorg_nm"] = $HTTP_POST_VARS["old_srcorg_nm"];
                              }
                              $comment = _HIND_BASELINEDATASAVEFAIL."<br/>".$comment;
                           } else {
                              if ($state == "add") {
                                 $datarec["valid0"] = $HTTP_POST_VARS["valid0"];
                                 $datarec["valid1"] = $HTTP_POST_VARS["valid1"];
                                 //unset($HTTP_POST_VARS);
                              }
                              $comment = _HIND_BASELINEDATASAVESUCCESS;
                           }
                           if ($state == "add") {
                              $ret = $this->formAddEdit($state,$datarec,$showcancel,$ses_org_id,$ses_bldt_bl_var,$comment);
                           } else {
                              $ret = $this->formShowDetail($HTTP_POST_VARS,$comment);
                           }
                        }
                     } elseif (isset($HTTP_POST_VARS["edit"])) {
                        global $ses_org_id,$ses_bldt_bl_var;
                        $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel,$ses_org_id,$ses_bldt_bl_var);
                     } elseif (isset($HTTP_POST_VARS["cancel"])) {  // Cancel
                        if ($state == "add") {
                           $datarec["valid0"] = $HTTP_POST_VARS["valid0"];
                           $datarec["valid1"] = $HTTP_POST_VARS["valid1"];
                           unset($HTTP_POST_VARS);
                           $ret = $this->formAddEdit($state,$datarec,$showcancel,_HIND_BASELINEDATASAVECANCEL);
                        } else{
                           if ($state == "edit") {
                              // Set back to original data
                              $comment = _HIND_BASELINEDATASAVECANCEL;
                              $HTTP_POST_VARS["bl_nm"] = $HTTP_POST_VARS["old_bl_nm"];
                              $HTTP_POST_VARS["bl_var"] = $HTTP_POST_VARS["old_bl_var"];
                              $HTTP_POST_VARS["valid0"] = $HTTP_POST_VARS["old_valid0"];
                              $HTTP_POST_VARS["valid1"] = $HTTP_POST_VARS["old_valid1"];
                              $HTTP_POST_VARS["bl_val"] = $HTTP_POST_VARS["old_bl_val"];
                              $HTTP_POST_VARS["srcorg_nm"] = $HTTP_POST_VARS["old_srcorg_nm"];
                           } else {
                              $comment = _HIND_BASELINEDATADELCANCEL;
                           }
                           $ret = $this->formShowDetail($HTTP_POST_VARS,$comment);
                        }
                     }
                     break;
                  case "blnav":  // Baseline navigation
                     global $ses_bldt_pgroup_id,$ses_org_id;
                     if (isset($HTTP_POST_VARS["btn_cancel"])) {
                        session_unregister("ses_org_id");
                        $ret = $this->orgNavigate($ses_bldt_pgroup_id);
                     } elseif (isset($HTTP_POST_VARS["btn_add"])) {
                        $ret = $this->formAddEdit($state,NULL,$showcancel,$ses_org_id);
                     }
                     break;
                  case "bldtnav":  // Baseline data navigation
                     global $ses_org_id,$ses_bldt_bl_var;
                     if (isset($HTTP_POST_VARS["btn_cancel"])) {
                        session_unregister("ses_bldt_bl_var");
                        $ret = $this->baselineNavigate("","","",$ses_org_id);
                     } elseif (isset($HTTP_POST_VARS["btn_add"])) {
                        $ret = $this->formAddEdit($state,NULL,$showcancel,$ses_org_id,$ses_bldt_bl_var);
                     }
                     break;
               }
            } elseif ($HTTP_GET_VARS["browse"] == "y" && $HTTP_GET_VARS["x"] != "") {
               // Template baseline data page
               global $ses_org_id;
               session_register("ses_bldt_org_id");
               $ses_org_id = $HTTP_GET_VARS["x"];
               $ret = $this->baselineNavigate("","","",$ses_org_id);
            } elseif ($HTTP_GET_VARS["list"] == "y" && $HTTP_GET_VARS["x"] != "") {
               // Navigate baseline data
               global $ses_bldt_bl_var,$ses_org_id;
               session_register("ses_bldt_bl_var");
               $ses_bldt_bl_var = $HTTP_GET_VARS["x"];
               $ret = $this->baselineDataNavigate("","",$ses_org_id,$ses_bldt_bl_var);
            } elseif ($HTTP_GET_VARS["show"] == "y" && $HTTP_GET_VARS["x"] != "") {
               global $ses_bldt_bl_var,$ses_org_id;
               // Show baseline data detail
               list($org_id,$bl_var,$valid0,$valid1,$bl_val,$srcorg_nm) = explode(";",base64_decode($HTTP_GET_VARS["x"]));
               $sql = "SELECT bl.bl_nm,bl.bl_unit,dt.org_id,dt.bl_var,dt.valid0,dt.valid1,dt.bl_val,dt.srcorg_nm
                       FROM ".XOCP_PREFIX."ind_baselinedata dt,".XOCP_PREFIX."ind_baseline bl
                       WHERE dt.bl_var = bl.bl_var AND dt.org_id = $org_id AND dt.bl_var = '$bl_var' AND
                             dt.valid0 = '$valid0' AND dt.valid1 = '$valid1' AND dt.bl_val = '$bl_val' AND
                             dt.srcorg_nm = '$srcorg_nm'";
               $result = $db->query($sql);
               if ($db->getRowsNum($result) > 0) {
                  $datarec = $db->fetchArray($result);
                  $ret = $this->formShowDetail($datarec);
               } else {
                  $ret = $this->baselineDataNavigate("","",$ses_org_id,$ses_bldt_bl_var);
               }
            } elseif ($HTTP_GET_VARS["p"] != "") {
               // Navigate baseline or baseline data data page
               global $ses_org_id,$ses_bldt_bl_var;
               if ($HTTP_GET_VARS["type"] == "blnav") {
                  $ret = $this->baselineNavigate($HTTP_GET_VARS["fi"],$HTTP_GET_VARS["p"],$HTTP_GET_VARS["f"],$ses_org_id);
               } else {
                  $ret = $this->baselineDataNavigate($HTTP_GET_VARS["p"],$HTTP_GET_VARS["f"],$ses_org_id,$ses_bldt_bl_var);
               }
            } else {
               // This must be ripped out
               $ret = $this->baselineNavigate();
            }
            break;
         default:
            // Default handler
            global $ses_bldt_pgroup_id,$ses_org_id,$ses_bldt_bl_var;
            if (isset($ses_bldt_bl_var)) {
            	$ret = $this->baselineDataNavigate("","",$ses_org_id,$ses_bldt_bl_var);
            } elseif (isset($ses_org_id)) {
               $ret = $this->baselineNavigate("","","",$ses_org_id);
            } else {
               if (!session_is_registered("ses_bldt_pgroup_id")) {
                  session_register("ses_bldt_pgroup_id");
                  $ses_bldt_pgroup_id = "1";
               }
               $ret = $this->orgNavigate($ses_bldt_pgroup_id);
            }
            break;
      }
      return $ret;
   }

}
} // HEALTHINDICATOR_BASELINEDATA_DEFINED
?>