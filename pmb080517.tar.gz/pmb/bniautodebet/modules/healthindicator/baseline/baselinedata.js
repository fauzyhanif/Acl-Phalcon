<script language='JavaScript'>
function setBaselineName() {
   obj = document.faddeditbaselinedata.bl_var;
   document.faddeditbaselinedata.bl_nm.value = obj.options[obj.selectedIndex].text;
   return true;
}
</script>
