<?php
// Form elements - Add group/subgroup
if (($HTTP_GET_VARS["y"] == "" || $HTTP_GET_VARS["y"] == "0") &&
    ($HTTP_GET_VARS["x"] == "" || $HTTP_GET_VARS["x"] == "0") &&
    ($HTTP_GET_VARS["m"] == "" || $HTTP_GET_VARS["m"] == "0")) {
   $HTTP_GET_VARS["y"] = "0";
   $HTTP_GET_VARS["x"] = "0";
   $HTTP_GET_VARS["m"] = "0";
   $title = _HIND_NEWGROUPTITLE;
   $caption = _HIND_GROUPNAME;
} else {
   $title = _HIND_NEWSUBGROUPTITLE;
   $caption = _HIND_SUBGROUPNAME;
}
$hidden_parent_group_nm = new XocpFormHidden("parent_group_nm",$datarec["group_nm"]);
$text_group_nm = new XocpFormText($caption,"group_nm",30,200,$HTTP_POST_VARS["group_nm"]);
$submit_save = new XocpFormButton("","save",_SAVE,"submit");

// Constructing a form - Add group/subgroup
$form = new XocpThemeForm($title,"fnewgroup","index.php?edit=y&x=".$HTTP_GET_VARS["x"]."&y=".$HTTP_GET_VARS["y"].
                          "&m=".$HTTP_GET_VARS["m"]."&mn=".$HTTP_GET_VARS["mn"],"post");
$form->addElement($this->postparam);
$form->addElement($hidden_parent_group_nm);
$form->addElement($text_group_nm);
$form->addElement($submit_save);
if ($comment != "" && $HTTP_POST_VARS["parent_group_nm"] != "") {
   $form->setComment($comment);
}
   
$ret .= $form->render();
?>