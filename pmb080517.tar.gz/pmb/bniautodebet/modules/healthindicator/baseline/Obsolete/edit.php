<?php
// Do edit group
$hidden_group_nm = new XocpFormHidden("old_group_nm",$HTTP_POST_VARS["group_nm"]);
$text_group_nm = new XocpFormText(_HIND_GROUPNAME,"group_nm",30,200,$HTTP_POST_VARS["group_nm"]);
$submit_save = new XocpFormButton("","save",_SAVE,"submit");
$submit_reset = new XocpFormButton("","reset",_RESET,"reset");
$submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
$elementtray_button = new XocpFormElementTray("");
$elementtray_button->addElement($submit_save);
$elementtray_button->addElement($submit_reset);
$elementtray_button->addElement($submit_cancel);

// Constructing a form - Add group/subgroup
$form = new XocpThemeForm(_HIND_EDITGROUPTITLE,"feditgroup","index.php?edit=y&x=".$HTTP_GET_VARS["x"].
                          "&y=".$HTTP_GET_VARS["y"]."&m=".$HTTP_GET_VARS["m"]."&mn=".$HTTP_GET_VARS["mn"],"post");
$form->addElement($this->postparam);
$form->addElement($hidden_group_nm);
$form->addElement($text_group_nm);
$form->addElement($elementtray_button);
   
$ret = $form->render();
?>