<?php
// Form elements - Add/edit a baseline
$text_bl_var = new XocpFormText(_HIND_BASELINEVAR,"bl_var",30,200,$datarec["bl_var"]);
$text_bl_nm = new XocpFormText(_HIND_BASELINENAME,"bl_nm",30,200,$datarec["bl_nm"]);
$text_bl_unit = new XocpFormText(_HIND_BASELINEUNIT,"bl_unit",30,200,$datarec["bl_unit"]);
$textarea_description = new XocpFormTextArea(_HIND_BASELINEDESC,"description",$datarec["description"]);
$submit_save = new XocpFormButton("","do_add",_SAVE,"submit");
$submit_reset = new XocpFormButton("","reset",_RESET,"reset");
$submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
$elementtray_button = new XocpFormElementTray("");
$elementtray_button->addElement($submit_save);
$elementtray_button->addElement($submit_reset);
$elementtray_button->addElement($submit_cancel);

// Constructing a form - Add/edit a baseline
$form = new XocpThemeForm(_HIND_BASELINEADDTITLE,"faddeditbaseline","index.php");
$form->addElement($this->postparam);
$form->addElement($text_bl_var);
$form->addElement($text_bl_nm);
$form->addElement($text_bl_unit);
$form->addElement($textarea_description);
$form->addElement($elementtray_button);
if ($comment != "") {
   $form->setComment($comment);
}
   
$ret = $form->render();
?>