<?php
if ( !defined('HEALTHINDICATOR_BASELINE_DEFINED') ) {
   define('HEALTHINDICATOR_BASELINE_DEFINED', TRUE);
   
include_once(XOCP_DOC_ROOT."/modules/healthindicator/modconsts.php");

function baseline_funccmp($a,$b) {
   if ($a[3] == $b[3]) {
      return strcmp($a[1],$b[1]);
   }
   return ($a[3] > $b[3]) ? -1 : 1;
}

class _healthindicator_Baseline extends XocpBlock {
   // Set block width
   var $width = "100%";
   // Catch variable for get method -- See below
   var $getparam;
   // Catch variable for post method -- See below
   var $postparam;
   
   // $find: text to search
   // $p: page number
   // $f: data page filename
   function navigate($find = "",$p = "0",$f = "") {
      $db =& Database::getInstance();
      // Is the data page filename set?
      if (trim($f) != "") {  // Retrieve from a previously made data page
         $dp = XocpDataPage::unserialize($f);
         // Check whether the data page has any data or not
         $dp->reset();
         $dp_data = $dp->retrieve();
         if ($dp_data[0][0] != _HIND_BASELINENOTFOUND) {
            $found = TRUE;
         } else {
            $found = FALSE;
         }
         // Set back to proper page number
         $dp->setPage($p);
      } else {  // Create a new data page
         if (trim($find) == "") { // Browse
            $sql = "SELECT bl_var,bl_nm,description
                    FROM ".XOCP_PREFIX."ind_baseline
                    ORDER BY bl_nm";
         } else { // Search
            $sql = "SELECT bl_var,bl_nm,description
                    FROM ".XOCP_PREFIX."ind_baseline
                    WHERE bl_nm LIKE '$find' OR description LIKE '$find'
                    ORDER BY bl_nm";
         }

         $result = $db->query($sql);
         $dp = new XocpDataPage();
         $dp->setPageSize(10);
         if ($db->getRowsNum($result) > 0) {
            $found = TRUE;
            while (list($bl_var,$bl_nm,$description) = $db->fetchRow($result)) {
               similar_text($bl_nm,str_replace("%","",$find),$score1);
               similar_text($description,str_replace("%","",$find),$score2);
               $dp->addData(array($bl_var,$bl_nm,$description,round(((2 * $score1) + $score2) / 3,2)));
            }
            // Sort data
            if (trim($find) != "") {
               usort($dp->data,"baseline_funccmp");
               array_reverse($dp->data);
            }
         } else {
            $found = FALSE;
            $dp->addData(array(_HIND_BASELINENOTFOUND));
         }
         $dp->serialize();
      }
      
      // Preparing the data page
      if ($found) {
         $dp_found = $dp->getCount();
         $no1 = $dp->getOffset() + 1;
      } else {
         $dp_found = "0";
         $no1 = "0";
      }
      $no2 = $no1 + $dp->getPageSize() - 1;
      if ($dp_found <= $no2) {
         $no2 = $dp_found;
      }
      
      // Creating header
      $dp_header = new XocpSimpleTable();
      // Is it searching? Set for the appropriate title
      if ($find != "") {  // Yes, it'is searching
         $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&fi=".urlencode($find));
         $title = "<font class='tdh1'>"._HIND_BASELINELIST." ["._HIND_SEARCHRESULT." ($no1 - $no2 "._OF." $dp_found)]</font>";
      } else {  // No, it's just retrieving from a previously made data page
         $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam);
         $title = "<font class='tdh1'>"._HIND_BASELINELIST." ($no1 - $no2 "._OF." $dp_found)</font>";
      }
      // How many page in data page?
      if ($found && count($dp->getPageArray()) > 1) {  // More than 1, show navigation links
         $hrow = $dp_header->addRow($title,$dp_prevnext);
      } else {
         $hrow = $dp_header->addRow($title);
      }
      $dp_header->setCellAlign($hrow,array("","right"));
      $dp_header->setWidth("100%");

      // Creating search form
      $txt_cond = new XocpFormText("","txt_find",20,50,"");
      $btn_find = new XocpFormButton("","btn_find",_SEARCH,"submit");
      $elm_tray_find = new XocpFormElementTray("");
      $elm_tray_find->addElement($txt_cond);
      $elm_tray_find->addElement($btn_find);
      
      $form_find = new XocpSimpleForm("","ffind",XOCP_SERVER_SUBDIR."/index.php");
      $form_find->addElement($this->postparam);
      $form_find->addElement($elm_tray_find);

      // Creating button tray form
      $btn_add = new XocpFormButton("","btn_add",_ADD,"submit");
      $elm_tray_add = new XocpFormElementTray("");
      $elm_tray_add->addElement($btn_add);
      
      $form_buttons = new XocpSimpleForm("","fbuttons",XOCP_SERVER_SUBDIR."/index.php");
      $form_buttons->addElement($this->postparam);
      $form_buttons->addElement($elm_tray_add);

      // Creating footer
      $dp_footer = new XocpSimpleTable();
      $frow = $dp_footer->addRow($form_buttons->render(),$form_find->render());
      $dp_footer->setCellAlign($frow,array("left","right"));
      $dp_footer->setWidth("100%");
                                    
      // Creating data page
      $dp_table = new XocpTable(1);
      $dp_table->setWidth("100%");
      $hrow = $dp_table->addHeader($dp_header->render());
      $frow = $dp_table->addFooter($dp_footer->render());
                                           
      // Populating data page
      $dp_data = $dp->retrieve();
      foreach ($dp_data as $row) {
         list($bl_var,$bl_nm,$description,$score) = $row;
         if ($found) {
            if ($find != "") {
               $drow = $dp_table->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&show=y&x=$bl_var'>$bl_nm</a> ($score% "._MATCH.")<br/>".nl2br($description));
            } else {
               $drow = $dp_table->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&show=y&x=$bl_var'>$bl_nm</a><br/>".nl2br($description));
            }
         } else {
            $drow = $dp_table->addRow($bl_var);
         }
      }
                                                                     
      return $dp_table->render();
   }
   
   function formShowDetail($datarec,$comment = "") {
      // Show baseline detail
      $hidden_type = new XocpFormHidden("type","show");
      $hidden_state = new XocpFormHidden("state","edit");
      $hidden_bl_var = new XocpFormHidden("old_bl_var",$datarec["bl_var"]);
      $hidden_bl_nm = new XocpFormHidden("old_bl_nm",$datarec["bl_nm"]);
      $hidden_bl_unit = new XocpFormHidden("old_bl_unit",$datarec["bl_unit"]);
      $hidden_description = new XocpFormHidden("old_description",$datarec["description"]);
      $label_bl_var = new XocpFormLabel(_HIND_BASELINEVAR,$datarec["bl_var"]);
      $label_bl_nm = new XocpFormLabel(_HIND_BASELINENAME,$datarec["bl_nm"]);
      $label_bl_unit = new XocpFormLabel(_HIND_BASELINEUNIT,$datarec["bl_unit"]);
      $label_description = new XocpFormLabel(_HIND_BASELINEDESC,nl2br($datarec["description"]));
      $submit_edit = new XocpFormButton("","edit",_EDIT,"submit");
      $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
      $submit_delete = new XocpFormButton("","delete",_DELETE,"submit");
      $elementtray_button = new XocpFormElementTray("");
      $elementtray_button->addElement($submit_edit);
      $elementtray_button->addElement($submit_cancel);
      $elementtray_button->addElement($submit_delete);

      // Constructing a form - Show baseline detail
      $form = new XocpThemeForm(_HIND_BASELINESHOWDETAILTITLE,"fshowbaseline","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_type);
      $form->addElement($hidden_state);
      $form->addElement($hidden_bl_nm);
      $form->addElement($hidden_bl_var);
      $form->addElement($hidden_bl_unit);
      $form->addElement($hidden_description);
      $form->addElement($label_bl_var);
      $form->addElement($label_bl_nm);
      $form->addElement($label_bl_unit);
      $form->addElement($label_description);
      $form->addElement($elementtray_button);
      if ($comment != "") {
         $form->setComment($comment);
      }
   
      $this->html->setBodyOnload(" onload='document.fshowbaseline.cancel.focus();'");

      return $form->render();
   }

   function formAddEdit($state = "add",$datarec = NULL,$showcancel = TRUE,$comment = "") {
      // Form elements - Add/edit a baseline
      $hidden_type = new XocpFormHidden("type","addedit");
      $hidden_state = new XocpFormHidden("state",$state);
      if ($state == "edit") {
         $hidden_old_bl_var = new XocpFormHidden("old_bl_var",$datarec["old_bl_var"]);
         $hidden_old_bl_nm = new XocpFormHidden("old_bl_nm",$datarec["old_bl_nm"]);
         $hidden_old_bl_unit = new XocpFormHidden("old_bl_unit",$datarec["old_bl_unit"]);
         $hidden_old_description = new XocpFormHidden("old_description",$datarec["old_description"]);
      }
      $text_bl_var = new XocpFormText(_HIND_BASELINEVAR,"bl_var",10,10,$datarec["bl_var"]);
      $text_bl_nm = new XocpFormText(_HIND_BASELINENAME,"bl_nm",50,250,$datarec["bl_nm"]);
      $text_bl_unit = new XocpFormText(_HIND_BASELINEUNIT,"bl_unit",10,10,$datarec["bl_unit"]);
      $textarea_description = new XocpFormTextArea(_HIND_BASELINEDESC,"description",$datarec["description"]);
      $submit_save = new XocpFormButton("","save",_SAVE,"submit");
      $submit_reset = new XocpFormButton("","reset",_RESET,"reset");
      $elementtray_button = new XocpFormElementTray("");
      $elementtray_button->addElement($submit_save);
      $elementtray_button->addElement($submit_reset);
      // Show or hide Cancel button
      if ($showcancel) {
         $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
         $elementtray_button->addElement($submit_cancel);
      }

      // Constructing a form - Add/edit a baseline
      if ($state == "add") {
         $title = _HIND_BASELINEADDTITLE;
      } else {
         $title = _HIND_BASELINEEDITTITLE;
      }
      $form = new XocpThemeForm($title,"faddeditbaseline","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_type);
      $form->addElement($hidden_state);
      if ($state == "edit") {
         $form->addElement($hidden_old_bl_var);
         $form->addElement($hidden_old_bl_nm);
         $form->addElement($hidden_old_bl_unit);
         $form->addElement($hidden_old_description);
      }
      $form->addElement($text_bl_nm);
      $form->addElement($text_bl_var);
      $form->addElement($text_bl_unit);
      $form->addElement($textarea_description);
      $form->addElement($elementtray_button);
      if ($comment != "") {
         $form->setComment($comment);
      }
   
      $this->html->setBodyOnload(" onload='document.faddeditbaseline.bl_nm.focus();'");

      return $form->render();
   }
   
   function formConfirm($state = "add",$datarec,$title = "") {
      // Form elements - Confirm Added/edited baseline
      $hidden_type = new XocpFormHidden("type","confirm");
      $hidden_state = new XocpFormHidden("state",$state);
      if ($state == "edit") {
         $hidden_old_bl_var = new XocpFormHidden("old_bl_var",$datarec["old_bl_var"]);
         $hidden_old_bl_nm = new XocpFormHidden("old_bl_nm",$datarec["old_bl_nm"]);
         $hidden_old_bl_unit = new XocpFormHidden("old_bl_unit",$datarec["old_bl_unit"]);
         $hidden_old_description = new XocpFormHidden("old_description",$datarec["old_description"]);
      }
      $hidden_bl_var = new XocpFormHidden("bl_var",$datarec["bl_var"]);
      $hidden_bl_nm = new XocpFormHidden("bl_nm",$datarec["bl_nm"]);
      $hidden_bl_unit = new XocpFormHidden("bl_unit",$datarec["bl_unit"]);
      $hidden_description = new XocpFormHidden("description",$datarec["description"]);
      $label_bl_var = new XocpFormLabel(_HIND_BASELINEVAR,$datarec["bl_var"]);
      $label_bl_nm = new XocpFormLabel(_HIND_BASELINENAME,$datarec["bl_nm"]);
      $label_bl_unit = new XocpFormLabel(_HIND_BASELINEUNIT,$datarec["bl_unit"]);
      $label_description = new XocpFormLabel(_HIND_BASELINEDESC,nl2br($datarec["description"]));
      $submit_ok = new XocpFormButton("","ok",_OK,"submit");
      if ($state != "delete") {
         $submit_edit = new XocpFormButton("","edit",_EDIT,"submit");
      }
      $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
      $elementtray_button = new XocpFormElementTray("");
      $elementtray_button->addElement($submit_ok);
      if ($state != "delete") {
         $elementtray_button->addElement($submit_edit);
      }
      $elementtray_button->addElement($submit_cancel);

      // Constructing a form - Confirm Added/edited baseline
      $form = new XocpThemeForm($title,"fconfirmbaseline","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_type);
      $form->addElement($hidden_state);
      if ($state == "edit") {
         $form->addElement($hidden_old_bl_var);
         $form->addElement($hidden_old_bl_nm);
         $form->addElement($hidden_old_bl_unit);
         $form->addElement($hidden_old_description);
      }
      $form->addElement($hidden_bl_nm);
      $form->addElement($hidden_bl_var);
      $form->addElement($hidden_bl_unit);
      $form->addElement($hidden_description);
      $form->addElement($label_bl_var);
      $form->addElement($label_bl_nm);
      $form->addElement($label_bl_unit);
      $form->addElement($label_description);
      $form->addElement($elementtray_button);

      if ($state == "add") {
         $this->html->setBodyOnload(" onload='document.fconfirmbaseline.ok.focus();'");
      } else {
         $this->html->setBodyOnload(" onload='document.fconfirmbaseline.cancel.focus();'");
      }

      return $form->render();
   }
   
   function main() {
      $db =& Database::getInstance();
      $this->getparam = _HIND_CATCH_VAR."="._HIND_BASELINE_BLOCK;
      $this->postparam = new XocpFormHidden(_HIND_CATCH_VAR,_HIND_BASELINE_BLOCK);
      switch ($this->catch) {
         case _HIND_BASELINE_BLOCK:
            global $HTTP_POST_VARS,$HTTP_GET_VARS;
            if (trim($HTTP_POST_VARS["txt_find"]) != "") {
               // Search baselines
               $nm = trim($HTTP_POST_VARS["txt_find"]);
               if (!eregi("\*",$nm)) {
                  $nm = "%$nm%";
               } else {
                  $nm = str_replace("*","%",$nm);
               }
               $ret = $this->navigate($nm);
            } elseif (isset($HTTP_POST_VARS["type"])) {
               // Form handler a.k.a page script flow
               $state = $HTTP_POST_VARS["state"];  // Preserve state
               //$showcancel = ($state == "edit") ? TRUE : FALSE;  // Show cancel button on add/edit form
               $showcancel = TRUE;  // Show cancel button on add/edit form
               switch ($HTTP_POST_VARS["type"]) {
                  case "show":  // Show detail form
                     if (!isset($HTTP_POST_VARS["cancel"])) {
                        // Initialize values
                        $HTTP_POST_VARS["bl_var"] = $HTTP_POST_VARS["old_bl_var"];
                        $HTTP_POST_VARS["bl_nm"] = $HTTP_POST_VARS["old_bl_nm"];
                        $HTTP_POST_VARS["bl_unit"] = $HTTP_POST_VARS["old_bl_unit"];
                        $HTTP_POST_VARS["description"] = $HTTP_POST_VARS["old_description"];
                     }
                     if (isset($HTTP_POST_VARS["edit"])) {  // Edit
                        $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel);
                     } elseif (isset($HTTP_POST_VARS["cancel"])) {  // Cancel
                        $ret = $this->navigate();
                     } else {  // This must be delete operation, not yet implemented
                        $ret = $this->formConfirm("delete",$HTTP_POST_VARS,_HIND_BASELINEDELCONFIRMTITLE);
                     }
                     break;
                  case "addedit":  // Add/edit form
                     if (isset($HTTP_POST_VARS["save"])) {  // Save
                        if (trim($HTTP_POST_VARS["bl_var"]) != "") {  // Check for required field
                          if ($state == "add") {
                             $title = _HIND_BASELINEADDCONFIRMTITLE;
                          } else {
                             $title = _HIND_BASELINEEDITCONFIRMTITLE;
                          }
                           $ret = $this->formConfirm($state,$HTTP_POST_VARS,$title);
                        } else {
                           $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel,_HIND_BASELINESAVEERROR);
                        }
                     } elseif (isset($HTTP_POST_VARS["cancel"])) {  // Cancel
                        if ($state == "edit") {
                           // Set back to original values
                           $HTTP_POST_VARS["bl_var"] = $HTTP_POST_VARS["old_bl_var"];
                           $HTTP_POST_VARS["bl_nm"] = $HTTP_POST_VARS["old_bl_nm"];
                           $HTTP_POST_VARS["bl_unit"] = $HTTP_POST_VARS["old_bl_unit"];
                           $HTTP_POST_VARS["description"] = $HTTP_POST_VARS["old_description"];
                           $ret = $this->formShowDetail($HTTP_POST_VARS,_HIND_BASELINESAVECANCEL);
                        } else {
                           $ret = $this->navigate();
                        }
                     }
                     break;
                  case "confirm":  // Confirmation form
                     if (isset($HTTP_POST_VARS["ok"])) {  // Ok, save/delete baseline
                        if ($state == "delete") {  // Do delete baseline
                           $sql = "DELETE FROM ".XOCP_PREFIX."ind_baseline WHERE bl_var = '".$HTTP_POST_VARS["bl_var"]."'";
                           $result = $db->query($sql);
                           $comment = $db->error();
                           if ($comment == "") {
                              // Warning: this isn't the proper function
                              //if ($db->getRowsNum($result) > 0) {
                              if (mysql_affected_rows() > 0) {
                                 $comment = _HIND_BASELINEDELETESUCCESS;
                              } else {
                                 $comment = _HIND_BASELINEDELETEFAIL;
                              }
                           } else {
                              $comment = _HIND_BASELINEDELETEERROR."<br/>$comment";
                           }
                           $ret = $this->navigate();
                        } else {
                           // Check for duplicated variable
                           $sql = "SELECT tmpl_id FROM ".XOCP_PREFIX."ind_template WHERE tmpl_vars LIKE '%|".$HTTP_POST_VARS["bl_var"]."|%'";
                           $result = $db->query($sql);
                           if ($db->getRowsNum($result) > 0) {  // Duplicated variable found
                              $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel,_HIND_BASELINEDUPLICATEVAR);
                           } else {  // No duplication
                              $HTTP_POST_VARS["bl_var"] = str_replace("$","",$HTTP_POST_VARS["bl_var"]);
                              if ($state == "add") {  // New baseline, do add
                                 $sql = "INSERT INTO ".XOCP_PREFIX."ind_baseline (bl_var,bl_nm,bl_unit,description)
                                         VALUES ('".$HTTP_POST_VARS["bl_var"]."','".$HTTP_POST_VARS["bl_nm"]."','".$HTTP_POST_VARS["bl_unit"]."','".$HTTP_POST_VARS["description"]."')";
                              } else {  // Old baseline, do update
                                 $sql = "UPDATE ".XOCP_PREFIX."ind_baseline
                                         SET bl_var = '".$HTTP_POST_VARS["bl_var"]."',
                                             bl_nm = '".$HTTP_POST_VARS["bl_nm"]."',
                                             bl_unit = '".$HTTP_POST_VARS["bl_unit"]."',
                                             description = '".$HTTP_POST_VARS["description"]."'
                                         WHERE bl_var = '".$HTTP_POST_VARS["old_bl_var"]."'";
                              }
                              $result = $db->query($sql);
                              $comment = $db->error();
                              if ($comment != "") {
                                 if ($state != "add") {  // Set back to original values
                                    $HTTP_POST_VARS["bl_var"] = $HTTP_POST_VARS["old_bl_var"];
                                    $HTTP_POST_VARS["bl_nm"] = $HTTP_POST_VARS["old_bl_nm"];
                                    $HTTP_POST_VARS["bl_unit"] = $HTTP_POST_VARS["old_bl_unit"];
                                    $HTTP_POST_VARS["description"] = $HTTP_POST_VARS["old_description"];
                                 }
                                 $comment = _HIND_BASELINESAVEFAIL."<br/>".$comment;
                              } else {
                                 if ($state == "add") {
                                    unset($HTTP_POST_VARS);
                                 }
                                 $comment = _HIND_BASELINESAVESUCCESS;
                              }
                              if ($state == "add") {
                                 $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel,$comment);
                              } else {
                                 $ret = $this->formShowDetail($HTTP_POST_VARS,$comment);
                              }
                           }
                        }
                     } elseif (isset($HTTP_POST_VARS["edit"])) {
                         $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel);
                     } elseif (isset($HTTP_POST_VARS["cancel"])) {  // Cancel
                        if ($state == "add") {
                           unset($HTTP_POST_VARS);
                           $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel,_HIND_BASELINESAVECANCEL);
                        } else{
                           if ($state == "edit") {
                              // Set back to original data
                              $comment = _HIND_BASELINESAVECANCEL;
                              $HTTP_POST_VARS["bl_var"] = $HTTP_POST_VARS["old_bl_var"];
                              $HTTP_POST_VARS["bl_nm"] = $HTTP_POST_VARS["old_bl_nm"];
                              $HTTP_POST_VARS["bl_unit"] = $HTTP_POST_VARS["old_bl_unit"];
                              $HTTP_POST_VARS["description"] = $HTTP_POST_VARS["old_description"];
                           } else {
                              $comment = _HIND_BASELINEDELETECANCEL;
                           }
                           $ret = $this->formShowDetail($HTTP_POST_VARS,$comment);
                        }
                     }
                     break;
               }
            } elseif ($HTTP_GET_VARS["show"] == "y" && $HTTP_GET_VARS["x"] != "") {
               // Show baseline detail
               $sql = "SELECT bl_var,bl_nm,bl_unit,description
                       FROM ".XOCP_PREFIX."ind_baseline
                       WHERE bl_var = '".$HTTP_GET_VARS["x"]."'";
               $result = $db->query($sql);
               if ($db->getRowsNum($result) > 0) {
                  $datarec = $db->fetchArray($result);
                  $ret = $this->formShowDetail($datarec);
               } else {
                  $ret = $this->navigate();
               }
            } elseif ($HTTP_GET_VARS["p"] != "") {
               // Navigate data page
               $ret = $this->navigate($HTTP_GET_VARS["fi"],$HTTP_GET_VARS["p"],$HTTP_GET_VARS["f"]);
            } elseif (isset($HTTP_POST_VARS["btn_add"])) {
               // Add form
               $ret = $this->formAddEdit();
            } else {
               // This must be ripped out
               $ret = $this->navigate();
            }
            break;
         default:
            // Default handler
            $ret = $this->navigate();
            break;
      }
      return $ret;
   }

}
} // HEALTHINDICATOR_BASELINE_DEFINED
?>