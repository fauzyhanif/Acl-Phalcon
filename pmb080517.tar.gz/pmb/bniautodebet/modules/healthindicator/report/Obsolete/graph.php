<?php
include_once("../../../config.php");
include_once(XOCP_DOC_ROOT."/class/jpgraph/jpgraph.php");
include_once(XOCP_DOC_ROOT."/class/jpgraph/jpgraph_line.php");
include_once(XOCP_DOC_ROOT."/class/jpgraph/jpgraph_bar.php");

// A format callbakc function
function mycallback($l) {
   return trim(sprintf("%4.2f",$l));
}

$ydata = array(11,3,8,12,5,1,9,13,5,7);
$ydata2 = array(1,19,15,7,22,14,5,9,21,13);

$gJpgBrandTiming=false;

// Create the graph. These two calls are always required
$graph = new Graph(450,250);    
$graph->img->SetMargin(50,130,30,35);
$graph->SetScale("textlin");

$theme = array(
"orange","skyblue3","darkolivegreen4","aquamarine3","darkolivegreen2","lightred",
"red","wheat1","dodgerblue3","rosybrown1",
"khaki1","cyan","yellow","red");

$x=0;

$databar = array();
$place_nmbar = array();

foreach($place_name as $place_id=>$place_nm) {

   unset($ind_y);
   $ind_y = array();
   $n=0;
   foreach($year_array as $y) {
      
      if(!empty($ind_value_array[$place_id][$y])) {
         $ind_y[$n] = $ind_value_array[$place_id][$y];
      } else {
         $ind_y[$n] = "";
      }
      $n++;
   }

   unset($plot);

   if(count($year_array) >1) {
      $plot = new LinePlot($ind_y);
   } else {
      $y = $year_array[0];
      $ind_valy = array("",$ind_y[0],"");
      $plot = new LinePlot($ind_valy);
   }

   $plot->SetLegend($place_nm);
   $plot->SetColor($theme[$x]);
   $plot->SetWeight(2);
   $plot->mark->SetType(MARK_SQUARE);
   $plot->mark->SetFillColor($theme[$x]);
   $plot->mark->SetWidth(8);

   $graph->Add($plot);
   
   $x++;
}


if(count($year_array) == 1) {
   $graph->xaxis->SetTickLabels(array($year_array[0]-1,$year_array[0],$year_array[0]+1));
} else {
   $graph->xaxis->SetTickLabels($year_array);
}


$graph->yaxis->scale->SetGrace(10,10);
$graph->title->Set("$template_name");

$graph->title->SetFont(FF_FONT1,FS_BOLD);
$graph->yaxis->title->SetFont(FF_FONT1,FS_BOLD);
$graph->xaxis->title->SetFont(FF_FONT1,FS_BOLD);
$graph->yaxis->SetTickSide(SIDE_LEFT);
$graph->xaxis->SetTickSide(SIDE_DOWN);

$graph->SetColor(array(255,255,255));
$graph->SetMarginColor(array(220,220,255));
$graph->SetShadow();

// Display the graph
$graph->Stroke();

?>