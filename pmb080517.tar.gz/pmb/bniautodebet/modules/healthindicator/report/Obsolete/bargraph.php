<?php
include_once("../../../config.php");
include_once(XOCP_DOC_ROOT."/class/jpgraph/jpgraph.php");
include_once(XOCP_DOC_ROOT."/class/jpgraph/jpgraph_line.php");
include_once(XOCP_DOC_ROOT."/class/jpgraph/jpgraph_bar.php");

// A format callbakc function
function mycallback($l) {
   return trim(sprintf("%4.2f",$l));
}

$ydata = array(11,3,8,12,5,1,9,13,5,7);
$ydata2 = array(1,19,15,7,22,14,5,9,21,13);

$gJpgBrandTiming=false;

// Create the graph. These two calls are always required
$graph = new Graph(450,250);    
$graph->img->SetMargin(40,130,30,35);
$graph->SetScale("textlin");

$theme = array(
"orange","skyblue3","aquamarine3","darkolivegreen2","lightred",
"salmon1","wheat1","dodgerblue3","rosybrown1",
"khaki1","cyan","yellow","red");

$x=0;

$databar = array();
$place_nmbar = array();
foreach($place_name as $place_id=>$place_nm) {

   $place_nmbar[] = $place_nm;

   unset($ind_y);
   $ind_y = array();
   foreach($year_array as $y) {
      $ind_y[] = $ind_value_array[$place_id][$y];
   }
   
   
   unset($plot);

   if(count($year_array) >1) {
      $plot = new LinePlot($ind_y);
      $plot->SetLegend($place_nm);
      $plot->SetColor($theme[$x]);
      $plot->SetWeight(2);
//      $plot->mark->SetType(MARK_FILLEDCIRCLE);
      $plot->mark->SetType(MARK_SQUARE);
      $plot->mark->SetFillColor($theme[$x]);
      $plot->mark->SetWidth(8);


      $graph->Add($plot);
   } else {
      $y = $year_array[0];
      $ind_valy = array($ind_value_array[$place_id][$y]);
      $plot = new BarPlot($ind_valy);
      $plot->SetFillColor($theme[$x]);
      $plot->SetLegend($place_nm);
      $plot->value->Show();
      $plot->value->SetFormatCallback("mycallback");
      $databar[] = $plot;
   }
   
   $x++;
}


if(count($year_array) == 1) {
   $bplot = new GroupBarPlot($databar);
   $bplot->SetWidth(1);
   $graph->Add($bplot);
   $graph->xaxis->SetTickLabels(array(""));
} else {
   $graph->xaxis->SetTickLabels($year_array);
}


$graph->yaxis->scale->SetGrace(10);

$graph->title->Set("$template_name");

$graph->title->SetFont(FF_FONT1,FS_BOLD);
$graph->yaxis->title->SetFont(FF_FONT1,FS_BOLD);
$graph->xaxis->title->SetFont(FF_FONT1,FS_BOLD);
$graph->yaxis->SetTickSide(SIDE_LEFT);
$graph->xaxis->SetTickSide(SIDE_DOWN);

$graph->SetColor(array(255,255,255));
$graph->SetMarginColor(array(220,220,255));
$graph->yaxis->SetColor("darkred");
$graph->yaxis->SetWeight(1);
$graph->SetShadow();

// Display the graph
$graph->Stroke();

?>