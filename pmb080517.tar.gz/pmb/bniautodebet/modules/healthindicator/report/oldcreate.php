<?php
//--------------------------------------------------------------------//
// Filename : modules/menu/menu.php                                   //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-20                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('HEALTHINDICATOR VIEWGROUPS_DEFINED') ) {
   define('HEALTHINDICATOR_VIEWGROUPS_DEFINED', TRUE);

include_once(XOCP_DOC_ROOT."/modules/healthindicator/common.php");

class _healthindicator_CreateReport extends XocpBlock {
   var $parent;
   var $groupname;
   var $is_parent;
   var $space;
   var $printed;
   var $ret = "";
   var $href;
   var $sendvar = "X_healthindicator=10";
   
   function main() {
      switch($this->catch) {
         case "10" :
            global $HTTP_GET_VARS,$HTTP_POST_VARS;
            if($HTTP_GET_VARS["rep"] == 1) {
               global $group_id;
               session_register("group_id");                              // <----------- register group_id
               $group_id = $HTTP_GET_VARS["group_id"];                    // <----------- set group_id
               $db =& Database::getInstance();
               $sql = "SELECT a.tmpl_id,b.tmpl_nm,b.description from ".XOCP_PREFIX."ind_grouptmpl a"
                    . " LEFT JOIN ".XOCP_PREFIX."ind_template b USING(tmpl_id) where a.group_id = '$group_id'";
               $result = $db->query($sql);
               if($db->getRowsNum($result)>0) {

                  $form = new XocpThemeForm("Template Indikator","ind_form","index.php","get");

                  while($row=$db->fetchRow($result)) {
                     list($tmpl_id,$tmpl_nm,$description) = $row;
                     $elementtray = new XocpFormElementTray($tmpl_id,"<br />");
                     $url = $this->sendvar."&tmpl_id=$tmpl_id&rep=2";
                     $title = new XocpFormLabel("","<a href=".XOCP_SERVER_SUBDIR."/index.php?$url>".nl2br($tmpl_nm)."</a>");
                     $elementtray->addElement($title);

                     $dsc = new XocpFormLabel("",nl2br($description));
                     $elementtray->addElement($dsc);
                     $form->addElement($elementtray);
                  }
                  $ret .= $form->render();




               } else {
                  $ret = "Group template belum memiliki template";
               }
            } elseif($HTTP_GET_VARS["rep"] == 2) {
               global $tmpl_id;
               session_register("tmpl_id");                            // <----- register tmpl_id
               $tmpl_id = $HTTP_GET_VARS["tmpl_id"];
               $sql = "SELECT place_id,place_nm from places order by place_nm";
               $db =& Database::getInstance();
               $result = $db->query($sql);
               if($db->getRowsNum($result)>0) {
                  $countx = 0;
                  $elementtray = new XocpFormElementTray("Pilih Wilayah","<br />");
                  $form = new XocpThemeForm("Pemilihan Wilayah Pelaporan Indikator","ind_form","index.php","get");
                  while($row=$db->fetchRow($result)) {
                     list($place_id,$place_nm) = $row;
                     $ckbox = new XocpFormCheckBox("","place_id".$countx,array($place_id));
                     $ckbox->addOption($place_id,"<b>$place_nm</b>");
                     $elementtray->addElement($ckbox);
                     $countx++;
                  }
                  $todaydate = new XocpDateTime(getdate());
                  $periode0 = new XocpFormDateTime("Periode awal","period0",$todaydate,"year");
                  $periode1 = new XocpFormDateTime("Periode akhir","period1",$todaydate,"year");

                  $graf_t = new XocpFormSelect("Tipe Grafik","graf_t");
                  $graf_t->addOption("line","line");
                  $graf_t->addOption("bar","bar");
                  $graf_t->addOption("pie","pie");

                  $form->addElement($elementtray);
                  $form->addElement($periode0);
                  $form->addElement($periode1);
                  $form->addElement($graf_t);
                  $hidden = new XocpFormHidden("X_healthindicator","10");
                  $hidden2 = new XocpFormHidden("rep","3");
                  $c = new XocpFormHidden("c",$countx);
                  $submit = new XocpFormButton("","asdf","Proses","submit");
                  $form->addElement($hidden);
                  $form->addElement($hidden2);
                  $form->addElement($c);
                  $form->addElement($submit);
                  $ret = $form->render();
               }
            } elseif($HTTP_GET_VARS["rep"] == 3) {
               global $place_id_array;
               global $report_period;
               global $chart_t;
               global $tmpl_id;
               global $group_id;
               global $report_period0;
               global $report_period1;
               global $template_name;
               global $target_val;
               global $ind_value_array;
               global $place_name;
               global $year_array;
               session_register("place_id_array");          // <---------- register place_id_array
               session_register("report_period0");           // <---------- register report_period0
               session_register("report_period1");           // <---------- register report_period1
               session_register("chart_t");                 // <---------- register chart_t
               session_register("template_name");           // <---------- register template_name
               session_register("target_val");           // <---------- register target_val
               session_register("ind_value_array");           // <---------- register ind_value_array
               session_register("place_name");           // <---------- register place_name
               session_register("year_array");           // <----------- register year_array
               $chart_t = $HTTP_GET_VARS["graf_t"];        // <---------- set chart_t

               $period0 = new XocpDateTime();
               $period0->eatVars("period0","get");
               $period0->truncDate();
               $report_period0 = $period0->getMySQL("date");  // <---------- set report_periode0

               $period1 = new XocpDateTime();
               $period1->eatVars("period1","get");
               $period1->truncDate();
               $report_period1 = $period1->getMySQL("date");  // <---------- set report_periode1
               list($yyyy0,$mm0,$dd0) = explode("-",$report_period0);
               list($yyyy1,$mm1,$dd1) = explode("-",$report_period1);

               $wheredate = "periode LIKE '%-00-00' AND periode >= '$yyyy0' AND periode < '". ($yyyy1+1) ."'";

               for($i=0;$i<$HTTP_GET_VARS["c"];$i++) {
                  $place_var = "place_id$i";
                  if($HTTP_GET_VARS[$place_var] != "") {
                     $places[$i] = $HTTP_GET_VARS[$place_var];
                  }
               }
               $place_id_array = implode(",",$places);      // <---------- set place_id_array
               //
               // template vs place vs periode
               // 
               // laporan periode : ...
               // 
               // +- indikator ------>
               // |
               // p
               // l
               // a
               // c
               // e
               // |
               // |
               // V
               // 
               //
               //
               $db =& Database::getInstance();

               $sql = "SELECT tmpl_nm,target_val FROM ind_template WHERE tmpl_id = '$tmpl_id'";
               $result = $db->query($sql);
               list($template_name,$target_val)=$db->fetchRow($result);

               $sql = "SELECT place_id, place_nm FROM places WHERE place_id IN ($place_id_array) order by place_id";
               $result = $db->query($sql);

               if($db->getRowsNum($result)>0) {

                  $oldplace_id = "";
                  while(list($place_idx,$place_nmx) = $db->fetchRow($result)) {
                     $place_name[$place_idx] = $place_nmx;
                     $sql = "SELECT ind_value,periode FROM ind_items WHERE tmpl_id = '$tmpl_id' AND place_id = '$place_idx' AND $wheredate";
                     $result_item = $db->query($sql);
                     while(list($ind_value,$periode) = $db->fetchRow($result_item)) {
                        list($yearx,,) = explode("-",$periode);
                        $ind_value_array[$place_idx][$yearx] = $ind_value;
                     }
                  }
                  
                  
                  $tbody .= "<tr><td class=ft>&nbsp;</td>";
                  $year_array = array();
                  for($y = $yyyy0; $y <= $yyyy1; $y++) {
                     $tbody .= "<td class=ft>$y</td>";
                     $year_array[] = $y;
                  }
                  $tbody .= "</tr>";
                  foreach($place_name as $place_idx => $place_nmx) {
                     $tbody .= "<tr><td class=ca>$place_nmx</td>";
                     for($y = $yyyy0; $y <= $yyyy1; $y++) {
                        $tbody .= "<td class=ca align=center>".$ind_value_array[$place_idx][$y]."&nbsp;</td>";
                     }
                     $tbody .= "</tr>";
                  }


                  $ret .= "\n<b>$template_name</b><br><br>" . _theme::openForm() . "\n" .$tbody. "</table>";
                  $ret .= "<br><br><img src=/xocp/modules/healthindicator/report/graph.php?".time().">&nbsp;";
               }

            }
            break;
         default :
            $db =& Database::getInstance();
            $sql = "SELECT group_id,parent_id,group_nm FROM ".XOCP_PREFIX."ind_groups"
                 . " ORDER BY group_id, group_nm";
            $result = $db->query($sql);
            if($db->getRowsNum($result)>0) {
               $table = new XocpTable();
               $ret = _theme::openForm();
               $ret .= "<tr><td colspan=2 class='ft'>Group Indikator</td></tr>\n";
               while($row=$db->fetchRow($result)) {
                  list($group_id,$parent_id,$group_nm) = $row;
                  $ret .= "<tr><td class=ca>$group_id</td><td class=in><a href=".XOCP_SERVER_SUBDIR."/index.php?".$this->sendvar."&group_id=$group_id&rep=1>$group_nm</a></td></tr>\n";
               }
               
               $ret .= _theme::closeForm();


            }
            break;
      }
      return "<h4>Pembuatan Laporan Indikator</h4>".$ret;
   }
}

} // HEALTHINDICATOR_VIEWGROUPS_DEFINED
?>