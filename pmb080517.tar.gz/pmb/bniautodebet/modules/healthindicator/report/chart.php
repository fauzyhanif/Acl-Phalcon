<?php
include_once("../../../config.php");
include_once(XOCP_DOC_ROOT."/modules/healthindicator/language/".$xocpConfig["language"].".php");
include_once(XOCP_DOC_ROOT."/class/jpgraph/jpgraph.php");
include_once(XOCP_DOC_ROOT."/class/jpgraph/jpgraph_line.php");
include_once(XOCP_DOC_ROOT."/class/jpgraph/jpgraph_bar.php");
include_once(XOCP_DOC_ROOT."/class/jpgraph/jpgraph_pie.php");
include_once(XOCP_DOC_ROOT."/class/jpgraph/jpgraph_canvas.php");

$gJpgBrandTiming=false;

switch ($HTTP_GET_VARS["ctype"]) {
   case "1":
      $ctype = "BarPlot";
      break;
   case "2":
      $ctype = "LinePlot";
      break;
   case "3":
      $ctype = "PiePlot";
      break;
   default:
      $ctype = "BarPlot";
      break;
}

$p3 = explode("-",$HTTP_GET_VARS["p0"]);
$p4 = explode("-",$HTTP_GET_VARS["p1"]);

if ($p3[2] == "00" || $p4[2] == "00" || $p3[2] == "0" || $p4[2] == "0") {
   $p3[2] = "00";
} else {
   $p3[2] = "%";
}
if ($p3[1] == "00" || $p4[1] == "00" || $p3[1] == "0" || $p4[1] == "0") {
   $p3[1] = "00";
} else {
   $p3[1] = "%";
}

$p = "%-".$p3[1]."-".$p3[2];

$db =& Database::getInstance();
$sql = "SELECT periode,ind_value,target_val FROM ".XOCP_PREFIX."ind_items WHERE org_id = '".$HTTP_GET_VARS["o"]."' AND "
     . "tmpl_id = '".$HTTP_GET_VARS["x"]."' AND (periode >= '".$HTTP_GET_VARS["p0"]
     . "' AND periode <= '".$HTTP_GET_VARS["p1"]."') AND periode LIKE '$p' ORDER BY periode";
$result = $db->query($sql);
if ($db->getRowsNum($result) > 0) {
   $graph = new Graph(450,250);    
   $graph->img->SetMargin(50,130,30,35);
   $graph->SetScale("textlin");
   
   $axisx = array();
   $actual = array();
   $target = array();
   while (list($periode,$ind_value,$target_val) = $db->fetchRow($result)) {
      $axisx[] = sql2ind2($periode);
      $actual[] = $ind_value;
      $target[] = $target_val;
   }
   if (count($actual) == 1) {
      array_unshift($actual,"");
      $actual[2] = "";
      array_unshift($target,"");
      $target[2] = "";
      array_unshift($axisx,"");
      $axisx[2] = "";
   }
   // Making plot
   $plot_val = new $ctype($actual);
   if ($ctype == "LinePlot") {
      $plot_val->SetColor("blue");
      $plot_val->mark->SetType(MARK_CIRCLE);
   } elseif ($ctype == "BarPlot") {
      $plot_val->SetFillColor("cornflowerblue");
   }
   $plot_val->SetLegend(_HIND_REPORTACTUALVALUE);
   $plot_val->value->Show();
   $plot_val->value->SetFormat(trim("%s ".$HTTP_GET_VARS["un"]));
   $plot_target = new $ctype($target);
   if ($ctype == "LinePlot") {
      $plot_target->SetColor("azure4");
      $plot_target->mark->SetType(MARK_DIAMOND);
   } elseif ($ctype == "BarPlot") {
      $plot_target->SetFillColor("azure4");
   }
   $plot_target->SetLegend(_HIND_REPORTTARGETVALUE);
   $plot_target->value->Show();
   $plot_target->value->SetFormat(trim("%s ".$HTTP_GET_VARS["un"]));
   // Adding plot to chart
   if ($ctype == "LinePlot") {
      $graph->Add($plot_val);
      $graph->Add($plot_target);
   } elseif ($ctype == "BarPlot") {
      $plot_group = new GroupBarPlot(array($plot_val,$plot_target));
      $graph->Add($plot_group);
   }
   $graph->xaxis->SetTickLabels($axisx);
   $graph->xaxis->SetTextLabelInterval(2);
   $graph->xaxis->scale->SetGrace(10,10);
   $graph->yaxis->scale->SetGrace(10);
   if ($HTTP_GET_VARS["p0"] == $HTTP_GET_VARS["p1"]) {
      $per = sql2ind2($HTTP_GET_VARS["p0"]);
   } else {
      $per = sql2ind2($HTTP_GET_VARS["p0"])." - ".sql2ind2($HTTP_GET_VARS["p1"]);
   }
   $graph->title->Set($HTTP_GET_VARS["y"]);
   $graph->subtitle->Set($per);

   $graph->title->SetFont(FF_FONT1,FS_BOLD);
   $graph->yaxis->title->SetFont(FF_FONT1,FS_BOLD);
   $graph->xaxis->title->SetFont(FF_FONT1,FS_BOLD);
   $graph->yaxis->SetTickSide(SIDE_LEFT);
   $graph->xaxis->SetTickSide(SIDE_DOWN);

   $graph->SetColor(array(255,255,255));
   $graph->SetMarginColor(array(220,220,255));
   $graph->SetShadow();
} else {
   $graph = new CanvasGraph(450,250,"auto");
   $text = new Text(_HIND_REPORTNOGRAPH."\n"._HIND_INDICATORDATANOTFOUND);
   $text->SetColor("red");
   $text->Pos(0.5,0.5,"center","center");
   $text->ParagraphAlign("centered");
   $graph->AddText($text);
}

$graph->Stroke();
?>