<?php
//--------------------------------------------------------------------//
// Filename : modules/menu/menu.php                                   //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-20                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('HEALTHINDICATOR VIEWGROUPS_DEFINED') ) {
   define('HEALTHINDICATOR_VIEWGROUPS_DEFINED', TRUE);

include_once(XOCP_DOC_ROOT."/modules/healthindicator/common.php");

class _healthindicator_CreateReport extends XocpBlock {
   var $parent;
   var $groupname;
   var $is_parent;
   var $space;
   var $printed;
   var $ret = "";
   var $href;
   var $sendvar = "X_healthindicator=10";
   var $width = "100%";
   
   function getPeriod($start,$end) {
      $start = explode("-",$start);
      $end = explode("-",$end);

      if ($start[2] == "00" || $end[2] == "00" || $start[2] == "0" || $end[2] == "0") {
         $patt[2] = "00";
      } else {
         $patt[2] = "%";
      }
      if ($start[1] == "00" || $end[1] == "00" || $start[1] == "0" || $end[1] == "0") {
         $patt[1] = "00";
      } else {
         $patt[1] = "%";
      }
      
      $pattern = "%-".$patt[1]."-".$patt[2];
      
      // Year handling
      if ($start[0] != $end[0]) {
         $years = array();
         for ($i == $start[0]; $i <= $end[0]; $i++) {
            $years[] = strval($i);
         }
      } else {
         $years = array($start[0]);
      }
      // Month handling
      switch (count($years)) {
         case 1:
            $months = array();
            for ($i = $start[1]; $i <= $end[1]; $i++) {
               $months[] = strval($i);
            }
            break;
         case 2:
         default:
      }
   }

   function selectGroup() {
      global $group_id;
      session_unregister("group_id");
      unset($group_id);
      $db =& Database::getInstance();
      $sql = "SELECT g.group_id,g.parent_id,g.group_nm,te.tmpl_nm "
           . "FROM ".XOCP_PREFIX."ind_groups g LEFT JOIN ".XOCP_PREFIX."ind_grouptmpl t ON (g.group_id = t.group_id) "
           . "     LEFT JOIN ".XOCP_PREFIX."ind_template te ON (te.tmpl_id = t.tmpl_id) "
           . "ORDER BY g.group_nm,g.group_id,te.tmpl_nm";
      $result = $db->query($sql);
      $table = new XocpTable(1);
      $table->setWidth("100%");
      $hno = $table->addHeader(array(_HIND_REPORTGROUPLIST));
      if($db->getRowsNum($result)>0) {
         $grp = "";
         $str = "";
         while($row=$db->fetchRow($result)) {
            list($group_id,$parent_id,$group_nm,$tmpl_nm) = $row;
            if ($grp != $group_id && $grp != "") {
               $rno = $table->addRow(array($str));
            }
            if ($grp != $group_id) {
               $grp = $group_id;
               $str = "<a href=".XOCP_SERVER_SUBDIR."/index.php?".$this->sendvar."&group_id=$group_id&rep=1>".$group_nm."</a>";
               if ($tmpl_nm != "") {
                  $str .= "<br />&nbsp;&nbsp;$tmpl_nm<br />";
               }
            } else {
               $str .= "&nbsp;&nbsp;$tmpl_nm<br />";
            }
         }
         $rno = $table->addRow(array($str));
      } else {
         $rno = $table->addRow(array(_HIND_REPORTNOGROUP));
      }
      return $table->render();
   }
   
   function selectIndicator($comment = "") {
      global $group_id,$HTTP_GET_VARS;
      if (!session_is_registered("group_id")) {
         session_register("group_id");                              // <----------- register group_id
         $group_id = $HTTP_GET_VARS["group_id"];                    // <----------- set group_id
      }
      $db =& Database::getInstance();
      $sql = "SELECT a.tmpl_id,b.tmpl_nm FROM ".XOCP_PREFIX."ind_grouptmpl a"
           . " LEFT JOIN ".XOCP_PREFIX."ind_template b USING(tmpl_id) WHERE a.group_id = '$group_id' ORDER BY b.tmpl_nm";
      $result = $db->query($sql);
      $form = new XocpThemeForm(_HIND_REPORTINDICATORLIST,"fselectind","index.php","post");
      if ($db->getRowsNum($result)>0) {
         $elementtray_indicators = new XocpFormElementTray(_HIND_REPORTSELECTINDICATOR,"<br />");
         while($row = $db->fetchRow($result)) {
            list($tmpl_id,$tmpl_nm,$description) = $row;
            $checkbox_indicator = new XocpFormCheckBox("","tmpl_ids[]",$tmpl_id);
            $checkbox_indicator->addOption($tmpl_id,$tmpl_nm);
            $elementtray_indicators->addElement($checkbox_indicator);
         }
      } else {
         $elementtray_indicators = new XocpFormLabel(_HIND_REPORTSELECTINDICATOR,_HIND_REPORTGROUPNOINDICATOR);
      }
      $todaydate = new XocpDateTime(getdate());
      $periode0 = new XocpFormDateTime(_HIND_REPORTDATE1,"period0",$todaydate);
      $periode1 = new XocpFormDateTime(_HIND_REPORTDATE2,"period1",$todaydate);
      $chart_type = new XocpFormSelect(_HIND_REPORTCHARTTYPE,"ctype");
      $chart_type->addOption("1",_HIND_REPORTCHARTBAR);
      $chart_type->addOption("2",_HIND_REPORTCHARTLINE);
      //$chart_type->addOption("3",_HIND_REPORTCHARTPIE);
      $hidden2 = new XocpFormHidden("X_healthindicator","10");
      $hidden = new XocpFormHidden("create","x");
      $elementtray_button = new XocpFormElementTray("");
      $submit = new XocpFormButton("","proceed",_HIND_REPORTPROCEED,"submit");
      $cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
      $cancel->setExtra("onclick='fselectind.create.value=\"n\";'");
      if ($db->getRowsNum($result)>0) {
         $elementtray_button->addElement($submit);
      }
      $elementtray_button->addElement($cancel);

      $form->addElement($elementtray_indicators);
      $form->addElement($periode0);
      $form->addElement($periode1);
      $form->addElement($chart_type);
      $form->addElement($hidden2);
      $form->addElement($hidden);
      $form->addElement($elementtray_button);
      if ($comment != "") {
         $form->setComment($comment);
      }
      return $form->render();
   }
   
   function main() {
      switch($this->catch) {
         case "10" :
            global $HTTP_GET_VARS,$HTTP_POST_VARS,$ses_org_id;
            if($HTTP_GET_VARS["rep"] == 1 || $HTTP_POST_VARS["create"] == "nope") {
               $ret = $this->selectIndicator();
            } elseif($HTTP_GET_VARS["rep"] == 2) {
               global $tmpl_id;
               session_register("tmpl_id");                            // <----- register tmpl_id
               $tmpl_id = $HTTP_GET_VARS["tmpl_id"];
               $sql = "SELECT org_id,org_nm FROM ".XOCP_PREFIX."orgs ORDER BY org_nm";
               $db =& Database::getInstance();
               $result = $db->query($sql);
               if($db->getRowsNum($result)>0) {
                  $countx = 0;
                  $elementtray = new XocpFormElementTray("Pilih Wilayah","<br />");
                  $form = new XocpThemeForm("Pemilihan Wilayah Pelaporan Indikator","ind_form","index.php?".$this->sendvar,"get");
                  $form->setTheme(1);
                  while($row=$db->fetchRow($result)) {
                     list($place_id,$place_nm) = $row;
                     $ckbox = new XocpFormCheckBox("","place_id".$countx,array($place_id));
                     $ckbox->addOption($place_id,"<b>$place_nm</b>");
                     $elementtray->addElement($ckbox);
                     $countx++;
                  }
                  $todaydate = new XocpDateTime(getdate());
                  $periode0 = new XocpFormDateTime("Periode awal","period0",$todaydate,"year");
                  $periode1 = new XocpFormDateTime("Periode akhir","period1",$todaydate,"year");

                  $graf_t = new XocpFormSelect("Tipe Grafik","graf_t");
                  $graf_t->addOption("line","line");
                  $graf_t->addOption("bar","bar");
                  $graf_t->addOption("pie","pie");

                  $form->addElement($elementtray);
                  $form->addElement($periode0);
                  $form->addElement($periode1);
                  $form->addElement($graf_t);
                  $hidden = new XocpFormHidden("X_healthindicator","10");
                  $hidden2 = new XocpFormHidden("rep","3");
                  $c = new XocpFormHidden("c",$countx);
                  $submit = new XocpFormButton("","asdf","Proses","submit");
                  $form->addElement($hidden);
                  $form->addElement($hidden2);
                  $form->addElement($c);
                  $form->addElement($submit);
                  $ret = $form->render();
               }
            } elseif ($HTTP_POST_VARS["create"] == "y") {
               if ($HTTP_POST_VARS["ids"] != "") {
                  $db =& Database::getInstance();
                  $sql = "SELECT tmpl_id,tmpl_nm,description,bl_vars,tmpl_unit FROM ".XOCP_PREFIX.
                         "ind_template WHERE tmpl_id IN (".$HTTP_POST_VARS["ids"].") ORDER BY tmpl_nm";
                  $result = $db->query($sql);
                  while (list($tmpl_id,$tmpl_nm,$description,$bl_vars,$tmpl_unit) = $db->fetchRow($result)) {
                     $ret .= "<b>$tmpl_nm</b><br /><br />".nl2br($description)."<br /><br />"._HIND_REPORTBASELINEUSED.":<br />";
                     $bl_vars = ($bl_vars == "") ? array() : explode("|",$bl_vars);
                     $bl_var = array();
                     for ($i = 0; $i < count($bl_vars); $i++) {
                        $bl_var[] = "'".$bl_vars[$i]."'";
                     }
                     if (count($bl_var) > 0) {
                        $bl_vars = implode(",",$bl_var);
                        $sql = "SELECT bl_var,bl_nm,description FROM ".XOCP_PREFIX."ind_baseline WHERE bl_var IN ($bl_vars) ORDER BY bl_nm";
                        $result1 = $db->query($sql);
                        while (list($bl_var,$bl_nm,$description) = $db->fetchRow($result1)) {
                           $ret .= "<u>$bl_nm ($bl_var)</u>: ".nl2br($description)."<br />";
                        }
                     }
                     $ret .= "<br /><br />"
                           . "<img src='".XOCP_SERVER_SUBDIR."/modules/healthindicator/report/chart.php?rand=".time()
                           . "&o=$ses_org_id&x=$tmpl_id&y=".urlencode($tmpl_nm)."&p0=".$HTTP_POST_VARS["periode0"]
                           . "&p1=".$HTTP_POST_VARS["periode1"]."&ctype=".$HTTP_POST_VARS["ctype"]."&un=".urlencode($tmpl_unit)."'><br /><br /><hr />";
                  }
               } else {
                  $ret = $this->selectGroup();
               }
            } elseif ($HTTP_POST_VARS["create"] == "n") {
               $ret = $this->selectGroup();
            } elseif ($HTTP_POST_VARS["create"] == "x") {
               if (count($HTTP_POST_VARS["tmpl_ids"]) > 0) {
                  $p0 = new XocpDateTime();
                  $p0->eatVars("period0","post");
                  $p1 = new XocpDateTime();
                  $p1->eatVars("period1","post");
                  $p3 = explode("-",$p0->getMySQL());
                  $p4 = explode("-",$p1->getMySQL());

                  if ($p3[2] == "00" || $p4[2] == "00" || $p3[2] == "0" || $p4[2] == "0") {
                     $p3[2] = "00";
                  } else {
                     $p3[2] = "%";
                  }
                  if ($p3[1] == "00" || $p4[1] == "00" || $p3[1] == "0" || $p4[1] == "0") {
                     $p3[1] = "00";
                  } else {
                     $p3[1] = "%";
                  }
                  $p = "%-".$p3[1]."-".$p3[2];
                  $db =& Database::getInstance();
                  $ids = implode(",",$HTTP_POST_VARS["tmpl_ids"]);
                  $ctype = $HTTP_POST_VARS["ctype"];
                  $sql = "SELECT t.tmpl_id,t.tmpl_nm,t.description,i.ind_value,i.target_val,i.periode FROM ".
                          XOCP_PREFIX."ind_template t LEFT JOIN ".XOCP_PREFIX."ind_items i USING(tmpl_id) ".
                          "WHERE t.tmpl_id IN ($ids) AND i.org_id = $ses_org_id AND (i.periode >= '".
                          $p0->getMySQL()."' AND i.periode <= '".$p1->getMySQL()."') AND i.periode LIKE '$p' ORDER BY t.tmpl_nm";
                  $result = $db->query($sql);
                  $indicators = array();
                  $per = array();
                  if ($db->getRowsNum($result) > 0) {
                     while (list($tmpl_id,$tmpl_nm,$description,$ind_value,$target_val,$periode) = $db->fetchRow($result)) {
   	                  if (!in_array(sql2ind2($periode),$per)) {
   		                 $per[] = sql2ind2($periode);
   	                  }
   	                  $indicators[$tmpl_id]["tmpl_nm"] = $tmpl_nm;
   	                  $indicators[$tmpl_id]["description"] = $description;
   	                  $indicators[$tmpl_id]["periode"][sql2ind2($periode)] = "$ind_value ($target_val)";
                     }
                     $footer = new XocpSimpleTable();
                     $footer->setWidth("100%");
                     $hidden1 = new XocpFormHidden("X_healthindicator","10");
                     $hidden2 = new XocpFormHidden("create","y");
                     $hidden3 = new XocpFormHidden("ids",$ids);
                     $hidden4 = new XocpFormHidden("periode0",$p0->getMySQL());
                     $hidden5 = new XocpFormHidden("periode1",$p1->getMySQL());
                     $hidden6 = new XocpFormHidden("ctype",$ctype);
                     $button_showchart = new XocpFormButton("","showchart",_HIND_REPORTSHOWCHART,"submit");
                     $button_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
                     $button_cancel->setExtra("onclick='fshowchart.create.value=\"nope\";'");
                     $elemtray_buttons = new XocpFormElementTray();
                     $elemtray_buttons->addElement($button_showchart);
                     $elemtray_buttons->addElement($button_cancel);
                     $form = new XocpSimpleForm("","fshowchart",XOCP_SERVER_SUBDIR."/index.php");
                     $form->addElement($elemtray_buttons);
                     $form->addElement($hidden1);
                     $form->addElement($hidden2);
                     $form->addElement($hidden3);
                     $form->addElement($hidden4);
                     $form->addElement($hidden5);
                     $form->addElement($hidden6);
                     $drow = $footer->addRow($form->render());
                     $footer->setCellAlign($drow,"right");	
                  
                     $table = new XocpTable(1);
                     $hrow = $table->addHeader(_HIND_REPORTINDICATORTABLE);
                     $table->setColSpan($hrow,count($per) + 1);
                     $hrow = $table->addFooter($footer->render());
                     $table->setColSpan($hrow,count($per) + 1);
                     $table->setWidth("100%");
                  
                     $title = array("<p align='right'>"._HIND_INDICATORPERIOD."</p><p align='left'>"._HIND_TEMPLATENAME."</p>");
                     $title = array_merge($title,$per);
                     $halign = array_pad(array(),count($per) + 1,"center");
                     $drow = $table->addRow($title);
                     $table->setCellAlign($drow,$halign);
                     $ralign = array_pad(array(""),count($per) + 1,"right");
                     foreach ($indicators as $key => $val) {
   	                 $val_array = array($val["tmpl_nm"]."<br />".$val["description"]);
   	                 for ($i = 0; $i < count($per); $i++) {
   		                if ($val["periode"][$per[$i]] != "") {
   		                   $val_array[] = $val["periode"][$per[$i]];
   	                    } else {
   		                   $val_array[] = "-";
   	                    }
   	                 }
   	                 $drow = $table->addRow($val_array);
   	                 $table->setCellAlign($drow,$ralign);
                     }
                     $ret = $table->render();
                  } else {
                     $ret = $this->selectIndicator(_HIND_INDICATORDATANOTFOUND);
                  }
               } else {
                  $ret = $this->selectGroup();
               }
            }
            break;
         default :
            $ret = $this->selectGroup();
            break;
      }
      return $ret;
   }
}

} // HEALTHINDICATOR_VIEWGROUPS_DEFINED
?>