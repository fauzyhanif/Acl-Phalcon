
############# DHS PROJECT #############################      
#######################################################
# INDIKATOR KESEHATAN

# untuk modul indikator kesehatan, tabel-tablenya
# sudah cukup stabil, dan reliable untuk mengatasi
# segala kondisi.

CREATE TABLE ind_groups (
  group_id int(10) unsigned NOT NULL auto_increment,
  parent_id int(10) unsigned NOT NULL default '0',
  group_nm char(200) NOT NULL default '',
  PRIMARY KEY (group_id)
);

CREATE TABLE ind_template (
  tmpl_id int(10) unsigned NOT NULL auto_increment,
  tmpl_nm text NOT NULL,
  tmpl_vars text NOT NULL,
  bl_vars text NOT NULL,
  tmpl_unit text NOT NULL,
  formula text NOT NULL,
  description text NOT NULL,
  target_val char(10) NOT NULL default '',
  PRIMARY KEY (tmpl_id)
);

CREATE TABLE ind_baseline (
  bl_var char(10) NOT NULL,
  bl_nm char(250) NOT NULL,
  bl_unit char(10) NOT NULL,
  description text NOT NULL,
  PRIMARY KEY (bl_var)
);

CREATE TABLE ind_baselinedata (
  org_id int(10) unsigned NOT NULL default '0',
  bl_var char(10) NOT NULL default '',
  valid0 char(10) NOT NULL default '0000-00-00',
  valid1 char(10) NOT NULL default '0000-00-00',
  bl_val char(30) NOT NULL default ''
);

CREATE TABLE ind_grouptmpl (
  group_id int(10) unsigned NOT NULL default '0',
  tmpl_id int(10) unsigned NOT NULL default '0',
  PRIMARY KEY (group_id,tmpl_id)
);

CREATE TABLE ind_items (
  org_id int(10) unsigned NOT NULL default '0',
  ind_id int(10) unsigned NOT NULL default '0',

  ind_nm text NOT NULL,
  description text NOT NULL,
  tmpl_id int(10) unsigned NOT NULL default '0',
  ind_vars text NOT NULL,
  ind_value text NOT NULL,
  periode char(10) NOT NULL default '0000-00-00',
  created datetime NOT NULL default '0000-00-00 00:00:00',
  modified datetime NOT NULL default '0000-00-00 00:00:00',
  publish enum('n','y') NOT NULL default 'y',
  PRIMARY KEY (org_id,ind_id)
);

# table : ind_orglink
# dengan table ini, maka wilayah atas (propinsi), bisa
# merekap/merangkum indikator bawah (kabupaten)

CREATE TABLE ind_orglink (
  org_id int(10) unsigned NOT NULL default '0',     # super org.
  sub_id int(10) unsigned NOT NULL default '0',     # sub org.
  PRIMARY KEY  (org_id,sub_id)
) TYPE=MyISAM;

CREATE TABLE ind_pgroup_org (
  pgroup_id int(10) unsigned NOT NULL default '0',
  org_id int(10) unsigned NOT NULL default '0',
  PRIMARY KEY (pgroup_id,org_id)
) TYPE=MyISAM;




