<?php
//--------------------------------------------------------------------//
// Filename : modules/ehr/patient.php                                 //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-03-24                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('EHR_PATIENT_DEFINED') ) {
   define('EHR_PATIENT_DEFINED', TRUE);
   
include_once(XOCP_DOC_ROOT."/modules/ehr/modconsts.php");
      
class _ehr_PatientRegistration extends XocpBlock {
   var $width = "100%";
   var $postparam;
   var $getparam;
  
  function formSearch($datarec=NULL,$comment=""){

      $frm_search = new XocpThemeForm(_EHR_PATIENT_SEARCHPERSON,"frm_search",XOCP_SERVER_SUBDIR."/index.php","get");
      $txt0_search = new XocpFormText(_EHR_PATIENTEXTID,"patient_mrn",20,50,$datarec["patient_mrn"]);
      $txt1_search = new XocpFormText(_EHR_PATIENT_PERSONNAME,"person_nm_txt",20,50,$datarec["person_nm_txt"]);
      $btn1_search = new XocpFormButton("","btn_search",_SEARCH,"submit");
      $btn2_search = new XocpFormButton("","btn_new",_NEW,"submit");
      $buttons = new XocpFormElementTray("");
      $hdn1_search = new XocpFormHidden("X_ehr",_EHR_PATIENTREG_BLOCK);
      $buttons->addElement($btn1_search);
      $buttons->addElement($btn2_search);

      $frm_search->addElement($txt0_search);
      $frm_search->addElement($txt1_search);
      $frm_search->addElement($buttons);
      $frm_search->addElement($hdn1_search);
      $frm_search->setComment($comment);
       
      return $frm_search->render();

  }
  
  
   ///////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////
   function doSearch($datarec) {
      global $ehr_ses_ehr_id;
      $db =& Database::getInstance();

      $nm = trim($datarec["person_nm_txt"]);
      $mrn = trim($datarec["patient_mrn"]);

      if($mrn != "") {
         $mrn = str_replace("*","%",$mrn);
         $sql = "SELECT p.person_id,p.person_nm,p.addr_txt,pt.patient_ext_id,pt.patient_id"
              . " FROM ".XOCP_PREFIX."persons p"
              . " LEFT JOIN ".XOCP_PREFIX."ehr_patient pt USING (person_id)"
              . " WHERE pt.patient_ext_id LIKE '$mrn' AND pt.org_id = '$ehr_ses_ehr_id'";
      } elseif ($nm != "") {
         if (!eregi("\*",$nm)) {
            $nm = "%$nm%";
         } else {
            $nm = str_replace("*","%",$nm);
         }
         $sql = "SELECT p.person_id,p.person_nm,p.addr_txt,pt.patient_ext_id,pt.patient_id"
              . " FROM ".XOCP_PREFIX."persons p"
              . " LEFT JOIN ".XOCP_PREFIX."ehr_patient pt USING (person_id)"
              . " WHERE p.person_nm LIKE '$nm'";
      } else {
         $ret = $this->formSearch($datarec);
         return $ret;
      }
      
      
      $result = $db->query($sql);
      if ($db->getRowsNum($result) > 0) {
         $dp = new XocpDataPage();
         $dp->setPageSize(5);
         while ($row = $db->fetchRow($result)) {
            list($person_id,$person_nm,$addr_txt,$patient_ext_id,$patient_id) = $row;
            similar_text($person_nm,str_replace("%","",$nm),$score);
            $link = XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&edit=y&person_id=$person_id";
            $dp->addData(array("<a href='$link'>$person_nm</a>",$person_nm,$addr_txt,$patient_ext_id,$patient_id,$score));
         }
         array_reverse($dp->data);
         $dp->serialize();
         $search_result = $this->navigate($dp->getFile(),0);
         if ($dp->getCount() > 5) {
            $comment = _EHR_SEARCHPATIENTINFO;
         }
      } else {
         $comment = _EHR_PATIENTNOTFOUND;
         $search_result = "";
      }
      $ret = $this->formSearch($datarec,$comment)."<br />".$search_result;
      return $ret;
   }
   

   function navigate($f,$p) {
      $dp = XocpDataPage::unserialize($f);
      // Set page number
      $dp->setPage($p);
      $dp_found = $dp->getCount();
      $no1 = $dp->getOffset() + 1;
      $no2 = $no1 + $dp->getPageSize() - 1;
      if ($dp_found <= $no2) {
         $no2 = $dp_found;
      }
      // Creating header
      $dp_header = new XocpSimpleTable();
      $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam);
      $title = "<font class='tdh1'>"._EHR_PRSN_SEARCHRESULT." ($no1 - $no2 "._OF." $dp_found)</font>";
      // How many page in data page?
      if (count($dp->getPageArray()) > 1) {  // More than 1, show navigation links
         $hrow = $dp_header->addRow($title,$dp_prevnext);
      } else {
         $hrow = $dp_header->addRow($title);
      }
      $dp_header->setCellAlign($hrow,array("","right"));
      $dp_header->setWidth("100%");

      // Creating footer
      $dp_footer = new XocpSimpleTable();
      if (count($dp->getPageArray()) > 1) {  // More than 1, show navigation links
         $frow = $dp_footer->addRow("&nbsp;",$dp_prevnext);
      } else {
         $frow = $dp_footer->addRow("&nbsp;");
      }
      $dp_footer->setCellAlign($frow,array("","right"));
      $dp_footer->setWidth("100%");
                                    
      // Creating data page
      $dp_table = new XocpTable(1);
      $dp_table->setWidth("100%");
      $hrow = $dp_table->addHeader($dp_header->render());
      $frow = $dp_table->addFooter($dp_footer->render());
                                           
      // Populating data page
      $dp_data = $dp->retrieve();
      foreach ($dp_data as $row) {
         list($link,$person_nm,$addr_txt,$patient_ext_id,$patient_id,$score) = $row;
         if($patient_id > 0) {
            $is_reg = "[ $patient_ext_id ]";
         } else {
            $is_reg = _EHR_PATIENT_UNREGISTERED;
         }
         $drow = $dp_table->addRow("$is_reg<br/>$link<br />".nl2br($addr_txt));
      }
                                                                     
      return $dp_table->render();
   }
   

  ///////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////
  
  function searchResult($name,&$found){
    global $ehr_ses_ehr_id,$xocp_page_id ;
    $db =& Database::getInstance();

    $queryname = str_replace("*","%",$name);
    $sql = "SELECT ps.person_id, ps.person_nm, ps.addr_txt, pt.patient_id, pt.status_cd"
         . " FROM ".XOCP_PREFIX."persons ps"
         . " LEFT JOIN ".XOCP_PREFIX."ehr_patient pt USING(person_id)" 
         . " WHERE ps.person_nm LIKE '$queryname'" 
         . " ORDER BY ps.person_nm";
    
    $result = $db->query($sql);
    $found = $db->getRowsNum($result);
    
    $dp = new XocpDataPage();
    $dp->setPageSize(20);

    while( list($person_id,$person_nm,$addr_txt,$patient_id,$status_cd) = $db->fetchRow($result)) { 
      $dp->addData( array($person_id,$person_nm,$addr_txt,$patient_id,$status_cd) );
    }
    $dp->serialize();
       
    $xurl = XOCP_SERVER_SUBDIR."/index.php?X_ehr="._EHR_PATIENTREG_BLOCK;
    $prevnext = $dp->getPageLinks($xurl);
      
    $htable = new XocpSimpleTable();
    $sno = $htable->addRow(_EHR_PRSN_SEARCHRESULT." : $found "._FOUND,$prevnext);
    $htable->setCellAlign($sno,array("","right"));
    $htable->setWidth("100%");

    $ftable = new XocpSimpleTable();
    $sno = $ftable->addRow($prevnext);
    $ftable->setCellAlign($sno,array("right"));
    $ftable->setWidth("100%");

    $table = new XocpTable(1);
    $table->setWidth("100%");
    $hno = $table->addHeader($htable->render());
    $fno = $table->addFooter($ftable->render());
                  
    $dp->reset();
    $no = $dp->getOffset() + 1;
    $data = $dp->retrieve();
    
    foreach($data as $x) {
      list($person_id,$person_nm,$addr_txt,$patient_id,$status_cd) = $x;
      $rno = $table->addRow("$no. <a href=".XOCP_SERVER_SUBDIR."/index.php?X_ehr="._EHR_PATIENTREG_BLOCK."&edit=y&person_id=$person_id".">$person_nm</a><br>$person_id<br>$addr_txt<br>$status_cd");
      $no++;
    }

     return $table->render();
     
  }
  

   function editPerson($person_id = 0,$person_nm) {
      global $xocp_vars;
      
      $form = new XocpThemeForm(_SYS_PRSN_EDITFORM, "updatepersonform", "index.php","post",TRUE);
      $submit_button = new XocpFormButton("", "saveperson", _SUBMIT, "submit");
      $cancel_button = new XocpFormButton("", "cancel", _CANCEL, "button");
      $reset_button = new XocpFormButton("", "reset", _RESET, "reset");
      $cancel_button->setExtra("onclick=\"javascript:history.go(-1);\"");
      $elementtray_buttons = new XocpFormElementTray("");
      $elementtray_buttons->addElement($submit_button);
      $elementtray_buttons->addElement($cancel_button);
      $elementtray_buttons->addElement($reset_button);
   
      if($person_id > 0) {
         $db =& Database::getInstance();
         $sql = "SELECT person_id,person_nm,ssn,ext_id,adm_gender_cd,"
              . "addr_txt,zip_cd,telecom FROM ".XOCP_PREFIX."persons "
              . " WHERE person_id = '".$person_id."'";
         $result = $db->query($sql);
         list($person_id,$person_nm,$ssn,$ext_id,$gender,$addr_txt,$zip_cd,$telecom) = $db->fetchRow($result);
         $hperson_id = new XocpFormHidden("person_id","$person_id");
         $form->addElement($hperson_id);
         $delete_button = new XocpFormButton("", "deleteperson", _DELETE, "submit");
         $elementtray_buttons->addElement($delete_button);
      } else {
         $gender = "m";
         $form->setTitle(_SYS_PRSN_ADDFORM);
      }
   
      $personname = new XocpFormText(_SYS_PRSN_PERSONNAME, "person_nm", 40, 100, "$person_nm");
      $personssn = new XocpFormText(_SYS_PRSN_PERSONSSN, "ssn", 40, 100, "$ssn");
      $personext_id = new XocpFormText(_SYS_PRSN_PERSONEXT_ID, "ext_id", 40, 100, "$ext_id");
      $persongd = new XocpFormRadio(_SYS_PRSN_PERSONGENDER, "gender", "$gender");
      $persongd->addOptionArray($xocp_vars["gender"]);
      $personaddr_txt = new XocpFormText(_SYS_PRSN_PERSONADDR_TXT, "addr_txt", 40, 255, "$addr_txt");
      $personzip_cd = new XocpFormText(_SYS_PRSN_PERSONZIP_CD, "zip_cd", 10, 10, "$zip_cd");
      $persontelecom = new XocpFormText(_SYS_PRSN_PERSONTELECOM, "telecom", 40, 30, "$telecom");
      $hidden = new XocpFormHidden("X_ehr",_EHR_PATIENTREG_BLOCK);
      
      
      $form->setRequired(array("person_nm"));
               
      $form->addElement($personname);
      $form->addElement($personssn);
      $form->addElement($personext_id);
      $form->addElement($persongd);
      $form->addElement($personaddr_txt);
      $form->addElement($personzip_cd);
      $form->addElement($persontelecom);
      $form->addElement($hidden);
      $form->addElement($elementtray_buttons);
   
      return $form->render();
   
   }



  
   function editPatient($person_id,$comment=""){
      global $ehr_ses_ehr_id;
      
      $patient_id = 0;
      $db =& Database::getInstance();
      $sql = "SELECT pt.patient_id, pt.patient_ext_id, ps.person_nm, pt.status_cd, pt.vip_cd, pt.confidentiality_cd"
           . " FROM ".XOCP_PREFIX."persons ps"
           . " LEFT JOIN ".XOCP_PREFIX."ehr_patient pt USING(person_id)" 
           . " WHERE ps.person_id = '$person_id'"; 
  
      $result = $db->query($sql);
      
      list($patient_id,$patient_ext_id,$person_nm,$status_cd,$vip_cd,$conf_cd) = $db->fetchRow($result);
      if(empty($patient_id)) {
        $sql = "SELECT MAX(patient_id) FROM ".XOCP_PREFIX."ehr_patient"
             . " WHERE org_id = '$ehr_ses_ehr_id'";
        $result = $db->query($sql);
        list($patient_id) = $db->fetchRow($result);
        $patient_id++;
        $sql = "INSERT INTO ".XOCP_PREFIX."ehr_patient(org_id,patient_id,person_id,rc_dttm)"
             . " VALUES ('$ehr_ses_ehr_id','$patient_id','$person_id',now() )";
        $result = $db->query($sql);
      }  elseif($status_cd == "nullified") {
         $sql  = "UPDATE ".XOCP_PREFIX."ehr_patient SET status_cd = 'normal'";
         $sql .= " WHERE person_id = '".$HTTP_POST_VARS["person_id"]."'";
         $sql .= " AND org_id = '$ehr_ses_ehr_id'";
         $result = $db->query($sql);
      
      }
      
      $frm_edit = new XocpThemeForm(_EHR_PATIENT_EDITFORM, "frm_editpatient", 
                                    XOCP_SERVER_SUBDIR."/index.php","post",TRUE);
      
      $lbl_person_nm      = new XocpFormLabel(_EHR_PATIENT_PERSONNAME,$person_nm);
      $txt_patient_ext_id = new XocpFormText(_EHR_PATIENTEXTID,"patient_ext_id",40,100,$patient_ext_id);

      $rb_vip_cd        = new XocpFormRadioYN(_EHR_PATIENT_VIP,"rbvip",$vip_cd);
      $rb_confidentiality_cd =  new XocpFormRadioYN(_EHR_PATIENT_CONFIDENTIALITY,"rbconf",$conf_cd);
      
      $hperson = new XocpFormHidden("person_id",$person_id);
      $hidden  = new XocpFormHidden("X_ehr",_EHR_PATIENTREG_BLOCK);
      
      $frm_edit->addElement($lbl_person_nm);
      $frm_edit->addElement($txt_patient_ext_id);
//      $frm_edit->addElement($rb_vip_cd);
//      $frm_edit->addElement($rb_confidentiality_cd);
      
      $elm_buttons = new XocpFormElementTray("");
       
      $submit_button = new XocpFormButton("", "btn_savepatient", _SAVE, "submit");
      $reset_button = new XocpFormButton("", "btn_reset", _RESET, "reset");
      $cancel_button = new XocpFormButton("", "btn_cancel", _CANCEL, "button");
      $cancel_button->setExtra("onclick=\"javascript:history.go(-1);\"");
      $delete_button = new XocpFormButton("","btn_deletepatient", _DELETE, "submit");
      
      $elm_buttons->addElement($submit_button);
      $elm_buttons->addElement($cancel_button);
      $elm_buttons->addElement($reset_button);
      $elm_buttons->addElement($delete_button);
      
      $frm_edit->addElement($elm_buttons);
      $frm_edit->addElement($hperson);
      $frm_edit->addElement($hidden);
      
      $frm_edit->setComment($comment);
      $frm_edit->setRequired("patient_ext_id");
     
      return $frm_edit->render();
  
    }


  function main() {
     global $HTTP_GET_VARS,$HTTP_POST_VARS,$ehr_ses_org_id,$ehr_ses_ehr_id;
     $db =& Database::getInstance();

     $this->getparam = _EHR_CATCH_VAR."="._EHR_PATIENTREG_BLOCK;
     $this->postparam = new XocpFormHidden(_EHR_CATCH_VAR,_EHR_PATIENTREG_BLOCK);

     switch ($this->catch) {
      case _EHR_PATIENTREG_BLOCK :
         if ( trim($HTTP_GET_VARS["person_nm_txt"]) != "" || trim($HTTP_GET_VARS["patient_mrn"]) != "" ) {
            if($HTTP_GET_VARS["btn_new"] != '') {
               $ret = $this->editPerson(0,trim($HTTP_GET_VARS["person_nm_txt"]));
            } else {
               $ret = "<br />" . $this->doSearch($HTTP_GET_VARS);
            }

         } elseif ($HTTP_GET_VARS["p"] != "") {
            $ret = $this->formSearch(NULL)."<br />".$this->navigate($HTTP_GET_VARS["f"],$HTTP_GET_VARS["p"]);

         } elseif($HTTP_GET_VARS["btn_new"] != '') {
            $ret = $this->editPerson(0,"",_EHR_PATIENTREG_BLOCK);

         } elseif($HTTP_GET_VARS["edit"] == "y") {
            $ret = $this->editPerson($HTTP_GET_VARS["person_id"],"");

         } elseif(!empty($HTTP_POST_VARS["person_nm"])) {
            $person_id = $HTTP_POST_VARS["person_id"];
            if($person_id > 0) {
               $sql = "UPDATE ".XOCP_PREFIX."persons set person_nm = '".$HTTP_POST_VARS["person_nm"]."',"
                    . " ssn = '".$HTTP_POST_VARS["ssn"]."',"
                    . " ext_id = '".$HTTP_POST_VARS["ext_id"]."',"
                    . " adm_gender_cd = '".$HTTP_POST_VARS["gender"]."',"
                    . " addr_txt = '".$HTTP_POST_VARS["addr_txt"]."',"
                    . " zip_cd = '".$HTTP_POST_VARS["zip_cd"]."',"
                    . " telecom = '".$HTTP_POST_VARS["telecom"]."'"
                    . " WHERE person_id = '".$HTTP_POST_VARS["person_id"]."'";
               $result = $db->query($sql);
            } else {
               $sql = "INSERT INTO ".XOCP_PREFIX."persons (person_nm,ssn,ext_id,adm_gender_cd,"
                    . "addr_txt,zip_cd,telecom)"
                    . " VALUES ('".$HTTP_POST_VARS["person_nm"]."','".$HTTP_POST_VARS["ssn"]
                    . "','".$HTTP_POST_VARS["ext_id"]."','".$HTTP_POST_VARS["gender"]
                    . "','".$HTTP_POST_VARS["addr_txt"]."','".$HTTP_POST_VARS["zip_cd"]
                    . "','".$HTTP_POST_VARS["telecom"]."')";
               $result = $db->query($sql);
               $person_id = $db->getInsertId();
            }
            $ret = $this->editPatient($person_id);

         } elseif ($HTTP_POST_VARS["btn_deletepatient"] != '') {
            $sql  = "UPDATE ".XOCP_PREFIX."ehr_patient SET status_cd = 'nullified'";
            $sql .= " WHERE person_id = '".$HTTP_POST_VARS["person_id"]."'";
            $sql .= " AND org_id = '$ehr_ses_ehr_id'";
            $result = $db->query($sql);
            $ret = $this->formSearch(NULL,_EHR_PATIENT_PATIENTDELETED);
            
         } elseif ($HTTP_POST_VARS["btn_savepatient"] != '') {
            $sql  = "UPDATE ".XOCP_PREFIX."ehr_patient SET ";
            $sql .= " vip_cd = '".$HTTP_POST_VARS["rbvip"]."',";
            $sql .= " patient_ext_id = '".$HTTP_POST_VARS["patient_ext_id"]."',";
            $sql .= " confidentiality_cd = '".$HTTP_POST_VARS["rbconf"]."'";
            $sql .= " WHERE person_id = '".$HTTP_POST_VARS["person_id"]."'";
            $sql .= " AND org_id = '$ehr_ses_ehr_id'";
            $result = $db->query($sql);
            echo $sql;
            $ret = $this->formSearch(NULL,_EHR_PATIENT_PATIENTSAVED);
               
         }

         break;

      default:
           if($ehr_ses_ehr_id == "0") {
              $ret = "";
           } else {
             $ret = $this->formSearch();
           }
           break;
    }
    return $ret;
  }

}

} //EHR_PATIENT_DEFINED

?>