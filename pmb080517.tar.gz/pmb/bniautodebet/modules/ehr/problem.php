<?php
//--------------------------------------------------------------------//
// Filename : modules/ehr/problem.php                                 //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-03-24                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('EHR_PATIENTPROBLEM_DEFINED') ) {
   define('EHR_PATIENTPROBLEM_DEFINED', TRUE);

include_once(XOCP_DOC_ROOT."/modules/ehr/modconsts.php");
   
class _ehr_PatientProblem extends XocpBlock {
   var $width = "100%";
   var $postparam;
   var $getparam;
   var $language;

   function _ehr_PatientProblem($catch=NULL) { /* fungsi konstruktor wajib punya parameter $catch
                                                  yang diteruskan ke konstruktor parent class */
      global $xocpConfig,$xocp_user;
      
      $this->XocpBlock($catch);                /* ini meneruskan $catch ke parent constructor */
      
      $mylanguage = $xocp_user->getVar("language");
      if($mylanguage == '') {
         $mylanguage = $xocpConfig["language"];
      }
      
      $this->language = $mylanguage;
      
   }
   
   function getLanguage() {
      return $this->language;
   }

   
   function browseChapter() {
      global $HTTP_GET_VARS;
      
         $db = Database::getInstance();
         $sql = "SELECT chapter_id,english_nm,".$this->getLanguage()
              . "_nm,start_ct,stop_ct from ".XOCP_PREFIX."ehr_icd_chapter"
              . " ORDER BY chapter_id";
         $result = $db->query($sql);
         $found = $db->getRowsNum($result);
         $dp = new XocpDataPage();
         $dp->setPageSize(0);
         if($found > 0) {
            while($row=$db->fetchRow($result)) {
               $dp->addData($row);
            }
            $dp->reset();
         }

      $xurl = XOCP_SERVER_SUBDIR."/index.php?".$this->getparam;

      $table = new XocpTable(1);
      $table->setWidth("100%");

      $hno = $table->addHeader($this->searchForm());
      $table->setColSpan($hno,2);
      $table->setCellAlign($hno,"right");

      $hno = $table->addHeader(_EHR_ICD_CHAPTERLIST." : $found "._FOUND);
      $table->setColSpan($hno,2);

      $fno = $table->addFooter($this->searchForm());
      $table->setColSpan($fno,2);
      $table->setCellAlign($fno,"right");
      
      $data = $dp->retrieve();
      foreach($data as $x) {
         list($chapter_id,$english_name,$chapter_name,$start_ct,$stop_ct) = $x;

         if(trim($chapter_name) == "") {
            $chapter_name = $english_name;
         }

         $rno = $table->addRow("<b>$chapter_id</b>","$chapter_name [$start_ct-$stop_ct] <a href='$xurl&chapterlink=y&x=$chapter_id'>[v]</a>");
         $table->setCellAlign($rno,"right");
      }

      return $table->render();

   }
   

   function browseBlock($chapter_id) {
      global $HTTP_GET_VARS;
      
      $db = Database::getInstance();
      $result = $db->query("SELECT english_nm,".$this->getLanguage()."_nm,start_ct,stop_ct FROM ".XOCP_PREFIX."ehr_icd_chapter WHERE chapter_id = '$chapter_id'");
      list($chapter_english_name,$chapter_name,$start_ct,$stop_ct) = $db->fetchRow($result);
      if(trim($chapter_name) == "") {
         $chapter_name = $chapter_english_name;
      }
         
      $sql = "SELECT block_id,parentblock_id,english_nm,".$this->getLanguage()
           . "_nm,start_ct,stop_ct FROM ".XOCP_PREFIX."ehr_icd_block"
           . " WHERE chapter_id = '$chapter_id'"
           . " ORDER BY block_id";
      $result = $db->query($sql);
      $found = $db->getRowsNum($result);
      $dp = new XocpDataPage();
      $dp->setPageSize(0);
      if($found > 0) {
         while($row=$db->fetchRow($result)) {
            $dp->addData($row);
         }
      }
      $dp->reset();

      $xurl = XOCP_SERVER_SUBDIR."/index.php?".$this->getparam;
      $selectchapterlink = "<a href='$xurl&slch=y'>[^]</a>";
      
      $table = new XocpTable(1);
      $table->setWidth("100%");

      $hno = $table->addHeader($this->searchForm());
      $table->setColSpan($hno,3);
      $table->setCellAlign($hno,"right");
      
      $hno = $table->addHeader("$chapter_id - $chapter_name $selectchapterlink");
      $table->setColSpan($hno,3);

      $fno = $table->addFooter($this->searchForm());
      $table->setColSpan($fno,3);
      $table->setCellAlign($fno,"right");
      
      $data = $dp->retrieve();
      foreach($data as $x) {
         list($block_id,$parentblock_id,$block_english_name,$block_name,$start_ct,$stop_ct) = $x;
         if(trim($block_name) == "") {
            $block_name = $block_english_name;
         }

         $browselink = "<a href=$xurl&blocklink=y&x=$chapter_id&y=$block_id".">[v]</a>";
         $addlink = "<a href=$xurl&addproblemblocklink=y&x=$chapter_id&y=$block_id".">[+]</a>";
         if($parentblock_id > 0) {
            $rno = $table->addRow("","<b>$block_id</b>","$block_name [$start_ct-$stop_ct] $addlink $browselink");
            $table->setCellAlign($rno,"","right");
         } else {
            $rno = $table->addRow("<b>$block_id</b>","$block_name [$start_ct-$stop_ct] $addlink $browselink");
            $table->setColSpan($rno,1,2);
            $table->setCellAlign($rno,"right");
         }
         
      }

      return $table->render();

   }
   

   function browseItem($chapter_id,$block_id,$q="") {
      global $HTTP_GET_VARS;
      
      $db = Database::getInstance();
      $result = $db->query("SELECT a.english_nm,a.".$this->getLanguage()."_nm,b.english_nm,b."
                         . $this->getLanguage()."_nm FROM ".XOCP_PREFIX."ehr_icd_block a"
                         . " LEFT JOIN ".XOCP_PREFIX."ehr_icd_chapter b USING (chapter_id)"
                         . " WHERE a.block_id = '$block_id'");
      list($block_english_name,$block_name,$chapter_english_name,$chapter_name) = $db->fetchRow($result);

      if(trim($block_name) == "") {
         $block_name = $block_english_name;
      }

      if(trim($chapter_name) == "") {
         $chapter_name = $chapter_english_name;
      }
      
      $sql = "SELECT category,subcategory,english_nm,".$this->getLanguage()."_nm FROM "
           . XOCP_PREFIX."ehr_icd_item"
           . " WHERE block_id = '$block_id'"
           . " ORDER BY category,subcategory";
      $result = $db->query($sql);
      $found = $db->getRowsNum($result);
      $dp = new XocpDataPage();
      $dp->setPageSize(0);
      if($found > 0) {
         while($row=$db->fetchRow($result)) {
            $dp->addData($row);
         }
      }
      $dp->reset();

      $xurl = XOCP_SERVER_SUBDIR."/index.php?".$this->getparam;
      $selectchapterlink = "<a href='$xurl&slch=y'>[^]</a>";
      $selectblocklink   = "<a href='$xurl&chapterlink=y&x=$chapter_id'>[^]</a>";      
      $table = new XocpTable(1);
      $table->setWidth("100%");

      $hno = $table->addHeader($this->searchForm($q));
      $table->setColSpan($hno,3);
      $table->setCellAlign($hno,"right");

      $hno = $table->addHeader("$chapter_id - $chapter_name $selectchapterlink");
      $table->setColSpan($hno,3);
      $hno = $table->addHeader("$block_id - $block_name $selectblocklink");
      $table->setColSpan($hno,3);

      $fno = $table->addFooter($this->searchForm($q));
      $table->setColSpan($fno,3);
      $table->setCellAlign($fno,"right");
      
      
      $data = $dp->retrieve();
      if($q != "") {
         $qarray = explode(" ",$q);
      }
      foreach($data as $x) {
         list($category,$subcategory,$item_english_name,$item_name) = $x;

         if(trim($item_name) == "") {
            $item_name = $item_english_name;
         }

         if($q != "") {
            for($i = 0; $i < count($qarray); $i++) {
               $item_name = eregi_replace($qarray[$i],"<font style='color:red;font-weight:bold;'>\\0</font>",$item_name);
            }
         }

         $catno = $category . ($subcategory != '' ? ".$subcategory" : "");
         $addlink = "<a href=$xurl&addproblemitemlink=y&x=$category&y=$subcategory".">[+]</a>";
         if($subcategory != '') {
            $catno = "<b>$category.$subcategory</b>";
            $rno = $table->addRow("","$catno","$item_name $addlink");
         } else {
            $catno = "<b>$category</b>";
            $rno = $table->addRow("$catno","<b>$item_name</b> $addlink");
            $table->setColSpan($rno,1,2);
         }
      }

      return $table->render();

   }


   function searchForm($q="") {
      
      $fc_search = new XocpFormText("","q",20,100,"$q");

      $submit_button = new XocpFormButton("", "searchICD", _SEARCH, "submit");
      $reset_button = new XocpFormButton("", "reset", _RESET, "reset");

      $elementtray = new XocpFormElementTray("");

      $elementtray->addElement($fc_search);
      $elementtray->addElement($submit_button);
      $elementtray->addElement($reset_button);

      $fc_form = new XocpSimpleForm("","searchICDform","index.php","get");
      $fc_form->addElement($this->postparam);
      $fc_form->addElement($elementtray);
      return $fc_form->render();
   
   }


   function searchItem($q,$chapter_id = 0,$block_id = 0) {
      global $HTTP_GET_VARS,$ehr_ses_icd_browser,$ehr_ses_icd_searchItem_q;
      
      
      $db = Database::getInstance();

      $sql = "SELECT chapter_id,block_id,category,subcategory,english_nm,".$this->getLanguage()."_nm FROM "
           . XOCP_PREFIX."ehr_icd_item"
           . " WHERE ";
           
      $q = trim($q);
      if(strlen($q) > 1 ) {
         $no = 0;
         $array_key = explode(" ",$q);
         $sql .= " (";

         for($i = 0; $i < count($array_key); $i++) {
            if($n > 0) $sql .= " or ";
            if(!empty($array_key[$i])) {
               $sql .= "english_nm like '%$array_key[$i]%'";
               $n++;
            }
         }

         for($i = 0; $i < count($array_key); $i++) {
            if($n > 0) $sql .= " or ";
            if(!empty($array_key[$i])) {
               $sql .= $this->getLanguage()."_nm like '%$array_key[$i]%'";
               $n++;
            }
         }

         $sql .= ")";
      }

      $sql .= " ORDER BY category,subcategory";
      $result = $db->query($sql);
      $found = $db->getRowsNum($result);
      $dp = new XocpDataPage();
      $dp->setPageSize(0);
      if($found > 0) {
         while($row=$db->fetchRow($result)) {
            $dp->addData($row);
         }
      }
      $dp->reset();

      $xurl = XOCP_SERVER_SUBDIR."/index.php?".$this->getparam;
      
      $table = new XocpTable(1);
      $table->setWidth("100%");

      $hno = $table->addHeader($this->searchForm($q));
      $table->setColSpan($hno,3);
      $table->setCellAlign($hno,"right");


      $hno = $table->addHeader(_EHR_ICD_SEARCH_RESULT." $found "._FOUND." <div align=right><a href='".XOCP_SERVER_SUBDIR."/index.php'>["._EHR_ICD_SELECTCHAPTER."]</a></div>");
      $table->setColSpan($hno,3);

      $fno = $table->addFooter($this->searchForm($q));
      $table->setColSpan($fno,3);
      $table->setCellAlign($fno,"right");
      
      
      $data = $dp->retrieve();
      foreach($data as $x) {
         list($chapter_id,$block_id,$category,$subcategory,$item_english_name,$item_name) = $x;

         if(trim($item_name) == "") {
            $item_name = $item_english_name;
         }

         $qarray = explode(" ",$q);
         for($i = 0; $i < count($qarray); $i++) {
            $item_name = eregi_replace($qarray[$i],"<font style='color:red;font-weight:bold;'>\\0</font>",$item_name);
         }

         $catno = $category . ($subcategory != '' ? ".$subcategory" : "");
         
         $blocklink = "<a href=$xurl&blocklink=y&x=$chapter_id&y=$block_id&qq=y>[^]</a>";
         $addlink = "<a href=$xurl&addproblemitemlink=y&x=$category&y=$subcategory".">[+]</a>";

         if($subcategory != '') {
            $rno = $table->addRow("","$catno","$item_name $addlink $blocklink");
         } else {
            $rno = $table->addRow("$catno","$item_name $addlink $blocklink");
            $table->setColSpan($rno,1,2);
         }
      }

      return $table->render();

   }
   
   
   function problemList() {
      global $ehr_ses_org_id,$ehr_ses_ehr_id,$ehr_ses_patient_id;
      $db = &Database::getInstance();
      
      $link = XOCP_SERVER_SUBDIR . "/index.php?" . $this->getparam;
      
      $o_table = new XocpTable(1);
      $o_table->setWidth("100%");
      $hrow = $o_table->addRow(_EHR_PROBLEM_LIST);
      
      $sql = "select admission_id,admission_dt,admission_tm"
           . " FROM ".XOCP_PREFIX."ehr_admission"
           . " WHERE patient_org_id = '$ehr_ses_ehr_id'"
           . " AND patient_id = '$ehr_ses_patient_id'"
           . " ORDER by admission_dt desc,admission_tm desc";
      $result = $db->query($sql);
      if($db->getRowsNum($result)>0) {
         while(list($admission_id,$admission_dt,$admission_tm)=$db->fetchRow($result)) {
            $urladm = urlencode("$admission_dt|$admission_id");
            $addlink = "[<a href=$link&adm=$urladm>"._ADD."</a>]";
            $sql = "SELECT p.problem_id,p.block_id,p.category,p.subcategory,p.problem_lvl,b.english_nm,i.english_nm,"
                 . "b." . $this->getLanguage() . "_nm,i." . $this->getLanguage() . "_nm"
                 . " FROM ".XOCP_PREFIX."ehr_problem p"
                 . " LEFT JOIN ".XOCP_PREFIX."ehr_icd_block b ON b.block_id = p.block_id"
                 . " LEFT JOIN ".XOCP_PREFIX."ehr_icd_item i ON i.category = p.category"
                 . " AND i.subcategory = p.subcategory"
                 . " WHERE p.patient_id = '$ehr_ses_patient_id'"
                 . " AND p.patient_org_id = '$ehr_ses_ehr_id'"
                 . " AND p.admission_dt = '$admission_dt'"
                 . " AND p.admission_id = '$admission_id'"
                 . " ORDER BY p.problem_id";
            $presult = $db->query($sql);
            $p_table = new XocpTable(1);
            $p_table->setWidth("100%");
            if($db->getRowsNum($presult)>0) {
               while(list($problem_id,$block_id,$category,$subcategory,$problem_lvl,$b_english_nm,$i_english_nm,$b_item_name,$i_item_name)=$db->fetchRow($presult)) {
                  if($category != "") {
                     $catno = $category;
                     if($subcategory != "") {
                        $catno .= ".$subcategory";
                     }
                     $description = (empty($i_item_name) ? $i_english_nm : $i_item_name);
                  } elseif ($block_id > 0) {
                     $catno = "$block_id";
                     $description = (empty($b_item_name) ? $b_english_nm : $b_item_name);
                  } else {
                  
                  }
                  
                  $description = "<a style='font-weight:normal;' href='$link&edp=y&problem_id=$problem_id&udp=$urladm'>$description</a>";
                  
                  $drow = $p_table->addRow("<b>$catno</b>", $description,$problem_lvl);
               }
               
               $hrow = $p_table->addHeader("$admission_dt $admission_tm");
               $p_table->setColSpan($hrow,3);
               $drow = $p_table->addRow($addlink);
               $p_table->setColSpan($drow,3);
               
            } else {
               $hrow = $p_table->addheader("$admission_dt $admission_tm");
               $drow = $p_table->addRow(_EHR_PROBLEM_EMPTY);
               $drow = $p_table->addRow($addlink);
            }
            $drow = $o_table->addRow($p_table->render());
         }
      } else {
         $hrow = $o_table->addRow(_EHR_PROBLEM_EMPTY_ADMISSION);
         $o_table->setCellAlign($hrow,"center");
      }
      return $o_table->render();
   }
   
   function editProblem($admission_dt,$admission_id,$problem_id) {
      global $ehr_ses_patient_id,$ehr_ses_ehr_id;
      
      $db = &Database::getInstance();

      $sql = "SELECT p.block_id,p.category,p.subcategory,p.problem_lvl,b.english_nm,i.english_nm,"
           . "b." . $this->getLanguage() . "_nm,i." . $this->getLanguage() . "_nm"
           . " FROM ".XOCP_PREFIX."ehr_problem p"
           . " LEFT JOIN ".XOCP_PREFIX."ehr_icd_block b ON b.block_id = p.block_id"
           . " LEFT JOIN ".XOCP_PREFIX."ehr_icd_item i ON i.category = p.category"
           . " AND i.subcategory = p.subcategory"
           . " WHERE p.patient_id = '$ehr_ses_patient_id'"
           . " AND p.patient_org_id = '$ehr_ses_ehr_id'"
           . " AND p.admission_dt = '$admission_dt'"
           . " AND p.admission_id = '$admission_id'"
           . " AND p.problem_id = '$problem_id'";
      $presult = $db->query($sql);
      list($block_id,$category,$subcategory,$problem_lvl,$b_english_nm,$i_english_nm,$b_item_name,$i_item_name)=$db->fetchRow($presult);

                  if($category != "") {
                     $catno = $category;
                     if($subcategory != "") {
                        $catno .= ".$subcategory";
                     }
                     $description = (empty($i_item_name) ? $i_english_nm : $i_item_name);
                  } elseif ($block_id > 0) {
                     $catno = "$block_id";
                     $description = (empty($b_item_name) ? $b_english_nm : $b_item_name);
                  } else {
                  
                  }

      $fc_problem_desc = new XocpFormLabel(_EHR_PATIENTPROBLEM_DESC,"<b>$catno</b> $description");
      $fc_problem_lvl = new XocpFormLabel(_EHR_PATIENTPROBLEM_LVL,"$problem_lvl");
//      $fc_problem_lvl = new XocpFormRadio(_EHR_PATIENTPROBLEM_LVL,"problem_lvl",$problem_lvl);
//      $fc_problem_lvl->addOption("symptom",_EHR_PATIENTPROBLEM_LVL_SYMPTOMP);
//      $fc_problem_lvl->addOption("diagnostic",_EHR_PATIENTPROBLEM_LVL_DIAGNOSTIC);

      $submit1_button = new XocpFormButton("", "cancelsaveproblem", _CANCEL, "submit");
      if($problem_lvl == "symptom") {
         $submit2_button = new XocpFormButton("", "saveproblemasdiagnostic", _EHR_PROBLEM_SAVEDIAGNOSTIC, "submit");
      } else {
         $submit2_button = new XocpFormButton("", "saveproblemassymptom", _EHR_PROBLEM_SAVESYMPTOM, "submit");
      }
      
      $delete_button = new XocpFormButton("", "deleteproblem", _DELETE, "submit");

      $elementtray = new XocpFormElementTray("");

      $elementtray->addElement($submit2_button);
      $elementtray->addElement($submit1_button);
      $elementtray->addElement($delete_button);

      $fc_form = new XocpThemeForm(_EHR_PATIENTPROBLEM_EDIT,"editproblemform","index.php","post");
      $fc_form->addElement($fc_problem_desc);
      $fc_form->addElement($fc_problem_lvl);
      $fc_form->addElement($this->postparam);
      $fc_form->addElement($elementtray);
      $fc_form->addElement(new XocpFormHidden("admission_dt",$admission_dt));
      $fc_form->addElement(new XocpFormHidden("admission_id",$admission_id));
      $fc_form->addElement(new XocpFormHidden("problem_id",$problem_id));
      return $fc_form->render();
   
   }



   function main() {
      global $ehr_ses_org_id,$ehr_ses_patient_id,$HTTP_GET_VARS,$xocp_page_id;
      global $HTTP_POST_VARS,$ehr_ses_ehr_id,$ehr_ses_problem_adm_dt,$ehr_ses_problem_adm_id;
      global $ehr_ses_icd_browser,$ehr_ses_icd_browseBlock_chapter_id;
      global $ehr_ses_icd_browseItem_block_id,$ehr_ses_icd_searchItem_q;
      
      $db = &Database::getInstance();

      $this->getparam = _EHR_CATCH_VAR."="._EHR_PATIENTPROBLEM_BLOCK;
      $this->postparam = new XocpFormHidden(_EHR_CATCH_VAR,_EHR_PATIENTPROBLEM_BLOCK);
      
      if(!session_is_registered("ehr_ses_problem_adm_dt")) {
         session_register("ehr_ses_problem_adm_dt");
      }
      if(!session_is_registered("ehr_ses_problem_adm_id")) {
         session_register("ehr_ses_problem_adm_id");
      }
      if(!session_is_registered("ehr_ses_icd_browser")) {
         session_register("ehr_ses_icd_browser");
      }

      if(!session_is_registered("ehr_ses_icd_browseBlock_chapter_id")) {
         session_register("ehr_ses_icd_browseBlock_chapter_id");
      }

      if(!session_is_registered("ehr_ses_icd_browseItem_block_id")) {
         session_register("ehr_ses_icd_browseItem_block_id");
      }

      if(!session_is_registered("ehr_ses_icd_searchItem_q")) {
         session_register("ehr_ses_icd_searchItem_q");
      }

      switch ($this->catch) {
         case _EHR_PATIENTPROBLEM_BLOCK:
            if($HTTP_GET_VARS["adm"] != "") {
               list($admission_dt,$admission_id) = explode("|",$HTTP_GET_VARS["adm"]);
               $ehr_ses_problem_adm_dt = $admission_dt;
               $ehr_ses_problem_adm_id = $admission_id;

               switch($ehr_ses_icd_browser) {
                  case "browseBlock" :
                     $ret = $this->browseBlock($ehr_ses_icd_browseBlock_chapter_id);
                     break;
                  case "browseItem" :
                     $ret = $this->browseItem($ehr_ses_icd_browseBlock_chapter_id,$ehr_ses_icd_browseItem_block_id);
                     break;
                  case "searchItem" :
                     $ret = $this->searchItem($ehr_ses_icd_searchItem_q);
                     break;
                  default:
                     $ehr_ses_icd_browser = "browseChapter";
                     $ret = $this->browseChapter();
                     break;
               }
               



            } elseif(!empty($HTTP_GET_VARS["slch"])) {
               $ehr_ses_icd_browser = "browseChapter";
               $ret = $this->browseChapter();
            } elseif(!empty($HTTP_GET_VARS["chapterlink"])) {
               $chapter_id = $HTTP_GET_VARS["x"];
               $ehr_ses_icd_browser = "browseBlock";
               $ehr_ses_icd_browseBlock_chapter_id = $chapter_id;
               $ret .= $this->browseBlock($chapter_id);
            } elseif (!empty($HTTP_GET_VARS["blocklink"])) {
               $chapter_id = $HTTP_GET_VARS["x"];
               $block_id = $HTTP_GET_VARS["y"];
               $ehr_ses_icd_browser = "browseItem";
               $ehr_ses_icd_browseItem_block_id = $block_id;
               $ehr_ses_icd_browseBlock_chapter_id = $chapter_id;
               if($HTTP_GET_VARS["qq"] != "") {
                  $q = $ehr_ses_icd_searchItem_q;
               } else {
                  $q = "";
               }
               $ret .= $this->browseItem($chapter_id,$block_id,$q);
            } elseif (!empty($HTTP_GET_VARS["itemlink"])) {
               $category = $HTTP_GET_VARS["x"];
               $subcategory = $HTTP_GET_VARS["y"];
            } elseif (!empty($HTTP_GET_VARS["q"])) {
               $ehr_ses_icd_browser = "searchItem";
               $ehr_ses_icd_searchItem_q = $HTTP_GET_VARS["q"];
               $ret .= $this->searchItem($HTTP_GET_VARS["q"]);
               
            } elseif (!empty($HTTP_GET_VARS["addproblemitemlink"])) {
               $category = $HTTP_GET_VARS["x"];
               $subcategory = $HTTP_GET_VARS["y"];
               $sql = "SELECT MAX(problem_id) FROM ".XOCP_PREFIX."ehr_problem"
                    . " WHERE patient_org_id = '$ehr_ses_ehr_id'"
                    . " AND patient_id = '$ehr_ses_patient_id'"
                    . " AND admission_dt = '$ehr_ses_problem_adm_dt'"
                    . " AND admission_id = '$ehr_ses_problem_adm_id'";
               $result = $db->query($sql);
               list($problem_id) = $db->fetchRow($result);
               $problem_id++;
               $sql = "INSERT INTO ".XOCP_PREFIX."ehr_problem"
                    . " (patient_org_id,patient_id,problem_id,admission_id"
                    . " ,admission_dt,category,subcategory)"
                    . " VALUES ('$ehr_ses_ehr_id','$ehr_ses_patient_id',"
                    . " '$problem_id','$ehr_ses_problem_adm_id','$ehr_ses_problem_adm_dt',"
                    . " '$category','$subcategory')";
               $db->query($sql);
               $ret = $this->problemList();
//               $ret = $this->editProblem($ehr_ses_problem_adm_dt,$ehr_ses_problem_adm_id,$problem_id);
            } elseif (!empty($HTTP_GET_VARS["addproblemblocklink"])) {
               $chapter_id = $HTTP_GET_VARS["x"];
               $block_id = $HTTP_GET_VARS["y"];
               $sql = "SELECT MAX(problem_id) FROM ".XOCP_PREFIX."ehr_problem"
                    . " WHERE patient_org_id = '$ehr_ses_ehr_id'"
                    . " AND patient_id = '$ehr_ses_patient_id'"
                    . " AND admission_dt = '$ehr_ses_problem_adm_dt'"
                    . " AND admission_id = '$ehr_ses_problem_adm_id'";
               $result = $db->query($sql);
               list($problem_id) = $db->fetchRow($result);
               $problem_id++;
               $sql = "INSERT INTO ".XOCP_PREFIX."ehr_problem"
                    . " (patient_org_id,patient_id,problem_id,admission_id"
                    . " ,admission_dt,block_id)"
                    . " VALUES ('$ehr_ses_ehr_id','$ehr_ses_patient_id',"
                    . " '$problem_id','$ehr_ses_problem_adm_id','$ehr_ses_problem_adm_dt',"
                    . " '$block_id')";
               $db->query($sql);
               $ret = $this->problemList();
//               $ret = $this->editProblem($ehr_ses_problem_adm_dt,$ehr_ses_problem_adm_id,$problem_id);
            } elseif (!empty($HTTP_GET_VARS["edp"])) {
               $problem_id = $HTTP_GET_VARS["problem_id"];
               list($admission_dt,$admission_id) = explode("|",$HTTP_GET_VARS["udp"]);
               $ret = $this->editProblem($admission_dt,$admission_id,$problem_id);
            } elseif (!empty($HTTP_POST_VARS["cancelsaveproblem"])) {
               $ret = $this->problemList();
               
            } elseif (!empty($HTTP_POST_VARS["saveproblemassymptom"])) {
               $admission_dt = $HTTP_POST_VARS["admission_dt"];
               $admission_id = $HTTP_POST_VARS["admission_id"];
               $problem_id = $HTTP_POST_VARS["problem_id"];
               $problem_lvl = $HTTP_POST_VARS["problem_lvl"];
               $sql = "UPDATE ".XOCP_PREFIX."ehr_problem SET"
                    . " problem_lvl = 'symptom'"
                    . " WHERE patient_org_id = '$ehr_ses_ehr_id'"
                    . " AND patient_id = '$ehr_ses_patient_id'"
                    . " AND admission_dt = '$admission_dt'"
                    . " AND admission_id = '$admission_id'"
                    . " AND problem_id = '$problem_id'";
               $db->query($sql);
               $ret = $this->problemList();
               
            } elseif (!empty($HTTP_POST_VARS["saveproblemasdiagnostic"])) {
               $admission_dt = $HTTP_POST_VARS["admission_dt"];
               $admission_id = $HTTP_POST_VARS["admission_id"];
               $problem_id = $HTTP_POST_VARS["problem_id"];
               $problem_lvl = $HTTP_POST_VARS["problem_lvl"];
               $sql = "UPDATE ".XOCP_PREFIX."ehr_problem SET"
                    . " problem_lvl = 'diagnostic'"
                    . " WHERE patient_org_id = '$ehr_ses_ehr_id'"
                    . " AND patient_id = '$ehr_ses_patient_id'"
                    . " AND admission_dt = '$admission_dt'"
                    . " AND admission_id = '$admission_id'"
                    . " AND problem_id = '$problem_id'";
               $db->query($sql);
               $ret = $this->problemList();
               
            } elseif (!empty($HTTP_POST_VARS["deleteproblem"])) {
               $admission_dt = $HTTP_POST_VARS["admission_dt"];
               $admission_id = $HTTP_POST_VARS["admission_id"];
               $problem_id = $HTTP_POST_VARS["problem_id"];
               $sql = "DELETE FROM ".XOCP_PREFIX."ehr_problem"
                    . " WHERE patient_org_id = '$ehr_ses_ehr_id'"
                    . " AND patient_id = '$ehr_ses_patient_id'"
                    . " AND admission_dt = '$ehr_ses_problem_adm_dt'"
                    . " AND admission_id = '$ehr_ses_problem_adm_id'"
                    . " AND problem_id = '$problem_id'";
               $db->query($sql);
               $ret = $this->problemList();
            } else {
               $ret = $this->problemList();
            }
            break;
         default:
            if($ehr_ses_ehr_id > 0) {
               if($ehr_ses_patient_id == 0) {
                  $ret = "";
               } else {
                  $ret = $this->problemList();
               }
            } else {
               $ret = "";
            }
            break;
      }
      return $ret;
   }
}

} // EHR_PATIENTPROBLEM_DEFINED
?>