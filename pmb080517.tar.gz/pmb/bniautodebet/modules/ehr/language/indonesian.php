<?php
//--------------------------------------------------------------------//
// Filename : modules/ehr/language/indonesian.php                     //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-03-24                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('EHR_LANGUAGE_DEFINED') ) {
   define('EHR_LANGUAGE_DEFINED', TRUE);

// Module's Global Language Definition
define("_EHR_SELECTORGSELECT","Pilih Organisasi");
define("_EHR_SELECTORGANIZATION","Pilih organisasi");
define("_EHR_SELECTUNITSELECT","Pilih Unit");
define("_EHR_SELECTUNIT","Pilih unit");
define("_EHR_PATIENTEXTID","Nomor Rekam Medis");
define("_EHR_PATIENTNAME","Nama Pasien");
define("_EHR_PATIENTSSN","SSN");
define("_EHR_PATIENTADDRTXT","Alamat");
define("_EHR_PATIENTLIST","Daftar Pasien");
define("_EHR_SEARCHRESULT","Hasil Pencarian");

// Block's Language Definition
// Group Service
define("_EHR_GROUPSRV_NOTFOUND","Kelompok layanan tidak ditemukan");
define("_EHR_GROUPSRV_LIST","Daftar Kelompok Layanan");
define("_EHR_GROUPSRV_ID","Kode Kelompok Layanan");
define("_EHR_GROUPSRV_NAME","Nama Kelompok Layanan");
define("_EHR_GROUPSRV_SHOWDETAILTITLE","Kelompok Layanan - Rincian");
define("_EHR_GROUPSRV_ADDTITLE","Kelompok Layanan - Tambah");
define("_EHR_GROUPSRV_EDITTITLE","Kelompok Layanan - Ubah");
define("_EHR_GROUPSRV_DELCONFIRMTITLE","Kelompok Layanan - Konfirmasi Hapus");
define("_EHR_GROUPSRV_ADDCONFIRMTITLE","Kelompok Layanan - Konfirmasi Tambah");
define("_EHR_GROUPSRV_EDITCONFIRMTITLE","Kelompok Layanan - Konfirmasi Ubah");
define("_EHR_GROUPSRV_SAVECANCEL","Penyimpanan dibatalkan");
define("_EHR_GROUPSRV_DELETESUCCESS","Data telah dihapus dari basisdata");
define("_EHR_GROUPSRV_DELETEFAIL","Gagal menghapus data");
define("_EHR_GROUPSRV_DELETEERROR","Terjadi kesalahan pada saat menghapus data");
define("_EHR_GROUPSRV_SAVEFAIL","Terjadi kesalahan pada saat menyimpan data");
define("_EHR_GROUPSRV_SAVESUCCESS","Data telah disimpan ke dalam basisdata");
define("_EHR_GROUPSRV_DELCANCEL","Penghapusan data dibatalkan");
define("_EHR_GROUPSRV_NOORGSELECTED","Tidak ada organisasi yang dipilih");
// Patient Admission
define("_EHR_PTADM_SEARCHPATIENTTITLE","Admisi Pasien - Pencarian");
define("_EHR_PTADM_PREADMITTEST","Diperiksa Sebelum Admisi");
define("_EHR_PTADM_ADMISSIONDTTM","Tanggal & Jam Admisi");
define("_EHR_PTADM_ADMIT","Admisi");
define("_EHR_PTADM_PATIENTADMISSIONTITLE","Admisi Pasien - Simpan");
define("_EHR_PTADM_SEARCHPATIENTINFO","Hasil pencarian terlalu banyak.<br />Silakan persempit kriteria pencarian Anda.");
define("_EHR_PTADM_PATIENTNOTFOUND","Tidak ada pasien yang sesuai dengan kriteria tersebut");
define("_EHR_PTADM_SAVESUCCESS","Data admisi telah disimpan");
define("_EHR_PTADM_SAVEFAIL","Gagal menyimpan data admisi");
// Patient Encounter
define("_EHR_PTENC_ADMISSIONDATE","Tanggal Admisi");
define("_EHR_PTENC_SEARCHPATIENTTITLE","Kunjungan Pasien - Pencarian");
define("_EHR_PTENC_SELECTPHYSICIAN","Nama Dokter");
define("_EHR_PTENC_ENCOUNTERDTTM","Tanggal & Jam Kunjungan");
define("_EHR_PTENC_PATIENTENCOUNTERTITLE","Kunjungan Pasien - Simpan");
define("_EHR_PTENC_SEARCHPATIENTINFO","Hasil pencarian terlalu banyak.<br />Silakan persempit kriteria pencarian Anda.");
define("_EHR_PTENC_PATIENTNOTFOUND","Tidak ada pasien yang sesuai dengan kriteria tersebut");
define("_EHR_PTENC_SAVESUCCESS","Data admisi telah disimpan");
define("_EHR_PTENC_SAVEFAIL","Gagal menyimpan data admisi");
// Employee Registration
define("_EHR_EMPREG_SEARCHPERSONTITLE","Pendaftaran Pegawai - Pencarian");
define("_EHR_EMPREG_PERSONNAME","Nama&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
define("_EHR_EMPREG_PERSONLIST","Daftar Person");
define("_EHR_EMPREG_PERSONADDRTXT","Alamat Rumah");
define("_EHR_EMPREG_PERSONGENDER","Jenis Kelamin");
define("_EHR_EMPREG_PERSONBIRTHPLACE","Tempat Lahir");
define("_EHR_EMPREG_PERSONBIRTHDATE","Tanggal Lahir");
define("_EHR_EMPREG_PERSONZIPCD","Kode Pos");
define("_EHR_EMPREG_PERSONTELECOM","Telepon Rumah");
define("_EHR_EMPREG_JOBTITLE","Pekerjaan");
define("_EHR_EMPREG_HAZARDEXP","Hazard Exposure");
define("_EHR_EMPREG_OFFICEADDR","Alamat Kantor");
define("_EHR_EMPREG_OFFICETELECOM","Telepon Kantor");
define("_EHR_EMPREG_JOBSTART","Tanggal Mulai Bekerja");
define("_EHR_EMPREG_JOBSTOP","Tanggal Berhenti Bekerja");
define("_EHR_EMPREG_JOBCODE","Kode Pekerjaan");
define("_EHR_EMPREG_JOBCLASSCODE","Jenis Pegawai");
define("_EHR_EMPREG_FULLTIME","Penuh");
define("_EHR_EMPREG_PARTTIME","Paruh waktu");
define("_EHR_EMPREG_ONDEMAND","Sesuai kebutuhan");
define("_EHR_EMPREG_REGISTER","Daftar");
define("_EHR_EMPREG_EMPLOYEEREGTITLE","Pendaftaran Pegawai - Daftar");
define("_EHR_EMPREG_EMPREGISTERED","<font style='color:green;font-weight:bold;'>Telah terdaftar</font>");
define("_EHR_EMPREG_EMPNOTREGISTERED","<font style='color:red;font-weight:bold;'>Belum terdaftar</font>");
define("_EHR_EMPREG_SEARCHPERSONINFO","Hasil pencarian terlalu banyak. Silakan persempit kriteria pencarian Anda.<br />Jika nama yang Anda maksud tidak ada, silakan gunakan tombol '"._ADD."' untuk menambah.");
define("_EHR_EMPREG_PERSONNOTFOUND","Nama tidak ditemukan, silakan gunakan formulir di bawah untuk menambah");
define("_EHR_EMPREG_PERSONSAVEFAIL","Gagal menyimpan data personal, pegawai tidak didaftar");
define("_EHR_EMPREG_PERSONSAVEERROR","Nama pegawai tidak boleh kosong");
define("_EHR_EMPREG_SAVEFAIL","Gagal mendaftar pegawai");
define("_EHR_EMPREG_SAVESUCCESS","Pegawai berhasil didaftar");

}// EHR_LANGUAGE_DEFINED
?>