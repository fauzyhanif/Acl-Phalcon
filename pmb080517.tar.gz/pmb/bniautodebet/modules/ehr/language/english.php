<?php
//--------------------------------------------------------------------//
// Filename : modules/ehr/language/english.php                        //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-03-24                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('EHR_LANGUAGE_DEFINED') ) {
   define('EHR_LANGUAGE_DEFINED', TRUE);


}// EHR_LANGUAGE_DEFINED
?>