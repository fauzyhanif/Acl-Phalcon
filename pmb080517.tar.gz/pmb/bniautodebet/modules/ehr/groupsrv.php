<?php
//--------------------------------------------------------------------//
// Filename : modules/ehr/groupsrv.php                                //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2003-03-25                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('EHR_GROUPSERVICE_DEFINED') ) {
   define('EHR_GROUPSERVICE_DEFINED', TRUE);
   
include_once(XOCP_DOC_ROOT."/modules/ehr/modconsts.php");

function groupsrv_funccmp($a,$b) {
   if ($a[4] == $b[4]) {
      return strcmp($a[2],$b[2]);
   }
   return ($a[4] > $b[4]) ? -1 : 1;
}

class _ehr_GroupService extends XocpBlock {
   // Set block width
   var $width = "100%";
   // Catch variable for get method -- See below
   var $getparam;
   // Catch variable for post method -- See below
   var $postparam;
   
   // $find: text to search
   // $p: page number
   // $f: data page filename
   // $org_id: organization id
   function groupServiceNavigate($find = "",$p = "0",$f = "",$org_id  = "") {
      $db =& Database::getInstance();
      // Is the data page filename set?
      if (trim($f) != "") {  // Retrieve from a previously made data page
         $dp = XocpDataPage::unserialize($f);
         // Check whether the data page has any data or not
         $dp->reset();
         $dp_data = $dp->retrieve();
         if ($dp_data[0][0] != _EHR_GROUPSRV_NOTFOUND) {
            $found = TRUE;
         } else {
            $found = FALSE;
         }
         // Set back to proper page number
         $dp->setPage($p);
      } else {  // Create a new data page
         if (trim($find) == "") { // Browse
            $sql = "SELECT groupsrv_id,groupsrv_nm,status_cd
                    FROM ".XOCP_PREFIX."ehr_groupsrv
                    WHERE org_id = '$org_id' AND status_cd = 'active'
                    ORDER BY groupsrv_id";
         } else { // Search
            $sql = "SELECT groupsrv_id,groupsrv_nm,status_cd
                    FROM ".XOCP_PREFIX."ehr_groupsrv
                    WHERE org_id = '$org_id' AND groupsrv_nm LIKE '$find'
                          AND status_cd = 'active'
                    ORDER BY groupsrv_id";
         }

         $result = $db->query($sql);
         $dp = new XocpDataPage();
         $dp->setPageSize(20);
         if ($db->getRowsNum($result) > 0) {
            $found = TRUE;
            while (list($groupsrv_id,$groupsrv_nm,$status_cd) = $db->fetchRow($result)) {
               similar_text($groupsrv_nm,str_replace("%","",$find),$score);
               $dp->addData(array($groupsrv_id,$groupsrv_nm,$status_cd,round($score,2)));
            }
            // Sort data
            if (trim($find) != "") {
               usort($dp->data,"groupsrv_funccmp");
               array_reverse($dp->data);
            }
         } else {
            $found = FALSE;
            $dp->addData(array(_EHR_GROUPSRV_NOTFOUND));
         }
         $dp->serialize();
      }
      
      // Preparing the data page
      if ($found) {
         $dp_found = $dp->getCount();
         $no1 = $dp->getOffset() + 1;
      } else {
         $dp_found = "0";
         $no1 = "0";
      }
      $no2 = $no1 + $dp->getPageSize() - 1;
      if ($dp_found <= $no2) {
         $no2 = $dp_found;
      }
      
      // Creating header
      $dp_header = new XocpSimpleTable();
      // Is it searching? Set for the appropriate title
      if ($find != "") {  // Yes, it'is searching
         $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&fi=".urlencode($find));
         $title = "<font class='tdh1'>"._EHR_GROUPSRV_LIST." ["._EHR_SEARCHRESULT." ($no1 - $no2 "._OF." $dp_found)]</font>";
      } else {  // No, it's just retrieving from a previously made data page
         $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam);
         $title = "<font class='tdh1'>"._EHR_GROUPSRV_LIST." ($no1 - $no2 "._OF." $dp_found)</font>";
      }
      // How many page in data page?
      if ($found && count($dp->getPageArray()) > 1) {  // More than 1, show navigation links
         $hrow = $dp_header->addRow($title,$dp_prevnext);
      } else {
         $hrow = $dp_header->addRow($title);
      }
      $dp_header->setCellAlign($hrow,array("","right"));
      $dp_header->setWidth("100%");

      // Creating search form
      $hdn_state = new XocpFormHidden("state","add");
      $txt_cond = new XocpFormText("","txt_find",20,40,"");
      $btn_find = new XocpFormButton("","btn_find",_SEARCH,"submit");
      $elm_tray_find = new XocpFormElementTray("");
      $elm_tray_find->addElement($txt_cond);
      $elm_tray_find->addElement($btn_find);
      
      $form_find = new XocpSimpleForm("","ffind",XOCP_SERVER_SUBDIR."/index.php");
      $form_find->addElement($this->postparam);
      $form_find->addElement($elm_tray_find);

      // Creating button tray form
      $btn_add = new XocpFormButton("","btn_add",_ADD,"submit");
      $elm_tray_add = new XocpFormElementTray("");
      $elm_tray_add->addElement($btn_add);
      
      $form_buttons = new XocpSimpleForm("","fbuttons",XOCP_SERVER_SUBDIR."/index.php");
      $form_buttons->addElement($this->postparam);
      $form_buttons->addElement($hdn_state);
      $form_buttons->addElement($elm_tray_add);

      // Creating footer
      $dp_footer = new XocpSimpleTable();
      $frow = $dp_footer->addRow($form_buttons->render(),$form_find->render());
      $dp_footer->setCellAlign($frow,array("left","right"));
      $dp_footer->setWidth("100%");
                                    
      // Creating data page
      $dp_table = new XocpTable(1);
      $dp_table->setWidth("100%");
      $hrow = $dp_table->addHeader($dp_header->render());
      $frow = $dp_table->addFooter($dp_footer->render());
                                           
      // Populating data page
      $dp_data = $dp->retrieve();
      foreach ($dp_data as $row) {
         list($groupsrv_id,$groupsrv_nm,$status_cd,$score) = $row;
         if ($found) {
            if ($find != "") {
               $drow = $dp_table->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&show=y&x=".urlencode($groupsrv_id)."'>$groupsrv_nm</a> ($score% "._MATCH.")");
            } else {
               $drow = $dp_table->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&show=y&x=".urlencode($groupsrv_id)."'>$groupsrv_nm</a><br/>");
            }
         } else {
            $drow = $dp_table->addRow($groupsrv_id);
         }
      }
                                                                     
      return $dp_table->render();
   }
   
   function formShowDetail($datarec,$comment = "") {
      // Show baseline detail
      $hidden_type = new XocpFormHidden("type","show");
      $hidden_state = new XocpFormHidden("state","edit");
      $hidden_groupsrv_id = new XocpFormHidden("old_groupsrv_id",htmlspecialchars(stripslashes($datarec["groupsrv_id"]),ENT_QUOTES));
      $hidden_groupsrv_nm = new XocpFormHidden("old_groupsrv_nm",htmlspecialchars(stripslashes($datarec["groupsrv_nm"]),ENT_QUOTES));
      
      $label_groupsrv_id = new XocpFormLabel(_EHR_GROUPSRV_ID,stripslashes($datarec["groupsrv_id"]));
      $label_groupsrv_nm = new XocpFormLabel(_EHR_GROUPSRV_NAME,stripslashes($datarec["groupsrv_nm"]));
      $submit_edit = new XocpFormButton("","edit",_EDIT,"submit");
      $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
      $submit_delete = new XocpFormButton("","delete",_DELETE,"submit");
      $elementtray_button = new XocpFormElementTray("");
      $elementtray_button->addElement($submit_edit);
      $elementtray_button->addElement($submit_cancel);
      $elementtray_button->addElement($submit_delete);

      // Constructing a form - Show baseline detail
      $form = new XocpThemeForm(_EHR_GROUPSRV_SHOWDETAILTITLE,"fshowgroupsrv","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_type);
      $form->addElement($hidden_state);

      $form->addElement($hidden_groupsrv_id);
      $form->addElement($hidden_groupsrv_nm);

      $form->addElement($label_groupsrv_id);
      $form->addElement($label_groupsrv_nm);
      $form->addElement($elementtray_button);
      if ($comment != "") {
         $form->setComment($comment);
      }

      $this->html->setBodyOnload(" onload='document.fshowgroupsrv.cancel.focus();'");
   
      return $form->render();
   }

   function formAddEdit($state = "add",$datarec = NULL,$showcancel = TRUE,$comment = NULL) {
      // Form elements - Add/edit a group service data
      $hidden_type = new XocpFormHidden("type","addedit");
      $hidden_state = new XocpFormHidden("state",$state);
      if ($state == "edit") {
         $hidden_old_groupsrv_id = new XocpFormHidden("old_groupsrv_id",htmlspecialchars(stripslashes($datarec["old_groupsrv_id"]),ENT_QUOTES));
         $hidden_old_groupsrv_nm = new XocpFormHidden("old_groupsrv_nm",htmlspecialchars(stripslashes($datarec["old_groupsrv_nm"]),ENT_QUOTES));
      }
      $text_groupsrv_nm = new XocpFormText(_EHR_GROUPSRV_NAME,"groupsrv_nm",50,40,htmlspecialchars(stripslashes($datarec["groupsrv_nm"]),ENT_QUOTES));
      $submit_save = new XocpFormButton("","save",_SAVE,"submit");
      $submit_reset = new XocpFormButton("","reset",_RESET,"reset");
      $elementtray_button = new XocpFormElementTray("");
      $elementtray_button->addElement($submit_save);
      $elementtray_button->addElement($submit_reset);
      // Show or hide Cancel button
      if ($showcancel) {
         $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
         $elementtray_button->addElement($submit_cancel);
      }

      // Constructing a form - Add/edit a group service data
      if ($state == "add") {
         $title = _EHR_GROUPSRV_ADDTITLE;
      } else {
         $title = _EHR_GROUPSRV_EDITTITLE;
      }
      $form = new XocpThemeForm($title,"faddeditgroupsrv","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_type);
      $form->addElement($hidden_state);
      if ($state == "edit") {
         $form->addElement($hidden_old_groupsrv_id);
         $form->addElement($hidden_old_groupsrv_nm);
      }
      $form->addElement($text_groupsrv_nm);
      $form->addElement($elementtray_button);
      if ($comment != "") {
         $form->setComment($comment);
      }
 
      $this->html->setBodyOnload(" onload='document.faddeditgroupsrv.groupsrv_nm.focus();'");
   
      return $form->render();
   }
   
   function formConfirm($state = "add",$datarec,$title = "") {
      // Form elements - Confirm group service being added/edited/deleted
      $hidden_type = new XocpFormHidden("type","confirm");
      $hidden_state = new XocpFormHidden("state",$state);
      if ($state != "add") {
         $hidden_old_groupsrv_id = new XocpFormHidden("old_groupsrv_id",htmlspecialchars(stripslashes($datarec["old_groupsrv_id"]),ENT_QUOTES));
         $hidden_old_groupsrv_nm = new XocpFormHidden("old_groupsrv_nm",htmlspecialchars(stripslashes($datarec["old_groupsrv_nm"]),ENT_QUOTES));
      }
      $hidden_groupsrv_nm = new XocpFormHidden("groupsrv_nm",htmlspecialchars(stripslashes($datarec["groupsrv_nm"]),ENT_QUOTES));
      $label_groupsrv_nm = new XocpFormLabel(_EHR_GROUPSRV_NAME,stripslashes($datarec["groupsrv_nm"]));
      $submit_ok = new XocpFormButton("","ok",_OK,"submit");
      if ($state != "delete") {
         $submit_edit = new XocpFormButton("","edit",_EDIT,"submit");
      }
      $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
      $elementtray_button = new XocpFormElementTray("");
      $elementtray_button->addElement($submit_ok);
      if ($state != "delete") {
         $elementtray_button->addElement($submit_edit);
      }
      $elementtray_button->addElement($submit_cancel);

      // Constructing a form - Confirm Added/edited group service
      $form = new XocpThemeForm($title,"fconfirmgroupsrv","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_type);
      $form->addElement($hidden_state);
      if ($state != "add") {
         $form->addElement($hidden_old_groupsrv_id);
         $form->addElement($hidden_old_groupsrv_nm);
      }
      $form->addElement($hidden_groupsrv_nm);
      $form->addElement($label_groupsrv_nm);
      $form->addElement($elementtray_button);
      
      if ($state == "add") {
         $this->html->setBodyOnload(" onload='document.fconfirmgroupsrv.ok.focus();'");
      } else {
         $this->html->setBodyOnload(" onload='document.fconfirmgroupsrv.cancel.focus();'");
      }

      return $form->render();
   }
   
   function main() {
      $db =& Database::getInstance();
      $this->getparam = _EHR_CATCH_VAR."="._EHR_GROUPSERVICE_BLOCK;
      $this->postparam = new XocpFormHidden(_EHR_CATCH_VAR,_EHR_GROUPSERVICE_BLOCK);
      switch ($this->catch) {
         case _EHR_GROUPSERVICE_BLOCK:
            global $HTTP_POST_VARS,$HTTP_GET_VARS;
            if (trim($HTTP_POST_VARS["txt_find"]) != "") {
               // Search baseline datas
               $nm = trim($HTTP_POST_VARS["txt_find"]);
               if (!eregi("\*",$nm)) {
                  $nm = "%$nm%";
               } else {
                  $nm = str_replace("*","%",$nm);
               }
               global $ehr_ses_ehr_id;
               $ret = $this->groupServiceNavigate($nm,"","",$ehr_ses_ehr_id);
            } elseif (isset($HTTP_POST_VARS["type"])) {
               // Form handler a.k.a page script flow
               $state = $HTTP_POST_VARS["state"];  // Preserve state
               //$showcancel = ($state == "edit") ? TRUE : FALSE;  // Show cancel button on add/edit form
               $showcancel = TRUE;  // Always show cancel button on add/edit form
               switch ($HTTP_POST_VARS["type"]) {
                  case "show":  // Show detail form
                     global $ehr_ses_ehr_id;
                     if (!isset($HTTP_POST_VARS["cancel"])) {
                        // Initialize values
                        $HTTP_POST_VARS["org_id"] = $HTTP_POST_VARS["old_org_id"];
                        $HTTP_POST_VARS["groupsrv_id"] = $HTTP_POST_VARS["old_groupsrv_id"];
                        $HTTP_POST_VARS["groupsrv_nm"] = $HTTP_POST_VARS["old_groupsrv_nm"];
                     }
                     if (isset($HTTP_POST_VARS["edit"])) {  // Edit
                        $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel);
                     } elseif (isset($HTTP_POST_VARS["cancel"])) {  // Cancel
                        $ret = $this->groupServiceNavigate("","","",$ehr_ses_ehr_id);
                     } else {  // Delete
                        $ret = $this->formConfirm("delete",$HTTP_POST_VARS,_EHR_GROUPSRV_DELCONFIRMTITLE);
                     }
                     break;
                  case "addedit":  // Add/edit form
                     if (isset($HTTP_POST_VARS["groupsrv_nm"]) && !isset($HTTP_POST_VARS["cancel"])) {  // Save
                        if ($state == "add") {
                           $title = _EHR_GROUPSRV_ADDCONFIRMTITLE;
                        } else {
                          $title = _EHR_GROUPSRV_EDITCONFIRMTITLE;
                        }
                        $ret = $this->formConfirm($state,$HTTP_POST_VARS,$title);
                     } elseif (isset($HTTP_POST_VARS["cancel"])) {  // Cancel
                        if ($state == "edit") {
                           // Set back to original values
                           $HTTP_POST_VARS["org_id"] = $HTTP_POST_VARS["old_org_id"];
                           $HTTP_POST_VARS["groupsrv_id"] = $HTTP_POST_VARS["old_groupsrv_id"];
                           $HTTP_POST_VARS["groupsrv_nm"] = $HTTP_POST_VARS["old_groupsrv_nm"];
                           $ret = $this->formShowDetail($HTTP_POST_VARS,_EHR_GROUPSRV_SAVECANCEL);
                        } else {
                           global $ehr_ses_ehr_id;
                           $ret = $this->groupServiceNavigate("","","",$ehr_ses_ehr_id);
                        }
                     }
                     break;
                  case "confirm":  // Confirmation form
                     global $ehr_ses_ehr_id;
                     if (isset($HTTP_POST_VARS["ok"])) {  // Ok, save/delete baseline data
                        if ($state == "delete") {  // Do delete baseline data
                           $sql = "UPDATE ".XOCP_PREFIX."ehr_groupsrv
                                   SET status_cd = 'nullified'
                                   WHERE org_id = '$ehr_ses_ehr_id' AND
                                         groupsrv_id = '".$HTTP_POST_VARS["old_groupsrv_id"]."'";
                           $result = $db->query($sql);
                           $comment = $db->error();
                           if ($comment == "") {
                              // Warning: this isn't the proper function
                              //if ($db->getRowsNum($result) > 0) {
                              if (mysql_affected_rows() > 0) {
                                 $comment = _EHR_GROUPSRV_DELETESUCCESS;
                              } else {
                                 $comment = _EHR_GROUPSRV_DELETEFAIL;
                              }
                           } else {
                              $comment = _EHR_GROUPSRV_DELETEERROR."<br/>$comment";
                           }
                           $ret = $this->groupServiceNavigate("","","",$ehr_ses_ehr_id);
                        } else {
                           if ($state == "add") {  // New group service data, do add
                              $sqla = $sql = "SELECT MAX(groupsrv_id) FROM ".XOCP_PREFIX."ehr_groupsrv
                                      WHERE org_id = '$ehr_ses_ehr_id'";
                              $result = $db->query($sql);
                              list($groupsrv_id) = $db->fetchRow($result);
                              $groupsrv_id++;
                              $sql = "INSERT INTO ".XOCP_PREFIX."ehr_groupsrv (org_id,groupsrv_id,groupsrv_nm,status_cd)
                                      VALUES ('$ehr_ses_ehr_id','$groupsrv_id','".$HTTP_POST_VARS["groupsrv_nm"]."','active')";
                           } else {  // Old baseline data, do update
                              $sql = "UPDATE ".XOCP_PREFIX."ehr_groupsrv
                                      SET groupsrv_nm = '".$HTTP_POST_VARS["groupsrv_nm"]."'
                                      WHERE org_id = '$ehr_ses_ehr_id' AND
                                            groupsrv_id = '".$HTTP_POST_VARS["old_groupsrv_id"]."'";
                           }
                           $result = $db->query($sql);
                           $comment = $db->error();
                           if ($comment != "") {
                              if ($state != "add") {  // Set back to original values
                                 $HTTP_POST_VARS["org_id"] = $HTTP_POST_VARS["old_org_id"];
                                 $HTTP_POST_VARS["groupsrv_id"] = $HTTP_POST_VARS["old_groupsrv_id"];
                                 $HTTP_POST_VARS["groupsrv_nm"] = $HTTP_POST_VARS["old_groupsrv_nm"];
                              }
                              $comment = _EHR_GROUPSRV_SAVEFAIL."<br/>".$comment;
                           } else {
                              $comment = _EHR_GROUPSRV_SAVESUCCESS;
                           }
                           if ($state == "add") {
                              $ret = $this->formAddEdit($state,$datarec,$showcancel,$comment);
                           } else {
                              $HTTP_POST_VARS["groupsrv_id"] = $HTTP_POST_VARS["old_groupsrv_id"];
                              $ret = $this->formShowDetail($HTTP_POST_VARS,$comment);
                           }
                        }
                     } elseif (isset($HTTP_POST_VARS["edit"])) {
                        global $ehr_ses_ehr_id;
                        $ret = $this->formAddEdit($state,$HTTP_POST_VARS,$showcancel);
                     } elseif (isset($HTTP_POST_VARS["cancel"])) {  // Cancel
                        if ($state == "add") {
                           unset($HTTP_POST_VARS);
                           $ret = $this->formAddEdit($state,$datarec,$showcancel,_EHR_GROUPSRV_SAVECANCEL);
                        } else{
                           if ($state == "edit") {
                              // Set back to original data
                              $comment = _EHR_GROUPSRV_SAVECANCEL;
                              $HTTP_POST_VARS["org_id"] = $HTTP_POST_VARS["old_org_id"];
                              $HTTP_POST_VARS["groupsrv_id"] = $HTTP_POST_VARS["old_groupsrv_id"];
                              $HTTP_POST_VARS["groupsrv_nm"] = $HTTP_POST_VARS["old_groupsrv_nm"];
                           } else {
                              $comment = _EHR_GROUPSRV_DELCANCEL;
                           }
                           $ret = $this->formShowDetail($HTTP_POST_VARS,$comment);
                        }
                     }
                     break;
               }
            } elseif ($HTTP_GET_VARS["show"] == "y" && $HTTP_GET_VARS["x"] != "") {
               global $ehr_ses_ehr_id;
               // Show group service data detail
               $sql = "SELECT groupsrv_id,groupsrv_nm
                       FROM ".XOCP_PREFIX."ehr_groupsrv
                       WHERE org_id = '$ehr_ses_ehr_id' AND status_cd = 'active'
                             AND groupsrv_id = '".$HTTP_GET_VARS["x"]."'";
               $result = $db->query($sql);
               if ($db->getRowsNum($result) > 0) {
                  $datarec = $db->fetchArray($result);
                  $ret = $this->formShowDetail($datarec);
               } else {
                  $ret = $this->groupServiceNavigate("","","",$ehr_ses_ehr_id);
               }
            } elseif ($HTTP_GET_VARS["p"] != "") {
               // Navigate group service data page
               global $ehr_ses_ehr_id;
               $ret = $this->groupServiceNavigate($HTTP_GET_VARS["fi"],$HTTP_GET_VARS["p"],$HTTP_GET_VARS["f"],$ehr_ses_ehr_id);
            } elseif (isset($HTTP_POST_VARS["btn_add"])) {
               // Add form
               $ret = $this->formAddEdit();
            } else {
               // This must be ripped out
               global $ehr_ses_ehr_id;
               $ret = $this->groupServiceNavigate("","","",$ehr_ses_ehr_id);
            }
            break;
         default:
            // Default handler
            global $ehr_ses_ehr_id;
            if (isset($ehr_ses_ehr_id) && $ehr_ses_ehr_id > 0) {
               $ret = $this->groupServiceNavigate("","","",$ehr_ses_ehr_id);
            } else {
               $ret = _EHR_GROUPSRV_NOORGSELECTED;
               $ret = $this->groupServiceNavigate("","","","0");
            }
            break;
      }
      return $ret;
   }

}
} // EHR_GROUPSERVICE_DEFINED
?>