<?php 
// --------------------------------------------------------------------//
// Filename : modules/ehr/empreg.php                                   //
// Software : XOCP - X Open Community Portal                           //
// Version  : 0.1                                                      //
// Date     : 2003-03-25                                               //
// License  : Public Domain                                            //
//                                                                     //
// You may use and modify this software as you wish. Share and Enjoy!  //
// --------------------------------------------------------------------//
if (!defined('EHR_EMPLOYEEREGISTRATION_DEFINED')) {
   define('EHR_EMPLOYEEREGISTRATION_DEFINED',true);

include_once(XOCP_DOC_ROOT."/modules/ehr/modconsts.php");

class _ehr_EmployeeRegistration extends XocpBlock {
   // Set block width
   var $width = "100%"; 
   // Catch variable for get method -- See below
   var $getparam; 
   // Catch variable for post method -- See below
   var $postparam;

   function searchPerson($datarec,$focused = TRUE,$comment = "") {
      $text_person_nm = new XocpFormText(_EHR_EMPREG_PERSONNAME,"person_nm",50,250,$datarec["person_nm"]);
      $submit_button = new XocpFormButton("","searchuser",_SEARCH,"submit");

      $form = new XocpThemeForm(_EHR_EMPREG_SEARCHPERSONTITLE,"fsearchperson","index.php");
      $form->addElement($this->postparam);
      $form->addElement($text_person_nm);
      $form->addElement($submit_button);
      if ($comment != "") {
         $form->setComment($comment);
      }
      if ($focused) {
         $this->html->setBodyOnLoad("onload='document.fsearchperson.person_nm.focus();'");
      }

      return $form->render();
   }

   function navigate($f,$p) {
      $dp = XocpDataPage::unserialize($f); 
      // Set page number
      $dp->setPage($p);
      $dp_found = $dp->getCount();
      $no1 = $dp->getOffset() + 1;
      $no2 = $no1 + $dp->getPageSize() - 1;
      if ($dp_found <= $no2) {
         $no2 = $dp_found;
      }
      // Creating header
      $dp_header = new XocpSimpleTable();
      $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam);
      $title = "<font class='tdh1'>"._EHR_EMPREG_PERSONLIST." ($no1 - $no2 "._OF." $dp_found)</font>"; 
      // How many page in data page?
      if (count($dp->getPageArray()) > 1) { // More than 1,show navigation links
         $hrow = $dp_header->addRow($title,$dp_prevnext);
      } else {
         $hrow = $dp_header->addRow($title);
      }
      $dp_header->setCellAlign($hrow,array("","right"));
      $dp_header->setWidth("100%"); 
      // Creating button tray form
      $btn_addnreg = new XocpFormButton("","btn_addnreg",_ADD,"submit");
      $elm_tray_addnreg = new XocpFormElementTray("");
      $elm_tray_addnreg->addElement($btn_addnreg);

      $form_buttons = new XocpSimpleForm("","fbuttons",XOCP_SERVER_SUBDIR."/index.php");
      $form_buttons->addElement($this->postparam);
      $form_buttons->addElement($elm_tray_addnreg); 
      // Creating footer
      $dp_footer = new XocpSimpleTable();
      if (count($dp->getPageArray()) > 1) { // More than 1,show navigation links
         $frow = $dp_footer->addRow($form_buttons->render(),$dp_prevnext);
      } else {
         $frow = $dp_footer->addRow($form_buttons->render());
      }
      $dp_footer->setCellAlign($frow,array("","right"));
      $dp_footer->setWidth("100%"); 
      // Creating data page
      $dp_table = new XocpTable(1);
      $dp_table->setWidth("100%");
      $hrow = $dp_table->addHeader($dp_header->render());
      $frow = $dp_table->addFooter($dp_footer->render()); 
      // Populating data page
      $dp_data = $dp->retrieve();
      foreach ($dp_data as $row) {
         list($link,$person_nm,$ssn,$ext_id,$addr_txt,$status_cd) = $row;
         $drow = $dp_table->addRow("<table width='100%'><tr><td width='75%'>$link</td><td width='25%' align='right'>$status_cd</td></tr><tr><td class='td1' colspan='2'>$addr_txt</td></tr></table>");
      }

      return $dp_table->render();
   }

   function doRegister($datarec,$comment = "",$allowadd = FALSE) {
      global $ehr_ses_ehr_id,$xocp_vars;
      $db = &Database::getInstance();
      list($person_id,$person_nm,$ssn,$addr_txt,$ext_id,$e_person_id,$employee_id,
           $status_cd,$jobtitle_nm,$hazard_exp_cd,$office_addr_txt,
           $telecom,$jobstart_dttm,$jobstop_dttm,$job_cd,$jobclass_cd,$adm_gender_cd,
           $birthplace,$birthdate,$zip_cd,$tel) = $datarec;
      if ($employee_id != "") {
         $registered = TRUE;
      } else {
         $registered = FALSE;
      }
      $elementtray_button = new XocpFormElementTray("");
      $hidden_person_id = new XocpFormHidden("person_id",htmlspecialchars(stripslashes($person_id)));
      $hidden_employee_id = new XocpFormHidden("employee_id",htmlspecialchars(stripslashes($employee_id)));
      if ($person_id != "0") {
         $hidden_person_nm = new XocpFormHidden("person_nm",htmlspecialchars(stripslashes($person_nm)));
         $hidden_adm_gender_cd = new XocpFormHidden("adm_gender_cd",htmlspecialchars(stripslashes($adm_gender_cd)));
         $hidden_birthplace = new XocpFormHidden("birthplace",htmlspecialchars(stripslashes($birthplace)));
         $hidden_birth_dttm = new XocpFormHidden("birth_dttm",htmlspecialchars(stripslashes($birthdate)));
         //$hidden_ssn = new XocpFormHidden("ssn",htmlspecialchars(stripslashes($ssn)));
         //$hidden_ext_id = new XocpFormHidden("ext_id",htmlspecialchars(stripslashes($ext_id)));
         $hidden_addr_txt = new XocpFormHidden("addr_txt",htmlspecialchars(stripslashes($addr_txt)));
         $hidden_zip_cd = new XocpFormHidden("zip_cd",htmlspecialchars(stripslashes($zip_cd)));
         $hidden_tel = new XocpFormHidden("tel",htmlspecialchars(stripslashes($tel)));
         
         $label_person_nm = new XocpFormLabel(_EHR_EMPREG_PERSONNAME,stripslashes($person_nm));
         $label_adm_gender_cd = new XocpFormLabel(_EHR_EMPREG_PERSONGENDER,$xocp_vars['gender'][$adm_gender_cd]);
         $label_birthplace = new XocpFormLabel(_EHR_EMPREG_PERSONBIRTHPLACE,stripslashes($birthplace));
         $label_birth_dttm = new XocpFormLabel(_EHR_EMPREG_PERSONBIRTHDATE,sql2ind2($birthdate));
         //$label_ssn = new XocpFormLabel(_EHR_EMPREG_PERSONSSN,stripslashes($ssn));
         //$label_ext_id = new XocpFormLabel(_EHR_EMPREG_PERSONEXTID,stripslashes($ext_id));
         $label_addr_txt = new XocpFormLabel(_EHR_EMPREG_PERSONADDRTXT,stripslashes($addr_txt));
         $label_zip_cd = new XocpFormLabel(_EHR_EMPREG_PERSONZIPCD,stripslashes($zip_cd));
         $label_tel = new XocpFormLabel(_EHR_EMPREG_PERSONTELECOM,stripslashes($tel));
      } else {
         $label_person_nm = new XocpFormText(_EHR_EMPREG_PERSONNAME,"person_nm",49,100,htmlspecialchars(stripslashes($person_nm)));
         $adm_gender_cd = $adm_gender_cd == "" ? "m" : $adm_gender_cd;
         $label_adm_gender_cd = new XocpFormRadio(_EHR_EMPREG_PERSONGENDER,"adm_gender_cd",htmlspecialchars(stripslashes($adm_gender_cd)));
         $label_adm_gender_cd->addOption('m',_MALE);
         $label_adm_gender_cd->addOption('f',_FEMALE);
         $label_birthplace = new XocpFormText(_EHR_EMPREG_PERSONBIRTHPLACE,"birthplace",49,100,htmlspecialchars(stripslashes($birthplace)));
         if ($birthdate == "" || $birthdate == "--") {
            $birthdate = date("Y-m-d",time());
         }
         $label_birth_dttm = new XocpFormDateTime(_EHR_EMPREG_PERSONBIRTHDATE,"birth",new XocpDateTime($birthdate));
         //$label_ssn = new XocpFormText(_EHR_EMPREG_PERSONSSN,"ssn",49,100,htmlspecialchars(stripslashes($ssn)));
         //$label_ext_id = new XocpFormText(_EHR_EMPREG_PERSONEXTID,"ext_id",49,100,htmlspecialchars(stripslashes($ext_id)));
         $label_addr_txt = new XocpFormTextArea(_EHR_EMPREG_PERSONADDRTXT,"addr_txt",htmlspecialchars(stripslashes($addr_txt)));
         $label_zip_cd = new XocpFormText(_EHR_EMPREG_PERSONZIPCD,"zip_cd",10,10,htmlspecialchars(stripslashes($zip_cd)));
         $label_tel = new XocpFormText(_EHR_EMPREG_PERSONTELECOM,"tel",30,50,htmlspecialchars(stripslashes($tel)));
      }
      if (!$registered) {
         $text_jobtitle_nm = new XocpFormText(_EHR_EMPREG_JOBTITLE,"jobtitle_nm",30,30,htmlspecialchars(stripslashes($jobtitle_nm)));
         $select_hazard_exp_cd = new XocpFormSelect(_EHR_EMPREG_HAZARDEXP,"hazard_exp_cd",htmlspecialchars(stripslashes($hazard_exp_cd)));
         $sql = "SELECT hazard_exp_cd,hazard_exp_nm FROM ".XOCP_PREFIX."sys_cd_hazard_exp ORDER BY hazard_exp_nm";
         $result = $db->query($sql);
         while (list($hazard_exp_cd,$hazard_exp_nm) = $db->fetchRow($result)) {
            $select_hazard_exp_cd->addOption($hazard_exp_cd,$hazard_exp_nm);
         }
         $textarea_addr_txt = new XocpFormTextArea(_EHR_EMPREG_OFFICEADDR,"office_addr_txt",htmlspecialchars(stripslashes($office_addr_txt)));
         $text_telecom = new XocpFormText(_EHR_EMPREG_OFFICETELECOM,"telecom",30,50,htmlspecialchars(stripslashes($telecom)));
         if ($jobstart_dttm == "--" || $jobstart_dttm == "") {
            $jobstart_dttm = date("Y-m-d",time());
         }
         $date_jobstart_dttm = new XocpFormDateTime(_EHR_EMPREG_JOBSTART,"jobstart",new XocpDateTime($jobstart_dttm));
         if ($jobstop_dttm == "--" || $jobstop_dttm == "") {
            $jobstop_dttm = date("Y-m-d",time());
         }
         $date_jobstop_dttm = new XocpFormDateTime(_EHR_EMPREG_JOBSTOP,"jobstop",new XocpDateTime($jobstop_dttm));
         $select_job_cd = new XocpFormSelect(_EHR_EMPREG_JOBCODE,"job_cd",htmlspecialchars(stripslashes($job_cd)));
         $sql = "SELECT jobclass_cd,jobclass_nm FROM ".XOCP_PREFIX."sys_cd_jobclass ORDER BY jobclass_nm";
         $result = $db->query($sql);
         while (list($jobclass_cod,$jobclass_nm) = $db->fetchRow($result)) {
            $select_job_cd->addOption($jobclass_cod,$jobclass_nm);
         }
         $select_jobclass_cd = new XocpFormSelect(_EHR_EMPREG_JOBCLASSCODE,"jobclass_cd",$jobclass_cd);
         $select_jobclass_cd->addOption("full_time",_EHR_EMPREG_FULLTIME);
         $select_jobclass_cd->addOption("part_time",_EHR_EMPREG_PARTTIME);
         $select_jobclass_cd->addOption("on_demand",_EHR_EMPREG_ONDEMAND);
         $submit_register = new XocpFormButton("","register",_EHR_EMPREG_REGISTER,"submit");
         $elementtray_button->addElement($submit_register);
      }
      $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
      $elementtray_button->addElement($submit_cancel);
      if ($allowadd) {
        $submit_add = new XocpFormButton("","btn_addnreg",_ADD,"submit");
        $elementtray_button->addElement($submit_add);
      }

      $form = new XocpThemeForm(_EHR_EMPREG_EMPLOYEEREGTITLE,"fempreg","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_person_id);
      $form->addElement($hidden_employee_id);
      if ($person_id != "0") {
         $form->addElement($hidden_person_nm);
         $form->addElement($hidden_adm_gender_cd);
         $form->addElement($hidden_birthplace);
         $form->addElement($hidden_birth_dttm);
         //$form->addElement($hidden_ssn);
         //$form->addElement($hidden_ext_id);
         $form->addElement($hidden_addr_txt);
         $form->addElement($hidden_zip_cd);
         $form->addElement($hidden_tel);
      }
      $form->addElement($label_person_nm);
      $form->addElement($label_adm_gender_cd);
      $form->addElement($label_birthplace);
      $form->addElement($label_birth_dttm);
      //$form->addElement($label_ssn);
      //$form->addElement($label_ext_id);
      $form->addElement($label_addr_txt);
      $form->addElement($label_zip_cd);
      $form->addElement($label_tel);
      if (!$registered) {
         $form->addElement($text_jobtitle_nm);
         $form->addElement($select_hazard_exp_cd);
         $form->addElement($textarea_addr_txt);
         $form->addElement($text_telecom);
         $form->addElement($date_jobstart_dttm);
         $form->addElement($date_jobstop_dttm);
         $form->addElement($select_job_cd);
         $form->addElement($select_jobclass_cd);
         if ($person_id != "0") {
            $this->html->setBodyOnLoad("onload='document.fempreg.register.focus();'");
         } else {
            $this->html->setBodyOnLoad("onload='document.fempreg.person_nm.focus();'");
         }
      } else {
         $form->setComment(_EHR_EMPREG_EMPREGISTERED);
         $this->html->setBodyOnLoad("onload='document.fempreg.cancel.focus();'");
      }
      $form->addElement($elementtray_button);
      if ($comment != "") {
         $form->setComment($comment);
      }
      return $form->render();
   }

   function doSearch($datarec) {
      global $ehr_ses_ehr_id;
      $db = &Database::getInstance();
      $nm = trim($datarec["person_nm"]);
      if (!eregi("\*",$nm)) {
         $nm = "%$nm%";
      } else {
         $nm = str_replace("*","%",$nm);
      }
      $sql = "SELECT p.person_id,p.person_nm,p.ssn,p.addr_txt,p.ext_id,e.person_id,
                     e.employee_id,e.status_cd
              FROM ".XOCP_PREFIX."persons p LEFT JOIN ".XOCP_PREFIX."ehr_employee e
                   ON (e.person_id = p.person_id AND e.org_id = '$ehr_ses_ehr_id')
              WHERE p.status_cd != 'nullified' AND p.person_nm LIKE '$nm'
              ORDER BY p.person_nm";
      $result = $db->query($sql);
      $found = (($numrec = $db->getRowsNum($result)) > 0);
      if ($found) {
         if ($numrec == 1) { // single record
            $search_result = $this->doRegister($db->fetchRow($result),NULL,TRUE);
         } else { // multiple record
            $dp = new XocpDataPage();
            $dp->setPageSize(5);
            while ($row = $db->fetchRow($result)) {
               list($person_id,$person_nm,$ssn,$addr_txt,$ext_id,$e_person_id,$employee_id,$status_cd) = $row;
               if ($status_cd == "nullified" || $e_person_id == "") {
                  $status_cd = _EHR_EMPREG_EMPNOTREGISTERED;
               } else {
                  $status_cd = _EHR_EMPREG_EMPREGISTERED;
               }
               $link = XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&show=y&pid=$person_id";
               $dp->addData(array("<a href='$link'>$person_nm</a>",
                                  $person_nm,$ssn,$ext_id,$addr_txt,$status_cd));
            }
            $dp->serialize();
            $search_result = $this->navigate($dp->getFile(),0);
            if ($dp->getCount() > 5) {
               $comment = _EHR_EMPREG_SEARCHPERSONINFO;
            }
         }
      } else {
         $comment = _EHR_EMPREG_PERSONNOTFOUND;
         $search_result = $this->doRegister(array(0,$datarec["person_nm"]));
      }
      $ret = $this->searchPerson($datarec,!$found,$comment)."<br />".$search_result;
      return $ret;
   }

   function show() {
      global $HTTP_POST_VARS,$HTTP_GET_VARS,$ehr_ses_ehr_id;
      $db = &Database::getInstance();
      $this->getparam = _EHR_CATCH_VAR."="._EHR_EMPLOYEEREGISTRATION_BLOCK;
      $this->postparam = new XocpFormHidden(_EHR_CATCH_VAR,_EHR_EMPLOYEEREGISTRATION_BLOCK);
      switch ($this->catch) {
         case _EHR_EMPLOYEEREGISTRATION_BLOCK:
            if (trim($HTTP_POST_VARS["person_nm"]) != "" && !isset($HTTP_POST_VARS["person_id"])) {
               // Search person
               $ret = $this->doSearch($HTTP_POST_VARS);
            } elseif ($HTTP_GET_VARS["p"] != "") {
               $ret = $this->searchPerson(NULL)."<br />".$this->navigate($HTTP_GET_VARS["f"],$HTTP_GET_VARS["p"]);
            } elseif ($HTTP_GET_VARS["show"] == "y") {
               $sql = "SELECT p.person_id,p.person_nm,p.ssn,p.addr_txt,p.ext_id,
                              e.person_id,e.employee_id,e.status_cd,e.jobtitle_nm,
                              e.hazard_exp_cd,e.addr_txt,e.telecom,e.jobstart_dttm,
                              e.jobstop_dttm,e.job_cd,e.jobclass_cd,p.adm_gender_cd,
                              p.birthplace,p.birth_dttm,p.zip_cd,p.telecom AS tel
                       FROM ".XOCP_PREFIX."persons p LEFT JOIN ".XOCP_PREFIX."ehr_employee e
                            ON (p.person_id = e.person_id AND e.org_id = '$ehr_ses_ehr_id')
                       WHERE p.person_id = '".$HTTP_GET_VARS["pid"]."'";
               $result = $db->query($sql);
               if ($db->getRowsNum($result)) {
                  $row = $db->fetchRow($result);
                  $ret = $this->searchPerson(NULL,FALSE)."<br />".$this->doRegister($row,NULL,$row[5] != "");
               } else {
                  $ret = $this->searchPerson(NULL,FALSE,_EHR_EMPREG_PERSONNOTFOUND)."<br />".$this->doRegister(array(0));
               }
            } elseif ($HTTP_POST_VARS["btn_addnreg"] != "") {
               $ret = $this->searchPerson(NULL,FALSE)."<br />".$this->doRegister(array(0));
            } elseif (($HTTP_POST_VARS["register"] != "" || $HTTP_POST_VARS["jobtitle_nm"] != "") && !isset($HTTP_POST_VARS["cancel"])) {
               if ($HTTP_POST_VARS["person_id"] == "0") { // Add person first
                  if (trim($HTTP_POST_VARS["person_nm"]) != "") {
                     $birthdate = $HTTP_POST_VARS["birth_year"]."-".$HTTP_POST_VARS["birth_mon"]."-".$HTTP_POST_VARS["birth_mday"]." 00:00:00";
                     $sql = "INSERT INTO ".XOCP_PREFIX."persons (person_nm,ssn,ext_id,addr_txt,
                                                                 zip_cd,telecom,birthplace,birth_dttm,adm_gender_cd)
                             VALUES ('".$HTTP_POST_VARS["person_nm"]."','".$HTTP_POST_VARS["ssn"]."',
                                     '".$HTTP_POST_VARS["ext_id"]."','".$HTTP_POST_VARS["addr_txt"]."',
                                     '".$HTTP_POST_VARS["zip_cd"]."','".$HTTP_POST_VARS["tel"]."',
                                     '".$HTTP_POST_VARS["birthplace"]."','$birthdate','".$HTTP_POST_VARS["adm_gender_cd"]."')";
                     $result = $db->query($sql);
                     $comment = $db->error();
                     if ($comment != "") {
                        $ret = $this->searchPerson(NULL,FALSE,_EHR_EMPREG_PERSONSAVEFAIL."<br />$comment");
                        break;
                     } else {
                        $HTTP_POST_VARS["person_id"] = $db->getInsertId();
                     }
                  } else {
                     $ret = $this->searchPerson(NULL,FALSE)."<br />".
                            $this->doRegister(array($HTTP_POST_VARS["person_id"],
                                                    $HTTP_POST_VARS["person_nm"],
                                                    $HTTP_POST_VARS["ssn"],
                                                    $HTTP_POST_VARS["addr_txt"],
                                                    $HTTP_POST_VARS["ext_id"],
                                                    $HTTP_POST_VARS["person_id"],
                                                    $HTTP_POST_VARS["employee_id"],"",
                                                    $HTTP_POST_VARS["jobtitle_nm"],
                                                    $HTTP_POST_VARS["hazard_exp_cd"],
                                                    $HTTP_POST_VARS["office_addr_txt"],
                                                    $HTTP_POST_VARS["telecom"],
                                                    $HTTP_POST_VARS["jobstart_year"]."-".
                                                    $HTTP_POST_VARS["jobstart_mon"]."-".
                                                    $HTTP_POST_VARS["jobstart_mday"],
                                                    $HTTP_POST_VARS["jobstop_year"]."-".
                                                    $HTTP_POST_VARS["jobstop_mon"]."-".
                                                    $HTTP_POST_VARS["jobstop_mday"],
                                                    $HTTP_POST_VARS["job_cd"],
                                                    $HTTP_POST_VARS["jobclass_cd"],
                                                    $HTTP_POST_VARS["adm_gender_cd"],
                                                    $HTTP_POST_VARS["birthplace"],
                                                    $HTTP_POST_VARS["birth_year"]."-".
                                                    $HTTP_POST_VARS["birth_mon"]."-".
                                                    $HTTP_POST_VARS["birth_mday"],
                                                    $HTTP_POST_VARS["zip_cd"],
                                                    $HTTP_POST_VARS["tel"]),
                                              _EHR_EMPREG_PERSONSAVEERROR);
                      break;
                  }
               }
               // Register person
               $jobstart_dttm = $HTTP_POST_VARS["jobstart_year"]."-".
                                $HTTP_POST_VARS["jobstart_mon"]."-".
                                $HTTP_POST_VARS["jobstart_mday"];
               $jobstop_dttm = $HTTP_POST_VARS["jobstop_year"]."-".
                               $HTTP_POST_VARS["jobstop_mon"]."-".
                               $HTTP_POST_VARS["jobstop_mday"];
               if ($HTTP_POST_VARS["employee_id"] == "") {
                 $sql = "SELECT MAX(employee_id) FROM ".XOCP_PREFIX."ehr_employee
                         WHERE org_id = '$ehr_ses_ehr_id'";
                 $result = $db->query($sql);
                 list($employee_id) = $db->fetchRow($result);
                 if ($employee_id == "") {
                    $employee_id = 1;
                 } else {
                    $employee_id++;
                 } 
               } else {
                  $employee_id = $HTTP_POST_VARS["employee_id"];
               }
               $sql = "REPLACE INTO ".XOCP_PREFIX."ehr_employee (org_id,employee_id,person_id,
                                                                 jobtitle_nm,hazard_exp_cd,
                                                                 addr_txt,telecom,jobstart_dttm,
                                                              	  jobstop_dttm,job_cd,
                                                                 status_cd,rc_dttm,jobclass_cd)
                       VALUES ('$ehr_ses_ehr_id','$employee_id','".$HTTP_POST_VARS["person_id"]."',
                               '".$HTTP_POST_VARS["jobtitle_nm"]."','".$HTTP_POST_VARS["hazard_exp_cd"]."',
                               '".$HTTP_POST_VARS["office_addr_txt"]."','".$HTTP_POST_VARS["telecom"]."',
                               '$jobstart_dttm 00:00:00','$jobstop_dttm 00:00:00',
                               '".$HTTP_POST_VARS["job_cd"]."','active',NOW(),'".$HTTP_POST_VARS["jobclass_cd"]."')";
               $result = $db->query($sql);
               $comment = $db->error();
               if ($comment != "") {
                  $ret = $this->searchPerson(NULL,TRUE,_EHR_EMPREG_SAVEFAIL."<br />$comment");
               } else {
                  $ret = $this->searchPerson(NULL,TRUE,_EHR_EMPREG_SAVESUCCESS);
               }
            } else {
               if ($ehr_ses_ehr_id > 0) {
                  $ret = $this->searchPerson(NULL);
               }
            }
            break;
        default: 
           // Default handler
           if ($ehr_ses_ehr_id > 0) {
              $ret = $this->searchPerson($HTTP_POST_VARS);
           }
           break;
        }
        return "<br />".$ret;
    }
}

} // EHR_EMPLOYEEREGISTRATION_DEFINED
?>