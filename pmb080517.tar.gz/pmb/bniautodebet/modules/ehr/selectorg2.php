<?php
//--------------------------------------------------------------------//
// Filename : modules/ehr/selectorg.php                               //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-03-24                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('EHR_SELECTORG_DEFINED') ) {
   define('EHR_SELECTORG_DEFINED', TRUE);

include_once(XOCP_DOC_ROOT."/modules/ehr/modconsts.php");
include_once(XOCP_DOC_ROOT."/modules/ehr/class/orgtree.php");
   
class _ehr_SelectOrg extends XocpBlock {

   function formSelectOrg() {
      global $xocp_user,$xocp_page_id;
      $pgroup_id = $xocp_user->getVar("pgroup_id");
      $db =& Database::getInstance();
      $sql = "SELECT a.org_id,b.org_nm,c.org_id FROM ".XOCP_PREFIX."ehr_pgroup_org a"
           . " LEFT JOIN ".XOCP_PREFIX."orgs b USING(org_id)"
           . " LEFT JOIN ".XOCP_PREFIX."ehr_orglink c ON c.sub_id = a.org_id"
           . " WHERE a.pgroup_id = '$pgroup_id' ORDER BY b.org_nm";
      $result = $db->query($sql);
      $tree = new _ehr_OrgTree();
      while (list($org_id,$org_nm,$parent_org_id) = $db->fetchRow($result)) {
         $parents["$org_id"] = $org_nm;
         $node = new _ehr_OrgTreeNode($org_id,$org_nm,$parent_org_id,XOCP_SERVER_SUBDIR."/index.php?XP_".$xocp_page_id."_ehr=6&org_id=$org_id");
         $tree->addItem($node);
      }
      
      $dp_header = new XocpSimpleTable();
      $hrow = $dp_header->addRow("<font class='tdh1'>"._EHR_SELECTORGSELECT."</font>");
      $dp_header->setWidth("100%");
      $dp_table = new XocpTable(1);
      $hrow = $dp_table->addHeader($dp_header->render());
      $drow = $dp_table->addRow($tree->render());
      return $dp_table->render();
   }
   
   function showOrg() {
      global $ehr_ses_ehr_id,$xocp_page_id;
      $db =& Database::getInstance();
      $sql = "SELECT o.org_id,o.org_nm FROM ".XOCP_PREFIX."orgs o
              WHERE o.org_id = $ehr_ses_ehr_id";
      $result = $db->query($sql);
      list($org_id,$org_nm) = $db->fetchRow($result);
      if($org_nm == "") $org_nm = "select";
      return "<table border=0 width=100% cellpadding=2 cellspacing=0>
              <tr><td bgcolor=#aa0000><b><i>$org_nm</i></b></td>
              <td align=right bgcolor=#aa0000>[<a href='".XOCP_SERVER_SUBDIR."/index.php?XP_".$xocp_page_id."_ehr=6"
              ."&ch=y'>"._EHR_SELECTORGANIZATION."</a>]</td></tr></table>";
   }

   function show() {
      global $ehr_ses_org_id,$ehr_ses_ehr_id,$HTTP_GET_VARS,$xocp_page_id;
      switch ($this->catch) {
         case "6":
            if ($HTTP_GET_VARS["org_id"] != "") {
               $ehr_ses_ehr_id = $HTTP_GET_VARS["org_id"];
               $ehr_ses_org_id = $HTTP_GET_VARS["org_id"];
               $ret = $this->showOrg();
            } elseif ($HTTP_GET_VARS["ch"] == "y") {
               $ehr_ses_ehr_id = 0;
               $ehr_ses_org_id = 0;
               $ret = "<br />".$this->formSelectOrg();
            }
            break;
         default:
            if (!session_is_registered("ehr_ses_org_id")) {
               session_register("ehr_ses_org_id");
               $ehr_ses_org_id = "0";
            }
            if (!session_is_registered("ehr_ses_ehr_id")) {
               session_register("ehr_ses_ehr_id");
               $ehr_ses_ehr_id = "0";
            }
            if($ehr_ses_ehr_id == "0") {
               $ret = "<br />".$this->formSelectOrg();
            } else {
               $ret = $this->showOrg();
            }
            break;
      }
      return $ret;
   }
}

} // EHR_SELECTORG_DEFINED
?>