<?php
//--------------------------------------------------------------------//
// Filename : modules/ehr/orglink.php                                 //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-03-17                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('PRJ_ORGLINK_DEFINED') ) {
   define('PRJ_ORGLINK_DEFINED', TRUE);

include_once(XOCP_DOC_ROOT."/modules/ehr/modconsts.php");

class _ehr_OrgLink extends XocpBlock {
   var $width = "100%";
   
   function browse($f = NULL) {
      global $HTTP_GET_VARS;
      
      if($f == NULL) {
         $db = Database::getInstance();
         $sql = "SELECT a.org_nm,a.org_id,b.sub_id,c.org_nm FROM ".XOCP_PREFIX."orgs a"
              . " LEFT JOIN ".XOCP_PREFIX."ehr_orglink b USING (org_id)"
              . " LEFT JOIN ".XOCP_PREFIX."orgs c on c.org_id=b.sub_id"
              . " ORDER BY a.org_nm,c.org_nm";
         $result = $db->query($sql);
         $c = $db->getRowsNum($result);
         if($c > 0) {
            $dp = new XocpDataPage();
            $dp->setPageSize(20);
            unset($old_org_id);
            unset($old_org_nm);
            while(list($org_nm,$org_id,$sub_id,$sub_nm)=$db->fetchRow($result)) {
               if($org_id != $old_org_id) {
                  if(isset($old_org_nm)) {
                     $dp->addData(array($old_org_id,$old_org_nm,implode("<br/>",$sublist)));
                  }
                  unset($sublist);
                  $sublist = array();
                  if ($sub_nm != "") {
                  	$sublist[] = $sub_nm;
                  }
                  $old_org_nm = $org_nm;
                  $old_org_id = $org_id;
               } else {
                  if ($sub_nm != "") {
                  	$sublist[] = $sub_nm;
                  }
               }
            }
            $dp->addData(array($old_org_id,$old_org_nm,implode(", ",$sublist)));
            $dp->serialize();
            $found = $dp->getCount();
            $dpfile = $dp->getFile();
            $dp->reset();
         } else {
            return $sql . _EHR_ORGLINK_ORGNOTFOUND;
         }
      } else {
         $dp = XocpDataPage::unserialize($f);
         $dp->setPage($HTTP_GET_VARS["p"]);
         $found = $dp->getCount();
      }

      $xurl = XOCP_SERVER_SUBDIR."/index.php?X_ehr=2";
      $prevnext = $dp->getPageLinks($xurl);

      $htable = new XocpSimpleTable();
      $sno = $htable->addRow(_EHR_ORGLINK_ORGLIST." : $found "._FOUND,$prevnext);
      $htable->setCellAlign($sno,array("","right"));
      $htable->setWidth("100%");

      $ftable = new XocpSimpleTable();
      $sno = $ftable->addRow($prevnext);
      $ftable->setCellAlign($sno,array("right"));
      $ftable->setWidth("100%");

      $table = new XocpTable(1);
      $table->setWidth("100%");
      $hno = $table->addHeader($htable->render());
      $fno = $table->addFooter($ftable->render());
      
      $no = $dp->getOffset() + 1;
      $data = $dp->retrieve();
      foreach($data as $x) {
         list($org_id,$org_nm,$sublist) = $x;
         $rno = $table->addRow("$no. <b><a href=$xurl&edit=y&x=$org_id".">$org_nm</a></b><br/>$sublist");
         $no++;
      }

      return $table->render();

   }
   

   function editOrgLink($org_id,$catch_id) {
      $db =& Database::getInstance();
      $sql = "SELECT a.org_nm,c.org_id,c.org_nm from ".XOCP_PREFIX."orgs a"
           . " LEFT JOIN ".XOCP_PREFIX."ehr_orglink b USING (org_id)"
           . " LEFT JOIN ".XOCP_PREFIX."orgs c ON c.org_id=b.sub_id"
           . " WHERE a.org_id = '$org_id'"
           . " ORDER BY c.org_nm";
      $result = $db->query($sql);
      $c = $db->getRowsNum($result);
      $org_nm = "";
      if($c > 0) {
         while(list($org_nmx,$sub_id,$sub_nm) = $db->fetchRow($result)) {
            $subarray[$sub_id] = $sub_nm;
            $org_nm = $org_nmx;
         }
      }
      
      $orgname = new XocpFormLabel(_EHR_ORGLINK_ORGNAME, "$org_nm");
      $elementtray_subs = new XocpFormElementTray(_EHR_ORGLINK_ASSIGNEDORGLIST,"<br/>");
      if(is_array($subarray)) {
         reset($subarray);
         $n = 0;
         foreach($subarray as $sub_id=>$sub_nm) {
            if(empty($sub_nm)) continue;
            $ckbname = "sub$n";
            $xckb = new XocpFormCheckBox("",$ckbname);
            $xckb->addOption($sub_id,$sub_nm);
            $elementtray_subs->addElement($xckb);
            $n++;
         }
         if($n>0) {
            $delete_sub = new XocpFormButton("", "deletesub", _DELETE, "submit");
            $elementtray_subs->addElement($delete_sub);
         } else {
            $nosub = new XocpFormLabel("",_EHR_ORGLINK_ORGNOTASSIGNED);
            $elementtray_subs->addElement($nosub);
         }
      }
   
   
      $hidden = new XocpFormHidden("X_ehr",$catch_id);
      $hidden_n = new XocpFormHidden("n",$n);
      $horg_id = new XocpFormHidden("uorg","$org_id");
      
      $add_button = new XocpFormButton("", "addsub", _ADD, "submit");
      $selectsub = new XocpFormSelect("","addsub_id");
      $sql = "SELECT org_id,org_nm,description FROM ".XOCP_PREFIX."orgs"
           . " ORDER BY org_nm";
      $result = $db->query($sql);
      if($db->getRowsNum($result)>0) {
         while(list($org_id,$org_nm,$description)=$db->fetchRow($result)) {
            $selectsub->addOption($org_id,$org_nm);
         }
      }
      
      $elementtray_buttons = new XocpFormElementTray(_EHR_ORGLINK_ADDORG,"<br/>");
      $elementtray_buttons->addElement($selectsub);
      $elementtray_buttons->addElement($add_button);
   
      $cancel_button = new XocpFormButton("", "cancel", _CANCEL, "submit");
      
      $form = new XocpThemeForm(_EHR_ORGLINK_EDITLINK, "updateorglinkform", "index.php","post");
      $form->setWidth("100%");
               
      $form->addElement($orgname);
      $form->addElement($elementtray_subs);
      $form->addElement($hidden);
      $form->addElement($hidden_n);
      $form->addElement($horg_id);
      $form->addElement($elementtray_buttons);
      $form->addElement($cancel_button);
   
      return $form;
   }


   function main() {
      
      switch($this->catch) {
         case "2" :
            global $HTTP_POST_VARS,$HTTP_GET_VARS;
            if($HTTP_GET_VARS["f"] != "") {
               $ret = $this->browse($HTTP_GET_VARS["f"]);
               break;
            } else if($HTTP_GET_VARS["edit"] == "y") {
               $form = $this->editOrgLink($HTTP_GET_VARS["x"],2);
               $ret .= $form->render();
               break;
            } else if(!empty($HTTP_POST_VARS["addsub"])) {
               $db =& Database::getInstance();
               $sql = "INSERT INTO ".XOCP_PREFIX."ehr_orglink (org_id,sub_id)"
                    . " VALUES ('".$HTTP_POST_VARS["uorg"]."','".$HTTP_POST_VARS["addsub_id"]."')";
               $db->query($sql);
               $form = $this->editOrgLink($HTTP_POST_VARS["uorg"],2);
               $form->setComment($db->error());
               $ret .= $form->render();
               break;
            } else if(!empty($HTTP_POST_VARS["deletesub"])) {
               $org_id = $HTTP_POST_VARS["uorg"];
               $n = $HTTP_POST_VARS["n"];
               $db =& Database::getInstance();
               if($n>0) {
                  for($i=0;$i<$n;$i++) {
                     $sub_id = $HTTP_POST_VARS["sub$i"];
                     if($sub_id != '') {
                        $sql = "DELETE FROM ".XOCP_PREFIX."ehr_orglink"
                             . " WHERE org_id = '$org_id' AND sub_id = '$sub_id'";
                        $db->query($sql);
                     }
                  }
               }
               $form = $this->editOrgLink($org_id,2);
               $ret .= $form->render();
               break;
            }

         default : 
            $ret .= $this->browse();
      }
      
      return "<b>" . _EHR_ORGLINK_ADMIN . "</b><br/><br/>" . $ret;
      
   }
   
}

} // PRJ_ORGLINK_DEFINED
?>