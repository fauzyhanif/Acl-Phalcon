<?php
//--------------------------------------------------------------------//
// Filename : modules/ehr/selectpatient.php                           //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-03-24                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('EHR_SELECTPATIENT_DEFINED') ) {
   define('EHR_SELECTPATIENT_DEFINED', TRUE);

include_once(XOCP_DOC_ROOT."/modules/ehr/modconsts.php");
   
function ehr_searchpatient_funccmp($a,$b) {
   if ($a[5] == $b[5]) {
      return strcmp($a[1],$b[1]);
   }
   return ($a[5] > $b[5]) ? -1 : 1;
}

class _ehr_SelectPatient extends XocpBlock {
   var $width = "100%";
   var $postparam;
   var $getparam;

   function formSelectPatient($datarec,$comment="") {
      global $xocp_user,$xocp_page_id, $ehr_ses_ehr_id;

      $text_person_nm = new XocpFormText(_EHR_PATIENTNAME,"person_nm",50,250,$datarec["person_nm"]);
      $text_patient_mrn = new XocpFormText(_EHR_PATIENTEXTID,"patient_mrn",50,250,$datarec["patient_mrn"]);
      $submit_button = new XocpFormButton("","searchpatient",_SEARCH,"submit");

      $form = new XocpThemeForm(_EHR_PATIENT_SEARCH,"fselectpatient","index.php","get");
      $form->addElement($this->postparam);
      $form->addElement($text_patient_mrn);
      $form->addElement($text_person_nm);
      $form->addElement($submit_button);
      if ($comment != "") {
         $form->setComment($comment);
      }
      $this->html->setBodyOnLoad("onload='document.fselectpatient.patient_mrn.focus();'");

      return $form->render();
   }
   
   function doSearch($datarec) {
      global $ehr_ses_ehr_id;
      $db =& Database::getInstance();

      $nm = trim($datarec["person_nm"]);
      $mrn = trim($datarec["patient_mrn"]);
      
      if($mrn != "") {
         $mrn = str_replace("*","%",$mrn);
         $sql = "SELECT p.person_nm,p.addr_txt,pt.patient_ext_id,pt.patient_id"
              . " FROM ".XOCP_PREFIX."ehr_patient pt"
              . " LEFT JOIN ".XOCP_PREFIX."persons p USING (person_id)"
              . " WHERE pt.patient_ext_id LIKE '$mrn' AND pt.org_id = '$ehr_ses_ehr_id'";
      } elseif ($nm != "") {
         if (!eregi("\*",$nm)) {
            $nm = "%$nm%";
         } else {
            $nm = str_replace("*","%",$nm);
         }
         $sql = "SELECT p.person_nm,p.addr_txt,pt.patient_ext_id,pt.patient_id"
              . " FROM ".XOCP_PREFIX."ehr_patient pt"
              . " LEFT JOIN ".XOCP_PREFIX."persons p USING (person_id)"
              . " WHERE p.person_nm LIKE '$nm' AND pt.org_id = '$ehr_ses_ehr_id'";
      } else {
      
      }
      
      $result = $db->query($sql);
      if ($db->getRowsNum($result) > 0) {
         $dp = new XocpDataPage();
         $dp->setPageSize(5);
         while ($row = $db->fetchRow($result)) {
            list($person_nm,$addr_txt,$patient_ext_id,$patient_id) = $row;
            similar_text($person_nm,str_replace("%","",$nm),$score);
            $link = XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&selectpt=$patient_id";
            $dp->addData(array("<a href='$link'>$person_nm</a>",$person_nm,$addr_txt,$patient_ext_id,$patient_id,$score));
         }
         usort($dp->data,"ehr_searchpatient_funccmp");
         array_reverse($dp->data);
         $dp->serialize();
         $search_result = $this->navigate($dp->getFile(),0);
         if ($dp->getCount() > 5) {
            $comment = _EHR_SEARCHPATIENTINFO;
         }
      } else {
         $comment = _EHR_PATIENTNOTFOUND;
         $search_result = "";
      }
      $ret = $this->formSelectPatient($datarec,$comment)."<br />".$search_result;
      return $ret;
   }
   

   function navigate($f,$p) {
      $dp = XocpDataPage::unserialize($f);
      // Set page number
      $dp->setPage($p);
      $dp_found = $dp->getCount();
      $no1 = $dp->getOffset() + 1;
      $no2 = $no1 + $dp->getPageSize() - 1;
      if ($dp_found <= $no2) {
         $no2 = $dp_found;
      }
      // Creating header
      $dp_header = new XocpSimpleTable();
      $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam);
      $title = "<font class='tdh1'>"._EHR_PATIENTLIST." ($no1 - $no2 "._OF." $dp_found)</font>";
      // How many page in data page?
      if (count($dp->getPageArray()) > 1) {  // More than 1, show navigation links
         $hrow = $dp_header->addRow($title,$dp_prevnext);
      } else {
         $hrow = $dp_header->addRow($title);
      }
      $dp_header->setCellAlign($hrow,array("","right"));
      $dp_header->setWidth("100%");

      // Creating footer
      $dp_footer = new XocpSimpleTable();
      if (count($dp->getPageArray()) > 1) {  // More than 1, show navigation links
         $frow = $dp_footer->addRow("&nbsp;",$dp_prevnext);
      } else {
         $frow = $dp_footer->addRow("&nbsp;");
      }
      $dp_footer->setCellAlign($frow,array("","right"));
      $dp_footer->setWidth("100%");
                                    
      // Creating data page
      $dp_table = new XocpTable(1);
      $dp_table->setWidth("100%");
      $hrow = $dp_table->addHeader($dp_header->render());
      $frow = $dp_table->addFooter($dp_footer->render());
                                           
      // Populating data page
      $dp_data = $dp->retrieve();
      foreach ($dp_data as $row) {
         list($link,$person_nm,$addr_txt,$patient_ext_id,$patient_id,$score) = $row;
         $drow = $dp_table->addRow("[ $patient_ext_id ]<br />$link<br />".nl2br($addr_txt));
      }
                                                                     
      return $dp_table->render();
   }
   



   function showPatient() {
      global $ehr_ses_ehr_id,$ehr_ses_patient_id,$xocp_page_id;
      $db =& Database::getInstance();
      $sql = "SELECT p.person_nm,pt.patient_ext_id"
           . " FROM ".XOCP_PREFIX."ehr_patient pt"
           . " LEFT JOIN ".XOCP_PREFIX."persons p USING (person_id)"
           . " WHERE pt.patient_id = '$ehr_ses_patient_id' AND pt.org_id = '$ehr_ses_ehr_id'";
      $result = $db->query($sql);
      list($patient_nm,$patient_ext_id) = $db->fetchRow($result);
      return "<table border=0 width=100% cellpadding=2 cellspacing=0>
              <tr><td bgcolor=#00aa00><b>[ $patient_ext_id ] $patient_nm</b></td>
              <td align=right bgcolor=#00aa00>[<a href='".XOCP_SERVER_SUBDIR."/index.php?".$this->getparam
              ."&ch=y'>"._EHR_PATIENTSELECT."</a>]</td></tr></table>";
   }

   function show() {
      global $ehr_ses_org_id,$ehr_ses_patient_id,$HTTP_GET_VARS,$xocp_page_id;
      global $HTTP_POST_VARS,$ehr_ses_ehr_id;

      $this->getparam = _EHR_CATCH_VAR."="._EHR_SHOWPATIENT_BLOCK;
      $this->postparam = new XocpFormHidden(_EHR_CATCH_VAR,_EHR_SHOWPATIENT_BLOCK);

      switch ($this->catch) {
         case _EHR_SHOWPATIENT_BLOCK:
            if ($HTTP_GET_VARS["selectpt"] != "") {
               $ehr_ses_patient_id = $HTTP_GET_VARS["selectpt"];
               $ret = $this->showPatient();
            } elseif ($HTTP_GET_VARS["ch"] == "y") {
               $ehr_ses_patient_id = 0;
               $ret = "<br />".$this->formSelectPatient(NULL);
            } elseif ($HTTP_GET_VARS["searchpatient"] != "") {
               $ret = "<br />" . $this->doSearch($HTTP_GET_VARS);
            } elseif ($HTTP_GET_VARS["p"] != "") {
               $ret = $this->formSelectPatient(NULL)."<br />".$this->navigate($HTTP_GET_VARS["f"],$HTTP_GET_VARS["p"]);
            }
            break;
         default:
            if (!session_is_registered("ehr_ses_patient_id")) {
               session_register("ehr_ses_patient_id");
               $ehr_ses_patient_id = 0;
            }
            if($ehr_ses_ehr_id > 0) {
               if($ehr_ses_patient_id == 0) {
                  $ret = "<br />".$this->formSelectPatient(NULL);
               } else {
                  $ret = $this->showPatient();
               }
            } else {
               $ret = "";
            }
            break;
      }
      return $ret;
   }
}

} // EHR_SELECTPATIENT_DEFINED
?>