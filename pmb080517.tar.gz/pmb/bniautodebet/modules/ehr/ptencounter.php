<?php
//--------------------------------------------------------------------//
// Filename : modules/ehr/ptencounter.php                             //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2003-03-25                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('EHR_PATIENTENCOUNTER_DEFINED') ) {
   define('EHR_PATIENTENCOUNTER_DEFINED',TRUE);
   
include_once(XOCP_DOC_ROOT."/modules/ehr/modconsts.php");

function person_funccmp($a,$b) {
   if ($a[8] == $b[8]) {
      return strcmp($a[2],$b[2]);
   }
   return ($a[8] > $b[8]) ? -1 : 1;
}

class _ehr_PatientEncounter extends XocpBlock {
   // Set block width
   var $width = "100%";
   // Catch variable for get method -- See below
   var $getparam;
   // Catch variable for post method -- See below
   var $postparam;
   
   function searchPatient($datarec,$comment = "") {
      $text_ext_id = new XocpFormText(_EHR_PATIENTEXTID,"ext_id",50,250,htmlspecialchars(stripslashes($datarec["ext_id"])));
      $text_person_nm = new XocpFormText(_EHR_PATIENTNAME,"person_nm",50,250,htmlspecialchars(stripslashes($datarec["person_nm"])));
      $admission_dt = new XocpDateTime();
      $admission_dt->eatVars("admission","post");
      if ($admission_dt->getMySQL() == "0000-00-00") {
         $admission_dt->eatVars("encounter","post");
         if ($admission_dt->getMySQL() == "0000-00-00") {
            $admission_dt->setDateTime(getdate(time()));
         }
      }
      $date_admission_dt = new XocpFormDateTime(_EHR_PTENC_ADMISSIONDATE,"admission",$admission_dt,"date");
      $submit_button = new XocpFormButton("","searchperson",_SEARCH,"submit");

      $form = new XocpThemeForm(_EHR_PTENC_SEARCHPATIENTTITLE,"fsearchpatient","index.php");
      $form->addElement($this->postparam);
      $form->addElement($date_admission_dt);
      $form->addElement($text_ext_id);
      $form->addElement($text_person_nm);
      $form->addElement($submit_button);
      if ($comment != "") {
         $form->setComment($comment);
      }
      $this->html->setBodyOnLoad("onload='document.fsearchpatient.admission_mday.focus();'");

      return $form->render();
   }
   
   function navigate($f,$p) {
      $dp = XocpDataPage::unserialize($f);
      // Set page number
      $dp->setPage($p);
      $dp_found = $dp->getCount();
      $no1 = $dp->getOffset() + 1;
      $no2 = $no1 + $dp->getPageSize() - 1;
      if ($dp_found <= $no2) {
         $no2 = $dp_found;
      }
      // Creating header
      $dp_header = new XocpSimpleTable();
      $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam);
      $title = "<font class='tdh1'>"._EHR_PATIENTLIST." ($no1 - $no2 "._OF." $dp_found)</font>";
      // How many page in data page?
      if (count($dp->getPageArray()) > 1) {  // More than 1, show navigation links
         $hrow = $dp_header->addRow($title,$dp_prevnext);
      } else {
         $hrow = $dp_header->addRow($title);
      }
      $dp_header->setCellAlign($hrow,array("","right"));
      $dp_header->setWidth("100%");

      // Creating footer
      $dp_footer = new XocpSimpleTable();
      if (count($dp->getPageArray()) > 1) {  // More than 1, show navigation links
         $frow = $dp_footer->addRow("&nbsp;",$dp_prevnext);
      } else {
         $frow = $dp_footer->addRow("&nbsp;");
      }
      $dp_footer->setCellAlign($frow,array("","right"));
      $dp_footer->setWidth("100%");
                                    
      // Creating data page
      $dp_table = new XocpTable(1);
      $dp_table->setWidth("100%");
      $hrow = $dp_table->addHeader($dp_header->render());
      $frow = $dp_table->addFooter($dp_footer->render());
                                           
      // Populating data page
      $dp_data = $dp->retrieve();
      foreach ($dp_data as $row) {
         list($link,$person_id,$person_nm,$ssn,$addr_txt,$ext_id,$patient_id,$org_id,$score) = $row;
         $drow = $dp_table->addRow("$ext_id - $link<br />".nl2br($addr_txt));
      }
                                                                     
      return $dp_table->render();
   }
   
   function doEncounter($datarec,$comment = "") {
      global $ehr_ses_ehr_id,$ehr_ses_physician_id;
      $db = &Database::getInstance();
      $hidden_person_id = new XocpFormHidden("person_id",htmlspecialchars(stripslashes($datarec["person_id"])));
      $hidden_patient_id = new XocpFormHidden("patient_id",htmlspecialchars(stripslashes($datarec["patient_id"])));
      $hidden_patient_org_id = new XocpFormHidden("patient_org_id",htmlspecialchars(stripslashes($datarec["org_id"])));

      $hidden_person_nm = new XocpFormHidden("person_nm",htmlspecialchars(stripslashes($datarec["person_nm"])));
      //$hidden_ssn = new XocpFormHidden("ssn",htmlspecialchars(stripslashes($datarec["ssn"])));
      $hidden_ext_id = new XocpFormHidden("ext_id",htmlspecialchars(stripslashes($datarec["ext_id"])));
      //$hidden_addr_txt = new XocpFormHidden("addr_txt",htmlspecialchars(stripslashes($datarec["addr_txt"])));

      $label_person_nm = new XocpFormLabel(_EHR_PATIENTNAME,stripslashes($datarec["person_nm"]));
      //$label_ssn = new XocpFormLabel(_EHR_PATIENTSSN,stripslashes($datarec["ssn"]));
      $label_ext_id = new XocpFormLabel(_EHR_PATIENTEXTID,stripslashes($datarec["ext_id"]));
      //$label_addr_txt = new XocpFormLabel(_EHR_PATIENTADDRTXT,nl2br(stripslashes($datarec["addr_txt"])));
      $select_employee_id = new XocpFormSelect(_EHR_PTENC_SELECTPHYSICIAN,"employee_id",$ehr_ses_physician_id);
      $sql = "SELECT e.employee_id,p.person_nm FROM ".XOCP_PREFIX."ehr_employee e "
           . "LEFT JOIN ".XOCP_PREFIX."persons p USING (person_id) "
           . "WHERE e.org_id = '$ehr_ses_ehr_id' ORDER BY p.person_nm";
      $result = $db->query($sql);
      while (list($employee_id,$person_nm) = $db->fetchRow($result)) {
         $select_employee_id->addOption($employee_id,"$person_nm - $employee_id");
      }
      $current_date = new XocpDateTime();
      $current_date->eatVars("encounter","post");
      if ($current_date->getMySQL("datetime") == "0000-00-00 00:00:00") {
         /*$sql = "SELECT admission_dt,admission_tm FROM ".XOCP_PREFIX."ehr_admission "
              . "WHERE patient_org_id = '".$datarec["org_id"]."' AND patient_id = '".$datarec["patient_id"]."' "
              . "AND admission_dt = '".$datarec["date_adm"]."' AND patient_id = '".$datarec["patient_id"]."' "
              . "ORDER BY admission_dt DESC,admission_tm DESC";
         $result = $db->query($sql);
         list($date_adm,$time_adm) = $db->fetchRow($result);
         if ($date_adm != NULL) {
            $current_date->setDateTime("$date_adm $time_adm");
         } else {
            $current_date->setDateTime(getdate(time()));
         }*/
         $current_date->setDateTime(getdate(time()));
      }
      $dttm_encounter = new XocpFormDateTime(_EHR_PTENC_ENCOUNTERDTTM,"encounter",$current_date,"datetime");

      $submit_submit = new XocpFormButton("","submit",_SUBMIT,"submit");
      $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
      $elementtray_button = new XocpFormElementTray("");
      $elementtray_button->addElement($submit_submit);
      $elementtray_button->addElement($submit_cancel);

      $form = new XocpThemeForm(_EHR_PTENC_PATIENTENCOUNTERTITLE,"fptenc","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_person_id);
      $form->addElement($hidden_patient_id);
      $form->addElement($hidden_patient_org_id);
      $form->addElement($hidden_person_nm);
      //$form->addElement($hidden_ssn);
      $form->addElement($hidden_ext_id);
      //$form->addElement($hidden_addr_txt);
      $form->addElement($label_person_nm);
      //$form->addElement($label_ssn);
      $form->addElement($label_ext_id);
      //$form->addElement($label_addr_txt);
      $form->addElement($select_employee_id);
      $form->addElement($dttm_encounter);
      $form->addElement($elementtray_button);

      $this->html->setBodyOnLoad("onload='document.fptenc.submit.focus();'");
      if ($comment != "") {
         $form->setComment($comment);
      }
      return $form->render();
   }

   function doSearch($datarec) {
      global $ehr_ses_ehr_id;
      $db =& Database::getInstance();
      $nm = trim($datarec["person_nm"]);
      $id = trim($datarec["ext_id"]);
      if (!eregi("\*",$nm) && $nm != "") {
         $nm = "%$nm%";
      } else {
         $nm = str_replace("*","%",$nm);
      }
      $admission_dt = new XocpDateTime();
      $admission_dt->eatVars("admission","post");
      $sql = "SELECT DISTINCT p.person_id,p.person_nm,p.ssn,p.addr_txt,pt.patient_ext_id,pt.patient_id,
                     pt.org_id,a.admission_dt
              FROM ".XOCP_PREFIX."ehr_admission a
                   LEFT JOIN ".XOCP_PREFIX."ehr_patient pt
                      ON (a.patient_id = pt.patient_id AND a.patient_org_id = pt.org_id AND
                          a.patient_org_id = '$ehr_ses_ehr_id' AND a.admission_dt LIKE '".str_replace("-00","-%",$admission_dt->getMySQL())."')
                   LEFT JOIN ".XOCP_PREFIX."persons p
                      ON (pt.person_id = p.person_id)
              WHERE p.status_cd != 'nullified' AND (p.person_nm LIKE '$nm' OR pt.patient_ext_id = '$id')";
      $result = $db->query($sql);
      if ($db->getRowsNum($result) > 0) {
         $dp = new XocpDataPage();
         $dp->setPageSize(5);
         while ($row = $db->fetchRow($result)) {
            list($person_id,$person_nm,$ssn,$addr_txt,$ext_id,$patient_id,$org_id,$admission_dt) = $row;
            similar_text($person_nm,str_replace("%","",$nm),$score);
            $link = XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&show=y&x=$person_id&d=$admission_dt";
            $dp->addData(array("<a href='$link'>$person_nm</a>",$person_id,$person_nm,$ssn,$addr_txt,$ext_id,$patient_id,$org_id,$score));
         }
         usort($dp->data,"person_funccmp");
         array_reverse($dp->data);
         $dp->serialize();
         $search_result = $this->navigate($dp->getFile(),0);
         if ($dp->getCount() > 5) {
            $comment = _EHR_PTENC_SEARCHPATIENTINFO;
         }
      } else {
         $comment = _EHR_PTENC_PATIENTNOTFOUND;
         $search_result = "";
      }
      $ret = $this->searchPatient($datarec,$comment)."<br />".$search_result;
      return $ret;
   }
   
   function show() {
      global $HTTP_POST_VARS,$HTTP_GET_VARS,$ehr_ses_org_id,$ehr_ses_ehr_id;
      $db =& Database::getInstance();
      $this->getparam = _EHR_CATCH_VAR."="._EHR_PATIENTENCOUNTER_BLOCK;
      $this->postparam = new XocpFormHidden(_EHR_CATCH_VAR,_EHR_PATIENTENCOUNTER_BLOCK);
      switch ($this->catch) {
         case _EHR_PATIENTENCOUNTER_BLOCK:
            if ((trim($HTTP_POST_VARS["person_nm"]) != "" || trim($HTTP_POST_VARS["ext_id"]) != "") &&
                !isset($HTTP_POST_VARS["person_id"])) {
               // Search person
               $ret = $this->doSearch($HTTP_POST_VARS);
            } elseif ($HTTP_GET_VARS["p"] != "") {
               $ret = $this->searchPatient(NULL)."<br />".$this->navigate($HTTP_GET_VARS["f"],$HTTP_GET_VARS["p"]);
            } elseif ($HTTP_GET_VARS["show"] == "y") {
               $sql = "SELECT p.person_id,p.person_nm,p.ssn,p.addr_txt,pt.patient_ext_id as ext_id,
                              pt.patient_id,pt.org_id
                       FROM ".XOCP_PREFIX."persons p
                            LEFT JOIN ".XOCP_PREFIX."ehr_patient pt
                              ON (pt.person_id = p.person_id)
                       WHERE p.person_id = '".$HTTP_GET_VARS["x"]."'";
               $result = $db->query($sql);
               if ($db->getRowsNum($result)) {
                  $row = $db->fetchArray($result);
                  $row["date_adm"] = $HTTP_GET_VARS["d"];
                  $ret = $this->doEncounter($row);
               } else {
                  $ret = $this->searchPatient(NULL,_EHR_PTENC_PATIENTNOTFOUND);
               }
            } elseif (($HTTP_POST_VARS["submit"] != "" || $HTTP_POST_VARS["person_id"] != "") &&
                      !isset($HTTP_POST_VARS["cancel"])) {
               $admission_dttm = new XocpDateTime();
               $admission_dttm->eatVars("encounter","post");
               
               $sql = "SELECT MAX(encounter_id),MAX(encounter_dt)
                       FROM ".XOCP_PREFIX."ehr_encounter
                       WHERE patient_org_id = '$ehr_ses_ehr_id' AND
                             encounter_dt = '".$admission_dttm->getMySQL("date")."'";
               $result = $db->query($sql);
               list($encounter_id,$encounter_dt) = $db->fetchRow($result);
               if ($encounter_dt == NULL) {
                  $encounter_id = 1;
               } else {
                  $encounter_id++;
               }
               $sql = "INSERT INTO ".XOCP_PREFIX."ehr_encounter
                          (org_id,encounter_id,encounter_dt,encounter_tm,
                        	status_cd,patient_id,patient_org_id,employee_id,
                           employee_org_id)
                       VALUES ('$ehr_ses_org_id','$encounter_id',
                               '".$admission_dttm->getMySQL("date")."',
                               '".$admission_dttm->getMySQL("time")."',
                               'normal','".$HTTP_POST_VARS["patient_id"]."',
                               '".$HTTP_POST_VARS["patient_org_id"]."',
                               '".$HTTP_POST_VARS["employee_id"]."','$ehr_ses_ehr_id')";
               $result = $db->query($sql);
               $comment = $db->error();
               if ($comment == "") {
                  $HTTP_POST_VARS["person_nm"] = "";
                  $HTTP_POST_VARS["ext_id"] = "";
                  $ret = $this->searchPatient($HTTP_POST_VARS,_EHR_PTENC_SAVESUCCESS);
               } else {
                  $ret = $this->doAdmission($HTTP_POST_VARS,_EHR_PTENC_SAVEFAIL."<br />".$comment);
               }
               // Save physician
               global $ehr_ses_physician_id;
               if (!session_is_registered("ehr_ses_physician_id")) {
                  session_register("ehr_ses_physician_id");
               }
               $ehr_ses_physician_id = $HTTP_POST_VARS["employee_id"];
            } else {
               if ($ehr_ses_ehr_id > 0 && $ehr_ses_org_id > 0 && $ehr_ses_ehr_id != $ehr_ses_org_id) {
                  $HTTP_POST_VARS["person_nm"] = "";
                  $HTTP_POST_VARS["ext_id"] = "";
                  $ret = $this->searchPatient($HTTP_POST_VARS);
               }
            }
            break;
         default:
            // Default handler
            if ($ehr_ses_ehr_id > 0 && $ehr_ses_org_id > 0 && $ehr_ses_ehr_id != $ehr_ses_org_id) {
               $ret = $this->searchPatient($HTTP_POST_VARS);
            }
            break;
      }
      return "<br />".$ret;
   }

}

} // EHR_PATIENTENCOUNTER_DEFINED
?>