

/**************************
    HEALTH CARE ENTITIES
 **************************/

DROP TABLE IF EXISTS xocp_ehr_pgroup_org;
CREATE TABLE xocp_ehr_pgroup_org (
  pgroup_id int(10) unsigned NOT NULL default '0',
  org_id int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (pgroup_id,org_id)
) TYPE=MyISAM;

DROP TABLE IF EXISTS xocp_ehr_orglink;
CREATE TABLE xocp_ehr_orglink (
  org_id int(10) unsigned NOT NULL default '0',
  sub_id int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (org_id,sub_id)
) TYPE=MyISAM;





/***********
   D R U G
 ***********/
# Table : ehr_drug_brand
# HL7 Reference : Entity.Material
DROP TABLE IF EXISTS xocp_ehr_drug_brand;
CREATE TABLE xocp_ehr_drug_brand (
  org_id int(10) unsigned NOT NULL default '0',
  drug_brand_id int(10) unsigned NOT NULL default '0',
  drug_brand_nm char(40) NOT NULL default '',
  manufacture_id int(10) unsigned NOT NULL default '0',
  PRIMARY KEY (org_id,drug_brand_id)
) TYPE=MyISAM;
/*
   kaidah ehr_drug_brand:
   1. Isinya adalah nama obat (brand) saja.
   2. Bentuk sediaan (form) akan ditampung di table ehr_drug.
   3. Dosis pemakaian akan ditampung di table ehr_drug_dose.
   4. Generic akan ditampung di table ehr_drug_gnr.
   5. Komponen generic yang terkandung dalam sebuah drug brand
      akan ditaruh di table ehr_drug_gnr_rel.
*/

# Table : ehr_drug
# HL7 Reference : Entity.Material
DROP TABLE IF EXISTS xocp_ehr_drug;
CREATE TABLE xocp_ehr_drug (
  org_id int(10) unsigned NOT NULL default '0',
  drug_id int(10) unsigned NOT NULL default '0',
  drug_brand_id int(10) unsigned NOT NULL default '0',
  drug_form_cd tinyint(3) unsigned NOT NULL default '0',
  unit_cost_id int(10) unsigned NOT NULL default '0',

  # Berikut ini dihandle oleh table ehr_unit_cost:
  # drug_form_nm char(40) NOT NULL default '',
  # strength_qty float(12,2) unsigned NOT NULL default '0.00',
  # unit_cd smallint(5) unsigned NOT NULL default '0',
  # cost_qty float(12,2) unsigned NOT NULL default '0.00',

  PRIMARY KEY (org_id,drug_id)
) TYPE=MyISAM;
/*
   kaidah ehr_drug:
   1. Hanya form yang terdapat di pasaran.
*/


# Table : ehr_drug_gnr
# HL7 Reference : Entity.Material
DROP TABLE IF EXISTS xocp_ehr_drug_gnr;
CREATE TABLE xocp_ehr_drug_gnr (
  drug_gnr_id int(10) unsigned NOT NULL default '0',
  drug_gnr_nm char(40) NOT NULL default '',
  PRIMARY KEY (drug_gnr_id)
) TYPE=MyISAM;

# Table : ehr_drug_gnr_rel
# HL7 Reference : Entity.Material
DROP TABLE IF EXISTS xocp_ehr_drug_gnr_rel;
CREATE TABLE xocp_ehr_drug_gnr_rel (
  org_id int(10) unsigned NOT NULL default '0',
  drug_id int(10) unsigned NOT NULL default '0',
  drug_gnr_id int(10) unsigned NOT NULL default '0',
  strength_qty float(12,2) unsigned NOT NULL default '0.00',
  unit_cd smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY (org_id,drug_id,drug_gnr_id)
) TYPE=MyISAM;

# Table : ehr_drug_dose
# HL7 Reference : Entity.Material
DROP TABLE IF EXISTS xocp_ehr_drug_dose;
CREATE TABLE xocp_ehr_drug_dose (
  org_id int(10) unsigned NOT NULL default '0',
  drug_id int(10) unsigned NOT NULL default '0',
  drug_dose_id tinyint(3) unsigned NOT NULL default '0',
  drug_form_id tinyint(3) unsigned NOT NULL default '0',

  age_ivl_cd tinyint(3) unsigned NOT NULL default '0',

  strength_qty float(12,2) unsigned NOT NULL default '0.00',
  max_strength_qty float(12,2) unsigned NOT NULL default '0.00',
  unit_cd smallint(5) unsigned NOT NULL default '0',
  interval_qty tinyint(3) unsigned NOT NULL default '0',
  interval_cd enum('second','minute','hour','day','week','month','year') NOT NULL default 'minute',

  ind_cd char(96) NOT NULL default '',

      # delimited with '|' -> 'A00.0|A00.3' atau kali 16 field
  PRIMARY KEY (org_id,drug_id,drug_dose_id)
) TYPE=MyISAM;
/*
   kaidah ehr_drug_dose:
   1. Isinya hanya sebagai bantuan bagi physician untuk menentukan dosis
      yang tepat. Tidak ada hubungannya dengan billing system.
   
   ---- belum stabil, mungkin akan saya ubah lagi.
Query:

indication (icd) -> subject criteria -> brand, form, dose
indication (icd) -> brand -> subject criteria -> form, dose
brand -> indication(s) (icd) -> subject criteria -> form, dose
subject criteria -> indication vs. brand contra indication -> brand, dose
*/

DROP TABLE IF EXISTS xocp_ehr_drug2icd10;

/*********************************************************************/














# Table : ehr_substance
# HL7 Reference : Entity.Material
DROP TABLE IF EXISTS xocp_ehr_substance;
CREATE TABLE xocp_ehr_substance (
  org_id int(10) unsigned NOT NULL default '0',
  substance_id int(10) unsigned NOT NULL default '0',
  substance_nm char(40) NOT NULL default '',
  status_cd enum('active','inactive','normal','nullified') NOT NULL default 'active',
  PRIMARY KEY (org_id,substance_id)
) TYPE=MyISAM;

# Table : ehr_device
# HL7 Reference : Entity.Material
DROP TABLE IF EXISTS xocp_ehr_device;
CREATE TABLE xocp_ehr_device (
  org_id int(10) unsigned NOT NULL default '0',
  device_id int(10) unsigned NOT NULL default '0',
  device_nm char(40) NOT NULL default '',
  status_cd enum('active','inactive','normal','nullified') NOT NULL default 'active',
  PRIMARY KEY (org_id,device_id)
) TYPE=MyISAM;

# Table : ehr_material
# HL7 Reference : Entity.Material
DROP TABLE IF EXISTS xocp_ehr_material;
CREATE TABLE xocp_ehr_material (
  org_id int(10) unsigned NOT NULL default '0',
  material_id int(10) unsigned NOT NULL default '0',
  material_nm char(40) NOT NULL default '', 
  status_cd enum('active','inactive','normal','nullified') NOT NULL default 'active',
  PRIMARY KEY (org_id,material_id)
) TYPE=MyISAM;
/*
   kaidah ehr_material:
   1. Isinya adalah material yg mensupport medis, yang tidak bisa disebutkan
      dalam invoice, tapi mempengaruhi total invoice (betul gak? lih. catatan),
      misalkan: kasur, sprei, piring, gelas, dll.
      termasuk juga: listrik, air, dll.

   Catatan: Ketika memasukkan tindakan, semua komponen yang terkait
            akan punya option tampilan di invoice, yaitu sebagai item
            tersendiri atau dikumpulkan sebagai satu item,
            misalkan: jasa sarana (untuk material non drug, device),
                      jasa (untuk semua employee)
*/

/*****************************************************************************
                                   ROLES
 *****************************************************************************/

# Table : ehr_employee
# HL7 Reference : Role.Employee
DROP TABLE IF EXISTS xocp_ehr_employee;
CREATE TABLE xocp_ehr_employee (
  org_id int(10) unsigned NOT NULL default '0',
  employee_id int(10) unsigned NOT NULL default '0',
  jobtitle_nm char(30) NOT NULL default '',
  hazard_exp_cd smallint(5) unsigned NOT NULL default '0',
  protct_eqp_cd smallint(5) unsigned NOT NULL default '0',
  addr_txt char(60) NOT NULL default '',
  telecom char(30) NOT NULL default '',
  jobstart_dttm datetime NOT NULL default '0000-00-00 00:00:00',
  jobstop_dttm datetime NOT NULL default '0000-00-00 00:00:00',
  job_cd int(10) unsigned NOT NULL default '0',
  jobclass_cd enum('full_time','part_time','on_demand') NOT NULL default 'full_time',
         # OpenIssue: honorer?
  status_cd enum('normal','suspended','terminated','nullified') NOT NULL default 'normal',
  person_id int(10) unsigned NOT NULL default '0',
  rc_dttm datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (org_id,employee_id)
) TYPE=MyISAM;
/*
   Kaidah ehr_employee:
   - Employee selalu punya employer yaitu organization, maka PK-nya adalah
     org_id dan employee_id. Maka segala referensi terhadap seorang employee
     di lain table adalah SELALU dengan employee_id dan org_id.
   - Value employee_id unique dalam 1 org_id, dimulai dari 1.
   - FK adalah person_id. Satu person_id bisa terdaftar dalam banyak org_id,
     maupun terdaftar banyak dalam satu org_id. Pembedanya adalah employee_id.
     Sehingga dapat mengakomodasi perangkapan jabatan.
   - Attribute ehr_employee akan banyak bertambah. Namun supaya disepakati
     bahwa isi (tema) dari table adalah field-field yang menyangkut penugasan
     sebagai employee saja, maka salary tidak termasuk.
   - Data yang boleh masuk sini adalah data employee yang berkaitan dengan
     rumah sakit saja, misal: physician, nurse, tukang sapu rumah sakit, dll.
*/

# Table : ehr_salary
# HL7 Reference : Role.Employee
DROP TABLE IF EXISTS xocp_ehr_salary;
CREATE TABLE xocp_ehr_salary (
  org_id int(10) unsigned NOT NULL default '0',
  employee_id int(10) unsigned NOT NULL default '0',
  salary_id tinyint(3) unsigned NOT NULL default '0',
  salary_cd tinyint(3) unsigned NOT NULL default '0',
         # jenis gaji : pokok, tunjangan, dll.
  active_dttm datetime NOT NULL default '0000-00-00 00:00:00',
         # timestamp, gaji mulai diberlakukan
  salary_qty float(12,2) unsigned NOT NULL default '0.00',
  status_cd enum('active','obsolete','nullified') NOT NULL default 'active',
  salary_type_cd enum('once','minute','hour','day','week','month','year') NOT NULL default 'month',
         # unit waktu untuk pengali gaji
  multiply_n float(6,2) NOT NULL default '1.00',
         # berhubungan dengan salary_type_cd, misal: isinya 10.00 dan salary_type_cd =  'minute'
         # maka artinya digaji tiap 10 menit kerja aktif. aplikasi: untuk hitung biaya konsultasi.
  PRIMARY KEY  (org_id,employee_id,salary_id)
) TYPE=MyISAM;
/*
   Kaidah ehr_salary:
   - Ini adalah table salary untuk ehr_employee.
   - 1 employee_id dalam 1 org_id bisa berubah gajinya beberapa kali. Namun
     semua catatan gaji lama tidak boleh dihapus.
   - 1 employee_id dalam 1 org_id bisa memiliki beberapa gaji yang berbeda
     seperti tunjangan, gaji pokok, gaji langsung, dll, yang statusnya
     'active' semua.
   - Time boundary adalah jobstart_dttm-jobstop_dttm di ehr_employee dari
     employee_id ybs. Tapi perubahan gaji hanya mencatat waktu active gaji
     terakhir, maka status_cd pada record lama berubah menjadi 'obsolete'.
   - Status 'nullified' adalah flag hapus untuk creation in error. Dari
     kaidah nomor 3 dan nomor ini (4), maka tidak ada penghapusan record.
   - Untuk bayaran/gaji langsung dari tiap tindakan akan dimasukkan ke table
     ehr_uc_employee.
*/

# Table : ehr_patient
# HL7 Reference : Role.Patient
DROP TABLE IF EXISTS xocp_ehr_patient;
CREATE TABLE xocp_ehr_patient (
  org_id int(10) unsigned NOT NULL default '0',           # isinya ID puskesmas/rumah sakit
  patient_id int(10) unsigned NOT NULL default '0',
  patient_ext_id char(30) NOT NULL default '',
  status_cd enum('normal','nullified') NOT NULL default 'normal',
  vip_cd tinyint(3) unsigned NOT NULL default '0',
  confidentiality_cd tinyint(3) unsigned NOT NULL default '0',
  person_id int(10) unsigned NOT NULL default '0',
  rc_dttm datetime NOT NULL default '0000-00-00 00:00:00', # record creation datetime
  PRIMARY KEY  (org_id,patient_id)
) TYPE=MyISAM;

# kaidah : 
# - tiap org_id memiliki penomoran patient_id sendiri-sendiri (mulai dari 1)
# - ini adalah role table, maksudnya: Role (=peran) seorang person sebagai pasien.
#                                     Sehingga utk data personal harus join dgn 
#                                     table persons.

# Table : xocp_ehr_parent_rel
DROP TABLE IF EXISTS xocp_ehr_parent_rel;
CREATE TABLE xocp_ehr_parent_rel (
  mother_id int(10) unsigned NOT NULL default '0',
  father_id int(10) unsigned NOT NULL default '0',
  person_id int(10) unsigned NOT NULL default '0',
  order_no tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (person_id),
) TYPE=MyISAM;

# Table : ehr_guarantor
# HL7 Reference : Role.Guarantor
DROP TABLE IF EXISTS xocp_ehr_guarantor;
CREATE TABLE xocp_ehr_guarantor (
  org_id int(10) unsigned NOT NULL default '0',
  guarantor_id int(10) unsigned NOT NULL default '0',
  patient_id int(10) unsigned NOT NULL default '0',
  addr_txt text NOT NULL,
  telecom text NOT NULL,
  credit_rating_cd enum('excellent','good','fair','questionable','poor','unknown') NOT NULL default 'unknown',
  status_cd enum('active','normal','suspended','terminated','nullified') NOT NULL default 'active',
  entity_id int(10) unsigned NOT NULL default '0',
  entityclass_cd enum('person','organization') NOT NULL default 'person',
  rc_dttm datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (org_id,guarantor_id),
  UNIQUE KEY guarantor_index (org_id,patient_id,entity_id)
) TYPE=MyISAM;

# Table : ehr_cert
# HL7 Reference : Role.Certified_entity
DROP TABLE IF EXISTS xocp_ehr_cert;
CREATE TABLE xocp_ehr_cert (
  org_id int(10) unsigned NOT NULL default '0',
  cert_id int(10) unsigned NOT NULL default '0',
  cert_no char(100) NOT NULL default '0',
      # nomor sertifikat, jika ada.
  cert_cd smallint(5) unsigned NOT NULL default '0',
      # kode link ke jenis-jenis sertifikasi.
  entity_id int(10) unsigned NOT NULL default '0',
  entityclass_cd enum('person','employee','organization','device','place','material') NOT NULL default 'employee',
  cert_dttm datetime NOT NULL default '0000-00-00 00:00:00',
  re_cert_dttm datetime NOT NULL default '0000-00-00 00:00:00',
  status_cd enum('active','inactive','obsolete','terminated','nullified') NOT NULL default 'active',
  rc_dttm datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (org_id,entity_id,entityclass_cd,cert_id)
) TYPE=MyISAM;

# Table : ehr_assigned
# HL7 Reference : Role.Assigned_entity
DROP TABLE IF EXISTS xocp_ehr_assigned;
CREATE TABLE xocp_ehr_assigned (
  org_id int(10) unsigned NOT NULL default '0',
  assignment_id int(10) unsigned NOT NULL default '0',
  act_cd tinyint(3) unsigned NOT NULL default '0',
      # jenis act : maintenance, procedure, observation, encounter, dll.
  sub_act_cd smallint(5) unsigned NOT NULL default '0',
  assignment_cd int(10) unsigned NOT NULL default '0',
      # menggambarkan penugasan sebagai apa dalam suatu tindakan
  employee_id int(10) unsigned NOT NULL default '0',
  cert_id char(30) NOT NULL default '',
      # sertifikasi yang menjadi dasar assignment, jika ada.
      # isinya comma separated value dari cert_id.
  start_dttm datetime NOT NULL default '0000-00-00 00:00:00',
  stop_dttm datetime NOT NULL default '0000-00-00 00:00:00',
  status_cd enum('normal','suspended','obsolete','terminated','nullified') NOT NULL default 'normal',
  rc_dttm datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (org_id,employee_id,assignment_id)
) TYPE=MyISAM;

/*****************************************************************************
                                PARTICIPATION
 *****************************************************************************/
/*
      UNIT COST : ehr_unit_cost :
      
      Asumsi awal (sementara):
      -> Unit cost adalah biaya yang dibutuhkan untuk satu unit komponen
         dalam suatu tahap daur produksi.
         Misal : unit cost rawat inap, dihitung perhari a rupiah.
                 a rupiah diperoleh dari unit cost ruang b rupiah perhari
                                         unit cost laundry c rupiah
                                         unit cost listrik d rupiah perjam
                                         dll...
                 b rupiah diperoleh dari unit cost kebersihan e rupiah
                                         unit cost depresiasi gedung f rupiah
                                         unit cost biaya gedung g rupiah
                                         dll...
         Tingkat kedalaman dan keakuratan akan menghasilkan perhitungan
         yang lebih akurat.

      Isi record: 
      ===========
         unit cost yang ditagihkan jika memakai jasa/sarana/produk
         dalam suatu act, atau sebagai pembentuk unit cost lain.
      
      Penjelasan attribute:
      =====================

      unit_cost_id:
      -------------
      Adalah candidate untuk unit cost di suatu organisasi. Dalam 1
      organisasi, maka unit_cost_id adalah unique.
      
      unit_cost_nm:
      -------------
      Nama dari unit cost, descriptive purpose.

      act_id dan sub_act_id:
      ----------------------
      - act_id adalah coded value yang menunjukkan subtype dari act, misal:
        Patient_encounter, Observation, Procedure, Substance_administration,
        Supply, dll.
      - sub_act_id adalah coded value yang menunjukkan spesialisasi dari
        suatu subtype dari act, misal:
            Supply : Macrobiotic Diet, Cariogenic Diet, Diabetic Diet,
                     Fat-restricted Diet, dll.
            Patient_encounter : outpatient visit, home health support,
                                office visit, telephone call, dll.
      - filtering dengan act_id dan sub_act_id:
         + Jika sub_act_id dlm suatu record isinya '0', maka act dengan
           sub_act_id yang tidak terdapat dalam record tersendiri akan
           diikutkan harganya dengan record tersebut.
         + Jika tidak ada act dengan sub_act_id berisi '0', maka act
           dengan sub_act_id yang tidak terdapat dalam record tersendiri
           akan memiliki zero cost alias gratis.
      - Jika satu entity dalam act_id yang dimaksud tidak memiliki record
        disini, maka biayanya dianggap nol. Demikian pula jika memiliki
        tapi cost_qty isinya nol, biaya juga nol.
      
      cost_qty dan amnt_paid_qty:
      ---------------------------
      cost_qty akan dibayarkan ke rumah sakit sedangkan amnt_paid_qty akan
      menentukan gaji langsung. Jumlah tagihan di invoice adalah jumlah
      total kedua atribut ini.

      mul_cd:
      -------
      Tagihan sama dengan elapsed time dibagi interval_qty dikalikan 
      cost_qty dan/atau amnt_paid_qty, tergantung dari mul_cd.
    
      Penjelasan aplikasi:
      ====================
         employee : pemakaian jasa employee dalam suatu act (act participant).
                    entity_id     -> person_id
                    entityclas_cd -> 'employee'
                    - Biasanya hanya dengan time constraint atau
                      tanpa constraint.
                    
         other    : ialah unit cost yang tidak memiliki constraint
                    waktu maupun constraint massa/volume.
         
         device   : unit cost pemakaian device, termasuk perhitungan
                    pemakaian listrik sehingga punya time constraint,
                    atau tanpa time constraint, tapi jarang dengan mass
                    constraint.

         Jika unit cost tidak terlibat dalam medical act, maka act_id
         dan sub_act_id diisi '0'.
         Jika unit cost tidak memiliki entity maka entity_id diisi '0',
         entityclass_cd tidak akan dilihat.
         
         Contoh: jika pemakaian listrik yg tidak bisa dihitung per-device,
         dan akan dicharge ke seluruh layanan, maka setupnya:
         entity_id = 0,
         act_id = 0,
         interval_qty = 1
         interval_cd = hour
         amount_qty = 1
         unit_cd = watt
         mul_cd = cost_qty
         cost_qty = x (sesuai dengan harga 1 watt 1 hour atau 1/1000 kwh)
         amnt_paid_qty = 0
         currency_cd = IDR (rupiah)
         status_cd = active

   
   Table Entity   : Table Purchase      : Table Inventory
   -------------------------------------------------------------------------
   ehr_drug       : ehr_prchs_drug      : ehr_inv_drug
   ehr_employee   :                     : 
   ehr_device     : ehr_prchs_device    : ehr_inv_device
   glob_place     : ehr_prchs_place     : ehr_inv_place
   ehr_substance  : ehr_prchs_substance : ehr_inv_substance
   ehr_material   : ehr_prchs_material  : ehr_inv_material





*/

# Table : ehr_unit_cost
# HL7 Reference : Role to Participation
DROP TABLE IF EXISTS xocp_ehr_unit_cost;
CREATE TABLE xocp_ehr_unit_cost (
  org_id int(10) unsigned NOT NULL default '0',
  unit_cost_id int(10) unsigned NOT NULL default '0',
  unit_cost_nm char(40) NOT NULL default '',

  entity_id int(10) unsigned NOT NULL default '0',
  entityclass_cd enum('','employee','place','drug','substance','device','material','food') NOT NULL default '',
  act_id int(10) unsigned NOT NULL default '0',
  actclass_id tinyint(3) unsigned NOT NULL default '0',

  quantity float(12,2) unsigned NOT NULL default '0.00',
  unit_cd smallint(5) unsigned NOT NULL default '0',
  multiple_cd enum('cost_qty','amnt_paid_qty','both') NOT NULL default 'cost_qty',
  cost_qty float(12,2) unsigned NOT NULL default '0.00',
  amnt_paid_qty float(12,2) unsigned NOT NULL default '0.00',
  currency_cd enum('IDR','USD') NOT NULL default 'IDR',
  status_cd enum('active','inactive','nullified') NOT NULL default 'active',
  PRIMARY KEY  (org_id,unit_cost_id)
) TYPE=MyISAM;

DROP TABLE IF EXISTS xocp_ehr_unit_cost_rel;
CREATE TABLE xocp_ehr_unit_cost_rel (
  org_id int(10) unsigned NOT NULL default '0',
  unit_cost_id int(10) unsigned NOT NULL default '0',
  org_idx int(10) unsigned NOT NULL default '0',
  unit_cost_idx int(10) unsigned NOT NULL default '0',
  quantity float(12,2) unsigned NOT NULL default '0.00',
  PRIMARY KEY (org_id,unit_cost_id,org_idx,unit_cost_idx)
) TYPE=MyISAM;


/*****************************************************************************
                                     ACTS
 *****************************************************************************/

/***************
    ENCOUNTER
 ***************/
# Table : ehr_admission
# HL7 Reference : Acts.Patient_encounter
DROP TABLE IF EXISTS xocp_ehr_admission;
CREATE TABLE xocp_ehr_admission (
  patient_org_id int(10) unsigned NOT NULL default '0',
  admission_dt date NOT NULL default '0000-00-00',
  admission_id int(10) unsigned NOT NULL default '0',
  admission_tm time NOT NULL default '00:00:00',
  patient_id int(10) unsigned NOT NULL default '0',
  org_id int(10) unsigned NOT NULL default '0',
  status_cd enum('normal','nullified') NOT NULL default 'normal',
  pre_admit_test_ind enum('y','n') NOT NULL default 'n',
  PRIMARY KEY  (patient_org_id,admission_dt,admission_id)
) TYPE=MyISAM;


# Table : ehr_discharge
# HL7 Reference : Acts.Patient_encounter
DROP TABLE IF EXISTS xocp_ehr_discharge;
CREATE TABLE xocp_ehr_discharge (
  patient_org_id int(10) unsigned NOT NULL default '0',
  admission_dt date NOT NULL default '0000-00-00',
  admission_id int(10) unsigned NOT NULL default '0',
  patient_id int(10) unsigned NOT NULL default '0',
  org_id int(10) unsigned NOT NULL default '0',
  discharge_dt date NOT NULL default '0000-00-00',
  discharge_tm time NOT NULL default '00:00:00',
  status_cd enum('normal','nullified') NOT NULL default 'normal',
  disposition_cd tinyint(3) unsigned NOT NULL default '0', # resmi, paksa, lari
  PRIMARY KEY (patient_org_id,admission_dt,admission_id)
) TYPE=MyISAM;

# Table : ehr_transfer
# HL7 Reference : Acts.Patient_encounter
DROP TABLE IF EXISTS xocp_ehr_transfer;
CREATE TABLE xocp_ehr_transfer (
  patient_org_id int(10) unsigned NOT NULL default '0',
  transfer_id int(10) unsigned NOT NULL default '0',
  transfer_dt date NOT NULL default '0000-00-00',
  transfer_tm time NOT NULL default '00:00:00',
  patient_id int(10) unsigned NOT NULL default '0',
  org_id int(10) unsigned NOT NULL default '0',
  status_cd enum('normal','nullified') NOT NULL default 'normal',
  PRIMARY KEY  (patient_org_id,transfer_id,transfer_dt)
) TYPE=MyISAM;

# Table : ehr_encounter
# HL7 Reference : Acts.Patient_encounter

DROP TABLE IF EXISTS xocp_ehr_encounter;
CREATE TABLE xocp_ehr_encounter (
  patient_org_id int(10) unsigned NOT NULL default '0',
  encounter_dt date NOT NULL default '0000-00-00',
  encounter_id int(10) unsigned NOT NULL default '0',
  encounter_tm time NOT NULL default '00:00:00',
  patient_id int(10) unsigned NOT NULL default '0',
  org_id int(10) unsigned NOT NULL default '0',             # place/unit id
  employee_id int(10) unsigned NOT NULL default '0',        # 
  employee_org_id int(10) unsigned NOT NULL default '0',    # org id
  status_cd enum('normal','nullified') NOT NULL default 'normal',
  PRIMARY KEY  (patient_org_id,encounter_dt,encounter_id)
) TYPE=MyISAM;

/*
   Kaidah ehr_encounter:
   - Primary key adalah patient_org_id, tanggal dan nomor encounter, karena bisa
     tidak cukup jika hanya ditangani oleh satu field saja. Maka datetime
     encounter saya pisah jadi date dan time, soalnya biar bisa jadi pkey.
   - Jadi encounter_id adalah sequence number yang selalu reset tiap hari
     ke angka 1 tiap ehr
*/

# Table : ehr_birth_enc
# HL7 Reference : Acts.Patient_encounter
DROP TABLE IF EXISTS xocp_ehr_birth_enc;
CREATE TABLE xocp_ehr_birth_enc (
  org_id int(10) unsigned NOT NULL default '0',
  birth_id smallint(5) unsigned NOT NULL default '0',
  birth_dt date NOT NULL default '0000-00-00',
  birth_tm time NOT NULL default '00:00:00',
  status_cd enum('new','held','normal','active','cancelled','suspended','aborted','obsolete','completed','nullified') NOT NULL default 'normal',
  patient_id int(10) unsigned NOT NULL default '0',
  mother_id int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (org_id,birth_id,birth_dt)
) TYPE=MyISAM;


/***************************************
       SYMPTOM, SIGN AND DIAGNOSIS
 ***************************************/

DROP TABLE IF EXISTS xocp_ehr_problem;
CREATE TABLE xocp_ehr_problem (
  patient_org_id int(10) unsigned NOT NULL default '0',
  patient_id int(10) unsigned NOT NULL default '0',
  problem_id smallint(5) unsigned NOT NULL default '0',
  admission_id int(10) unsigned NOT NULL default '0',
  admission_dt date NOT NULL default '0000-00-00',
  block_id int(10) unsigned NOT NULL default '0',
  category char(3) NOT NULL default '',
  subcategory char(1) NOT NULL default '',
  problem_lvl enum('symptom','diagnostic') NOT NULL default 'symptom',
  status_cd enum('normal','nullified') NOT NULL default 'normal',
  PRIMARY KEY (patient_org_id,patient_id,admission_id,admission_dt,problem_id),
  UNIQUE KEY (patient_org_id,patient_id,admission_id,admission_dt,block_id,category,subcategory)
) TYPE=MyISAM;



/*****************
       ACTS
 *****************/
# Table : ehr_act
# HL7 Reference : Acts
DROP TABLE IF EXISTS xocp_ehr_act;
CREATE TABLE xocp_ehr_act (
  org_id int(10) unsigned NOT NULL default '0',
  act_req_id int(10) unsigned NOT NULL default '0',
  act_req_dt date NOT NULL default '0000-00-00',
  act_req_tm time NOT NULL default '00:00:00',
  begin_dttm datetime NOT NULL default '0000-00-00 00:00:00',
  end_dttm datetime NOT NULL default '0000-00-00 00:00:00',
  act_id tinyint(3) unsigned NOT NULL default '0',
  sub_act_id int(10) unsigned NOT NULL default '0',
  act_nm char(100) NOT NULL default '',
  priority_cd enum('high','normal','low') NOT NULL default 'normal',
  status_cd enum('new','held','normal','active','cancelled','suspended','aborted','obsolete','completed','nullified') NOT NULL default 'new',
  act_ref_cd char(40) NOT NULL default '',
  PRIMARY KEY  (org_id,act_req_id,act_req_dt)
) TYPE=MyISAM;

# Table : ehr_act_tmpl
# HL7 Reference : Acts
DROP TABLE IF EXISTS xocp_ehr_act_tmpl;
CREATE TABLE xocp_ehr_act_tmpl (
  org_id int(10) unsigned NOT NULL default '0',
  act_id tinyint(3) unsigned NOT NULL default '0',
  sub_act_id int(10) unsigned NOT NULL default '0',
  act_nm char(100) NOT NULL default '',
  act_ref_cd char(40) NOT NULL default '',
  PRIMARY KEY  (org_id,act_id,sub_act_id)
) TYPE=MyISAM;

# Table : ehr_act_tmpl_part
# HL7 Reference : Acts
DROP TABLE IF EXISTS xocp_ehr_act_tmpl_part;
CREATE TABLE xocp_ehr_act_tmpl_part (
  org_id int(10) unsigned NOT NULL default '0',
  act_id tinyint(3) unsigned NOT NULL default '0',
  sub_act_id int(10) unsigned NOT NULL default '0',
  entity_id int(10) unsigned NOT NULL default '0',
  entityclass_cd enum('employee','place','drug','substance','device','material','food','other') NOT NULL default 'employee',
  PRIMARY KEY  (org_id,act_id,sub_act_id,entity_id,entityclass_cd)
) TYPE=MyISAM;

/*****************************************************************************
                          CODING SYSTEMS AND LIBRARY
 *****************************************************************************/

DROP TABLE IF EXISTS xocp_sys_cd_religion;
CREATE TABLE xocp_sys_cd_religion (
  religion_cd char(1) NOT NULL default '',
  religion_nm char(10) NOT NULL default '',
  PRIMARY KEY  (religion_cd)
) TYPE=MyISAM;

DROP TABLE IF EXISTS xocp_sys_cd_educlvl;
CREATE TABLE xocp_sys_cd_educlvl (
  educlvl_cd tinyint(3) unsigned NOT NULL auto_increment,
  educlvl_nm text NOT NULL,
  PRIMARY KEY  (educlvl_cd)
) TYPE=MyISAM;

DROP TABLE IF EXISTS xocp_sys_cd_living_arr;
CREATE TABLE xocp_sys_cd_living_arr (
  living_arr_cd tinyint(3) unsigned NOT NULL auto_increment,
  living_arr_nm text NOT NULL,
  PRIMARY KEY  (living_arr_cd)
) TYPE=MyISAM;

DROP TABLE IF EXISTS xocp_sys_cd_ethnic;
CREATE TABLE xocp_sys_cd_ethnic (
  ethnic_cd int(10) unsigned NOT NULL auto_increment,
  ethnic_nm text NOT NULL,
  PRIMARY KEY  (ethnic_cd)
) TYPE=MyISAM;

DROP TABLE IF EXISTS xocp_sys_cd_race;
CREATE TABLE xocp_sys_cd_race (
  race_cd smallint(5) unsigned NOT NULL auto_increment,
  race_nm text NOT NULL,
  PRIMARY KEY  (race_cd)
) TYPE=MyISAM;

DROP TABLE IF EXISTS xocp_sys_cd_jobclass;
CREATE TABLE xocp_sys_cd_jobclass (
  jobclass_cd int(10) unsigned NOT NULL auto_increment,
  jobclass_nm text NOT NULL,
  PRIMARY KEY  (jobclass_cd)
) TYPE=MyISAM;

DROP TABLE IF EXISTS xocp_sys_cd_unit;
CREATE TABLE xocp_sys_cd_unit (
  unit_cd smallint(5) unsigned NOT NULL auto_increment,
  unit_nm char(40) NOT NULL default '',
  interval_tm int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (unit_cd)
) TYPE=MyISAM;

DROP TABLE IF EXISTS xocp_sys_cd_hazard_exp;
CREATE TABLE xocp_sys_cd_hazard_exp (
  hazard_exp_cd smallint(5) unsigned NOT NULL auto_increment,
  hazard_exp_nm text NOT NULL,
  PRIMARY KEY  (hazard_exp_cd)
) TYPE=MyISAM;

/*****************************************************************************
         CODING SYSTEMS AND LIBRARY CACHE FOR MEDICAL APPLICATION ONLY
 *****************************************************************************/

# Table : ehr_groupsrv
# HL7 Reference : Entity.Organization
DROP TABLE IF EXISTS xocp_ehr_groupsrv;
CREATE TABLE xocp_ehr_groupsrv (
  org_id int(10) unsigned NOT NULL default '0',
  groupsrv_id int(10) unsigned NOT NULL default '0', # group identifier
  groupsrv_nm char(40) NOT NULL default '',          # name of the group
  status_cd enum('active','inactive','normal','nullified') NOT NULL default 'active',
  PRIMARY KEY (org_id,groupsrv_id)
) TYPE=MyISAM;
/*
   kaidah ehr_groupsrv:
   1. Isinya adalah group service (kelompok layanan) yaitu: VVIP, VIP, Kelas I,
      Kelas II, Kelas III, dll.
*/

DROP TABLE IF EXISTS xocp_ehr_manufacture;
CREATE TABLE xocp_ehr_manufacture (
  manufacture_id int(10) unsigned NOT NULL default '0',
  # manufacture_id adalah glob_org.org_id tapi dipilih yang khusus
  # untuk drug saja.
  PRIMARY KEY (manufacture_id)
) TYPE=MyISAM;

DROP TABLE IF EXISTS xocp_ehr_drug_form_cd;
CREATE TABLE xocp_ehr_drug_form_cd (
  drug_form_cd tinyint(3) unsigned NOT NULL auto_increment,
  drug_form_nm char(40) NOT NULL default '',
  PRIMARY KEY (drug_form_cd)
) TYPE=MyISAM;

DROP TABLE IF EXISTS xocp_ehr_orgclass;
CREATE TABLE xocp_ehr_orgclass (
  orgclass_cd int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (orgclass_cd)
) TYPE=MyISAM;

