the basic need
   audit howto
   

Insurance
   claim howto, claim state, employer claims
   insurance type
   group?
   agent
   policies...
   effective date
   agent status_cd : excellent, good, fair, questionable, poor
   other agent state
   revision
   insurance plan (group insurance plan?)

guarantor
   credit rating : excellent, good, fair, questionable, poor
   patient-guarantor relation
   howto
   who can be one?

invoice_element

inventory/suppliers

account
   patient account
   provider account
   guarantor account
   insurance company account

financial act

financial contract

nullification of financial record

pricing
   material/substance
   device task
   care provider/place
   physician
   procedure
   encounter, managed participation
   
   
