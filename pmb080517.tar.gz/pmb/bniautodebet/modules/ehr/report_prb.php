<?php
//--------------------------------------------------------------------//
// Filename : modules/ehr/report_prb.php                              //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-03-24                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('EHR_REPORTPRB_DEFINED') ) {
   define('EHR_REPORTPRB_DEFINED', TRUE);

include_once(XOCP_DOC_ROOT."/modules/ehr/modconsts.php");
   
class _ehr_ProblemReport extends XocpBlock {
   var $width = "100%";
   var $postparam;
   var $getparam;
   var $language;
   
   function _ehr_ProblemReport($catch) {
   
      global $xocpConfig,$xocp_user;
      
      $this->XocpBlock($catch);                /* ini meneruskan $catch ke parent constructor */
      
      $mylanguage = $xocp_user->getVar("language");
      if($mylanguage == '') {
         $mylanguage = $xocpConfig["language"];
      }
      
      $this->language = $mylanguage;
      
   }
   
   function getLanguage() {
      return $this->language;
   }

   
   
   function formSelectMonth($comment = "") {
      $current_date = new XocpDateTime();
      $current_date->eatVars("reportprbmonth","get");
      if ($current_date->getMySQL("datetime") == "0000-00-00 00:00:00") {
        $current_date->setDateTime(getdate(time()));
      }
      $dttm_admission = new XocpFormDateTime(_EHR_REPORTPRB_ADMISSIONMONTH,"reportprbmonth",$current_date,"yearmonth");
      $form = new XocpThemeForm(_EHR_REPORTPRB_FORM,"formx","index.php","get");
      $dttm_admission->setType("yearmonth");
      $form->addElement($dttm_admission);

      $submit_button = new XocpFormButton("","genreportprb",_SUBMIT,"submit");

      $form->addElement($this->postparam);
      $form->addElement($submit_button);
      if ($comment != "") {
         $form->setComment($comment);
      }

      return $form->render();
   }
   
   function generateReport($comment = "") {
      global $ehr_ses_ehr_id;
      
      $db = &Database::getInstance();
      
      $report_date = new XocpDateTime();
      $report_date->eatVars("reportprbmonth","get");
      if ($report_date->getMySQL("datetime") == "0000-00-00 00:00:00") {
        $report_date->setDateTime(getdate(time()));
      }
      
      
      $year = $report_date->getDate("y");
      $month = $report_date->getDate("m");
      

      $sql = "SELECT p.problem_id,p.block_id,p.category,p.subcategory,p.problem_lvl,b.english_nm,i.english_nm,"
           . "b." . $this->getLanguage() . "_nm,i." . $this->getLanguage() . "_nm"
           . " FROM ".XOCP_PREFIX."ehr_problem p"
           . " LEFT JOIN ".XOCP_PREFIX."ehr_icd_block b ON b.block_id = p.block_id"
           . " LEFT JOIN ".XOCP_PREFIX."ehr_icd_item i ON i.category = p.category"
           . " AND i.subcategory = p.subcategory"
           . " WHERE p.patient_org_id = '$ehr_ses_ehr_id'"
           . " AND year(p.admission_dt) = '$year'"
           . " AND month(p.admission_dt) = '$month'"
           . " ORDER BY p.admission_dt,p.admission_id";


      
      $result = $db->query($sql);
      if($db->getRowsNum($result)>0) {
         unset($itemlist);
         unset($itemname);
         while(list($problem_id,
                    $block_id,
                    $category,
                    $subcategory,
                    $problem_lvl,
                    $b_english_nm,
                    $i_english_nm,
                    $b_item_name,
                    $i_item_name)=$db->fetchRow($result)) {


            if($block_id > 0) {
               $itemlist[$block_id] += 1;
               $itemname[$block_id] = (empty($b_item_name) ? $b_english_nm : $b_item_name);
            }
            if($category != "") {
               if($subcategory != "") {
                  $catno = "$category.$subcategory";
               } else {
                  $catno = "$category";
               }
               $itemlist[$catno] += 1;
               $itemname[$catno] = (empty($i_item_name) ? $i_english_nm : $i_item_name);
            }
            
         }
         
         $ptable = new XocpTable(1);
         $hrow = $ptable->addHeader(_EHR_REPORTPRB_PROBLEM_LIST);
         $ptable->setColSpan($hrow,3);
         arsort($itemlist);
         foreach($itemlist as $item_id => $item_cnt) {
            $ptable->addRow($item_id,$itemname[$item_id],$item_cnt);
         }
         
         return $ptable->render();
      }

      
   }
   
   function main() {
      global $ehr_ses_org_id,$ehr_ses_ehr_id,$HTTP_GET_VARS,$xocp_page_id;

      $this->getparam = _EHR_CATCH_VAR."="._EHR_REPORTPRB_BLOCK;
      $this->postparam = new XocpFormHidden(_EHR_CATCH_VAR,_EHR_REPORTPRB_BLOCK);

      switch ($this->catch) {
         case _EHR_REPORTPRB_BLOCK:
            $ret = $this->generateReport();
            break;
         default:
            $ret = $this->formSelectMonth();
            break;
      }
      return $ret;
   }
}

} // EHR_REPORTPRB_DEFINED
?>