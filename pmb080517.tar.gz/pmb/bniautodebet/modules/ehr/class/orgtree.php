<?php
//--------------------------------------------------------------------//
// Filename : modules/ehr/class/orgtree.php                           //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2003-03-17                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('EHR_ORGTREE_DEFINED') ) {
   define('EHR_ORGTREE_DEFINED', TRUE);

/*


   item_id, parent_id, text, link, icon

   $node = new Node(item_id,text,parent_id,link,icon);
   $tree = new _ehr_OrgTree();
   
   $tree->addItem($node);
   
   $tree->render();




*/


class _ehr_OrgTree {
   var $text;
   var $link;
   var $icon;
   var $item = array();
   var $parent = array();
   var $ret = "";
   var $indent = 20;

   function addItem($node) {
      $this->item[$node->id] = $node;
      $this->parent[$node->parent][$node->id] = $node->parent;
   }
   
   
   function isParent($node_id) {
      if(empty($this->parent[$node_id])) {
         return FALSE;
      } else {
         return is_array($this->parent[$node_id]);
      }
   }
   


   
   function renderNode($node_id,$depth=0) {
      if($this->isParent($node_id)) {

         // render as parent
         $this->ret .= "<nobr><img src=".XOCP_SERVER_SUBDIR."/images/spacer.gif width='".($depth*$this->indent)."' height=1>";
         $this->ret .= "<a href=\"".$this->item[$node_id]->link."\">".$this->item[$node_id]->text."</a></nobr><br>\n<div>";

         // recurse the child
         foreach($this->parent[$node_id] as $child_id => $parent_id) {
            $this->renderNode($child_id,$depth+1);
         }

         $this->ret .= "</div>";
         
      } else {

         // render as child
         $this->ret .= "<nobr><img src=".XOCP_SERVER_SUBDIR."/images/spacer.gif width='".($depth*$this->indent)."' height=1><a href=\"".$this->item[$node_id]->link."\" style='font-weight:normal;'>".$this->item[$node_id]->text."</a></nobr><br>\n";

      }
   }
   
   function render() {

      $p = $pp = 0;
      foreach($this->parent as $p => $a) {
         if(!empty($trav[$p]) && $trav[$p] == "y") continue;
         while(1) {
            $pp = $this->item[$p]->parent;
            $trav[$p] = "y";
            $trav[$pp] = "y";
            if($this->isParent($pp)) {
               $p = $pp;
            } else {
               break;
            }
         }
         if($rendered[$p] != "y") {
            $rendered[$p] = "y";
            foreach($this->parent[$p] as $node_id => $parent_id) {
               $trav[$p] = "y";
               $this->renderNode($node_id);
            }
         }
      }
      return $this->ret;
   }
}


class _ehr_OrgTreeNode {
   var $id;
   var $text;
   var $link;
   var $icon;
   var $parent;

   function _ehr_OrgTreeNode($id, $text, $parent = 0, $link = "", $icon = NULL) {
      $this->id       = $id;
      $this->text     = $text;
      $this->link     = $link;
      $this->parent   = intval($parent);
      $this->icon     = $icon;
   }

}

} // EHR_ORGTREE_DEFINED
?>