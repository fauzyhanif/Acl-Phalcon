<?php
if ( !defined('EHR_MODULECONSTS_DEFINED') ) {
   define('EHR_MODULECONSTS_DEFINED', TRUE);
   
// Defines catch variable name
define("_EHR_CATCH_VAR","X_ehr");

// Defines block registration number
define("_EHR_SELECTORG_BLOCK","1");
define("_EHR_SELECTUNIT_BLOCK","2");
define("_EHR_PGROUP2ORG_BLOCK","3");
define("_EHR_ORGLINK_BLOCK","4");
define("_EHR_EDITICD_BLOCK","5");
define("_EHR_PATIENTREG_BLOCK","6");
define("_EHR_PATIENTADMISSION_BLOCK","7");
define("_EHR_SHOWPATIENT_BLOCK","8");
define("_EHR_PATIENTPROBLEM_BLOCK","9");
define("_EHR_REPORTPRB_BLOCK","10");
define("_EHR_REPORTPRB_BLOCK","11");

} // EHR_MODULECONSTS_DEFINED
?>