<?php
//--------------------------------------------------------------------//
// Filename : modules/ehr/icd/edit.php                                //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-20                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//


if ( !defined('EHR_EDITICD_DEFINED') ) {
   define('EHR_EDITICD_DEFINED', TRUE);

include_once(XOCP_DOC_ROOT."/modules/ehr/modconsts.php");

class _ehr_EditICD extends XocpBlock {
   var $width = "100%";
   var $language;

   function _ehr_EditICD($catch=NULL) { /* fungsi konstruktor wajib punya parameter $catch
                                           yang diteruskan ke konstruktor parent class */
      global $xocpConfig,$xocp_user;
      
      $this->XocpBlock($catch);
      
      $mylanguage = $xocp_user->getVar("language");
      if($mylanguage == '') {
         $mylanguage = $xocpConfig["language"];
      }
      
      $this->language = $mylanguage;
      
   }
   
   function getLanguage() {
      return $this->language;
   }
   

   
   function getpgroup_cd($pgroup_id) {
      $db =& Database::getInstance();
      $result = $db->query("SELECT pgroup_cd FROM ".XOCP_PREFIX."pgroups WHERE pgroup_id = '$pgroup_id'");
      list($pgroup_cd) = $db->fetchRow($result);
      return $pgroup_cd;
   }
   
   function browseChapter() {
      global $HTTP_GET_VARS;
      
         $db = Database::getInstance();
         $sql = "SELECT chapter_id,english_nm,".$this->getLanguage()
              . "_nm,start_ct,stop_ct from ".XOCP_PREFIX."ehr_icd_chapter"
              . " ORDER BY chapter_id";
         $result = $db->query($sql);
         $found = $db->getRowsNum($result);
         $dp = new XocpDataPage();
         $dp->setPageSize(0);
         if($found > 0) {
            while($row=$db->fetchRow($result)) {
               $dp->addData($row);
            }
            $dp->reset();
         }

      $xurl = XOCP_SERVER_SUBDIR."/index.php?"._EHR_CATCH_VAR."="._EHR_EDITICD_BLOCK;

      $table = new XocpTable(1);
      $table->setWidth("100%");

      $hno = $table->addHeader($this->searchForm());
      $table->setColSpan($hno,2);
      $table->setCellAlign($hno,"right");

      $hno = $table->addHeader(_EHR_ICD_CHAPTERLIST." : $found "._FOUND);
      $table->setColSpan($hno,2);

      $fno = $table->addFooter($this->searchForm());
      $table->setColSpan($fno,2);
      $table->setCellAlign($fno,"right");
      
      $data = $dp->retrieve();
      foreach($data as $x) {
         list($chapter_id,$english_name,$chapter_name,$start_ct,$stop_ct) = $x;

         if(trim($chapter_name) == "") {
            $chapter_name = $english_name;
         }

//         $sql = "SELECT count(*) FROM ".XOCP_PREFIX."ehr_icd_block WHERE chapter_id = '$chapter_id'";
//         $result2 = $db->query($sql);
//         list($cnt) = $db->fetchRow($result2);
//         $cnt = "($cnt)";

         $rno = $table->addRow("<b>$chapter_id</b>","<b><a href=$xurl&chapterlink=y&x=$chapter_id".">$chapter_name [$start_ct-$stop_ct] $cnt</a>");
         $table->setCellAlign($rno,"right");
      }

      return $table->render();

   }
   

   function browseBlock($chapter_id) {
      global $HTTP_GET_VARS;
      
      $db = Database::getInstance();
      $result = $db->query("SELECT english_nm,".$this->getLanguage()."_nm,start_ct,stop_ct FROM ".XOCP_PREFIX."ehr_icd_chapter WHERE chapter_id = '$chapter_id'");
      list($chapter_english_name,$chapter_name,$start_ct,$stop_ct) = $db->fetchRow($result);
      if(trim($chapter_name) == "") {
         $chapter_name = $chapter_english_name;
      }
         
      $sql = "SELECT block_id,parentblock_id,english_nm,".$this->getLanguage()
           . "_nm,start_ct,stop_ct FROM ".XOCP_PREFIX."ehr_icd_block"
           . " WHERE chapter_id = '$chapter_id'"
           . " ORDER BY block_id";
      $result = $db->query($sql);
      $found = $db->getRowsNum($result);
      $dp = new XocpDataPage();
      $dp->setPageSize(0);
      if($found > 0) {
         while($row=$db->fetchRow($result)) {
            $dp->addData($row);
         }
      }
      $dp->reset();

      $xurl = XOCP_SERVER_SUBDIR."/index.php?"._EHR_CATCH_VAR."="._EHR_EDITICD_BLOCK;
      
      $table = new XocpTable(1);
      $table->setWidth("100%");

      $hno = $table->addHeader($this->searchForm());
      $table->setColSpan($hno,3);
      $table->setCellAlign($hno,"right");
      
      $editurl = $xurl . "&editchapter=y&chapter_id=$chapter_id";
      $hno = $table->addHeader("$chapter_id - $chapter_name <a href='$editurl'>["._EDIT."]</a><div align=right><a href='".XOCP_SERVER_SUBDIR."/index.php'>["._EHR_ICD_SELECTCHAPTER."]</a></div>");
      $table->setColSpan($hno,3);

      $fno = $table->addFooter($this->searchForm());
      $table->setColSpan($fno,3);
      $table->setCellAlign($fno,"right");
      
      $data = $dp->retrieve();
      foreach($data as $x) {
         list($block_id,$parentblock_id,$block_english_name,$block_name,$start_ct,$stop_ct) = $x;
         if(trim($block_name) == "") {
            $block_name = $block_english_name;
         }

//         $sql = "SELECT count(*) FROM ".XOCP_PREFIX."ehr_icd_item WHERE block_id = '$block_id' and subcategory = ''";
//         $result2 = $db->query($sql);
//         list($cnt) = $db->fetchRow($result2);
//         $cnt = "($cnt)";

         if($parentblock_id > 0) {
            $rno = $table->addRow("","<b>$block_id</b>","<a style='font-weight:normal;' href=$xurl&blocklink=y&x=$chapter_id&y=$block_id".">$block_name [$start_ct-$stop_ct] $cnt</a>");
            $table->setCellAlign($rno,"","right");
         } else {
            $rno = $table->addRow("<b>$block_id</b>","<a href=$xurl&blocklink=y&x=$chapter_id&y=$block_id".">$block_name [$start_ct-$stop_ct] $cnt</a>");
            $table->setColSpan($rno,1,2);
            $table->setCellAlign($rno,"right");
         }
         
      }

      return $table->render();

   }
   

   function browseItem($chapter_id,$block_id) {
      global $HTTP_GET_VARS;
      
      $db = Database::getInstance();
      $result = $db->query("SELECT a.english_nm,a.".$this->getLanguage()."_nm,b.english_nm,b."
                         . $this->getLanguage()."_nm FROM ".XOCP_PREFIX."ehr_icd_block a"
                         . " LEFT JOIN ".XOCP_PREFIX."ehr_icd_chapter b USING (chapter_id)"
                         . " WHERE a.block_id = '$block_id'");
      list($block_english_name,$block_name,$chapter_english_name,$chapter_name) = $db->fetchRow($result);

      if(trim($block_name) == "") {
         $block_name = $block_english_name;
      }

      if(trim($chapter_name) == "") {
         $chapter_name = $chapter_english_name;
      }
      
      $sql = "SELECT category,subcategory,english_nm,".$this->getLanguage()."_nm FROM "
           . XOCP_PREFIX."ehr_icd_item"
           . " WHERE block_id = '$block_id'"
           . " ORDER BY category,subcategory";
      $result = $db->query($sql);
      $found = $db->getRowsNum($result);
      $dp = new XocpDataPage();
      $dp->setPageSize(0);
      if($found > 0) {
         while($row=$db->fetchRow($result)) {
            $dp->addData($row);
         }
      }
      $dp->reset();

      $xurl = XOCP_SERVER_SUBDIR."/index.php?"._EHR_CATCH_VAR."="._EHR_EDITICD_BLOCK;
      
      $table = new XocpTable(1);
      $table->setWidth("100%");

      $hno = $table->addHeader($this->searchForm());
      $table->setColSpan($hno,3);
      $table->setCellAlign($hno,"right");

      $editchapterurl = $xurl . "&editchapter=y&chapter_id=$chapter_id";
      $editblockurl = $xurl . "&editblock=y&block_id=$block_id";

      $hno = $table->addHeader("$chapter_id - $chapter_name <a href='$editchapterurl'>["._EDIT."]</a><div align=right><a href='".XOCP_SERVER_SUBDIR."/index.php'>["._EHR_ICD_SELECTCHAPTER."]</a></div>");
      $table->setColSpan($hno,3);
      $hno = $table->addHeader("$block_id - $block_name <a href='$editblockurl'>["._EDIT."]</a><div align=right><a href='$xurl&chapterlink=y&x=$chapter_id'>["._EHR_ICD_SELECTBLOCK."]</a></div>");
      $table->setColSpan($hno,3);

      $fno = $table->addFooter($this->searchForm());
      $table->setColSpan($fno,3);
      $table->setCellAlign($fno,"right");
      
      
      $data = $dp->retrieve();
      foreach($data as $x) {
         list($category,$subcategory,$item_english_name,$item_name) = $x;

         $edititemurl = "[<a href='" . $xurl . "&edititem=y&category=$category&subcategory=$subcategory&block_id=$block_id&chapter_id=$chapter_id'>"._EDIT."</a>]";

         if(trim($item_name) == "") {
            $item_name = $item_english_name;
         }

         $catno = $category . ($subcategory != '' ? ".$subcategory" : "");
         if($subcategory != '') {
            $stylex = "style='font-weight:normal;'";
            $catno = "<b>$category.$subcategory</b>";
            $rno = $table->addRow("","$catno","<a $stylex href=$xurl&itemlink=y&x=$category&y=$subcategory".">$item_name</a> $edititemurl");
         } else {
            $stylex = "";
            $catno = "<b>$category</b>";
            $rno = $table->addRow("$catno","<a $stylex href=$xurl&itemlink=y&x=$category&y=$subcategory".">$item_name</a> $edititemurl");
            $table->setColSpan($rno,1,2);
         }
      }

      return $table->render();

   }
   
   function formEditChapter($chapter_id = 0) {

      $db = Database::getInstance();
      
      $fc_form = new XocpThemeForm("","updatechapterform","index.php","post");
      
      if($chapter_id > 0) { // edit chapter
         $fc_form->setTitle(_EHR_ICD_EDIT_CHAPTER);
         $fch_chapter_id = new XocpFormHidden("chapter_id",$chapter_id);
         $fc_chapter_id = new XocpFormLabel(_EHR_ICD_CHAPTER_ID,$chapter_id);
         $fc_form->addElement($fch_chapter_id);
         $fc_form->addElement($fc_chapter_id);
         $sql = "SELECT start_ct,stop_ct,english_nm,indonesian_nm FROM "
              . XOCP_PREFIX."ehr_icd_chapter"
              . " WHERE chapter_id = '$chapter_id'";
         $result = $db->query($sql);
         list($start_ct,$stop_ct,$english_nm,$indonesian_nm) = $db->fetchRow($result);
      } else {              // add chapter
         $fc_form->setTitle(_EHR_ICD_NEW_CHAPTER);
         $fc_chapter_id = new XocpFormText(_EHR_ICD_CHAPTER_ID,"chapter_id",5,5,$chapter_id);
         $fc_form->addElement($fc_chapter_id);
      }

      $hidden = new XocpFormHidden("X_ehr",_EHR_EDITICD_BLOCK);
      $fc_english_nm = new XocpFormText(_EHR_ICD_CHAPTER_ENGLISH_NM,"english_nm",40,200,"$english_nm");
      $fc_indonesian_nm = new XocpFormText(_EHR_ICD_CHAPTER_INDONESIAN_NM,"indonesian_nm",40,200,"$indonesian_nm");
      $fc_chapter_start_ct = new XocpFormText(_EHR_ICD_START_CT,"start_ct",5,3,"$start_ct");
      $fc_chapter_stop_ct = new XocpFormText(_EHR_ICD_STOP_CT,"stop_ct",5,3,"$stop_ct");
      $submit_button = new XocpFormButton("", "updatechapter", _SUBMIT, "submit");
      $cancel_button = new XocpFormButton("", "cancelupdatechapter", _CANCEL, "submit");
      $reset_button = new XocpFormButton("", "reset", _RESET, "reset");
      $delete_button = new XocpFormButton("", "deletechapter", _DELETE, "submit");
      $elementtray_buttons = new XocpFormElementTray("");
      $elementtray_buttons->addElement($submit_button);
      $elementtray_buttons->addElement($cancel_button);
      $elementtray_buttons->addElement($reset_button);
      $elementtray_buttons->addElement($delete_button);
      $fc_form->addElement($hidden);
      $fc_form->addElement($fc_english_nm);
      $fc_form->addElement($fc_indonesian_nm);
      $fc_form->addElement($fc_chapter_start_ct);
      $fc_form->addElement($fc_chapter_stop_ct);
      $fc_form->addElement($elementtray_buttons);
      $fc_form->setTheme(1);
      return $fc_form->render();
   
   }

   function formEditBlock($block_id = 0) {

      $db = Database::getInstance();
      
      $fc_form = new XocpThemeForm("","updateblockform","index.php","post");
      
      if($block_id > 0) { // edit block
         $fc_form->setTitle(_EHR_ICD_EDIT_BLOCK);
         $fch_block_id = new XocpFormHidden("block_id",$block_id);
         $fc_block_id = new XocpFormLabel(_EHR_ICD_BLOCK_ID,$block_id);
         $fc_form->addElement($fch_block_id);
         $fc_form->addElement($fc_block_id);
         $sql = "SELECT parentblock_id,chapter_id,start_ct,stop_ct,english_nm,indonesian_nm FROM "
              . XOCP_PREFIX."ehr_icd_block"
              . " WHERE block_id = '$block_id'";
         $result = $db->query($sql);
         list($parentblock_id,$chapter_id,$start_ct,$stop_ct,$english_nm,$indonesian_nm) = $db->fetchRow($result);
      } else {              // add chapter
         $fc_form->setTitle(_EHR_ICD_NEW_BLOCK);
         $fc_block_id = new XocpFormText(_EHR_ICD_BLOCK_ID,"block_id",5,5,$block_id);
         $fc_form->addElement($fc_block_id);
      }

      $hidden = new XocpFormHidden("X_ehr",_EHR_EDITICD_BLOCK);
      $fc_block_parent = new XocpFormText(_EHR_ICD_BLOCK_PARENT,"parentblock_id",5,3,"$parentblock_id");
      $fc_block_chapter = new XocpFormText(_EHR_ICD_BLOCK_CHAPTER,"chapter_id",5,3,"$chapter_id");
      $fc_english_nm = new XocpFormText(_EHR_ICD_BLOCK_ENGLISH_NM,"english_nm",40,200,"$english_nm");
      $fc_indonesian_nm = new XocpFormText(_EHR_ICD_BLOCK_INDONESIAN_NM,"indonesian_nm",40,200,"$indonesian_nm");
      $fc_block_start_ct = new XocpFormText(_EHR_ICD_START_CT,"start_ct",5,3,"$start_ct");
      $fc_block_stop_ct = new XocpFormText(_EHR_ICD_STOP_CT,"stop_ct",5,3,"$stop_ct");
      $submit_button = new XocpFormButton("", "updateblock", _SUBMIT, "submit");
      $cancel_button = new XocpFormButton("", "cancelupdateblock", _CANCEL, "submit");
      $reset_button = new XocpFormButton("", "reset", _RESET, "reset");
      $delete_button = new XocpFormButton("", "deleteblock", _DELETE, "submit");
      $elementtray_buttons = new XocpFormElementTray("");
      $elementtray_buttons->addElement($submit_button);
      $elementtray_buttons->addElement($cancel_button);
      $elementtray_buttons->addElement($reset_button);
      $elementtray_buttons->addElement($delete_button);
      $fc_form->addElement($hidden);
      $fc_form->addElement($fc_block_parent);
      $fc_form->addElement($fc_block_chapter);
      $fc_form->addElement($fc_english_nm);
      $fc_form->addElement($fc_indonesian_nm);
      $fc_form->addElement($fc_block_start_ct);
      $fc_form->addElement($fc_block_stop_ct);
      $fc_form->addElement($elementtray_buttons);
      $fc_form->setTheme(1);
      return $fc_form->render();
   
   }


   function formEditItem($category,$subcategory = "") {

      $db = Database::getInstance();
      
      $fc_form = new XocpThemeForm("","updateitemform","index.php","post");
      
      if($category != '') { // edit item
         $fc_form->setTitle(_EHR_ICD_EDIT_ITEM);
         $fch_category = new XocpFormHidden("category",$category);
         $fch_subcategory = new XocpFormHidden("subcategory",$subcategory);
         if($subcategory != "") {
            $item_id = "$category.$subcategory";
         } else {
            $item_id = $category;
         }
         $fc_item_id = new XocpFormLabel(_EHR_ICD_ITEM_ID,$item_id);
         $fc_form->addElement($fch_category);
         $fc_form->addElement($fch_subcategory);
         $fc_form->addElement($fc_item_id);
         $sql = "SELECT block_id,chapter_id,english_nm,indonesian_nm FROM "
              . XOCP_PREFIX."ehr_icd_item"
              . " WHERE category = '$category' and subcategory = '$subcategory'";
         $result = $db->query($sql);
         list($block_id,$chapter_id,$english_nm,$indonesian_nm) = $db->fetchRow($result);
      } else {              // add item
         $fc_form->setTitle(_EHR_ICD_NEW_ITEM);
         $fc_category = new XocpFormText(_EHR_ICD_CATEGORY,"category",5,5,"");
         $fc_subcategory = new XocpFormText(_EHR_ICD_CATEGORY,"subcategory",5,5,"");
         $fc_form->addElement($fc_subcategory);
      }

      $hidden = new XocpFormHidden("X_ehr",_EHR_EDITICD_BLOCK);
      $fc_block_id = new XocpFormText(_EHR_ICD_BLOCK_ID,"block_id",5,5,"$block_id");
      $fc_chapter_id = new XocpFormText(_EHR_ICD_CHAPTER_ID,"chapter_id",5,5,"$chapter_id");
      $fc_english_nm = new XocpFormText(_EHR_ICD_ITEM_ENGLISH_NM,"english_nm",40,200,"$english_nm");
      $fc_indonesian_nm = new XocpFormText(_EHR_ICD_ITEM_INDONESIAN_NM,"indonesian_nm",40,200,"$indonesian_nm");
      $submit_button = new XocpFormButton("", "updateitem", _SUBMIT, "submit");
      $cancel_button = new XocpFormButton("", "cancelupdateitem", _CANCEL, "submit");
      $reset_button = new XocpFormButton("", "reset", _RESET, "reset");
      $delete_button = new XocpFormButton("", "deleteitem", _DELETE, "submit");
      $elementtray_buttons = new XocpFormElementTray("");
      $elementtray_buttons->addElement($submit_button);
      $elementtray_buttons->addElement($cancel_button);
      $elementtray_buttons->addElement($reset_button);
      $elementtray_buttons->addElement($delete_button);
      $fc_form->addElement($hidden);
      $fc_form->addElement($fc_chapter_id);
      $fc_form->addElement($fc_block_id);
      $fc_form->addElement($fc_english_nm);
      $fc_form->addElement($fc_indonesian_nm);
      $fc_form->addElement($elementtray_buttons);
      $fc_form->setTheme(1);
      return $fc_form->render();
   
   }



   function searchForm($q="") {
      
      $hidden = new XocpFormHidden("X_ehr",_EHR_EDITICD_BLOCK);

      $fc_search = new XocpFormText("","q",20,100,"$q");

      $submit_button = new XocpFormButton("", "searchICD", _SEARCH, "submit");
      $reset_button = new XocpFormButton("", "reset", _RESET, "reset");

      $elementtray = new XocpFormElementTray("");

      $elementtray->addElement($fc_search);
      $elementtray->addElement($submit_button);
      $elementtray->addElement($reset_button);

      $fc_form = new XocpSimpleForm("","searchICDform","index.php","get");
      $fc_form->addElement($hidden);
      $fc_form->addElement($elementtray);
      return $fc_form->render();
   
   }


   function searchItem($q,$chapter_id = 0,$block_id = 0) {
      global $HTTP_GET_VARS;
      
      $db = Database::getInstance();

      $sql = "SELECT chapter_id,block_id,category,subcategory,english_nm,".$this->getLanguage()."_nm FROM "
           . XOCP_PREFIX."ehr_icd_item"
           . " WHERE ";
           
      $q = trim($q);
      if(strlen($q) > 1 ) {
         $no = 0;
         $array_key = explode(" ",$q);
         $sql .= " (";

         for($i = 0; $i < count($array_key); $i++) {
            if($n > 0) $sql .= " or ";
            if(!empty($array_key[$i])) {
               $sql .= "english_nm like '%$array_key[$i]%'";
               $n++;
            }
         }

         for($i = 0; $i < count($array_key); $i++) {
            if($n > 0) $sql .= " or ";
            if(!empty($array_key[$i])) {
               $sql .= $this->getLanguage()."_nm like '%$array_key[$i]%'";
               $n++;
            }
         }

         $sql .= ")";
      }

      $sql .= " ORDER BY category,subcategory";
      $result = $db->query($sql);
      $found = $db->getRowsNum($result);
      $dp = new XocpDataPage();
      $dp->setPageSize(0);
      if($found > 0) {
         while($row=$db->fetchRow($result)) {
            $dp->addData($row);
         }
      }
      $dp->reset();

      $xurl = XOCP_SERVER_SUBDIR."/index.php?"._EHR_CATCH_VAR."="._EHR_EDITICD_BLOCK;
      
      $table = new XocpTable(1);
      $table->setWidth("100%");

      $hno = $table->addHeader($this->searchForm($q));
      $table->setColSpan($hno,3);
      $table->setCellAlign($hno,"right");


      $hno = $table->addHeader(_EHR_ICD_SEARCH_RESULT." $found "._FOUND." <div align=right><a href='".XOCP_SERVER_SUBDIR."/index.php'>["._EHR_ICD_SELECTCHAPTER."]</a></div>");
      $table->setColSpan($hno,3);

      $fno = $table->addFooter($this->searchForm($q));
      $table->setColSpan($fno,3);
      $table->setCellAlign($fno,"right");
      
      
      $data = $dp->retrieve();
      foreach($data as $x) {
         list($chapter_id,$block_id,$category,$subcategory,$item_english_name,$item_name) = $x;

         if(trim($item_name) == "") {
            $item_name = $item_english_name;
         }

         $qarray = explode(" ",$q);
         for($i = 0; $i < count($qarray); $i++) {
            $item_name = eregi_replace($qarray[$i],"<font style='color:red;font-weight:bold;'>\\0</font>",$item_name);
         }

         $catno = $category . ($subcategory != '' ? ".$subcategory" : "");
         
         $blocklink = "<a href=$xurl&blocklink=y&x=$chapter_id&y=$block_id>_UP</a>";
         
         if($subcategory != '') {
            $stylex = "style='font-weight:normal;'";
            $catno = "<b>$category.$subcategory</b>";
            $rno = $table->addRow("","$catno","<a $stylex href=$xurl&itemlink=y&x=$category&y=$subcategory".">$item_name</a> $blocklink");
         } else {
            $stylex = "";
            $catno = "<b>$category</b>";
            $rno = $table->addRow("$catno","<a $stylex href=$xurl&itemlink=y&x=$category&y=$subcategory".">$item_name</a> $blocklink");
            $table->setColSpan($rno,1,2);
         }
      }

      return $table->render();

   }
   


   function main() {

      $db = Database::getInstance();
      
      $ret = "<b>". _EHR_ICD_EDITOR . "</b><br/><br/>";
      
      switch($this->catch) {
         case _EHR_EDITICD_BLOCK :
            global $HTTP_POST_VARS,$HTTP_GET_VARS;
            if(!empty($HTTP_GET_VARS["chapterlink"])) {
               $chapter_id = $HTTP_GET_VARS["x"];
               $ret .= $this->browseBlock($chapter_id);
            } elseif (!empty($HTTP_GET_VARS["blocklink"])) {
               $chapter_id = $HTTP_GET_VARS["x"];
               $block_id = $HTTP_GET_VARS["y"];
               $ret .= $this->browseItem($chapter_id,$block_id);
            } elseif (!empty($HTTP_GET_VARS["itemlink"])) {
               $category = $HTTP_GET_VARS["x"];
               $subcategory = $HTTP_GET_VARS["y"];
            } elseif (!empty($HTTP_GET_VARS["q"])) {
               $ret .= $this->searchItem($HTTP_GET_VARS["q"]);
            } elseif (!empty($HTTP_GET_VARS["editchapter"])) {
               $ret .= $this->formEditChapter($HTTP_GET_VARS["chapter_id"]);
            } elseif (!empty($HTTP_POST_VARS["updatechapter"])) {
               $chapter_id = $HTTP_POST_VARS["chapter_id"];
               $start_ct = $HTTP_POST_VARS["start_ct"];
               $stop_ct = $HTTP_POST_VARS["stop_ct"];
               $english_nm = $HTTP_POST_VARS["english_nm"];
               $indonesian_nm = $HTTP_POST_VARS["indonesian_nm"];
               $sql = "UPDATE ".XOCP_PREFIX."ehr_icd_chapter SET"
                    . " start_ct = '$start_ct',"
                    . " stop_ct = '$stop_ct',"
                    . " english_nm = '$english_nm',"
                    . " indonesian_nm = '$indonesian_nm'"
                    . " WHERE chapter_id = '$chapter_id'";
               $db->query($sql);
               $ret .= $this->browseBlock($chapter_id);
            } elseif (!empty($HTTP_POST_VARS["deletechapter"])) {
               $chapter_id = $HTTP_POST_VARS["chapter_id"];
               $sql = "DELETE FROM ".XOCP_PREFIX."ehr_icd_chapter"
                    . " WHERE chapter_id = '$chapter_id'";
               $db->query($sql);
               $ret .= $this->browseChapter();
            } elseif (!empty($HTTP_POST_VARS["cancelupdatechapter"])) {
               $ret .= $this->browseBlock($HTTP_POST_VARS["chapter_id"]);
            } elseif (!empty($HTTP_GET_VARS["editblock"])) {
               $ret .= $this->formEditBlock($HTTP_GET_VARS["block_id"]);
            } elseif (!empty($HTTP_POST_VARS["updateblock"])) {
               $block_id = $HTTP_POST_VARS["block_id"];
               $parentblock_id = $HTTP_POST_VARS["parentblock_id"];
               $chapter_id = $HTTP_POST_VARS["chapter_id"];
               $start_ct = $HTTP_POST_VARS["start_ct"];
               $stop_ct = $HTTP_POST_VARS["stop_ct"];
               $english_nm = $HTTP_POST_VARS["english_nm"];
               $indonesian_nm = $HTTP_POST_VARS["indonesian_nm"];
               $sql = "UPDATE ".XOCP_PREFIX."ehr_icd_block SET"
                    . " parentblock_id = '$parentblock_id',"
                    . " chapter_id = '$chapter_id',"
                    . " start_ct = '$start_ct',"
                    . " stop_ct = '$stop_ct',"
                    . " english_nm = '$english_nm',"
                    . " indonesian_nm = '$indonesian_nm'"
                    . " WHERE block_id = '$block_id'";
               $db->query($sql);
               $ret .= $this->browseItem($chapter_id,$block_id);
            } elseif (!empty($HTTP_POST_VARS["deleteblock"])) {
               $block_id = $HTTP_POST_VARS["block_id"];
               $chapter_id = $HTTP_POST_VARS["chapter_id"];
               $sql = "DELETE FROM ".XOCP_PREFIX."ehr_icd_block"
                    . " WHERE block_id = '$block_id'";
               $db->query($sql);
               $ret .= $this->browseBlock($chapter_id);
            } elseif (!empty($HTTP_POST_VARS["cancelupdateblock"])) {
               $block_id = $HTTP_POST_VARS["block_id"];
               $chapter_id = $HTTP_POST_VARS["chapter_id"];
               $ret .= $this->browseItem($chapter_id,$block_id);



            } elseif (!empty($HTTP_GET_VARS["edititem"])) {
               $category = $HTTP_GET_VARS["category"];
               $subcategory = $HTTP_GET_VARS["subcategory"];
               $ret .= $this->formEditItem($category,$subcategory);
            } elseif (!empty($HTTP_POST_VARS["updateitem"])) {
               $block_id = $HTTP_POST_VARS["block_id"];
               $chapter_id = $HTTP_POST_VARS["chapter_id"];
               $category = $HTTP_POST_VARS["category"];
               $subcategory = $HTTP_POST_VARS["subcategory"];
               $english_nm = $HTTP_POST_VARS["english_nm"];
               $indonesian_nm = $HTTP_POST_VARS["indonesian_nm"];
               $sql = "UPDATE ".XOCP_PREFIX."ehr_icd_item SET"
                    . " block_id = '$block_id',"
                    . " chapter_id = '$chapter_id',"
                    . " english_nm = '$english_nm',"
                    . " indonesian_nm = '$indonesian_nm'"
                    . " WHERE category = '$category' and subcategory = '$subcategory'";
               $db->query($sql);
               $ret .= $this->browseItem($chapter_id,$block_id);
            } elseif (!empty($HTTP_POST_VARS["deleteitem"])) {
               $block_id = $HTTP_POST_VARS["block_id"];
               $chapter_id = $HTTP_POST_VARS["chapter_id"];
               $category = $HTTP_POST_VARS["category"];
               $subcategory = $HTTP_POST_VARS["subcategory"];
               $sql = "DELETE FROM ".XOCP_PREFIX."ehr_icd_item"
                    . " WHERE category = '$category' and subcategory = '$subcategory'";
               $db->query($sql);
               $ret .= $this->browseItem($chapter_id,$block_id);
            } elseif (!empty($HTTP_POST_VARS["cancelupdateitem"])) {
               $block_id = $HTTP_POST_VARS["block_id"];
               $chapter_id = $HTTP_POST_VARS["chapter_id"];
               $ret .= $this->browseItem($chapter_id,$block_id);




            } else {
               $ret .= $this->browseChapter();
            }
            break;
         default : 
            $ret .= $this->browseChapter();
            break;
      }
      
      return $ret;
      
   }
   
}





} // EHR_EDITICD_DEFINED
?>