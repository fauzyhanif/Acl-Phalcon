<?php
//--------------------------------------------------------------------//
// Filename : modules/ehr/ptadmission.php                             //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2003-03-25                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('EHR_PATIENTADMISSION_DEFINED') ) {
   define('EHR_PATIENTADMISSION_DEFINED',TRUE);
   
include_once(XOCP_DOC_ROOT."/modules/ehr/modconsts.php");

function person_funccmp($a,$b) {
   if ($a[8] == $b[8]) {
      return strcmp($a[2],$b[2]);
   }
   return ($a[8] > $b[8]) ? -1 : 1;
}

class _ehr_PatientAdmission extends XocpBlock {
   // Set block width
   var $width = "100%";
   // Catch variable for get method -- See below
   var $getparam;
   // Catch variable for post method -- See below
   var $postparam;
   
   function searchPatient($datarec,$comment = "") {
      $text_ext_id = new XocpFormText(_EHR_PATIENTEXTID,"ext_id",50,250,htmlspecialchars(stripslashes($datarec["ext_id"])));
      $text_person_nm = new XocpFormText(_EHR_PATIENTNAME,"person_nm",50,250,htmlspecialchars(stripslashes($datarec["person_nm"])));
      $submit_button = new XocpFormButton("","searchperson",_SEARCH,"submit");

      $form = new XocpThemeForm(_EHR_PTADM_SEARCHPATIENTTITLE,"fsearchpatient","index.php");
      $form->addElement($this->postparam);
      $form->addElement($text_ext_id);
      $form->addElement($text_person_nm);
      $form->addElement($submit_button);
      if ($comment != "") {
         $form->setComment($comment);
      }
      $this->html->setBodyOnLoad("onload='document.fsearchpatient.ext_id.focus();'");

      return $form->render();
   }
   
   function navigate($f,$p) {
      $dp = XocpDataPage::unserialize($f);
      // Set page number
      $dp->setPage($p);
      $dp_found = $dp->getCount();
      $no1 = $dp->getOffset() + 1;
      $no2 = $no1 + $dp->getPageSize() - 1;
      if ($dp_found <= $no2) {
         $no2 = $dp_found;
      }
      // Creating header
      $dp_header = new XocpSimpleTable();
      $dp_prevnext = $dp->getPageLinks(XOCP_SERVER_SUBDIR."/index.php?".$this->getparam);
      $title = "<font class='tdh1'>"._EHR_PATIENTLIST." ($no1 - $no2 "._OF." $dp_found)</font>";
      // How many page in data page?
      if (count($dp->getPageArray()) > 1) {  // More than 1, show navigation links
         $hrow = $dp_header->addRow($title,$dp_prevnext);
      } else {
         $hrow = $dp_header->addRow($title);
      }
      $dp_header->setCellAlign($hrow,array("","right"));
      $dp_header->setWidth("100%");

      // Creating footer
      $dp_footer = new XocpSimpleTable();
      if (count($dp->getPageArray()) > 1) {  // More than 1, show navigation links
         $frow = $dp_footer->addRow("&nbsp;",$dp_prevnext);
      } else {
         $frow = $dp_footer->addRow("&nbsp;");
      }
      $dp_footer->setCellAlign($frow,array("","right"));
      $dp_footer->setWidth("100%");
                                    
      // Creating data page
      $dp_table = new XocpTable(1);
      $dp_table->setWidth("100%");
      $hrow = $dp_table->addHeader($dp_header->render());
      $frow = $dp_table->addFooter($dp_footer->render());
                                           
      // Populating data page
      $dp_data = $dp->retrieve();
      foreach ($dp_data as $row) {
         list($link,$person_id,$person_nm,$ssn,$addr_txt,$ext_id,$patient_id,$org_id,$score) = $row;
         $drow = $dp_table->addRow("$ext_id - $link<br />".nl2br($addr_txt));
      }
                                                                     
      return $dp_table->render();
   }
   
   function doAdmission($datarec,$comment = "") {
      global $ehr_ses_org_id;
      $db = &Database::getInstance();
      $hidden_person_id = new XocpFormHidden("person_id",htmlspecialchars(stripslashes($datarec["person_id"])));
      $hidden_patient_id = new XocpFormHidden("patient_id",htmlspecialchars(stripslashes($datarec["patient_id"])));
      $hidden_patient_org_id = new XocpFormHidden("patient_org_id",htmlspecialchars(stripslashes($datarec["org_id"])));
      $hidden_person_nm = new XocpFormHidden("person_nm",htmlspecialchars(stripslashes($datarec["person_nm"])));
      //$hidden_ssn = new XocpFormHidden("ssn",htmlspecialchars(stripslashes($datarec["ssn"])));
      $hidden_ext_id = new XocpFormHidden("ext_id",htmlspecialchars(stripslashes($datarec["ext_id"])));
      //$hidden_addr_txt = new XocpFormHidden("addr_txt",htmlspecialchars(stripslashes($datarec["addr_txt"])));
      $label_person_nm = new XocpFormLabel(_EHR_PATIENTNAME,stripslashes($datarec["person_nm"]));
      //$label_ssn = new XocpFormLabel(_EHR_PATIENTSSN,stripslashes($datarec["ssn"]));
      $label_ext_id = new XocpFormLabel(_EHR_PATIENTEXTID,stripslashes($datarec["ext_id"]));
      //$label_addr_txt = new XocpFormLabel(_EHR_PATIENTADDRTXT,nl2br(stripslashes($datarec["addr_txt"])));
      if ($datarec["pre_admit_test_ind"] == "") {
         $datarec["pre_admit_test_ind"] = 0;
      }
      $radio_pre_admit_test_ind = new XocpFormRadioYN(_EHR_PTADM_PREADMITTEST,"pre_admit_test_ind",$datarec["pre_admit_test_ind"]);
      $current_date = new XocpDateTime();
      $current_date->eatVars("admission","post");
      if ($current_date->getMySQL("datetime") == "0000-00-00 00:00:00") {
        $current_date->setDateTime(getdate(time()));
      }
      $dttm_admission = new XocpFormDateTime(_EHR_PTADM_ADMISSIONDTTM,"admission",$current_date,"datetime");

      $submit_admit = new XocpFormButton("","admit",_EHR_PTADM_ADMIT,"submit");
      $submit_cancel = new XocpFormButton("","cancel",_CANCEL,"submit");
      $elementtray_button = new XocpFormElementTray("");
      $elementtray_button->addElement($submit_admit);
      $elementtray_button->addElement($submit_cancel);

      $form = new XocpThemeForm(_EHR_PTADM_PATIENTADMISSIONTITLE,"fptadm","index.php");
      $form->addElement($this->postparam);
      $form->addElement($hidden_person_id);
      $form->addElement($hidden_patient_id);
      $form->addElement($hidden_patient_org_id);
      $form->addElement($hidden_person_nm);
      //$form->addElement($hidden_ssn);
      $form->addElement($hidden_ext_id);
      //$form->addElement($hidden_addr_txt);
      $form->addElement($label_person_nm);
      //$form->addElement($label_ssn);
      $form->addElement($label_ext_id);
      //$form->addElement($label_addr_txt);
      $form->addElement($radio_pre_admit_test_ind);
      $form->addElement($dttm_admission);
      $form->addElement($elementtray_button);

      $this->html->setBodyOnLoad("onload='document.fptadm.admit.focus();'");
      if ($comment != "") {
         $form->setComment($comment);
      }
      return $form->render();
   }

   function doSearch($datarec) {
      global $ehr_ses_ehr_id;
      $db =& Database::getInstance();
      $nm = trim($datarec["person_nm"]);
      $id = trim($datarec["ext_id"]);
      if (!eregi("\*",$nm) && $nm != "") {
         $nm = "%$nm%";
      } else {
         $nm = str_replace("*","%",$nm);
      }
      $sql = "SELECT p.person_id,p.person_nm,p.ssn,p.addr_txt,pt.patient_ext_id,pt.patient_id,
                     pt.org_id
              FROM ".XOCP_PREFIX."persons p
                   LEFT JOIN ".XOCP_PREFIX."ehr_patient pt
                     ON (pt.person_id = p.person_id AND pt.org_id = '$ehr_ses_ehr_id')
              WHERE p.status_cd != 'nullified' AND pt.patient_id IS NOT NULL AND
                    (p.person_nm LIKE '$nm' OR pt.patient_ext_id = '$id')";
      $result = $db->query($sql);
      if ($db->getRowsNum($result) > 0) {
         $dp = new XocpDataPage();
         $dp->setPageSize(5);
         while ($row = $db->fetchRow($result)) {
            list($person_id,$person_nm,$ssn,$addr_txt,$ext_id,$patient_id,$org_id) = $row;
            similar_text($person_nm,str_replace("%","",$nm),$score);
            $link = XOCP_SERVER_SUBDIR."/index.php?".$this->getparam."&show=y&x=$person_id";
            $dp->addData(array("<a href='$link'>$person_nm</a>",$person_id,$person_nm,$ssn,$addr_txt,$ext_id,$patient_id,$org_id,$score));
         }
         usort($dp->data,"person_funccmp");
         array_reverse($dp->data);
         $dp->serialize();
         $search_result = $this->navigate($dp->getFile(),0);
         if ($dp->getCount() > 5) {
            $comment = _EHR_PTADM_SEARCHPATIENTINFO;
         }
      } else {
         $comment = _EHR_PTADM_PATIENTNOTFOUND;
         $search_result = "";
      }
      $ret = $this->searchPatient($datarec,$comment)."<br />".$search_result;
      return $ret;
   }
   
   function show() {
      global $HTTP_POST_VARS,$HTTP_GET_VARS,$ehr_ses_org_id,$ehr_ses_ehr_id;
      $db =& Database::getInstance();
      $this->getparam = _EHR_CATCH_VAR."="._EHR_PATIENTADMISSION_BLOCK;
      $this->postparam = new XocpFormHidden(_EHR_CATCH_VAR,_EHR_PATIENTADMISSION_BLOCK);
      switch ($this->catch) {
         case _EHR_PATIENTADMISSION_BLOCK:
            if ((trim($HTTP_POST_VARS["person_nm"]) != "" || trim($HTTP_POST_VARS["ext_id"]) != "") &&
                !isset($HTTP_POST_VARS["person_id"])) {
               // Search person
               $ret = $this->doSearch($HTTP_POST_VARS);
            } elseif ($HTTP_GET_VARS["p"] != "") {
               $ret = $this->searchPatient(NULL)."<br />".$this->navigate($HTTP_GET_VARS["f"],$HTTP_GET_VARS["p"]);
            } elseif ($HTTP_GET_VARS["show"] == "y") {
               $sql = "SELECT p.person_id,p.person_nm,p.ssn,p.addr_txt,p.ext_id,
                              pt.patient_id,pt.org_id
                       FROM ".XOCP_PREFIX."persons p
                            LEFT JOIN ".XOCP_PREFIX."ehr_patient pt
                              ON (pt.person_id = p.person_id)
                       WHERE p.person_id = '".$HTTP_GET_VARS["x"]."'";
               $result = $db->query($sql);
               if ($db->getRowsNum($result)) {
                  $row = $db->fetchArray($result);
                  $ret = $this->doAdmission($row);
               } else {
                  $ret = $this->searchPatient(NULL,_EHR_PTADM_PATIENTNOTFOUND);
               }
            } elseif (($HTTP_POST_VARS["admit"] != "" || $HTTP_POST_VARS["person_id"] != "") &&
                      !isset($HTTP_POST_VARS["cancel"])) {
               $yesno = array("n","y");
               $admission_dttm = new XocpDateTime();
               $admission_dttm->eatVars("admission","post");
               
               $sql = "SELECT MAX(admission_id),MAX(admission_dt)
                       FROM ".XOCP_PREFIX."ehr_admission
                       WHERE patient_org_id = '$ehr_ses_ehr_id' AND
                             admission_dt = '".$admission_dttm->getMySQL("date")."'";
               $result = $db->query($sql);
               list($admission_id,$admission_dt) = $db->fetchRow($result);
               if ($admission_dt == NULL) {
                  $admission_id = 1;
               } else {
                  $admission_id++;
               }
               $sql = "INSERT INTO ".XOCP_PREFIX."ehr_admission
                          (org_id,admission_id,admission_dt,admission_tm,
                        	status_cd,pre_admit_test_ind,patient_id, 
                        	patient_org_id)
                       VALUES ('$ehr_ses_org_id','$admission_id',
                               '".$admission_dttm->getMySQL("date")."',
                               '".$admission_dttm->getMySQL("time")."',
                               'normal','".$yesno[$HTTP_POST_VARS["pre_admit_test_ind"]]."',
                               '".$HTTP_POST_VARS["patient_id"]."','".$HTTP_POST_VARS["patient_org_id"]."')";
               $result = $db->query($sql);
               $comment = $db->error();
               if ($comment == "") {
                  $ret = $this->searchPatient(NULL,_EHR_PTADM_SAVESUCCESS);
               } else {
                  $ret = $this->doAdmission($HTTP_POST_VARS,_EHR_PTADM_SAVEFAIL."<br />".$comment);
               }
            } else {
               if ($ehr_ses_ehr_id > 0 && $ehr_ses_org_id > 0 && $ehr_ses_ehr_id != $ehr_ses_org_id) {
                  $ret = $this->searchPatient($NULL);
               }
            }
            break;
         default:
            // Default handler
            if ($ehr_ses_ehr_id > 0 && $ehr_ses_org_id > 0 && $ehr_ses_ehr_id != $ehr_ses_org_id) {
               $ret = $this->searchPatient($HTTP_POST_VARS);
            }
            break;
      }
      return "<br />".$ret;
   }

}

} // EHR_PATIENTADMISSION_DEFINED
?>