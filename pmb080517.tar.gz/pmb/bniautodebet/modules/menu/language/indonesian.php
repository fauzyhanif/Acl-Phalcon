<?php
//--------------------------------------------------------------------//
// Filename : modules/menu/language/english.php                       //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-13                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('MENU_LANGUAGE_DEFINED') ) {
   define('MENU_LANGUAGE_DEFINED', TRUE);

define("_MENU_ADMINISTRATION","Administrasi Menu Group");
define("_MENU_ADDFORM","Tambah Menu");
define("_MENU_EDITFORM","Edit Menu");
define("_MENU_MENUNAME","Nama Menu");
define("_MENU_SELECTPARENT","Kepala Menu");
define("_MENU_WEIGHT","Urutan");
define("_MENU_PARAM0","GET Parameter 1");
define("_MENU_PARAM1","GET Parameter 2");
define("_MENU_HTML","HTML");
define("_MENU_GROUPLIST","Daftar Group");
define("_MENU_MENUITEMSLIST","Daftar Menu");
define("_MENU_ROOTMENU"," - ");
define("_MENU_COPYFORM","Copy Menu Dari Group Lain");
define("_MENU_SELECTGROUPCOPY","Pilih Group");

define("_MENU_COPYFROM","Copy Dari");

} // MENU_LANGUAGE_DEFINED
?>