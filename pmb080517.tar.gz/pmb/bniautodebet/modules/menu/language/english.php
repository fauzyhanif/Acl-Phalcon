<?php
//--------------------------------------------------------------------//
// Filename : modules/menu/language/english.php                       //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-13                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('MENU_LANGUAGE_DEFINED') ) {
   define('MENU_LANGUAGE_DEFINED', TRUE);

define("_MENU_ADMINISTRATION","Menu Administration");
define("_MENU_ADDFORM","Add New Menu Item");
define("_MENU_EDITFORM","Edit Menu");
define("_MENU_MENUNAME","Menu Name");
define("_MENU_SELECTPARENT","Parent Menu");
define("_MENU_WEIGHT","Weight Order");
define("_MENU_PARAM0","GET Parameter 1");
define("_MENU_PARAM1","GET Parameter 2");
define("_MENU_GROUPLIST","Group List");
define("_MENU_MENUITEMSLIST","Menu Items List");
define("_MENU_ROOTMENU"," - ");
define("_MENU_COPYFORM","Copy Menu From Another Group");
define("_MENU_SELECTGROUPCOPY","Select Group");

define("_MENU_COPYFROM","Copy From");

} // MENU_LANGUAGE_DEFINED
?>