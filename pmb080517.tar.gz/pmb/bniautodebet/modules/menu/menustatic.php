<?php
//--------------------------------------------------------------------//
// Filename : modules/menu/menu.php                                   //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-20                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('MENU_DEFINED') ) {
   define('MENU_DEFINED', TRUE);

include_once(XOCP_DOC_ROOT."/modules/menu/class/treemenustatic.php");

class _menu_MenuStatic extends XocpBlock {

   function show() {
      global $xocp_user;
      
      $pgroup_id = $xocp_user->getVar("pgroup_id");
      

      $treemenu = new TreeMenu();

      $db = Database::getInstance();
      $sql = "SELECT menuitem_id,parent_id,menu_nm,param0,param1,weight,html FROM ".XOCP_PREFIX."menuitems"
           . " WHERE pgroup_id = '$pgroup_id'"
           . " ORDER BY parent_id,weight";
      $result = $db->query($sql);
      $found = $db->getRowsNum($result);

      if($found > 0) {
         while(list($menuitem_id,$parent_id,$menu_nm,$param0,$param1,$weight,$html)=$db->fetchRow($result)) {
            if($param0 != '') {
               $link = XOCP_SERVER_SUBDIR . "/index.php?" . $param0 . ($param1 != '' ? "&".$param1 : "");
            } else {
               $link = "";
            }
            $treemenu->addItem(new Node($menuitem_id,$menu_nm,$parent_id,$link,$html));
         }

      $ret = "\n";
      $ret .= $treemenu->render("X".$pgroup_id."X");
      $ret = "<table width=100% border=0 cellpadding=2 cellspacing=2><tr><td align=center class=menustatictitle>"
           . "<b><font color=#ffffff><i>MENU</i></font></b></td></tr>"
           . "<tr><td class=menustatic>" . $ret . "</td></tr></table>";

      }


      switch($this->catch) {
         default :
            return $ret;
//            if($xocp_user->getVar("user_id") > 0) {
//               return $ret;
//            } else {
//               return "";
//            }
      }
   }

}

} // MENU_DEFINED
?>