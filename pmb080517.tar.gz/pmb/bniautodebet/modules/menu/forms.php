<?php

if ( !defined('MENU_FORMADMINMENU_DEFINED') ) {
   define('MENU_FORMADMINMENU_DEFINED', TRUE);


function menu_copyform($pgroup_id) {
   $db =& Database::getInstance();
   $pgroup_cd = _menu_ControlMenu::getpgroup_cd($pgroup_id);
   $sql = "SELECT a.pgroup_id,a.pgroup_cd,COUNT(c.menuitem_id) FROM ".XOCP_PREFIX."pgroups a"
        . " LEFT JOIN ".XOCP_PREFIX."menuitems c USING(pgroup_id) GROUP BY a.pgroup_id";
   $result = $db->query($sql);
   if($db->getRowsNum($result)>0) {
      $sl = new XocpFormSelect(_MENU_SELECTGROUPCOPY,"copypgroup_id");
      while(list($pgroup_idx,$pgroup_cdx,$cnt)=$db->fetchRow($result)) {
         if($cnt>0 && $pgroup_cdx != $pgroup_cd) {
            $sl->addOption($pgroup_idx,$pgroup_cdx." ($cnt)");
         }
      }
   } else {
      $sl = new XocpFormLabel(_MENU_SELECTGROUPCOPY,_EMPTY_RESULT);
   }
   
   $buttons = new XocpFormElementTray("");
   $copy_button = new XocpFormButton("","docopypgroup",_COPY,"submit");
   $cancel_button = new XocpFormButton("","cancelcopypgroup",_CANCEL,"submit");
   $hidden = new XocpFormHidden("X_menu",1);
   $hpgroup = new XocpFormHidden("pgroup_id",$pgroup_id);
   $buttons->addElement($copy_button);
   $buttons->addElement($cancel_button);
   
   $form = new XocpThemeForm(_MENU_COPYFORM." : ".$pgroup_cd,"cpygroupmenu","index.php");
   $form->addElement($hidden);
   $form->addElement($hpgroup);
   $form->addElement($sl);
   $form->addElement($buttons);
   
   return $form;
}

function menu_addbutton($pgroup_id) {
   $add_button = new XocpFormButton("","addnewmenu",_ADD,"submit");
   $copyfrom_button = new XocpFormButton("","copymenu",_MENU_COPYFROM,"submit");
   $cancel_button = new XocpFormButton("","cancelpgroup",_CANCEL,"submit");
   $hidden = new XocpFormHidden("X_menu",1);
   $hpgroup = new XocpFormHidden("pgroup_id",$pgroup_id);
   
   $form = new XocpSimpleForm("","addnew","index.php");
   $form->addElement($add_button);
   $form->addElement($copyfrom_button);
   $form->addElement($cancel_button);
   $form->addElement($hidden);
   $form->addElement($hpgroup);
   return $form;
}


function menu_editform($pgroup_id,$menuitem_id = 0) {
   global $menu_lastparent,$HTTP_SESSION_VARS;
   session_register("menu_lastparent");
   
   $save_button = new XocpFormButton("","savemenuitem",_SAVE,"submit");
   $reset_button = new XocpFormButton("","reset",_RESET,"reset");
   $cancel_button = new XocpFormButton("","cancelsave",_CANCEL,"submit");
   $hidden = new XocpFormHidden("X_menu",1);
   $hpgroup = new XocpFormHidden("pgroup_id",$pgroup_id);

   $buttons = new XocpFormElementTray("");
   $buttons->addElement($save_button);
   $buttons->addElement($reset_button);
   $buttons->addElement($cancel_button);

   $db =& Database::getInstance();
   if($menuitem_id > 0) {
      $formtitle = _MENU_EDITFORM . " - ". _menu_ControlMenu::getpgroup_cd($pgroup_id);
      $sql = "SELEcT menu_nm,parent_id,weight,param0,param1,html FROM ".XOCP_PREFIX."menuitems"
           . " WHERE menuitem_id = '$menuitem_id' AND pgroup_id = '$pgroup_id'";
      $result = $db->query($sql);
      list($menu_nm,$sel_parent_id,$weight,$param0,$param1,$html) = $db->fetchRow($result);
      $htmlx = htmlentities($html);
      $delete_button = new XocpFormButton("","deletemenuitem",_DELETE,"submit");
      $buttons->addElement($delete_button);
   } else {
      $formtitle = _MENU_ADDFORM . " - ". _menu_ControlMenu::getpgroup_cd($pgroup_id);
   }
   
   $form = new XocpThemeForm($formtitle,"addnew","index.php");

   $menuname = new XocpFormText(_MENU_MENUNAME,"menu_nm",30,100,$menu_nm);
   $weight = new XocpFormText(_MENU_WEIGHT,"weight",10,50,$weight);
   $param0 = new XocpFormText(_MENU_PARAM0,"param0",50,255,$param0);
   $param1 = new XocpFormText(_MENU_PARAM1,"param1",50,255,$param1);
   $htmlf = new XocpFormText(_MENU_HTML,"html",50,255,$htmlx);
   
   $sql = "SELECT menuitem_id,menu_nm FROM ".XOCP_PREFIX."menuitems"
        . " WHERE pgroup_id = '$pgroup_id' AND param0 = ''"
        . " ORDER BY menuitem_id";
   $result = $db->query($sql);
   $selectparent = new XocpFormSelect(_MENU_SELECTPARENT,"parent_id",$sel_parent_id);
   $selectparent->addOption("0",_MENU_ROOTMENU);
   if($db->getRowsNum($result)>0) {
      while(list($menuitem_idx,$menu_nmx)=$db->fetchRow($result)) {
         if($menuitem_idx == $menuitem_id) continue;
         $selectparent->addOption($menuitem_idx,$menu_nmx);
      }
   }
   
   
   $form->addElement($menuname);
   $form->addElement($selectparent);
   $form->addElement($weight);
   $form->addElement($param0);
   $form->addElement($param1);
   $form->addElement($htmlf);
   $form->addElement($buttons);
   $form->addElement($hidden);
   $form->addElement($hpgroup);

   if($menuitem_id > 0) {
      $hmenuitem = new XocpFormHidden("menuitem_id",$menuitem_id);
      $form->addElement($hmenuitem);
   }

   return $form;
}



} // MENU_FORMADMINMENU_DEFINED
?>