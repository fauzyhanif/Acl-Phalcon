
var cookieStatus = new Array();
var cookieName = "menuX";
var branchStatus = new Array();

function saveExpandedStatus (nodeID, expanded) {
      cookieStatus[nodeID] = expanded;
      saveCookie();
}

function saveCookie () {
   var cookieString = new Array();

   for (var i in cookieStatus) {
      if (cookieStatus[i] == true) {
         cookieString[cookieString.length] = i;
      }
   }
   
   document.cookie = cookieName + '=' + cookieString.join(':');
}

function loadCookie () {
   var cookie = document.cookie.split('; ');
   for (var i=0; i < cookie.length; i++) {
      var crumb = cookie[i].split('=');
      if (cookieName == crumb[0] && crumb[1]) {
         var expandedBranches = crumb[1].split(':');
         for (var j=0; j<expandedBranches.length; j++) {
            cookieStatus[expandedBranches[j]] = true;
         }
      }
   }
}

function resetBranches () {
   loadCookie();
   for (var nodeID in cookieStatus) {
      if(cookieStatus[nodeID]) {
         toggleBranch(nodeID);
      }
   }
}



function toggleBranch (nodeID) {
   var currentBlock   = document.all[nodeID];
   if(!currentBlock) {
      return;
   }
   var newDisplay     = (currentBlock.style.display == 'inline' ? 'none' : 'inline');

   currentBlock.style.display = newDisplay;
   branchStatus[nodeID] = !branchStatus[nodeID];
   saveExpandedStatus(nodeID, branchStatus[nodeID]);

   // Swap image
   swapImage(nodeID);
}


function swapImage (nodeID) {
   if(!(document.images['img_' + nodeID])) return;
   imgSrc = document.images['img_' + nodeID].src;
   
   re = /^(.*)(plus|minus)(bottom|top|single)?.gif$/
   if (matches = imgSrc.match(re)) {
      document.images['img_' + nodeID].src = stringFormat('{0}{1}{2}{3}',
                                                matches[1],
                                                matches[2] == 'plus' ? 'minus' : 'plus',
                                                matches[3] ? matches[3] : '',
                                                '.gif');
   }
}

function stringFormat (strInput)
{
   var idx = 0;

   for (var i=1; i<arguments.length; i++) {
      while ((idx = strInput.indexOf('{' + (i - 1) + '}', idx)) != -1) {
         strInput = strInput.substring(0, idx) + arguments[i] + strInput.substr(idx + 3);
      }
   }
   
   return strInput;
}

