<?php
/*


   item_id, parent_id, text, link, expanded

   $node = new Node(item_id,text,parent_id,link,expanded);
   $treemenu = new TreeMenu();
   
   $treemenu->addItem($node);
   
   $treemenu->render(prefix);




*/


class TreeMenu {
   var $text;
   var $link;
   var $icon;
   var $item = array();
   var $parent = array();
   var $expanded;
   var $ret = "";
   var $prefix = "XXX";

   function addItem($node) {
      $this->item[$node->id] = $node;
      $this->parent[$node->parent][$node->id] = $node->parent;
   }
   
   function isParent($node_id) {
      if(empty($this->parent[$node_id])) {
         return FALSE;
      } else {
         return is_array($this->parent[$node_id]);
      }
   }
   
   function isHTML($node_id) {
      if(empty($this->item[$node_id]->html)) {
         return FALSE;
      } else {
         return TRUE;
      }
   }
   
   function renderNode($node_id,$depth=0) {
      if($this->isParent($node_id)) {

         // render as parent
         if($this->isHTML($node_id)) {
            $this->ret .= $this->item[$node_id]->html;
         } else {
            $this->ret .= "<nobr><img src=".XOCP_SERVER_SUBDIR."/modules/menu/images/spacer.gif width='".($depth*10)."' height=1><a class=menu_p>";
            $this->ret .= "<img src=".XOCP_SERVER_SUBDIR."/modules/menu/images/bullet.gif border=0 name=img_".$this->prefix."$node_id> ".$this->item[$node_id]->text."</a></nobr><br/>\n";
            $this->ret .= "<div id='".$this->prefix."$node_id' style='display:block;'>";
         }

         // recurse the child
         foreach($this->parent[$node_id] as $child_id => $parent_id) {
            $this->renderNode($child_id,$depth+1);
         }

         $this->ret .= "</div>";
         
      } else {

         // render as child
         if($this->isHTML($node_id)) {
            $this->ret .= $this->item[$node_id]->html;
         } else {
            $this->ret .= "<nobr><img src=".XOCP_SERVER_SUBDIR."/modules/menu/images/spacer.gif width='".($depth*10)."' height=1><a class=menu_c href=\"".$this->item[$node_id]->link."\"><img src=".XOCP_SERVER_SUBDIR."/modules/menu/images/bullet.gif border=0> ".$this->item[$node_id]->text."</a></nobr><br/>\n";
         }

      }
   }

   function render($prefix) {
      if(count($this->parent[0])<=0) {
         return;
      }
      /*
      $this->ret .= "\n<style type='text/css'>\n"
                  . "<!--\n"
                  . "A.menu_p       {  font-weight: normal; font-family: Tahoma, Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #ffffff; text-decoration: none}\n"
                  . "A.menu_p:hover {  font-weight: normal; font-family: Tahoma, Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #ffff00; text-decoration: none}\n"
                  . "A.menu_c       {  font-weight: normal; font-family: Tahoma, Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #ffffff; text-decoration: none}\n"
                  . "A.menu_c:hover {  font-weight: normal; font-family: Tahoma, Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #ffff00; text-decoration: none}\n"
                  . "-->\n"
                  . "</style>\n";
      */
      $this->prefix = $prefix;
      foreach($this->parent[0] as $node_id => $parent_id) {
         $this->renderNode($node_id);
      }
      
//      $this->ret .= "<script language=Javascript>resetBranches();</script>\n";
      
      return $this->ret;
   }
}


class Node {
   var $id;
   var $text;
   var $link;
   var $html;
   var $icon;
   var $expanded;
   var $parent;

   function Node($id, $text, $parent = 0, $link = "", $html = "", $icon = NULL, $expanded = FALSE) {
      $this->id       = $id;
      $this->text     = $text;
      $this->link     = $link;
      $this->html     = $html;
      $this->parent   = intval($parent);
      $this->icon     = $icon;
      $this->expanded = $expanded;
   }

}


?>