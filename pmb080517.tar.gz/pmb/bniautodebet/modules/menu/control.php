<?php
//--------------------------------------------------------------------//
// Filename : modules/menu/control.php                                //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-20                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//


if ( !defined('MENU_CONTROL_DEFINED') ) {
   define('MENU_CONTROL_DEFINED', TRUE);

include(XOCP_DOC_ROOT."/modules/menu/forms.php");

class _menu_ControlMenu extends XocpBlock {
   var $width = "100%";
   
   function getpgroup_cd($pgroup_id) {
      $db =& Database::getInstance();
      $result = $db->query("SELECT pgroup_cd FROM ".XOCP_PREFIX."pgroups WHERE pgroup_id = '$pgroup_id'");
      list($pgroup_cd) = $db->fetchRow($result);
      return $pgroup_cd;
   }
   
   function browseGroup() {
      global $HTTP_GET_VARS;
      
         $db = Database::getInstance();
         $sql = "SELECT pgroup_id,pgroup_cd,description from ".XOCP_PREFIX."pgroups"
              . " ORDER BY pgroup_cd";
         $result = $db->query($sql);
         $found = $db->getRowsNum($result);
         $dp = new XocpDataPage();
         $dp->setPageSize(0);
         if($found > 0) {
            while($row=$db->fetchRow($result)) {
               $dp->addData($row);
            }
            $dp->reset();
         }

      $xurl = XOCP_SERVER_SUBDIR."/index.php?X_menu=1";

      $table = new XocpTable(1);
      $table->setWidth("100%");
      $hno = $table->addHeader(_MENU_GROUPLIST." : $found "._FOUND);
      $table->setColSpan($hno,2);
      $fno = $table->addFooter("&nbsp;");
      $table->setColSpan($fno,2);
      
      $data = $dp->retrieve();
      foreach($data as $x) {
         list($pgroup_id,$pgroup_cd,$desc) = $x;
         $rno = $table->addRow($pgroup_id,"<b><a href=$xurl&edit=y&x=$pgroup_id".">$pgroup_cd</a></b><br/>$desc");
         $table->setCellAlign($rno,"center");
      }

      return $table->render();

   }
   

   function browseMenu($pgroup_id) {
      global $HTTP_GET_VARS;
      
         $db = Database::getInstance();
         $sql = "SELECT menuitem_id,parent_id,menu_nm,param0,param1,weight,html FROM ".XOCP_PREFIX."menuitems"
              . " WHERE pgroup_id = '$pgroup_id'"
              . " ORDER BY parent_id,weight";
         $result = $db->query($sql);
         $found = $db->getRowsNum($result);
         $dp = new XocpDataPage();
         $dp->setPageSize(0);
         if($found > 0) {
            while($row=$db->fetchRow($result)) {
               $dp->addData($row);
            }
         }
         $dp->reset();

      $xurl = XOCP_SERVER_SUBDIR."/index.php?X_menu=1";
      
      $addbutton = menu_addbutton($pgroup_id);

      $htable = new XocpSimpleTable();
      $sno = $htable->addRow("<b><i>"._MENU_MENUITEMSLIST." : ".$this->getpgroup_cd($pgroup_id)."</i></b>",$addbutton->render());
      $htable->setCellAlign($sno,array("","right"));
      $htable->setWidth("100%");

      $ftable = new XocpSimpleTable();
      $sno = $ftable->addRow($addbutton->render());
      $ftable->setCellAlign($sno,array("right"));
      $ftable->setWidth("100%");

      
      $itemtree = new _menu_MenuItemTree();
      if($found > 0) {
         $data = $dp->retrieve();
         foreach($data as $x) {
            list($menuitem_id,$parent_id,$menu_nm,$param0,$param1,$weight,$html) = $x;
            if(($param0 == '' && $param1 == '') /* || ($parent_id == 0) */) {
               $style="";
            } else {
               $style=" style='font-weight:normal;'";
            }
            if(trim($html) != "") {
               $param0 = htmlentities($html);
            }
            $itemx = new _menu_MenuItem($menuitem_id,"<b><a$style href=$xurl&editx=y&x=$pgroup_id&y=$menuitem_id".">$menu_nm</a></b>",$parent_id,$weight,$param0,$param1);
            $itemtree->addItem($itemx);
         }
      }
      
      $table = $itemtree->render();
      $table->setWidth("100%");
      $hno = $table->addHeader($htable->render());
      $table->setColSpan($hno,6);
      $fno = $table->addFooter($ftable->render());
      $table->setColSpan($fno,6);

      return $table->render();

   }
   


   function main() {
      
      $ret = "<b>". _MENU_ADMINISTRATION . "</b><br/><br/>";
      
      switch($this->catch) {
         case "1" :
            global $HTTP_POST_VARS,$HTTP_GET_VARS;
            if($HTTP_GET_VARS["f"] != "") {
               $ret .= $this->browseGroup($HTTP_GET_VARS["f"]);
               break;
            } else if(!empty($HTTP_POST_VARS["cancelpgroup"])) {
               $ret .= $this->browseGroup();
               break;
            } else if($HTTP_GET_VARS["edit"] == "y") {
               $ret .= $this->browseMenu($HTTP_GET_VARS["x"]);
               break;
            } else if(!empty($HTTP_POST_VARS["addnewmenu"])) {
               $form = menu_editform($HTTP_POST_VARS["pgroup_id"]);
               $ret .= $form->render();
               break;
            } else if(!empty($HTTP_POST_VARS["cancelsave"])) {
               $ret .= $this->browseMenu($HTTP_POST_VARS["pgroup_id"]);
               break;
            } else if(!empty($HTTP_POST_VARS["savemenuitem"])) {
               $db =& Database::getInstance();

               $pgroup_id = $HTTP_POST_VARS["pgroup_id"];
               $menu_nm = $HTTP_POST_VARS["menu_nm"];
               $weight = $HTTP_POST_VARS["weight"];
               $param0 = $HTTP_POST_VARS["param0"];
               $param1 = $HTTP_POST_VARS["param1"];
               $html = $HTTP_POST_VARS["html"];
               $parent_id = intval($HTTP_POST_VARS["parent_id"]);
               $menuitem_id = $HTTP_POST_VARS["menuitem_id"];
               $html = addslashes($html);
               
               
               global $menu_lastparent;
               $menu_lastparent = $parent_id;
               
               if(empty($menuitem_id)) {
                  $sql = "SELECT max(menuitem_id) FROM ".XOCP_PREFIX."menuitems"
                       . " WHERE pgroup_id = '$pgroup_id'";
                  $result = $db->query($sql);
                  list($menuitem_id)=$db->fetchRow($result);
                  $menuitem_id++;
                  $sql = "INSERT INTO ".XOCP_PREFIX."menuitems (menu_nm,menuitem_id,parent_id,pgroup_id,weight,param0,param1,html)"
                       . " VALUES ('$menu_nm','$menuitem_id','$parent_id','$pgroup_id','$weight','$param0','$param1','$html')";
               } else {
                  $sql = "UPDATE ".XOCP_PREFIX."menuitems SET menu_nm = '$menu_nm'"
                       . ",parent_id = '$parent_id',weight = '$weight',param0 = '$param0'"
                       . ",param1 = '$param1',html='$html'"
                       . " WHERE menuitem_id = '$menuitem_id' AND pgroup_id = '$pgroup_id'";
               }
               
               $db->query($sql);
               $ret .= $this->browseMenu($HTTP_POST_VARS["pgroup_id"]);
               break;
            } else if(!empty($HTTP_POST_VARS["deletemenuitem"])) {
               $db =& Database::getInstance();
               $pgroup_id = $HTTP_POST_VARS["pgroup_id"];
               $menuitem_id = $HTTP_POST_VARS["menuitem_id"];
               $sql = "DELETE FROM ".XOCP_PREFIX."menuitems"
                    . " WHERE menuitem_id = '$menuitem_id' AND pgroup_id = '$pgroup_id'";
               $db->query($sql);
               $sql = "UPDATE ".XOCP_PREFIX."menuitems SET parent_id = 0 WHERE parent_id = '$menuitem_id'"
                    . " AND pgroup_id = '$pgroup_id'";
               $db->query($sql);
               $ret .= $this->browseMenu($pgroup_id);
               break;
            } else if(!empty($HTTP_GET_VARS["editx"])) {
               $pgroup_id = $HTTP_GET_VARS["x"];
               $menuitem_id = $HTTP_GET_VARS["y"];
               $form = menu_editform($pgroup_id,$menuitem_id);
               $ret .= $form->render();
               break;
            } else if(!empty($HTTP_POST_VARS["copymenu"])) {
               $pgroup_id = $HTTP_POST_VARS["pgroup_id"];
               $form = menu_copyform($pgroup_id);
               $ret .= $form->render();
               break;
            } else if(!empty($HTTP_POST_VARS["cancelcopypgroup"])) {
               $ret .= $this->browseMenu($HTTP_POST_VARS["pgroup_id"]);
               break;
            } else if(!empty($HTTP_POST_VARS["docopypgroup"])) {
               $db =& Database::getInstance();
               
               $pgroup_id = $HTTP_POST_VARS["pgroup_id"];
               $copypgroup_id = $HTTP_POST_VARS["copypgroup_id"];
               
               if($copypgroup_id != '') {
                  $sql = "DELETE FROM ".XOCP_PREFIX."menuitems WHERE pgroup_id = '$pgroup_id'";
                  $db->query($sql);
                  $sql = "SELECT menuitem_id,parent_id,weight,menu_nm,param0,param1,html"
                       . " FROM ".XOCP_PREFIX."menuitems"
                       . " WHERE pgroup_id = '$copypgroup_id'";
                  $result = $db->query($sql);
                  while(list($menuitem_idx,$parent_idx,$weightx,$menu_nmx,$param0x,$param1x,$htmlx)=$db->fetchRow($result)) {
                     $htmlx = addslashes($htmlx);

                     $sql = "INSERT INTO ".XOCP_PREFIX."menuitems (menuitem_id,parent_id,pgroup_id,menu_nm,weight,param0,param1,html)"
                          . " VALUES('$menuitem_idx','$parent_idx','$pgroup_id','$menu_nmx','$weightx','$param0x','$param1x','$htmlx')";
                     $db->query($sql);
                  }
               }
               $ret .= $this->browseMenu($HTTP_POST_VARS["pgroup_id"]);
               break;
            }

         default : 
            $ret .= $this->browseGroup();
      }
      
      return $ret;
      
   }
   
}





class _menu_MenuItemTree {
   var $text;
   var $link;
   var $icon;
   var $item = array();
   var $parent = array();
   var $expanded;
   var $ret = "";
   var $prefix = "XXX";
   var $table;

   function _menu_MenuItemTree() {
//      $this->table = new XocpTable(1);
   }
   
   function addItem($node) {
      $this->item[$node->menuitem_id] = $node;
      $this->parent[$node->parent_id][$node->menuitem_id] = $node->parent_id;
   }
   
   function isParent($node_id) {
      return is_array($this->parent[$node_id]);
   }
   
   function renderNode($node_id) {
      if($this->isParent($node_id)) {

         // render as parent
         $rno = $this->table->addRow($this->item[$node_id]->menuitem_id,$this->item[$node_id]->menu_nm,$this->item[$node_id]->parent_id,$this->item[$node_id]->param0,$this->item[$node_id]->param1,$this->item[$node_id]->weight);

         // recurse the child
         foreach($this->parent[$node_id] as $child_id => $parent_id) {
            $this->renderNode($child_id);
         }

      } else {

         // render as child
         $this->table->addRow($this->item[$node_id]->menuitem_id,$this->item[$node_id]->menu_nm,$this->item[$node_id]->parent_id,$this->item[$node_id]->param0,$this->item[$node_id]->param1,$this->item[$node_id]->weight);

      }
   }

   function render() {
      $this->table = new XocpTable(1);
      if(count($this->item)>0) {
         foreach($this->parent[0] as $menuitem_id => $parent_id) {
            $this->renderNode($menuitem_id);
         }
      }
      return $this->table;
   }
}

class _menu_MenuItem {
   var $menuitem_id;
   var $menu_nm;
   var $param0;
   var $param1;
   var $weight;
   var $parent_id;

   function _menu_MenuItem($id, $text, $parent = 0, $weight = 0, $link0 = "", $link1 = "") {
      $this->menuitem_id = $id;
      $this->menu_nm     = $text;
      $this->param0      = $link0;
      $this->param1      = $link1;
      $this->parent_id   = intval($parent);
      $this->weight      = $weight;
   }

}




} // MENU_CONTROL_DEFINED
?>