<?php
//--------------------------------------------------------------------//
// Filename : modules/project/orglink.php                             //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-03-17                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('PRJ_ORGLINK_DEFINED') ) {
   define('PRJ_ORGLINK_DEFINED', TRUE);

include(XOCP_DOC_ROOT."/modules/project/forms.php");

class _project_OrgLink extends XocpBlock {
   var $width = "100%";
   
   function browse($f = NULL) {
      global $HTTP_GET_VARS;
      
      if($f == NULL) {
         $db = Database::getInstance();
         $sql = "SELECT a.org_nm,a.org_id,b.sub_id,c.org_nm FROM ".XOCP_PREFIX."orgs a"
              . " LEFT JOIN ".XOCP_PREFIX."prj_orglink b USING (org_id)"
              . " LEFT JOIN ".XOCP_PREFIX."orgs c on c.org_id=b.sub_id"
              . " ORDER BY a.org_nm,c.org_nm";
         $result = $db->query($sql);
         $c = $db->getRowsNum($result);
         if($c > 0) {
            $dp = new XocpDataPage();
            $dp->setPageSize(20);
            unset($old_org_id);
            unset($old_org_nm);
            while(list($org_nm,$org_id,$sub_id,$sub_nm)=$db->fetchRow($result)) {
               if($org_id != $old_org_id) {
                  if(isset($old_org_nm)) {
                     $dp->addData(array($old_org_id,$old_org_nm,implode("<br/>",$sublist)));
                  }
                  unset($sublist);
                  $sublist = array();
                  if ($sub_nm != "") {
                  	$sublist[] = $sub_nm;
                  }
                  $old_org_nm = $org_nm;
                  $old_org_id = $org_id;
               } else {
                  if ($sub_nm != "") {
                  	$sublist[] = $sub_nm;
                  }
               }
            }
            $dp->addData(array($old_org_id,$old_org_nm,implode(", ",$sublist)));
            $dp->serialize();
            $found = $dp->getCount();
            $dpfile = $dp->getFile();
            $dp->reset();
         } else {
            return $sql . _SYS_GROUP_NOTFOUND;
         }
      } else {
         $dp = XocpDataPage::unserialize($f);
         $dp->setPage($HTTP_GET_VARS["p"]);
         $found = $dp->getCount();
      }

      $xurl = XOCP_SERVER_SUBDIR."/index.php?X_project=2";
      $prevnext = $dp->getPageLinks($xurl);

      $htable = new XocpSimpleTable();
      $sno = $htable->addRow(_SYS_GROUP_USERLIST." : $found "._FOUND,$prevnext);
      $htable->setCellAlign($sno,array("","right"));
      $htable->setWidth("100%");

      $ftable = new XocpSimpleTable();
      $sno = $ftable->addRow($prevnext);
      $ftable->setCellAlign($sno,array("right"));
      $ftable->setWidth("100%");

      $table = new XocpTable(1);
      $table->setWidth("100%");
      $hno = $table->addHeader($htable->render());
      $fno = $table->addFooter($ftable->render());
      
      $no = $dp->getOffset() + 1;
      $data = $dp->retrieve();
      foreach($data as $x) {
         list($org_id,$org_nm,$sublist) = $x;
         $rno = $table->addRow("$no. <b><a href=$xurl&edit=y&x=$org_id".">$org_nm</a></b><br/>$sublist");
         $no++;
      }

      return $table->render();

   }
   
   function main() {
      
      switch($this->catch) {
         case "2" :
            global $HTTP_POST_VARS,$HTTP_GET_VARS;
            if($HTTP_GET_VARS["f"] != "") {
               $ret = $this->browse($HTTP_GET_VARS["f"]);
               break;
            } else if($HTTP_GET_VARS["edit"] == "y") {
               $form = project_editorglink($HTTP_GET_VARS["x"],2);
               $ret .= $form->render();
               break;
            } else if(!empty($HTTP_POST_VARS["addsub"])) {
               $db =& Database::getInstance();
               $sql = "INSERT INTO ".XOCP_PREFIX."prj_orglink (org_id,sub_id)"
                    . " VALUES ('".$HTTP_POST_VARS["uorg"]."','".$HTTP_POST_VARS["addsub_id"]."')";
               $db->query($sql);
               $form = project_editorglink($HTTP_POST_VARS["uorg"],2);
               $form->setComment($db->error());
               $ret .= $form->render();
               break;
            } else if(!empty($HTTP_POST_VARS["deletesub"])) {
               $org_id = $HTTP_POST_VARS["uorg"];
               $n = $HTTP_POST_VARS["n"];
               $db =& Database::getInstance();
               if($n>0) {
                  for($i=0;$i<$n;$i++) {
                     $sub_id = $HTTP_POST_VARS["sub$i"];
                     if($sub_id != '') {
                        $sql = "DELETE FROM ".XOCP_PREFIX."prj_orglink"
                             . " WHERE org_id = '$org_id' AND sub_id = '$sub_id'";
                        $db->query($sql);
                     }
                  }
               }
               $form = project_editorglink($org_id,2);
               $ret .= $form->render();
               break;
            }

         default : 
            $ret .= $this->browse();
      }
      
      return "<b>" . _SYS_GROUP_USERADMIN . "</b><br/><br/>" . $ret;
      
   }
   
}

} // PRJ_ORGLINK_DEFINED
?>