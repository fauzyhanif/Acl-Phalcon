<?php
//--------------------------------------------------------------------//
// Filename : modules/project/selectorg.php                           //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-03-18                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('PROJECT_INCLUDEPROJECT_DEFINED') ) {
   define('PROJECT_INCLUDEPROJECT_DEFINED', TRUE);

   function project_editProjectForm($prj_id = 0,$catch_id) {
      global $prj_ses_org_id,$prj_ses_prj_id,$xocp_page_id;
      $db =& Database::getInstance();


      $form = new XocpThemeForm(_PRJ_ADDFORM, "projectaddform", "index.php","post",TRUE);
      
      if($prj_id>0) {
         $sql = "SELECT a.prj_nm,a.description,a.priority_cd,b.org_nm,c.prj_nm,a.phase_set,a.base_cur FROM ".XOCP_PREFIX."prj_projects a"
              . " LEFT JOIN ".XOCP_PREFIX."orgs b ON b.org_id = a.par_org_id"
              . " LEFT JOIN ".XOCP_PREFIX."prj_projects c ON c.prj_id = a.par_prj_id AND c.org_id = a.par_org_id"
              . " WHERE a.org_id = '$prj_ses_org_id' AND a.prj_id = '$prj_id'";
         $result = $db->query($sql);
         list($prj_nm,$description,$priority_cd,$par_org_nm,$par_prj_nm,$phase_set,$base_cur) = $db->fetchRow($result);
         $hprj_id  = new XocpFormHidden("prj_id", $prj_id);
         $hedit  = new XocpFormHidden("edit", "y");
         $form->addElement($hedit);
      } else {
         $sql = "SELECT max(prj_id) FROM ".XOCP_PREFIX."prj_projects a"
              . " WHERE org_id = '$prj_ses_org_id'";
         $result = $db->query($sql);
         list($max_prj_id) = $db->fetchRow($result);
         $max_prj_id++;
         $sql = "INSERT INTO ".XOCP_PREFIX."prj_projects (org_id,prj_id,prj_nm,created,modified)"
              . " VALUES('$prj_ses_org_id','$max_prj_id','noname$max_prj_id',now(),now())";
         $db->query($sql);
         $hprj_id  = new XocpFormHidden("prj_id", $max_prj_id);
      }


      $prj_nm   = new XocpFormText(_PRJ_PROJECTNAME, "prj_nm", 40, 100, "$prj_nm");
      $description = new XocpFormTextArea(_PRJ_PROJECTDESCRIPTION, "description",$description);
      $priority_cd+=0;
      $priority   = new XocpFormRadio(_PRJ_PROJECTPRIORITY, "priority_cd",$priority_cd);
      $priority->addOption("0",_PRJ_HIGHPRIORITY);
      $priority->addOption("1",_PRJ_MEDIUMPRIORITY);
      $priority->addOption("2",_PRJ_LOWPRIORITY);
      
      if($par_prj_nm != "") {
         $parent_txt = "<b>$par_prj_nm</b><br/>$par_org_nm";
      } else {
         $parent_txt = "";
      }
      $parent   = new XocpFormLabel("", $parent_txt);
      $editparentbutton = new XocpFormButton("", "editparentproject", _EDIT, "submit");
      $elementtray_parent = new XocpFormElementTray(_PRJ_PARENTPROJECT);
      $elementtray_parent->addElement($parent);
      $elementtray_parent->addElement($editparentbutton);
      
      $sql = "SELECT phase_set,phase_nm FROM ".XOCP_PREFIX."prj_phase_code"
           . " ORDER BY phase_set";
      $result = $db->query($sql);
      if($db->getRowsNum($result)>0) {
         $selectphase   = new XocpFormSelect("", "phase_set",$phase_set);
         while(list($phase_setx,$phase_nmx)=$db->fetchRow($result)) {
            $selectphase->addOption($phase_setx,$phase_nmx);
         }
      } else {
         $selectphase = new XocpFormLabel("",_PRJ_NO_PHASE_DEFINED);
      }
//      $editphasebutton = new XocpFormButton("", "editphase", _EDIT, "submit");
      $elementtray_phase = new XocpFormElementTray(_PRJ_PROJECTPHASE);
      $elementtray_phase->addElement($selectphase);
//      $elementtray_phase->addElement($editphasebutton);


      $sql = "SELECT curency_cd,curency_nm FROM ".XOCP_PREFIX."sys_curency_code"
           . " ORDER BY curency_cd";
      $result = $db->query($sql);
      if($db->getRowsNum($result)>0) {
         $selectcurency   = new XocpFormSelect(_PRJ_BASECURENCY, "curency_cd",$base_cur);
         while(list($curency_cd,$curency_nm)=$db->fetchRow($result)) {
            $selectcurency->addOption($curency_cd,$curency_nm);
         }
      } else {
         $selectcurency = new XocpFormLabel(_PRJ_BASECURENCY,_PRJ_NO_CURENCY_DEFINED);
      }

      $submit_button = new XocpFormButton("", "saveproject", _SAVE, "submit");
      $reset_button = new XocpFormButton("", "resetproject", _RESET, "reset");

      $elementtray_buttons = new XocpFormElementTray("");
      $elementtray_buttons->addElement($submit_button);
      $elementtray_buttons->addElement($reset_button);

      $cancel_button = new XocpFormButton("", "cancelsaveproject", _CANCEL, "submit");
      $elementtray_buttons->addElement($cancel_button);

      if($prj_id>0) {
         $delete_button = new XocpFormButton("", "deleteproject", _DELETE, "submit");
         $elementtray_buttons->addElement($delete_button);
      }

      $hidden = new XocpFormHidden("X_project",$catch_id);

      $form->addElement($hprj_id);
      $form->addElement($prj_nm);
      $form->addElement($description);
      $form->addElement($priority);
      $form->addElement($elementtray_parent);
      $form->addElement($elementtray_phase);
      $form->addElement($selectcurency);
      $form->addElement($hidden);
      $form->addElement($elementtray_buttons);

      return $form->render();
      
   }
   
   function project_saveProject() {
      global $prj_ses_org_id,$HTTP_POST_VARS;
      $db =& Database::getInstance();
      $prj_id = $HTTP_POST_VARS["prj_id"];
      $prj_nm = $HTTP_POST_VARS["prj_nm"];
      if(trim($prj_nm) == "") $prj_nm = "noname$prj_id";
      $description = $HTTP_POST_VARS["description"];
      $priority_cd = $HTTP_POST_VARS["priority_cd"];
      $phase_set = $HTTP_POST_VARS["phase_set"];
      $base_cur = $HTTP_POST_VARS["curency_cd"];
      $sql = "UPDATE ".XOCP_PREFIX."prj_projects SET"
           . " prj_nm = '$prj_nm',"
           . " description = '$description',"
           . " priority_cd = '$priority_cd',"
           . " phase_set = '$phase_set',"
           . " base_cur = '$base_cur',"
           . " modified = now()"
           . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_id'";
      $db->query($sql);
      return $prj_id;
   }


} // PROJECT_INCLUDEPROJECT_DEFINED
?>