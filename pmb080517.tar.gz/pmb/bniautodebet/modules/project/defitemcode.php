<?php
//--------------------------------------------------------------------//
// Filename : modules/project/defitemcode.php                         //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2003-03-17                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('PRJ_DEFITEMCODE_DEFINED') ) {
   define('PRJ_DEFITEMCODE_DEFINED', TRUE);

include(XOCP_DOC_ROOT."/modules/project/forms.php");

class _project_DefItemCode extends XocpBlock {
   var $width = "100%";
   
   function browse($f = NULL) {
      global $HTTP_GET_VARS;
      
         $db = Database::getInstance();
         $sql = "SELECT item_t_cd,item_t_nm,description from ".XOCP_PREFIX."prj_item_code"
              . " ORDER BY item_t_cd";
         $result = $db->query($sql);
         $found = $db->getRowsNum($result);
         if($found > 0) {
            $dp = new XocpDataPage();
            $dp->setPageSize(0);
            while($row=$db->fetchRow($result)) {
               $dp->addData($row);
            }
            $dp->reset();
         }

      $xurl = XOCP_SERVER_SUBDIR."/index.php?X_project=4";

      $addbuttonform = project_itemcodeaddbuttonform();
      $addbutton = $addbuttonform->render();
      $htable = new XocpSimpleTable();
      $sno = $htable->addRow(_SYS_GROUP_GROUPLIST." : $found "._FOUND,$addbutton);
      $htable->setCellAlign($sno,array("","right"));
      $htable->setWidth("100%");

      $ftable = new XocpSimpleTable();
      $sno = $ftable->addRow($addbutton);
      $ftable->setCellAlign($sno,array("right"));
      $ftable->setWidth("100%");

      $table = new XocpTable(1);
      $table->setWidth("100%");
      $hno = $table->addHeader($htable->render());
      $fno = $table->addFooter($ftable->render());
      
      
      if($found > 0) {
         $no = 1;
         $data = $dp->retrieve();
         foreach($data as $x) {
            list($item_t_cd,$item_t_nm,$desc) = $x;
            $rno = $table->addRow("$item_t_cd. <b><a href=$xurl&edit=y&x=$item_t_cd".">$item_t_nm</a></b><br/>$desc");
            $no++;
         }
      }

      return $table->render();

   }
   
   function main() {
      global $ses_ind_org;
      switch($this->catch) {
         case "4" :
            global $HTTP_POST_VARS,$HTTP_GET_VARS;
            if($HTTP_POST_VARS["addnewitemcodebutton"] != "") {
               $form = project_additemcodeform(4);
               $ret .= $form->render();
               break;
            } else if($HTTP_GET_VARS["edit"] == "y") {
               $form = project_edititemcodeform($HTTP_GET_VARS["x"],4);
               $ret .= $form->render();
               break;
            } else if(!empty($HTTP_POST_VARS["newitemcode"])) {
               $db =& Database::getInstance();
               $item_t_nm = trim($HTTP_POST_VARS["item_t_nm"]);
               $item_t_cd = trim($HTTP_POST_VARS["item_t_cd"]);
               $description = trim($HTTP_POST_VARS["description"]);
               $sql = "INSERT INTO ".XOCP_PREFIX."prj_item_code(item_t_cd,item_t_nm,description)"
                    . " VALUES ('$item_t_cd','$item_t_nm','$description')";
               $db->query($sql);
               $ret .= $this->browse();
               break;
            } else if(!empty($HTTP_POST_VARS["updateitemcode"])) {
               $db =& Database::getInstance();
               $item_t_cd = trim($HTTP_POST_VARS["item_t_cd"]);
               $item_t_nm = trim($HTTP_POST_VARS["item_t_nm"]);
               $description = trim($HTTP_POST_VARS["description"]);
               $sql = "UPDATE ".XOCP_PREFIX."prj_item_code SET description = '$description',"
                    . "item_t_nm = '$item_t_nm'"
                    . " WHERE item_t_cd = '$item_t_cd'";
               $db->query($sql);
               $ret .= $this->browse();
               break;
            } else if (!empty($HTTP_POST_VARS["deleteitemcode"])) {
               $db =& Database::getInstance();
               $item_t_cd = trim($HTTP_POST_VARS["item_t_cd"]);
               $sql = "DELETE FROM ".XOCP_PREFIX."prj_item_code WHERE item_t_cd = '$item_t_cd'";
               $db->query($sql);
               $ret .= $this->browse();
               break;
            }

         default : 
            $ret .= $this->browse();
      }
      
      return "<b>" . _SYS_GROUP_PGROUPADMIN . "</b><br/><br/>" . $ret;
      
   }
   
}

} // PRJ_DEFITEMCODE_DEFINED
?>