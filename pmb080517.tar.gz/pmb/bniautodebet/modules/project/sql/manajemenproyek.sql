#DROP DATABASE IF EXISTS prj;
#CREATE DATABASE prj;
USE dhs;

/*

kaidah:
- proyek di organisasi
- proyek bisa memiliki sub proyek di organisasi sendiri
  maupun di organisasi lain.
- proyek memiliki item, berupa kegiatan-kegiatan.
- item bisa memiliki sub item dalam 1 proyek saja.
- item selalu dikaitkan (ditandai) dengan tipe item,
  yaitu sejenis dengan kode transaksi di bank. fungsinya
  untuk pengelompokan dan summary.
- tipe item didefinisikan di tiap proyek utama
  atau di-sub-nya.
- proyek dan item, masing-masing memiliki phase.
- phase didefinisikan di tiap proyek utama
  atau di-sub-nya.
- tiap proyek utama atau sub-proyek akan mendefinisikan
  resources seperlunya.
- resources ada 2 macam: work dan material.
- tiap proyek utama (sub-proyek juga boleh) memiliki
  base curency, yaitu mata uang yang disepakati untuk
  menilai harga nominal suatu resources.
- resources akan dipakai oleh item.
- pemakaian resources oleh item akan dicatat ditable
  prj_reslink. catatan ini akan menyertakan cur_rate,
  atau nilai tukar mata uang terhadap base curency
  (akan dikalikan untuk mendapatkan harga dalam base curency).

*/


#######################################################
# MANAJEMEN PROYEK

DROP TABLE IF EXISTS xocp_prj_projects;
CREATE TABLE xocp_prj_projects (
  org_id int(10) unsigned NOT NULL default '0',       # org_id dimana proyek didaftar
  prj_id int(10) unsigned NOT NULL default '0',       # project id

  prj_nm char(250) NOT NULL default '',
  description text NOT NULL,
  priority_cd tinyint(3) unsigned NOT NULL default '0',

  par_prj_id int(10) unsigned NOT NULL default '0',   # parent project
  par_org_id int(10) unsigned NOT NULL default '0',   # org of the parent project

  created datetime NOT NULL default '0000-00-00 00:00:00',
  modified datetime NOT NULL default '0000-00-00 00:00:00',
  phase_set int(10) unsigned NOT NULL default '0',    # current project phase
  base_cur char(3) NOT NULL default '0',              # base curency
  PRIMARY KEY (org_id,prj_id)
);

DROP TABLE IF EXISTS xocp_prj_item;
CREATE TABLE xocp_prj_item (
  org_id int(10) unsigned NOT NULL default '0',       # org_id dimana proyek didaftar
  prj_id int(10) unsigned NOT NULL default '0',       # project_id of the item belong to
  item_id int(10) unsigned NOT NULL default '0',      # tiap project_id punya item_id counter

  item_nm char(250) default NULL,
  item_t_cd char(10) NOT NULL default '',             # item type code
  description text NOT NULL,

  priority_cd tinyint(3) unsigned NOT NULL default '0',

  start_dt date NOT NULL default '0000-00-00',        # waktu tugas dimulai
  stop_dt date NOT NULL default '0000-00-00',         # batas waktu pelaksanaan
  complete_dt date NOT NULL default '0000-00-00 00:00:00',   # waktu tugas selesai
  comments text NOT NULL,
  completion tinyint(3) unsigned NOT NULL default '0',   # berapa persen tugas sudah dikerjakan..

  created datetime NOT NULL default '0000-00-00 00:00:00',  # record ini dibikin
  modified datetime NOT NULL default '0000-00-00 00:00:00', # waktu record di modifikasi
  prj_phase int(10) unsigned NOT NULL default '0',          # tugas dibuat pada fase proyek yg mana
  phase_set int(10) unsigned NOT NULL default '0',          # current item phase
  PRIMARY KEY  (org_id,prj_id,item_id)
) TYPE=MyISAM;


DROP TABLE IF EXISTS xocp_prj_res;
CREATE TABLE xocp_prj_res (
  org_id int(10) unsigned NOT NULL default '0',
  prj_id int(10) unsigned NOT NULL default '0',
  resources_id int(10) unsigned NOT NULL default '0',
  resources_nm char(250) NOT NULL default '',
  description text NOT NULL,
  curency char(20) NOT NULL default '',
  amount decimal(17,2) NOT NULL default '0.00',
  PRIMARY KEY (org_id,prj_id,resources_id)
);

DROP TABLE IF EXISTS xocp_prj_reslink;
CREATE TABLE xocp_prj_reslink (
  org_id int(10) unsigned NOT NULL default '0',
  prj_id int(10) unsigned NOT NULL default '0',
  item_id int(10) unsigned NOT NULL default '0',
  id int(10) unsigned NOT NULL default '0',

  res_org_id int(10) unsigned NOT NULL default '0',
  res_prj_id int(10) unsigned NOT NULL default '0',
  resources_id int(10) unsigned NOT NULL default '0',

  resources_type tinyint(3) NOT NULL default '0',
  description text NOT NULL,
  amount decimal(17,2) NOT NULL default '0.00',
  PRIMARY KEY (org_id,prj_id,item_id,id)
);


DROP TABLE IF EXISTS xocp_prj_item_code;
CREATE TABLE xocp_prj_item_code (
  item_t_cd char(10) NOT NULL default '',
  item_t_nm char(200) NOT NULL default '',
  description text NOT NULL,
  PRIMARY KEY (item_t_cd)
);

DROP TABLE IF EXISTS xocp_prj_phase_code;
CREATE TABLE xocp_prj_phase_code (
  phase_set int(10) NOT NULL auto_increment,
  phase_nm char(200) NOT NULL default '',
  description text NOT NULL,
  PRIMARY KEY (phase_set)
);

DROP TABLE IF EXISTS xocp_prj_priority_code;
CREATE TABLE xocp_prj_priority_code (
  priority_cd tinyint(3) NOT NULL auto_increment,
  priority_nm char(200) NOT NULL default '',
  PRIMARY KEY (priority_cd)
);

DROP TABLE IF EXISTS xocp_prj_curency_code;
CREATE TABLE xocp_prj_curency_code (
  curency_cd char(5) NOT NULL default '',
  curency_nm char(30) NOT NULL default '',
  PRIMARY KEY (curency_cd)
);

DROP TABLE IF EXISTS xocp_prj_pgroup_org;
CREATE TABLE xocp_prj_pgroup_org (
  pgroup_id int(10) unsigned NOT NULL default '0',
  org_id int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (pgroup_id,org_id)
) TYPE=MyISAM;

DROP TABLE IF EXISTS xocp_prj_orglink;
CREATE TABLE xocp_prj_orglink (
  org_id int(10) unsigned NOT NULL default '0',
  sub_id int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (org_id,sub_id)
) TYPE=MyISAM;

DROP TABLE IF EXISTS xocp_prj_sublink;
CREATE TABLE xocp_prj_sublink (
  org_id int(10) unsigned NOT NULL default '0',
  prj_id int(10) unsigned NOT NULL default '0',
  sub_id int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (org_id,prj_id,sub_id)
) TYPE=MyISAM;

DROP TABLE IF EXISTS xocp_prj_phase;
CREATE TABLE xocp_prj_phase (
  org_id int(10) unsigned NOT NULL default '0',
  prj_id int(10) unsigned NOT NULL default '0',
  id int(10) unsigned NOT NULL default '0',
  start_dt date NOT NULL default '0000-00-00',        # waktu phase mulai berlaku
  stop_dt date NOT NULL default '0000-00-00',         # waktu phase selesai
  description text NOT NULL,
  phase_set int(10) unsigned NOT NULL default '0',    # phase
  PRIMARY KEY  (org_id,prj_id,id)
) TYPE=MyISAM;

