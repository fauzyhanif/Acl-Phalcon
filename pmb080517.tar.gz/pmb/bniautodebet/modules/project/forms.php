<?php

if ( !defined('PROJECT_FORMS_DEFINED') ) {
   define('PROJECT_FORMS_DEFINED', TRUE);




function project_itemcodeaddbuttonform() {
   $add_button = new XocpFormButton("","addnewitemcodebutton",_ADD,"submit");
   $hidden = new XocpFormHidden("X_project",4);
   
   $form = new XocpSimpleForm("","addnewitemcodeform","index.php");
   $form->addElement($add_button);
   $form->addElement($hidden);
   return $form;
}

function project_edititemcodeform($item_t_cd,$catch_id) {
   $db =& Database::getInstance();
   $sql = "SELECT item_t_nm,description from ".XOCP_PREFIX."prj_item_code"
        . " WHERE item_t_cd = '$item_t_cd'";
   $result = $db->query($sql);
   list($item_t_nm,$description) = $db->fetchRow($result);
   
   $itemcode = new XocpFormLabel(_SYS_GROUP_GROUPNAME, "$item_t_cd");
   $itemcodename = new XocpFormText(_SYS_GROUP_GROUPNAME, "item_t_nm", 40, 100, "$item_t_nm");
   $description = new XocpFormTextArea(_SYS_GROUP_DESCRIPTION, "description",$description);
   $hidden = new XocpFormHidden("X_project",$catch_id);
   $hitem_t_cd = new XocpFormHidden("item_t_cd","$item_t_cd");
   
   $submit_button = new XocpFormButton("", "updateitemcode", _SUBMIT, "submit");
   $cancel_button = new XocpFormButton("", "cancel", _CANCEL, "submit");
   $reset_button = new XocpFormButton("", "reset", _RESET, "reset");
   $delete_button = new XocpFormButton("", "deleteitemcode", _DELETE, "submit");
   $elementtray_buttons = new XocpFormElementTray("");
   $elementtray_buttons->addElement($submit_button);
   $elementtray_buttons->addElement($cancel_button);
   $elementtray_buttons->addElement($reset_button);
   $elementtray_buttons->addElement($delete_button);
   
   $form = new XocpThemeForm(_SYS_GROUP_EDITFORM, "updateitemcodeform", "index.php","post",TRUE);
            
   $form->addElement($itemcode);
   $form->addElement($itemcodename);
   $form->addElement($description);
   $form->addElement($hidden);
   $form->addElement($hitem_t_cd);
   $form->addElement($elementtray_buttons);

   return $form;
}

function project_additemcodeform($catch_id) {

   $itemcode   = new XocpFormText(_SYS_GROUP_GROUPNAME, "item_t_cd", 40, 100, "");
   $itemcodename   = new XocpFormText(_SYS_GROUP_GROUPNAME, "item_t_nm", 40, 100, "");
   $description = new XocpFormTextArea(_SYS_GROUP_DESCRIPTION, "description");
   $submit_button = new XocpFormButton("", "newitemcode", _SUBMIT, "submit");
   $elementtray_buttons = new XocpFormElementTray("");
   $elementtray_buttons->addElement($submit_button);

   $hidden = new XocpFormHidden("X_project",$catch_id);
               
   $form = new XocpThemeForm(_SYS_GROUP_ADDFORM, "itemcodeaddform", "index.php","post",TRUE);
            
   $form->addElement($itemcode);
   $form->addElement($itemcodename);
   $form->addElement($description);
   $form->addElement($hidden);
   $form->addElement($elementtray_buttons);

   return $form;
}










function project_phaseaddbuttonform() {
   $add_button = new XocpFormButton("","addnewphasebutton",_ADD,"submit");
   $hidden = new XocpFormHidden("X_project",3);
   
   $form = new XocpSimpleForm("","addnewphaseform","index.php");
   $form->addElement($add_button);
   $form->addElement($hidden);
   return $form;
}

function project_editphaseform($phase_set,$catch_id) {
   $db =& Database::getInstance();
   $sql = "SELECT phase_nm,description from ".XOCP_PREFIX."prj_phase_code"
        . " WHERE phase_set = '$phase_set'";
   $result = $db->query($sql);
   list($phase_nm,$description) = $db->fetchRow($result);
   
   $phasename = new XocpFormLabel(_SYS_GROUP_GROUPNAME, "$phase_nm");
   $description = new XocpFormTextArea(_SYS_GROUP_DESCRIPTION, "description",$description);
   $hidden = new XocpFormHidden("X_project",$catch_id);
   $hphase_set = new XocpFormHidden("phase_set","$phase_set");
   
   $submit_button = new XocpFormButton("", "updatephase", _SUBMIT, "submit");
   $cancel_button = new XocpFormButton("", "cancel", _CANCEL, "submit");
   $reset_button = new XocpFormButton("", "reset", _RESET, "reset");
   $delete_button = new XocpFormButton("", "deletephase", _DELETE, "submit");
   $elementtray_buttons = new XocpFormElementTray("");
   $elementtray_buttons->addElement($submit_button);
   $elementtray_buttons->addElement($cancel_button);
   $elementtray_buttons->addElement($reset_button);
   $elementtray_buttons->addElement($delete_button);
   
   $form = new XocpThemeForm(_SYS_GROUP_EDITFORM, "updatephaseform", "index.php","post",TRUE);
            
   $form->addElement($phasename);
   $form->addElement($description);
   $form->addElement($hidden);
   $form->addElement($hphase_set);
   $form->addElement($elementtray_buttons);

   return $form;
}

function project_addphaseform($catch_id) {

   $phasename   = new XocpFormText(_SYS_GROUP_GROUPNAME, "phase_nm", 40, 100, "");
   $description = new XocpFormTextArea(_SYS_GROUP_DESCRIPTION, "description");
   $submit_button = new XocpFormButton("", "newphase", _SUBMIT, "submit");
   $elementtray_buttons = new XocpFormElementTray("");
   $elementtray_buttons->addElement($submit_button);

   $hidden = new XocpFormHidden("X_project",$catch_id);
               
   $form = new XocpThemeForm(_SYS_GROUP_ADDFORM, "phaseaddform", "index.php","post",TRUE);
            
   $form->addElement($phasename);
   $form->addElement($description);
   $form->addElement($hidden);
   $form->addElement($elementtray_buttons);

   return $form;
}


function project_editpgroup($pgroup_id,$catch_id) {
   $db =& Database::getInstance();
   $sql = "SELECT a.pgroup_cd,c.org_id,c.org_nm from ".XOCP_PREFIX."pgroups a"
        . " LEFT JOIN ".XOCP_PREFIX."prj_pgroup_org b USING (pgroup_id)"
        . " LEFT JOIN ".XOCP_PREFIX."orgs c USING (org_id)"
        . " WHERE a.pgroup_id = '$pgroup_id'"
        . " ORDER BY c.org_nm";
   $result = $db->query($sql);
   $c = $db->getRowsNum($result);
   $pgroup_cd = "";
   if($c > 0) {
      while(list($pgroup_cdx,$org_id,$org_nm) = $db->fetchRow($result)) {
         $orgarray[$org_id] = $org_nm;
         $pgroup_cd = $pgroup_cdx;
      }
   }
   
   $pgroupname = new XocpFormLabel(_SYS_USERADMIN_USERNAME, "$pgroup_cd");
   $elementtray_orgs = new XocpFormElementTray(_SYS_GROUP_ASSIGNEDGROUPLIST,"<br/>");
   if(is_array($orgarray)) {
      reset($orgarray);
      $n = 0;
      foreach($orgarray as $org_id=>$org_nm) {
         if(empty($org_nm)) continue;
         $ckbname = "org$n";
         $xckb = new XocpFormCheckBox("",$ckbname);
         $xckb->addOption($org_id,$org_nm);
         $elementtray_orgs->addElement($xckb);
         $n++;
      }
      if($n>0) {
         $delete_org = new XocpFormButton("", "deleteorg", _DELETE, "submit");
         $elementtray_orgs->addElement($delete_org);
      } else {
         $noorg = new XocpFormLabel("",_SYS_GROUP_USERNOTASSIGNED);
         $elementtray_orgs->addElement($noorg);
      }
   }


   $hidden = new XocpFormHidden("X_project",$catch_id);
   $hidden_n = new XocpFormHidden("n",$n);
   $hpgroup_id = new XocpFormHidden("upgroup","$pgroup_id");
   
   $add_button = new XocpFormButton("", "addorg", _ADD, "submit");
   $selectorg = new XocpFormSelect("","addorg_id");
   $sql = "SELECT org_id,org_nm,description FROM ".XOCP_PREFIX."orgs"
        . " ORDER BY org_nm";
   $result = $db->query($sql);
   if($db->getRowsNum($result)>0) {
      while(list($org_id,$org_nm,$description)=$db->fetchRow($result)) {
         $selectorg->addOption($org_id,$org_nm);
      }
   }
   
   $elementtray_buttons = new XocpFormElementTray(_SYS_GROUP_USERADDGROUP,"<br/>");
   $elementtray_buttons->addElement($selectorg);
   $elementtray_buttons->addElement($add_button);

   $cancel_button = new XocpFormButton("", "cancel", _CANCEL, "submit");
   
   $form = new XocpThemeForm(_SYS_GROUP_EDITUSER, "updatepgroup2orgform", "index.php","post");
   $form->setWidth("100%");
            
   $form->addElement($pgroupname);
   $form->addElement($elementtray_orgs);
   $form->addElement($hidden);
   $form->addElement($hidden_n);
   $form->addElement($hpgroup_id);
   $form->addElement($elementtray_buttons);
   $form->addElement($cancel_button);

   return $form;
}


function project_editorglink($org_id,$catch_id) {
   $db =& Database::getInstance();
   $sql = "SELECT a.org_nm,c.org_id,c.org_nm from ".XOCP_PREFIX."orgs a"
        . " LEFT JOIN ".XOCP_PREFIX."prj_orglink b USING (org_id)"
        . " LEFT JOIN ".XOCP_PREFIX."orgs c ON c.org_id=b.sub_id"
        . " WHERE a.org_id = '$org_id'"
        . " ORDER BY c.org_nm";
   $result = $db->query($sql);
   $c = $db->getRowsNum($result);
   $org_nm = "";
   if($c > 0) {
      while(list($org_nmx,$sub_id,$sub_nm) = $db->fetchRow($result)) {
         $subarray[$sub_id] = $sub_nm;
         $org_nm = $org_nmx;
      }
   }
   
   $orgname = new XocpFormLabel(_SYS_USERADMIN_USERNAME, "$org_nm");
   $elementtray_subs = new XocpFormElementTray(_SYS_GROUP_ASSIGNEDGROUPLIST,"<br/>");
   if(is_array($subarray)) {
      reset($subarray);
      $n = 0;
      foreach($subarray as $sub_id=>$sub_nm) {
         if(empty($sub_nm)) continue;
         $ckbname = "sub$n";
         $xckb = new XocpFormCheckBox("",$ckbname);
         $xckb->addOption($sub_id,$sub_nm);
         $elementtray_subs->addElement($xckb);
         $n++;
      }
      if($n>0) {
         $delete_sub = new XocpFormButton("", "deletesub", _DELETE, "submit");
         $elementtray_subs->addElement($delete_sub);
      } else {
         $nosub = new XocpFormLabel("",_SYS_GROUP_USERNOTASSIGNED);
         $elementtray_subs->addElement($nosub);
      }
   }


   $hidden = new XocpFormHidden("X_project",$catch_id);
   $hidden_n = new XocpFormHidden("n",$n);
   $horg_id = new XocpFormHidden("uorg","$org_id");
   
   $add_button = new XocpFormButton("", "addsub", _ADD, "submit");
   $selectsub = new XocpFormSelect("","addsub_id");
   $sql = "SELECT org_id,org_nm,description FROM ".XOCP_PREFIX."orgs"
        . " ORDER BY org_nm";
   $result = $db->query($sql);
   if($db->getRowsNum($result)>0) {
      while(list($org_id,$org_nm,$description)=$db->fetchRow($result)) {
         $selectsub->addOption($org_id,$org_nm);
      }
   }
   
   $elementtray_buttons = new XocpFormElementTray(_SYS_GROUP_USERADDGROUP,"<br/>");
   $elementtray_buttons->addElement($selectsub);
   $elementtray_buttons->addElement($add_button);

   $cancel_button = new XocpFormButton("", "cancel", _CANCEL, "submit");
   
   $form = new XocpThemeForm(_SYS_GROUP_EDITUSER, "updateorglinkform", "index.php","post");
   $form->setWidth("100%");
            
   $form->addElement($orgname);
   $form->addElement($elementtray_subs);
   $form->addElement($hidden);
   $form->addElement($hidden_n);
   $form->addElement($horg_id);
   $form->addElement($elementtray_buttons);
   $form->addElement($cancel_button);

   return $form;
}



} // PROJECT_FORMS_DEFINED
?>