<?php
//--------------------------------------------------------------------//
// Filename : modules/project/item.php                                //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-03-19                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('PROJECT_PROJECTITEM_DEFINED') ) {
   define('PROJECT_PROJECTITEM_DEFINED', TRUE);

include_once(XOCP_DOC_ROOT."/modules/project/class/orgtree.php");

/*
class _project_SelectResources {
   var $item_id;
   var $res_org_id;
   var $res_prj_id;
   var $resources_id;
}
*/

class _project_ProjectItem extends XocpBlock {
   var $width = "100%";
   
   
   function formSelectItem() {
      global $xocp_user,$xocp_page_id,$prj_ses_org_id,$prj_ses_prj_id;

      if($prj_ses_prj_id>0 && $prj_ses_org_id>0) {
      
         $db =& Database::getInstance();
         $sql = "SELECT item_id,item_nm,description FROM ".XOCP_PREFIX."prj_item"
              . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id'"
              . " ORDER BY item_id";
         $result = $db->query($sql);
      
         $add_button = new XocpFormButton("","addnewitembutton",_ADD,"submit");
         $hidden = new XocpFormHidden("X_project",9);
         $form = new XocpSimpleForm("","addnewitemformx","index.php","get");
         $form->addElement($add_button);
         $form->addElement($hidden);
         
         $dp_header = new XocpSimpleTable();
         $hrow = $dp_header->addRow("<font class='tdh1'>"._PRJ_SELECTITEM."</font>",$form->render());
         $dp_header->setCellAlign($hrow,"left","right");
         $dp_header->setWidth("100%");
         $dp_table = new XocpTable(1);
         $dp_table->setWidth("100%");
         $hrow = $dp_table->addHeader($dp_header->render());
         $dp_table->setColSpan($hrow,2); 
         while (list($item_id,$item_nm,$item_desc) = $db->fetchRow($result)) {
            $drow = $dp_table->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?X_project=9&edititem=y&x=$item_id'>$item_nm</a>",$item_desc);
         }
         return $dp_table->render();
      }
   }
   
   function editItemForm($item_id = 0,$catch_id) {
      global $prj_ses_org_id,$prj_ses_prj_id,$xocp_page_id;
      $db =& Database::getInstance();


      $form = new XocpThemeForm(_PRJ_EDITITEMFORM, "itemeditform", "index.php","post",TRUE);
      
      if($item_id>0) {

         $sql = "SELECT item_nm,item_t_cd,description,priority_cd,start_dt,stop_dt,complete_dt,"
              . "comments,completion,prj_phase,phase_set FROM ".XOCP_PREFIX."prj_item"
              . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id' AND item_id = '$item_id'";

         $result = $db->query($sql);
         list($item_nm,$item_t_cd,$description,$priority_cd,$start_dt,$stop_dt,$complete_dt,
              $comments,$completion,$prj_phase,$phase_set) = $db->fetchRow($result);
         $hitem_id  = new XocpFormHidden("item_id", $item_id);
         $hedit  = new XocpFormHidden("edit", "y");
         $form->addElement($hedit);

         $start_dt_obj = new XocpDateTime($start_dt);
         $stop_dt_obj = new XocpDateTime($stop_dt);
         $complete_dt_obj = new XocpDateTime($complete_dt);

      } else {
         $sql = "SELECT max(item_id) FROM ".XOCP_PREFIX."prj_item a"
              . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id'";
         $result = $db->query($sql);
         list($max_item_id) = $db->fetchRow($result);
         $max_item_id++;
         $sql = "INSERT INTO ".XOCP_PREFIX."prj_item (org_id,prj_id,item_id,item_nm,created,modified)"
              . " VALUES('$prj_ses_org_id','$prj_ses_prj_id','$max_item_id','item$max_item_id',now(),now())";
         $db->query($sql);
         $hitem_id  = new XocpFormHidden("item_id", $max_item_id);

         $start_dt_obj = new XocpDateTime();
         $stop_dt_obj = new XocpDateTime();
         $complete_dt_obj = new XocpDateTime();
      }


      $item_name   = new XocpFormText(_PRJ_ITEMNAME, "item_nm", 40, 100, "$item_nm");
      $item_completion   = new XocpFormText(_PRJ_ITEMCOMPLETION, "completion", 5, 100, "$completion");
      $item_desc = new XocpFormTextArea(_PRJ_ITEMDESCRIPTION, "description",$description);
      $item_comments = new XocpFormTextArea(_PRJ_ITEMCOMMENT, "comments",$comments);
      $priority_cd+=0;
      $item_priority   = new XocpFormRadio(_PRJ_ITEMPRIORITY, "priority_cd",$priority_cd);
      $item_priority->addOption("0",_PRJ_HIGHPRIORITY);
      $item_priority->addOption("1",_PRJ_MEDIUMPRIORITY);
      $item_priority->addOption("2",_PRJ_LOWPRIORITY);
      
      $item_start_dt = new XocpFormDateTime(_PRJ_ITEMSTART_DT,"ISTART",$start_dt_obj);
      $item_stop_dt = new XocpFormDateTime(_PRJ_ITEMSTOP_DT,"ISTOP",$stop_dt_obj);
      $item_complete_dt = new XocpFormDateTime(_PRJ_ITEMCOMPLETE_DT,"ICOMPLETE",$complete_dt_obj);
      
      
      $sql = "SELECT phase_set,phase_nm FROM ".XOCP_PREFIX."prj_phase_code"
           . " ORDER BY phase_set";
      $result = $db->query($sql);
      if($db->getRowsNum($result)>0) {
         $selectitemphase    = new XocpFormSelect("", "phase_set",$phase_set);
         $selectprojectphase = new XocpFormSelect("", "prj_phase",$prj_phase);
         while(list($phase_setx,$phase_nmx)=$db->fetchRow($result)) {
            $selectitemphase->addOption($phase_setx,$phase_nmx);
            $selectprojectphase->addOption($phase_setx,$phase_nmx);
         }
      } else {
         $selectitemphase = new XocpFormLabel("",_PRJ_NO_PHASE_DEFINED);
         $selectprojectphase = new XocpFormLabel("",_PRJ_NO_PHASE_DEFINED);
      }
      $item_elementtray_phase = new XocpFormElementTray(_PRJ_ITEMPHASE);
      $item_elementtray_phase->addElement($selectitemphase);
      $project_elementtray_phase = new XocpFormElementTray(_PRJ_PRJPHASE);
      $project_elementtray_phase->addElement($selectprojectphase);

      $sql = "SELECT a.id,b.org_nm,c.prj_nm,d.resources_nm,d.curency,a.resources_type,a.description,a.amount FROM ".XOCP_PREFIX."prj_reslink a"
           . " LEFT JOIN ".XOCP_PREFIX."orgs b on b.org_id = a.org_id"
           . " LEFT JOIN ".XOCP_PREFIX."prj_projects c on c.org_id = a.org_id AND c.prj_id = a.prj_id"
           . " LEFT JOIN ".XOCP_PREFIX."prj_res d on d.org_id = a.res_org_id AND d.prj_id = a.res_prj_id AND d.resources_id = a.resources_id"
           . " WHERE a.org_id = '$prj_ses_org_id' AND a.prj_id = '$prj_ses_prj_id' AND a.item_id = '$item_id'"
           . " ORDER BY a.id";
      $result = $db->query($sql);
      $rtype[0] = _PRJ_WORK;
      $rtype[1] = _PRJ_MATERIAL;
      $reslist = _PRJ_NO_RESOURCES_LINKED;
      if($db->getRowsNum($result)>0) {
         $dp_res = new XocpTable(1);
         $dp_res->addHeader(_PRJ_RES_RES,_PRJ_RES_DESC,_PRJ_RES_AMNT,_PRJ_RES_TYPE);
         while(list($id,$org_nm,$prj_nm,$res_nm,$curency,$resources_type,$description,$amount)=$db->fetchRow($result)) {
            $drow = $dp_res->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?X_project=9&editreslink=y&x=$item_id&y=$id'>$res_nm</a>",$description,$amount,$rtype[$resources_type]);
            $dp_res->setCellAlign($drow,"left","left","right");
         }
         $reslist = $dp_res->render();
      }
      $resources_list = new XocpFormLabel("",$reslist);
      $resources_edit_button = new XocpFormButton("","editresourceslist",_ADD,"submit");

      $item_elementtray_resources = new XocpFormElementTray(_PRJ_ITEMRESOURCES);
      $item_elementtray_resources->addElement($resources_list);
      $item_elementtray_resources->addElement($resources_edit_button);


      $sql = "SELECT item_t_cd,item_t_nm FROM ".XOCP_PREFIX."prj_item_code"
           . " ORDER BY item_t_cd";
      $result = $db->query($sql);
      if($db->getRowsNum($result)>0) {
         $item_selectcode   = new XocpFormSelect(_PRJ_ITEMCODE, "item_t_cd",$item_t_cd);
         while(list($item_t_cdx,$item_t_nmx)=$db->fetchRow($result)) {
            $item_selectcode->addOption($item_t_cdx,$item_t_nmx);
         }
      } else {
         $item_selectcode = new XocpFormLabel(_PRJ_ITEMCODE,_PRJ_NO_ITEMCODE_DEFINED);
      }

      $submit_button = new XocpFormButton("", "saveitem", _SAVE, "submit");
      $reset_button = new XocpFormButton("", "resetitem", _RESET, "reset");

      $elementtray_buttons = new XocpFormElementTray("");
      $elementtray_buttons->addElement($submit_button);
      $elementtray_buttons->addElement($reset_button);

      $cancel_button = new XocpFormButton("", "cancelsaveitem", _CANCEL, "submit");
      $elementtray_buttons->addElement($cancel_button);

      if($item_id>0) {
         $delete_button = new XocpFormButton("", "deleteitem", _DELETE, "submit");
         $elementtray_buttons->addElement($delete_button);
      } else {
      }

      $hidden = new XocpFormHidden("X_project",$catch_id);

      $form->addElement($hitem_id);
      $form->addElement($item_name);
      $form->addElement($item_priority);
      $form->addElement($item_completion);
      $form->addElement($item_desc);
      $form->addElement($item_comments);
      $form->addElement($item_start_dt);
      $form->addElement($item_stop_dt);
      $form->addElement($item_complete_dt);
      $form->addElement($item_elementtray_resources);
      $form->addElement($item_elementtray_phase);
      $form->addElement($project_elementtray_phase);
      $form->addElement($item_selectcode);
      $form->addElement($elementtray_buttons);
      $form->addElement($hidden);

      return $form->render();
      
   }
   
   function saveItem() {
      global $prj_ses_org_id,$HTTP_POST_VARS,$prj_ses_prj_id;
      $db =& Database::getInstance();
      $item_id = $HTTP_POST_VARS["item_id"];
      $item_nm = $HTTP_POST_VARS["item_nm"];
      if(trim($item_nm) == "") $item_nm = "item$item_id";
      $description = $HTTP_POST_VARS["description"];
      $item_t_cd = $HTTP_POST_VARS["item_t_cd"];
      $priority_cd = $HTTP_POST_VARS["priority_cd"];

      $start_dt_obj = new XocpDateTime();
      $stop_dt_obj = new XocpDateTime();
      $complete_dt_obj = new XocpDateTime();

      $start_dt_obj->eatVars("ISTART");
      $stop_dt_obj->eatVars("ISTOP");
      $complete_dt_obj->eatVars("ICOMPLETE");

      $comments = $HTTP_POST_VARS["comments"];
      $completion = $HTTP_POST_VARS["completion"];
      $prj_phase = $HTTP_POST_VARS["prj_phase"];
      $phase_set = $HTTP_POST_VARS["phase_set"];
      $sql = "UPDATE ".XOCP_PREFIX."prj_item SET"
           . " item_nm = '$item_nm',"
           . " description = '$description',"
           . " item_t_cd = '$item_t_cd',"
           . " priority_cd = '$priority_cd',"
           . " start_dt = '".$start_dt_obj->getMySQL()."',"
           . " stop_dt = '".$stop_dt_obj->getMySQL()."',"
           . " complete_dt = '".$complete_dt_obj->getMySQL()."',"
           . " comments = '$comments',"
           . " completion = '$completion',"
           . " prj_phase = '$prj_phase',"
           . " phase_set = '$phase_set',"
           . " modified = now()"
           . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id' AND item_id = '$item_id'";
      $db->query($sql);
      return $item_id;
   }


/////////////////////// RESOURCES LINK ////////////////////////////


   function editSelectResourcesOrg($item_id,$catch_id) {
      global $xocp_user,$xocp_page_id,$prj_ses_org_id;

      $pgroup_id = $xocp_user->getVar("pgroup_id");
      $db =& Database::getInstance();
      $sql = "SELECT a.org_id,b.org_nm,c.org_id FROM ".XOCP_PREFIX."prj_orglink a"
           . " LEFT JOIN ".XOCP_PREFIX."orgs b ON b.org_id=a.org_id"
           . " LEFT JOIN ".XOCP_PREFIX."prj_orglink c ON c.sub_id=a.org_id"
           . " WHERE a.sub_id = '$prj_ses_org_id' OR a.org_id = '$prj_ses_org_id' ORDER BY a.org_id";
      $result = $db->query($sql);
      $tree = new _project_OrgTree();


      while (list($res_org_id,$res_org_nm,$res_parent_org_id) = $db->fetchRow($result)) {
         $parents["$res_org_id"] = $res_org_nm;
         $node = new _project_OrgTreeNode($res_org_id,$res_org_nm,$res_parent_org_id,XOCP_SERVER_SUBDIR."/index.php?X_project=$catch_id&selectresourcesorg=y&y=$res_org_id");
         $tree->addItem($node);
      }

      $dp_header = new XocpSimpleTable();
      $hrow = $dp_header->addRow("<font class='tdh1'>"._PRJ_SELECTRESOURCESORG."</font>");
      $dp_header->setWidth("100%");
      $dp_table = new XocpTable(1);
      $hrow = $dp_table->addHeader($dp_header->render());
      $drow = $dp_table->addRow($tree->render());
      return $dp_table->render();
   }
   
   function editSelectResourcesPrj($item_id,$res_org_id,$catch_id) {
      global $xocp_user,$xocp_page_id,$prj_ses_org_id,$prj_ses_prj_id;

      if($prj_ses_org_id>0) {
      
         $db =& Database::getInstance();
         $sql = "SELECT prj_id,prj_nm,description FROM ".XOCP_PREFIX."prj_projects"
              . " WHERE org_id = '$res_org_id'";
         $result = $db->query($sql);
      
         $dp_header = new XocpSimpleTable();
         $hrow = $dp_header->addRow("<font class='tdh1'>"._PRJ_SELECTRESOURCESPRJ."</font>");
         $dp_header->setCellAlign($hrow,"left");
         $dp_header->setWidth("100%");
         $dp_table = new XocpTable(1);
         $dp_table->setWidth("100%");
         $hrow = $dp_table->addHeader($dp_header->render());
         $n=0;
         while (list($res_prj_id,$res_prj_nm,$res_prj_desc) = $db->fetchRow($result)) {
            $drow = $dp_table->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?X_project=$catch_id&selectresourcesproject=y&z=$res_prj_id'>$res_prj_nm</a>",$res_prj_desc);
            $n++;
         }
         if($n == 0) {
            $drow = $dp_table->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?X_project=$catch_id&editresourceslist=y&x=$item_id'>"._PRJ_NOPROJECTFOUND."</a>");
         } else {
            $dp_table->setColSpan($hrow,2);
         }
         return $dp_table->render();
      }
   }
   


   
   function editSelectResources($item_id,$res_org_id,$res_prj_id,$catch_id) {
      global $xocp_user,$xocp_page_id,$prj_ses_org_id,$prj_ses_prj_id;

      if($prj_ses_prj_id>0 && $prj_ses_org_id>0) {
      
         $db =& Database::getInstance();
         $sql = "SELECT resources_id,resources_nm,description,amount,curency FROM ".XOCP_PREFIX."prj_res"
              . " WHERE org_id = '$res_org_id' AND prj_id = '$res_prj_id'"
              . " ORDER BY resources_id";
         $result = $db->query($sql);
         $n = $db->getRowsNum($result);
      
         $dp_header = new XocpSimpleTable();
         $hrow = $dp_header->addRow("<font class='tdh1'>"._PRJ_SELECTRESOURCES."</font>");
         $dp_header->setWidth("100%");
         $dp_table = new XocpTable(1);
         $dp_table->setWidth("100%");
         $hrow = $dp_table->addHeader($dp_header->render());
         $dp_table->setColSpan($hrow,3);
         $hrow = $dp_table->addHeader(_PRJ_RESOURCESNAME,_PRJ_RESOURCESCURENCY,_PRJ_RESOURCESAMOUNT);
         while (list($resources_id,$resources_nm,$resources_desc,$amount,$curency) = $db->fetchRow($result)) {
            $drow = $dp_table->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?X_project=$catch_id&selectresourcesx=y&r=$resources_id'>$resources_nm</a>",$curency,$amount);
            $dp_table->setCellAlign($drow,"left","center","right");
         }
         return $dp_table->render();
      }
   }
   


   function editResourcesLink($catch_id,$item_id,$id=0,$res_org_id=0,$res_prj_id=0,$resources_id=0) {
      global $prj_ses_org_id,$prj_ses_prj_id,$xocp_page_id;
      $db =& Database::getInstance();


      $form = new XocpThemeForm(_PRJ_EDITRESOURCESLINKFORM, "resourceseditform", "index.php","post",TRUE);
      
      if($id>0) {

         $sql = "SELECT resources_type,description,amount FROM ".XOCP_PREFIX."prj_reslink"
              . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id' AND item_id = '$item_id' AND id = '$id'";

         $result = $db->query($sql);
         list($resources_type,$description,$amount) = $db->fetchRow($result);
         $h_id  = new XocpFormHidden("id", $id);
         $hedit  = new XocpFormHidden("edit", "y");
         $form->addElement($hedit);

      } else {
         $sql = "SELECT max(id) FROM ".XOCP_PREFIX."prj_reslink"
              . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id' AND item_id = '$item_id'";
         $result = $db->query($sql);
         list($max_id) = $db->fetchRow($result);
         $max_id++;
         $sql = "INSERT INTO ".XOCP_PREFIX."prj_reslink (org_id,prj_id,item_id,id,res_org_id,res_prj_id,resources_id)"
              . " VALUES('$prj_ses_org_id','$prj_ses_prj_id','$item_id','$max_id','$res_org_id','$res_prj_id','$resources_id')";
         $db->query($sql);
         $h_id  = new XocpFormHidden("id", $max_id);
      }

      $resources_type+=0;
      $reslink_restype   = new XocpFormRadio(_PRJ_PROJECTPRIORITY, "resources_type",$resources_type);
      $reslink_restype->addOption("0",_PRJ_RESOURCES_WORK);
      $reslink_restype->addOption("1",_PRJ_RESOURCES_MATERIAL);

      $reslink_desc = new XocpFormTextArea(_PRJ_RESOURCESDESCRIPTION, "description",$description);
      $reslink_amount   = new XocpFormText(_PRJ_RESOURCESAMOUNT, "amount", 40, 100, "$amount");


      $submit_button = new XocpFormButton("", "savereslinkx", _SAVE, "submit");
      $reset_button = new XocpFormButton("", "resetresources", _RESET, "reset");

      $elementtray_buttons = new XocpFormElementTray("");
      $elementtray_buttons->addElement($submit_button);
      $elementtray_buttons->addElement($reset_button);

      $cancel_button = new XocpFormButton("", "cancelsavereslinkx", _CANCEL, "submit");
      $elementtray_buttons->addElement($cancel_button);

      if($id>0) {
         $delete_button = new XocpFormButton("", "deletereslinkx", _DELETE, "submit");
         $elementtray_buttons->addElement($delete_button);
      } else {
      }

      $hidden = new XocpFormHidden("X_project",$catch_id);

      $h_item_id = new XocpFormHidden("item_id",$item_id);
      $h_res_org_id = new XocpFormHidden("res_org_id",$res_org_id);
      $h_res_prj_id = new XocpFormHidden("res_prj_id",$res_prj_id);
      $h_resources_id = new XocpFormHidden("resources_id",$resources_id);

      $form->addElement($h_item_id);
      $form->addElement($h_res_org_id);
      $form->addElement($h_res_prj_id);
      $form->addElement($h_resources_id);


      $form->addElement($h_id);
      $form->addElement($reslink_restype);
      $form->addElement($reslink_desc);
      $form->addElement($reslink_amount);
      $form->addElement($elementtray_buttons);
      $form->addElement($hidden);

      return $form->render();
      
   }


   function saveResLink() {
      global $prj_ses_org_id,$HTTP_POST_VARS,$prj_ses_prj_id,$prj_ses_selectresources;
      $db =& Database::getInstance();
      $item_id = $HTTP_POST_VARS["item_id"];
      $res_org_id = $HTTP_POST_VARS["res_org_id"];
      $res_prj_id = $HTTP_POST_VARS["res_prj_id"];
      $resources_id = $HTTP_POST_VARS["resources_id"];
      $id = $HTTP_POST_VARS["id"];
      $resources_type = $HTTP_POST_VARS["resources_type"];
      $description = $HTTP_POST_VARS["description"];
      $amount = $HTTP_POST_VARS["amount"];

      $sql = "UPDATE ".XOCP_PREFIX."prj_reslink SET"
           . " description = '$description',"
           . " amount = '$amount',"
           . " resources_type = '$resources_type'"
           . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id' AND item_id = '$item_id'"
           . " AND id = '$id'";
      $db->query($sql);
      return $item_id;
   }



/////////////////////////////////////////////////////////////////////////////////////


   function show() {
      global $prj_ses_org_id,$prj_ses_prj_id,$HTTP_GET_VARS,$HTTP_POST_VARS,$xocp_page_id;
      global $prj_ses_selectresources;

      switch ($this->catch) {
         case "9":
            $db =& Database::getInstance();
            if ($HTTP_GET_VARS["addnewitembutton"] != "") {
               $ret = "<br />" .$this->editItemForm(0,9);
            } elseif ($HTTP_GET_VARS["edititem"] != "") {
               $item_id = $HTTP_GET_VARS["x"];
               $ret = "<br />" .$this->editItemForm($item_id,9);
            } elseif ($HTTP_POST_VARS["saveitem"] != "") {
               $item_id = $this->saveItem();
               $ret = "<br />" .$this->formSelectItem();
            } elseif ($HTTP_POST_VARS["cancelsaveitem"] != "") {
               $item_id = $HTTP_POST_VARS["item_id"];
               if($HTTP_POST_VARS["edit"] != "y") {
                  $sql = "DELETE FROM ".XOCP_PREFIX."prj_item"
                       . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id' AND item_id = '$item_id'";
                  $db->query($sql);
               }
               $ret = "<br />".$this->formSelectItem();
            } elseif ($HTTP_POST_VARS["deleteitem"] != "") {
               $item_id = $HTTP_POST_VARS["item_id"];
               $sql = "DELETE FROM ".XOCP_PREFIX."prj_item"
                    . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id' AND item_id = '$item_id'";
               $db->query($sql);
               $ret = "<br />".$this->formSelectItem()."<br/><br/>"._PRJ_ITEMDELETED;


////////////////// RESOURCES LINK /////////////////////////////

            } elseif ($HTTP_POST_VARS["editresourceslist"] != "") {
               $item_id = $this->saveItem();
               session_register("prj_ses_selectresources");
               $prj_ses_selectresources = new _project_SelectResources();
               $prj_ses_selectresources->item_id = $item_id;
               $ret = "<br />" .$this->editSelectResourcesOrg($item_id,9);


            } elseif ($HTTP_GET_VARS["editresourceslist"] != "") {
               $item_id = $HTTP_GET_VARS["x"];
               session_register("prj_ses_selectresources");
               $prj_ses_selectresources = new _project_SelectResources();
               $prj_ses_selectresources->item_id = $item_id;
               $ret = "<br />" .$this->editSelectResourcesOrg($item_id,9);


            } elseif ($HTTP_GET_VARS["selectresourcesorg"] != "") {
               $res_org_id = $HTTP_GET_VARS["y"];
               $prj_ses_selectresources->res_org_id = $res_org_id;
               $ret = "<br />" .$this->editSelectResourcesPrj($prj_ses_selectresources->item_id,$res_org_id,9);


            } elseif ($HTTP_GET_VARS["selectresourcesproject"] != "") {
               $res_prj_id = $HTTP_GET_VARS["z"];
               $prj_ses_selectresources->res_prj_id = $res_prj_id;
               $ret = "<br />" .$this->editSelectResources($prj_ses_selectresources->item_id,$prj_ses_selectresources->res_org_id,$res_prj_id,9);


            } elseif ($HTTP_GET_VARS["selectresourcesx"] != "") {
               $resources_id = $HTTP_GET_VARS["r"];
               $prj_ses_selectresources->resources_id = $resources_id;
               $ret = "<br />" .$this->editResourcesLink(9,$prj_ses_selectresources->item_id,0,$prj_ses_selectresources->res_org_id,$prj_ses_selectresources->res_prj_id,$resources_id);


            } elseif ($HTTP_GET_VARS["editreslink"] != "") {
               $item_id = $HTTP_GET_VARS["x"];
               $id = $HTTP_GET_VARS["y"];
               $ret = "<br />" .$this->editResourcesLink(9,$item_id,$id);


            } elseif ($HTTP_POST_VARS["savereslinkx"] != "") {
               $item_id = $this->saveResLink();
               $ret = "<br />" .$this->editItemForm($item_id,9);


            } elseif ($HTTP_POST_VARS["cancelsavereslinkx"] != "") {
               $item_id = $HTTP_POST_VARS["item_id"];
               $id = $HTTP_POST_VARS["id"];
               if($HTTP_POST_VARS["edit"] != "y") {
                  $sql = "DELETE FROM ".XOCP_PREFIX."prj_reslink"
                       . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id' AND item_id = '$item_id' AND id = '$id'";
                  $db->query($sql);
               }
               $ret = "<br />".$this->editItemForm($item_id,9);
               session_unregister("prj_ses_selectresources");


            } elseif ($HTTP_POST_VARS["deletereslinkx"] != "") {
               $item_id = $HTTP_POST_VARS["item_id"];
               $id = $HTTP_POST_VARS["id"];
               $sql = "DELETE FROM ".XOCP_PREFIX."prj_reslink"
                    . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id' AND item_id = '$item_id' AND id = '$id'";
               $db->query($sql);
               $ret = "<br />".$this->editItemForm($item_id,9)."<br/><br/>"._PRJ_ITEMDELETED;
               session_unregister("prj_ses_selectresources");


////////////////////////////////////////////////////////////////






            } else {
               if($prj_ses_prj_id>0) {
                  $ret = "<br />".$this->formSelectItem();
               }
            }
            break;
         default:
            if($prj_ses_prj_id>0) {
               $ret = "<br />".$this->formSelectItem();
            }
            break;
      }


      return $ret;
   }
}

} // PROJECT_PROJECTITEM_DEFINED
?>