<?php
//--------------------------------------------------------------------//
// Filename : modules/project/resources.php                           //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-03-19                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('PROJECT_PROJECTRESOURCES_DEFINED') ) {
   define('PROJECT_PROJECTRESOURCES_DEFINED', TRUE);

class _project_ProjectResources extends XocpBlock {
   var $width = "100%";
   
   
   function formSelectResources() {
      global $xocp_user,$xocp_page_id,$prj_ses_org_id,$prj_ses_prj_id;

      if($prj_ses_prj_id>0 && $prj_ses_org_id>0) {
      
         $db =& Database::getInstance();
         $sql = "SELECT resources_id,resources_nm,description,amount,curency FROM ".XOCP_PREFIX."prj_res"
              . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id'"
              . " ORDER BY resources_id";
         $result = $db->query($sql);
         $n = $db->getRowsNum($result);
      
         $add_button = new XocpFormButton("","addnewresourcesbutton",_ADD,"submit");
         $hidden = new XocpFormHidden("X_project",11);
         $form = new XocpSimpleForm("","addnewresourcesformx","index.php","get");
         $form->addElement($add_button);
         $form->addElement($hidden);
         
         $dp_header = new XocpSimpleTable();
         $hrow = $dp_header->addRow("<font class='tdh1'>"._PRJ_RESOURCESLIST."</font>",$form->render());
         $dp_header->setCellAlign($hrow,"left","right");
         $dp_header->setWidth("100%");
         $dp_table = new XocpTable(1);
         $dp_table->setWidth("100%");
         $hrow = $dp_table->addHeader($dp_header->render());
         $dp_table->setColSpan($hrow,3);
         $hrow = $dp_table->addHeader(_PRJ_RESOURCESNAME,_PRJ_RESOURCESCURENCY,_PRJ_RESOURCESAMOUNT);
         while (list($resources_id,$resources_nm,$resources_desc,$amount,$curency) = $db->fetchRow($result)) {
            $drow = $dp_table->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?X_project=11&editresources=y&x=$resources_id'>$resources_nm</a>",$curency,$amount);
            $dp_table->setCellAlign($drow,"left","center","right");
         }
         return $dp_table->render();
      }
   }
   
   function editResourcesForm($resources_id = 0,$catch_id) {
      global $prj_ses_org_id,$prj_ses_prj_id,$xocp_page_id;
      $db =& Database::getInstance();


      $form = new XocpThemeForm(_PRJ_EDITRESOURCESFORM, "resourceseditform", "index.php","post",TRUE);
      
      if($resources_id>0) {

         $sql = "SELECT resources_nm,curency,description,amount FROM ".XOCP_PREFIX."prj_res"
              . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id' AND resources_id = '$resources_id'";

         $result = $db->query($sql);
         list($resources_nm,$curency,$description,$amount) = $db->fetchRow($result);
         $hresources_id  = new XocpFormHidden("resources_id", $resources_id);
         $hedit  = new XocpFormHidden("edit", "y");
         $form->addElement($hedit);

      } else {
         $sql = "SELECT max(resources_id) FROM ".XOCP_PREFIX."prj_res"
              . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id'";
         $result = $db->query($sql);
         list($max_resources_id) = $db->fetchRow($result);
         $max_resources_id++;
         $sql = "INSERT INTO ".XOCP_PREFIX."prj_res (org_id,prj_id,resources_id,resources_nm)"
              . " VALUES('$prj_ses_org_id','$prj_ses_prj_id','$max_resources_id','resources$max_resources_id')";
         $db->query($sql);
         $hresources_id  = new XocpFormHidden("resources_id", $max_resources_id);

      }

      $resources_name   = new XocpFormText(_PRJ_RESOURCESNAME, "resources_nm", 40, 100, "$resources_nm");
      $resources_desc = new XocpFormTextArea(_PRJ_RESOURCESDESCRIPTION, "description",$description);
      $resources_amount   = new XocpFormText(_PRJ_RESOURCESAMOUNT, "amount", 40, 100, "$amount");

      $sql = "SELECT curency_cd,curency_nm FROM ".XOCP_PREFIX."sys_curency_code"
           . " ORDER BY curency_cd";
      $result = $db->query($sql);
      if($db->getRowsNum($result)>0) {
         $selectcurency   = new XocpFormSelect(_PRJ_CURENCY, "curency_cd",$curency);
         while(list($curency_cd,$curency_nm)=$db->fetchRow($result)) {
            $selectcurency->addOption($curency_cd,$curency_nm);
         }
      } else {
         $selectcurency = new XocpFormLabel(_PRJ_CURENCY,_PRJ_NO_CURENCY_DEFINED);
      }

      $submit_button = new XocpFormButton("", "saveresources", _SAVE, "submit");
      $reset_button = new XocpFormButton("", "resetresources", _RESET, "reset");

      $elementtray_buttons = new XocpFormElementTray("");
      $elementtray_buttons->addElement($submit_button);
      $elementtray_buttons->addElement($reset_button);

      $cancel_button = new XocpFormButton("", "cancelsaveresources", _CANCEL, "submit");
      $elementtray_buttons->addElement($cancel_button);

      if($resources_id>0) {
         $delete_button = new XocpFormButton("", "deleteresources", _DELETE, "submit");
         $elementtray_buttons->addElement($delete_button);
      } else {
      }

      $hidden = new XocpFormHidden("X_project",$catch_id);

      $form->addElement($hresources_id);
      $form->addElement($resources_name);
      $form->addElement($resources_desc);
      $form->addElement($resources_amount);
      $form->addElement($selectcurency);
      $form->addElement($elementtray_buttons);
      $form->addElement($hidden);

      return $form->render();
      
   }
   
   function saveResources() {
      global $prj_ses_org_id,$HTTP_POST_VARS,$prj_ses_prj_id;
      $db =& Database::getInstance();
      $resources_id = $HTTP_POST_VARS["resources_id"];
      $resources_nm = $HTTP_POST_VARS["resources_nm"];
      if(trim($resources_nm) == "") $resources_nm = "resources$resources_id";
      $description = $HTTP_POST_VARS["description"];
      $amount = $HTTP_POST_VARS["amount"];
      $curency = $HTTP_POST_VARS["curency_cd"];

      $sql = "UPDATE ".XOCP_PREFIX."prj_res SET"
           . " resources_nm = '$resources_nm',"
           . " description = '$description',"
           . " amount = '$amount',"
           . " curency = '$curency'"
           . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id' AND resources_id = '$resources_id'";
      $db->query($sql);
      return $resources_id;
   }

   function show() {
      global $prj_ses_org_id,$prj_ses_prj_id,$HTTP_GET_VARS,$HTTP_POST_VARS,$xocp_page_id;
      switch ($this->catch) {
         case "11":
            $db =& Database::getInstance();
            if ($HTTP_GET_VARS["addnewresourcesbutton"] != "") {
               $ret = "<br />" .$this->editResourcesForm(0,11);
            } elseif ($HTTP_GET_VARS["editresources"] != "") {
               $resources_id = $HTTP_GET_VARS["x"];
               $ret = "<br />" .$this->editResourcesForm($resources_id,11);
            } elseif ($HTTP_POST_VARS["saveresources"] != "") {
               $resources_id = $this->saveResources();
               $ret = "<br />" .$this->formSelectResources();
            } elseif ($HTTP_POST_VARS["cancelsaveresources"] != "") {
               $resources_id = $HTTP_POST_VARS["resources_id"];
               if($HTTP_POST_VARS["edit"] != "y") {
                  $sql = "DELETE FROM ".XOCP_PREFIX."prj_res"
                       . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id' AND resources_id = '$resources_id'";
                  $db->query($sql);
               }
               $ret = "<br />".$this->formSelectResources();
            } elseif ($HTTP_POST_VARS["deleteresources"] != "") {
               $resources_id = $HTTP_POST_VARS["resources_id"];
               $sql = "DELETE FROM ".XOCP_PREFIX."prj_res"
                    . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id' AND resources_id = '$resources_id'";
               $db->query($sql);
               $ret = "<br />".$this->formSelectResources()."<br/><br/>"._PRJ_RESOURCESDELETED;
            } else {
               if($prj_ses_prj_id>0) {
                  $ret = "<br />".$this->formSelectResources();
               }
            }
            break;
         default:
            if($prj_ses_prj_id>0) {
               $ret = "<br />".$this->formSelectResources();
            }
            break;
      }
      return $ret;
   }
}

} // PROJECT_PROJECTRESOURCES_DEFINED
?>