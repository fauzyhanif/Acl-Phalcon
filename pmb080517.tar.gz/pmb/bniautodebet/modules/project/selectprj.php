<?php
//--------------------------------------------------------------------//
// Filename : modules/project/selectorg.php                           //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-03-18                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('PROJECT_SELECTPROJECT_DEFINED') ) {
   define('PROJECT_SELECTPROJECT_DEFINED', TRUE);

include_once(XOCP_DOC_ROOT."/modules/project/class/orgtree.php");

class _project_SelectProject extends XocpBlock {
   var $width = "100%";
   
   function formSelectPrj() {
      global $xocp_user,$xocp_page_id,$prj_ses_org_id;

      if($prj_ses_org_id>0) {
      
         $pgroup_id = $xocp_user->getVar("pgroup_id");
         $db =& Database::getInstance();
         $sql = "SELECT prj_id,prj_nm,description FROM ".XOCP_PREFIX."prj_projects"
              . " WHERE org_id = '$prj_ses_org_id'";
         $result = $db->query($sql);
      
         $add_button = new XocpFormButton("","addnewprojectbutton",_ADD,"submit");
         $hidden = new XocpFormHidden("X_project",7);
         $form = new XocpSimpleForm("","addnewprojectformx","index.php","get");
         $form->addElement($add_button);
         $form->addElement($hidden);
         
         $dp_header = new XocpSimpleTable();
         $hrow = $dp_header->addRow("<font class='tdh1'>"._PRJ_SELECTPROJECT."</font>",$form->render());
         $dp_header->setCellAlign($hrow,"left","right");
         $dp_header->setWidth("100%");
         $dp_table = new XocpTable(1);
         $dp_table->setWidth("100%");
         $hrow = $dp_table->addHeader($dp_header->render());
         $dp_table->setColSpan($hrow,2); 
         while (list($prj_id,$prj_nm,$prj_desc) = $db->fetchRow($result)) {
            $drow = $dp_table->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?X_project=7&selectproject=y&x=$prj_id'>$prj_nm</a>",$prj_desc);
         }
         return $dp_table->render();
      }
   }
   
   function showPrj() {
      global $prj_ses_org_id,$prj_ses_prj_id,$xocp_page_id;
      $db =& Database::getInstance();
      $sql = "SELECT prj_nm from ".XOCP_PREFIX."prj_projects"
           . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id'";
      $result = $db->query($sql);
      list($prj_nm) = $db->fetchRow($result);


      return "<table border=0 width=100% cellpadding=2 cellspacing=0>"
           . "<tr><td bgcolor=#aaaa00><b><i>"._PRJ_SHOWPROJECT
           . " : $prj_nm</i></b></td><td align=right bgcolor=#aaaa00>[<a href='"
           . XOCP_SERVER_SUBDIR."/index.php?XP_".$xocp_page_id."_project=7"
           . "&ch=y'>Select Project</a>]</td></tr></table>";
   }
   
   function show() {
      global $prj_ses_org_id,$prj_ses_prj_id,$HTTP_GET_VARS,$HTTP_POST_VARS,$xocp_page_id;
      switch ($this->catch) {
         case "7":
            $db =& Database::getInstance();
            if ($HTTP_GET_VARS["prj_id"] != "") {
               $prj_ses_prj_id = $HTTP_GET_VARS["prj_id"];
               $ret = $this->showPrj();
            } elseif ($HTTP_GET_VARS["ch"] == "y") {
               $prj_ses_prj_id = 0;
               $ret = "<br />".$this->formSelectPrj();
            } elseif ($HTTP_GET_VARS["addnewprojectbutton"] != "") {
               $sql = "SELECT max(prj_id) FROM ".XOCP_PREFIX."prj_projects a"
                    . " WHERE org_id = '$prj_ses_org_id'";
               $result = $db->query($sql);
               list($max_prj_id) = $db->fetchRow($result);
               $max_prj_id++;
               $sql = "INSERT INTO ".XOCP_PREFIX."prj_projects (org_id,prj_id,prj_nm,created,modified)"
                    . " VALUES('$prj_ses_org_id','$max_prj_id','noname$max_prj_id',now(),now())";
               $db->query($sql);
               $prj_ses_prj_id = $max_prj_id;
               $ret = $this->showPrj();
            } elseif ($HTTP_GET_VARS["selectproject"] != "") {
               $prj_id = $HTTP_GET_VARS["x"];
               $prj_ses_prj_id = $prj_id;
               $ret = $this->showPrj();
            } else {
               if($prj_ses_org_id>0) {
                  if (!session_is_registered("prj_ses_prj_id")) {
                     session_register("prj_ses_prj_id");
                     $prj_ses_prj_id = "0";
                  }
                  if($prj_ses_prj_id == "0") {
                     $ret = "<br />".$this->formSelectPrj();
                  } else {
                     $ret = $this->showPrj();
                  }
               }
            }
            break;
         default:
            if($prj_ses_org_id>0) {
               if (!session_is_registered("prj_ses_prj_id")) {
                  session_register("prj_ses_prj_id");
                  $prj_ses_prj_id = "0";
               }
               if($prj_ses_prj_id == "0") {
                  $ret = "<br />".$this->formSelectPrj();
               } else {
                  $ret = $this->showPrj();
               }
            }
            break;
      }
      return $ret;
   }
}

} // PROJECT_SELECTPROJECT_DEFINED
?>