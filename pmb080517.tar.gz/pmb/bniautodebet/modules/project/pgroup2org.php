<?php
//--------------------------------------------------------------------//
// Filename : modules/project/pgroup2org.php                          //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-03-17                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('PRJ_PGROUP2ORG_DEFINED') ) {
   define('PRJ_PGROUP2ORG_DEFINED', TRUE);

include(XOCP_DOC_ROOT."/modules/project/forms.php");

class _project_Pgroup2Org extends XocpBlock {
   var $width = "100%";
   
   function browse($f = NULL) {
      global $HTTP_GET_VARS;
      
      if($f == NULL) {
         $db = Database::getInstance();
         $sql = "SELECT a.pgroup_cd,a.pgroup_id,b.org_id,c.org_nm FROM ".XOCP_PREFIX."pgroups a"
              . " LEFT JOIN ".XOCP_PREFIX."prj_pgroup_org b USING (pgroup_id)"
              . " LEFT JOIN ".XOCP_PREFIX."orgs c USING (org_id)"
              . " ORDER BY a.pgroup_cd,c.org_nm";
         $result = $db->query($sql);
         $c = $db->getRowsNum($result);
         if($c > 0) {
            $dp = new XocpDataPage();
            $dp->setPageSize(20);
            unset($old_pgroup_id);
            unset($old_pgroup_cd);
            while(list($pgroup_cd,$pgroup_id,$org_id,$org_nm)=$db->fetchRow($result)) {
               if($pgroup_id != $old_pgroup_id) {
                  if(isset($old_pgroup_cd)) {
                     $dp->addData(array($old_pgroup_id,$old_pgroup_cd,implode("<br/>",$orglist)));
                  }
                  unset($orglist);
                  $orglist = array();
                  if ($org_nm != "") {
                  	$orglist[] = $org_nm;
                  }
                  $old_pgroup_cd = $pgroup_cd;
                  $old_pgroup_id = $pgroup_id;
               } else {
                  if ($org_nm != "") {
                  	$orglist[] = $org_nm;
                  }
               }
            }
            $dp->addData(array($old_pgroup_id,$old_pgroup_cd,implode(", ",$orglist)));
            $dp->serialize();
            $found = $dp->getCount();
            $dpfile = $dp->getFile();
            $dp->reset();
         } else {
            return $sql . _SYS_GROUP_NOTFOUND;
         }
      } else {
         $dp = XocpDataPage::unserialize($f);
         $dp->setPage($HTTP_GET_VARS["p"]);
         $found = $dp->getCount();
      }

      $xurl = XOCP_SERVER_SUBDIR."/index.php?X_project=1";
      $prevnext = $dp->getPageLinks($xurl);

      $htable = new XocpSimpleTable();
      $sno = $htable->addRow(_SYS_GROUP_USERLIST." : $found "._FOUND,$prevnext);
      $htable->setCellAlign($sno,array("","right"));
      $htable->setWidth("100%");

      $ftable = new XocpSimpleTable();
      $sno = $ftable->addRow($prevnext);
      $ftable->setCellAlign($sno,array("right"));
      $ftable->setWidth("100%");

      $table = new XocpTable(1);
      $table->setWidth("100%");
      $hno = $table->addHeader($htable->render());
      $fno = $table->addFooter($ftable->render());
      
      $no = $dp->getOffset() + 1;
      $data = $dp->retrieve();
      foreach($data as $x) {
         list($pgroup_id,$pgroup_cd,$orglist) = $x;
         $rno = $table->addRow("$no. <b><a href=$xurl&edit=y&x=$pgroup_id".">$pgroup_cd</a></b><br/>$orglist");
         $no++;
      }

      return $table->render();

   }
   
   function main() {
      
      switch($this->catch) {
         case "1" :
            global $HTTP_POST_VARS,$HTTP_GET_VARS;
            if($HTTP_GET_VARS["f"] != "") {
               $ret = $this->browse($HTTP_GET_VARS["f"]);
               break;
            } else if($HTTP_GET_VARS["edit"] == "y") {
               $form = project_editpgroup($HTTP_GET_VARS["x"],1);
               $ret .= $form->render();
               break;
            } else if(!empty($HTTP_POST_VARS["addorg"])) {
               $db =& Database::getInstance();
               $sql = "INSERT INTO ".XOCP_PREFIX."prj_pgroup_org (pgroup_id,org_id)"
                    . " VALUES ('".$HTTP_POST_VARS["upgroup"]."','".$HTTP_POST_VARS["addorg_id"]."')";
               $db->query($sql);
               $form = project_editpgroup($HTTP_POST_VARS["upgroup"],1);
               $form->setComment($db->error());
               $ret .= $form->render();
               break;
            } else if(!empty($HTTP_POST_VARS["deleteorg"])) {
               $pgroup_id = $HTTP_POST_VARS["upgroup"];
               $n = $HTTP_POST_VARS["n"];
               $db =& Database::getInstance();
               if($n>0) {
                  for($i=0;$i<$n;$i++) {
                     $org_id = $HTTP_POST_VARS["org$i"];
                     if($org_id != '') {
                        $sql = "DELETE FROM ".XOCP_PREFIX."prj_pgroup_org"
                             . " WHERE pgroup_id = '$pgroup_id' AND org_id = '$org_id'";
                        $db->query($sql);
                     }
                  }
               }
               $form = project_editpgroup($pgroup_id,1);
               $ret .= $form->render();
               break;
            }

         default : 
            $ret .= $this->browse();
      }
      
      return "<b>" . _SYS_GROUP_USERADMIN . "</b><br/><br/>" . $ret;
      
   }
   
}

} // PRJ_PGROUP2ORG_DEFINED
?>