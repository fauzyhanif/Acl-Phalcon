<?php
//--------------------------------------------------------------------//
// Filename : modules/projects/language/english.php                   //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-24                                              //
// Author   : (Ardiansyah, ardi@linuxmail.org)                        //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('PROJECTS_LANGUAGE_DEFINED') ) {
   define('PROJECTS_LANGUAGE_DEFINED', TRUE);

// New definition
define("_HIND_SELECTORGSELECT","Select Organization");
define("_PRJ_SELECTPROJECT","Select Project");
define("_PRJ_SHOWPROJECT","Show Project");
define("_PRJ_EDITPROJECT","Edit Project");
define("_PRJ_SELECTITEM","Select Project Item");
define("_PRJ_RESOURCESLIST","Item Resources List");
define("_PRJ_RESOURCESNAME","Resource Name");
define("_PRJ_RESOURCESCURENCY","Currency");
define("_PRJ_RESOURCESAMOUNT","Amount");
define("_PRJ_EDITITEMFORM","Project Item - Edit");
define("_PRJ_ITEMNAME","Item Name");
define("_PRJ_ITEMPRIORITY","Priority");
define("_PRJ_HIGHPRIORITY","High");
define("_PRJ_MEDIUMPRIORITY","Medium");
define("_PRJ_LOWPRIORITY","Low");
define("_PRJ_ITEMCOMPLETION","% of Completion");
define("_PRJ_ITEMDESCRIPTION","Description");
define("_PRJ_ITEMCOMMENT","Comment");
define("_PRJ_ITEMSTART_DT","Start Date");
define("_PRJ_ITEMSTOP_DT","Stopped Date");
define("_PRJ_ITEMCOMPLETE_DT","Completed Date");
define("_PRJ_ITEMRESOURCES","Item Resources");
define("_PRJ_NO_RESOURCES_LINKED","No Resource(s) Linked");
define("_PRJ_ITEMPHASE","Item Phase");
define("_PRJ_PRJPHASE","Project Phase");
define("_PRJ_ITEMCODE","Item Code");
define("_PRJ_EDITRESOURCESFORM","Item Resource - Edit");
define("_PRJ_RESOURCESDESCRIPTION","Description");
define("_PRJ_CURENCY","Currency");
define("_PRJ_CURENCY","Currency");
define("_PRJ_SELECTRESOURCESORG","Select Organization");
define("_PRJ_ADDFORM","Project - Add");
define("_PRJ_PROJECTNAME","Project Name");
define("_PRJ_PROJECTDESCRIPTION","Description");
define("_PRJ_PROJECTPRIORITY","Priority");
define("_PRJ_PARENTPROJECT","Parent Project");
define("_PRJ_PROJECTPHASE","Project Phase");
define("_PRJ_BASECURENCY","Base Currency");
define("_PRJ_RES_RES","Resource Name");
define("_PRJ_RES_DESC","Description");
define("_PRJ_RES_AMNT","Amount");
define("_PRJ_RES_TYPE","Resource Type");
define("_PRJ_WORK","Work");
define("_PRJ_MATERIAL","Material");
define("_PRJ_EDITRESOURCESLINKFORM","Resource Link - Edit");
define("_PRJ_RESOURCES_WORK","Work");
define("_PRJ_RESOURCES_MATERIAL","Material");
define("_PRJ_SELF_ORG","Self Organization");
define("_PRJ_SELECTORG","Select Organization");
define("_PRJ_SELECTRESOURCESPRJ","Select Project Resource");
define("_PRJ_SELECTRESOURCES","Select Resource");
define("_PRJ_ITEMDELETED","Project Item Deleted");

//English language for addprojects.php by Ardiansyah

define("_PRJ_PROJECT_ORGID","Project ID-ORG");
define("_PRJ_PROJECT_ID","Project ID");
define("_PRJ_PROJECT_NAME","Project Name");
define("_PRJ_PROJECT_DESCRIPTION","Project Description");
define("_PRJ_PROJECT_OWNERID","Project OwnerID");
define("_PRJ_PROJECT_PRIORITY","Project Priority");
define("_PRJ_PROJECT_PARENTID","Project ParentID");
define("_PRJ_PROJECT_PARENTORG","Project Parent-ORG");
define("_PRJ_PROJECT_CREATEDDATETIME","Project Created [YYYY-MM-DD HH-MM-SS]");
define("_PRJ_PROJECT_MODIFIEDDATETIME","Project Modified [YYYY-MM-DD HH-MM-SS]");
define("_PRJ_PROJECT_PHASESET","Project Phase");
define("_PRJ_PROJECT_STATUS","Project Status");
define("_PRJ_PROJECTSTATUS_START", "Start");
define("_PRJ_PROJECTSTATUS_OPEN", "Open");
define("_PRJ_PROJECT_ADDNEW","Save");
define("_PRJ_PROJECT_ADDFORM", "New Project");

//English language for addtask.php

define("_PRJ_TASK_ADDFORM", "New Task");
define("_PRJ_TASK_ID", "ID");
define("_PRJ_TASK_PARENTID", "Sub ID");
define("_PRJ_TASK_NAME", "Task Name");
define("_PRJ_TASK_DESCRIPTION", "Description");
define("_PRJ_TASK_PROJECTID", "Project ID");
define("_PRJ_TASK_OWNERID", "Owner Task ID");
define("_PRJ_TASK_ASSIGNEDTO", "Assigned To");
define("_PRJ_TASK_PRIORITY", "Priority");
define("_PRJ_TASK_STATUS", "Status");
define("_PRJ_TASK_CONFIRMST", "Confirm Set");
define("_PRJ_TASK_CONFIRMED", "Confirmed");
define("_PRJ_TASK_STARTDATE", "Start [YYYY-MM-DD]");
define("_PRJ_TASK_DUEDATE", "Due Date");
define("_PRJ_TASK_ESTIMATEDTIME", "Estimated Time");
define("_PRJ_TASK_ACTUALTIME", "Finish");
define("_PRJ_TASK_COMPLETEDATE", "Compelete Date");
define("_PRJ_TASK_COMMENTS", "Comments");
define("_PRJ_TASK_COMPLETION", "Completion");
define("_PRJ_TASK_CREATEDDATETIME", "Record Created [YYYY-MM-DD HH-MM-SS]");
define("_PRJ_TASK_MODIFIEDDATETIME", "Record Modified [YYYY-MM-DD  HH-MM-SS]");
define("_PRJ_TASK_ASSIGNED", "Assigned [YYYY-MM-DD)");
define("_PRJ_TASK_PUBLISHED", "Published?");
define("_PRJ_TASK_PROJECTPHASE", "Phase");
define("_PRJ_TASK_ADDNEW", "Save");

//English language for reources.php

define("_PRJ_RESOURCES_ADDFORM", "New Resources");
define("_PRJ_RESOURCES_PROJECTID", "Project ID");
define("_PRJ_RESOURCES_ID", "Resources ID");
define("_PRJ_RESOURCES_NAME", "Name");
define("_PRJ_RESOURCES_TYPE", "Type");
define("_PRJ_RESOURCESTYPE_MATERIAL", "Material");
define("_PRJ_RESOURCESTYPE_WORK", "Work");

define("_PRJ_RESOURCES_CURRENCY", "Currency");
define("_PRJ_RESOURCES_ESTAMOUNT", "Estimated Amount");
define("_PRJ_RESOURCES_CURRATE", "Currate");
define("_PRJ_RESOURCES_ACTUALAMOUNT", "Actual Amount");
define("_PRJ_RESOURCES_ACTUALCURRATE", "Actua Currate");
define("_PRJ_RESOURCES_ADDNEW", "Save");


//English language for projects.php
define("_HIND_SEARCHPROJECTTITLE","Project Management - Search");
define("_HIND_PROJECTNAME","Project Name");
define("_HIND_PROJECTDESCRIPTION","Description");
define("_HIND_SEARCHPROJECT","Search Project");
define("_HIND_NEWPROJECT","New Project"); 
define("_HIND_PROJECTSAVESUCCESS","Project has been successfully saved"); 
define("_HIND_PROJECTSAVEFAIL","Failed to save project"); 


//English language for newprojects.php
define("_HIND_NEWPROJECTTITLE","New Project");
define("_HIND_PROJECTPRIORITY","Priority");
define("_HIND_PROJECTSTATUS","Status");
define("_HIND_PROJECTPHASE","Project Phase");
define("_HIND_PROJECTCREATED","Created [yyyy:mm:dd][hh:mm:ss]");
define("_HIND_PROJECTMODIFIED","Modified [yyyy:mm:dd][hh:mm:ss]");
define("_HIND_SAVENEWPROJECT","Save Project");
define("_HIND_PROJECTBASECUR","Currency");
define("_HIND_PROJECTSTATUS_START","Start");
define("_HIND_PROJECTSTATUS_OPEN","Open");
define("_HIND_CANCEL","Cancel");

// End

}// PROJECTS_LANGUAGE_DEFINED
?>