<?php
//--------------------------------------------------------------------//
// Filename : modules/projects/language/indonesian.php                //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-24                                              //
// Author   : (Ardiansyah, ardi@linuxmail.org)                        //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('PROJECTS_LANGUAGE_DEFINED') ) {
   define('PROJECTS_LANGUAGE_DEFINED', TRUE);


//Menu bahasa Indonesia pada file addprojects.php

define("_PRJ_PROJECT_ORGID","ID-ORG");
define("_PRJ_PROJECT_ID","ID");
define("_PRJ_PROJECT_NAME","Nama");
define("_PRJ_PROJECT_DESCRIPTION","Deskripsi");
define("_PRJ_PROJECT_OWNERID","OwnerID Proyek");
define("_PRJ_PROJECT_PRIORITY","Prioritas");
define("_PRJ_PROJECT_PARENTID","Sub Proyek dari");
define("_PRJ_PROJECT_PARENTORG","Parent-ORG Proyek");
define("_PRJ_PROJECT_CREATEDDATETIME","Proyek Dibuat [YYYY-MM-DD HH-MM-SS");
define("_PRJ_PROJECT_MODIFIEDDATETIME","Proyek Diupdate [YYYY-MM-DD HH-MM-SS");
define("_PRJ_PROJECT_PHASESET","Tahap");
define("_PRJ_PROJECT_STATUS","Status");
define("_PRJ_PROJECTSTATUS_START", "Mulai");
define("_PRJ_PROJECTSTATUS_OPEN", "Terbuka");
define("_PRJ_PROJECT_ADDNEW","Rekam");
define("_PRJ_PROJECT_ADDFORM", "Proyek Baru");

//Menu bahasa Indonesia pada file addtask.php

define("_PRJ_TASK_ADDFORM", "Tugas Baru");
define("_PRJ_TASK_ID", "ID");
define("_PRJ_TASK_PARENTID", "Sub ID");
define("_PRJ_TASK_NAME", "Nama Tugas");
define("_PRJ_TASK_DESCRIPTION", "Deskripsi");
define("_PRJ_TASK_PROJECTID", "ID Proyek");
define("_PRJ_TASK_OWNERID", "ID Pemilik Task");
define("_PRJ_TASK_ASSIGNEDTO", "Pelaksana");
define("_PRJ_TASK_PRIORITY", "Prioritas");
define("_PRJ_TASK_STATUS", "Status");
define("_PRJ_TASK_CONFIRMST", "Set Konfirmasi");
define("_PRJ_TASK_CONFIRMED", "Dikonfirmasi");
define("_PRJ_TASK_STARTDATE", "Mulai [YYYY-MM-DD]");
define("_PRJ_TASK_DUEDATE", "Batas Waktu");
define("_PRJ_TASK_ESTIMATEDTIME", "Perkiraan Selesai");
define("_PRJ_TASK_ACTUALTIME", "Selesai");
define("_PRJ_TASK_COMPLETEDATE", "Waktu Selesai");
define("_PRJ_TASK_COMMENTS", "Keterangan");
define("_PRJ_TASK_COMPLETION", "Komplit");
define("_PRJ_TASK_CREATEDDATETIME", "Record Dibuat [YYYY-MM-DD HH-MM-SS])");
define("_PRJ_TASK_MODIFIEDDATETIME", "Record Diupdate [YYYY-MM-DD  HH-MM-SS)");
define("_PRJ_TASK_ASSIGNED", "Tugas Diberikan [YYYY-MM-DD)");
define("_PRJ_TASK_PUBLISHED", "Dipublikasikan?");
define("_PRJ_TASK_PROJECTPHASE", "Fase");
define("_PRJ_TASK_ADDNEW", "Rekam");

//Menu bahasa Indonesia pada file reources.php

define("_PRJ_RESOURCES_ADDFORM", "Sumber Daya Baru");
define("_PRJ_RESOURCES_PROJECTID", "ID Proyek");
define("_PRJ_RESOURCES_ID", "ID Sumber Daya");
define("_PRJ_RESOURCES_NAME", "Nama");
define("_PRJ_RESOURCES_TYPE", "Tipe");
define("_PRJ_RESOURCESTYPE_MATERIAL", "Material");
define("_PRJ_RESOURCESTYPE_WORK", "Kerja");

define("_PRJ_RESOURCES_CURRENCY", "Mata Uang");
define("_PRJ_RESOURCES_ESTAMOUNT", "Perkiraan Jumlah");
define("_PRJ_RESOURCES_CURRATE", "Nilai Tukar");
define("_PRJ_RESOURCES_ACTUALAMOUNT", "Jumlah Riil");
define("_PRJ_RESOURCES_ACTUALCURRATE", "Nilai Tukar Riil");
define("_PRJ_RESOURCES_ADDNEW", "Rekam");


//Menu bahasa Indonesia pada file projects.php
define("_HIND_SEARCHPROJECTTITLE","Manajemen Proyek - Cari");
define("_HIND_PROJECTNAME","Nama Proyek");
define("_HIND_PROJECTDESCRIPTION","Deskripsi");

} // PROJECTS_LANGUAGE_DEFINED
?>