<?php
//--------------------------------------------------------------------//
// Filename : modules/project/selectorg.php                           //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-03-18                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('PROJECT_EDITPROJECT_DEFINED') ) {
   define('PROJECT_EDITPROJECT_DEFINED', TRUE);

include_once(XOCP_DOC_ROOT."/modules/project/class/orgtree.php");

class _project_EditProject extends XocpBlock {
   var $width = "100%";
   
   function formSelectOrg() {
      global $xocp_user,$xocp_page_id,$prj_ses_org_id;
      $pgroup_id = $xocp_user->getVar("pgroup_id");
      $db =& Database::getInstance();
      $sql = "SELECT a.org_id,b.org_nm,c.org_id FROM ".XOCP_PREFIX."prj_pgroup_org a"
           . " LEFT JOIN ".XOCP_PREFIX."orgs b USING(org_id)"
           . " LEFT JOIN ".XOCP_PREFIX."prj_orglink c ON c.sub_id = a.org_id"
           . " WHERE a.pgroup_id = '$pgroup_id' ORDER BY b.org_nm";

      $sql = "SELECT a.org_id,b.org_nm,c.org_id FROM ".XOCP_PREFIX."prj_orglink a"
           . " LEFT JOIN ".XOCP_PREFIX."orgs b ON b.org_id=a.org_id"
           . " LEFT JOIN ".XOCP_PREFIX."prj_orglink c ON c.sub_id=a.org_id"
           . " WHERE a.sub_id = '$prj_ses_org_id' or a.org_id = '$prj_ses_org_id' ORDER BY a.org_id";

      $result = $db->query($sql);
      $tree = new _project_OrgTree();
      while (list($org_id,$org_nm,$parent_org_id) = $db->fetchRow($result)) {
         $parents["$org_id"] = $org_nm;
         $node = new _project_OrgTreeNode($org_id,$org_nm,$parent_org_id,XOCP_SERVER_SUBDIR."/index.php?X_project=7&selectparentorg=y&x=$org_id");
         $tree->addItem($node);
      }

      $dp_header = new XocpSimpleTable();
      $hrow = $dp_header->addRow("<font class='tdh1'>"._PRJ_SELECTORG."</font>");
      $dp_header->setWidth("100%");
      $dp_table = new XocpTable(1);
      $hrow = $dp_table->addHeader($dp_header->render());
      $drow = $dp_table->addRow($tree->render());
      return $dp_table->render();
   }
   
   function formSelectParentPrj($org_id) {
      global $xocp_user,$xocp_page_id,$prj_ses_org_id,$prj_ses_prj_id;

      if($prj_ses_org_id>0) {
      
         $pgroup_id = $xocp_user->getVar("pgroup_id");
         $db =& Database::getInstance();
         $sql = "SELECT prj_id,prj_nm,description FROM ".XOCP_PREFIX."prj_projects"
              . " WHERE org_id = '$org_id'";
         $result = $db->query($sql);
      
         $dp_header = new XocpSimpleTable();
         $hrow = $dp_header->addRow("<font class='tdh1'>"._PRJ_SELECTPARENTPRJ."</font>");
         $dp_header->setCellAlign($hrow,"left");
         $dp_header->setWidth("100%");
         $dp_table = new XocpTable(1);
         $dp_table->setWidth("100%");
         $hrow = $dp_table->addHeader($dp_header->render());
         $n=0;
         while (list($prj_id,$prj_nm,$prj_desc) = $db->fetchRow($result)) {
            if($org_id == $prj_ses_org_id && $prj_id == $prj_ses_prj_id) continue;
            $drow = $dp_table->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?X_project=7&selectparentproject=y&y=$prj_id&x=$org_id'>$prj_nm</a>",$prj_desc);
            $n++;
         }
         if($n == 0) {
            $drow = $dp_table->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?XP_".$xocp_page_id."_menu=0'>"._PRJ_NOPROJECTFOUND."</a>");
         } else {
            $dp_table->setColSpan($hrow,2);
         }
         return $dp_table->render();
      }
   }
   
   function formSelectPrj() {
      global $xocp_user,$xocp_page_id,$prj_ses_org_id;

      if($prj_ses_org_id>0) {
      
         $pgroup_id = $xocp_user->getVar("pgroup_id");
         $db =& Database::getInstance();
         $sql = "SELECT prj_id,prj_nm,description FROM ".XOCP_PREFIX."prj_projects"
              . " WHERE org_id = '$prj_ses_org_id'";
         $result = $db->query($sql);
      
         $add_button = new XocpFormButton("","addnewprojectbutton",_ADD,"submit");
         $hidden = new XocpFormHidden("X_project",7);
         $form = new XocpSimpleForm("","addnewprojectformx","index.php","get");
         $form->addElement($add_button);
         $form->addElement($hidden);
         
         $dp_header = new XocpSimpleTable();
         $hrow = $dp_header->addRow("<font class='tdh1'>"._PRJ_SELECTPROJECT."</font>",$form->render());
         $dp_header->setCellAlign($hrow,"left","right");
         $dp_header->setWidth("100%");
         $dp_table = new XocpTable(1);
         $dp_table->setWidth("100%");
         $hrow = $dp_table->addHeader($dp_header->render());
         $dp_table->setColSpan($hrow,2); 
         while (list($prj_id,$prj_nm,$prj_desc) = $db->fetchRow($result)) {
            $drow = $dp_table->addRow("<a href='".XOCP_SERVER_SUBDIR."/index.php?X_project=7&selectproject=y&x=$prj_id'>$prj_nm</a>",$prj_desc);
         }
         return $dp_table->render();
      }
   }
   
   function showPrj() {
      global $prj_ses_org_id,$prj_ses_prj_id,$xocp_page_id;
      $db =& Database::getInstance();
      $sql = "SELECT prj_nm from ".XOCP_PREFIX."prj_projects"
           . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id'";
      $result = $db->query($sql);
      list($prj_nm) = $db->fetchRow($result);


      return "<table border=0 width=100% cellpadding=2 cellspacing=0>"
           . "<tr><td bgcolor=#aaaa00><b><i>"._PRJ_SHOWPROJECT
           . " : $prj_nm</i></b></td><td align=right bgcolor=#aaaa00>[<a href='"
           . XOCP_SERVER_SUBDIR."/index.php?XP_".$xocp_page_id."_project=7"
           . "&ch=y'>Select Project</a>]</td></tr></table>";
   }
   
   
   function editProjectForm($prj_id = 0,$catch_id) {
      global $prj_ses_org_id,$prj_ses_prj_id,$xocp_page_id;
      $db =& Database::getInstance();


      $form = new XocpThemeForm(_PRJ_ADDFORM, "projectaddform", "index.php","post",TRUE);
      
      if($prj_id>0) {
         $sql = "SELECT a.prj_nm,a.description,a.priority_cd,b.org_nm,c.prj_nm,a.phase_set,a.base_cur FROM ".XOCP_PREFIX."prj_projects a"
              . " LEFT JOIN ".XOCP_PREFIX."orgs b ON b.org_id = a.par_org_id"
              . " LEFT JOIN ".XOCP_PREFIX."prj_projects c ON c.prj_id = a.par_prj_id AND c.org_id = a.par_org_id"
              . " WHERE a.org_id = '$prj_ses_org_id' AND a.prj_id = '$prj_id'";
         $result = $db->query($sql);
         list($prj_nm,$description,$priority_cd,$par_org_nm,$par_prj_nm,$phase_set,$base_cur) = $db->fetchRow($result);
         $hprj_id  = new XocpFormHidden("prj_id", $prj_id);
         $hedit  = new XocpFormHidden("edit", "y");
         $form->addElement($hedit);
      } else {
         $sql = "SELECT max(prj_id) FROM ".XOCP_PREFIX."prj_projects a"
              . " WHERE org_id = '$prj_ses_org_id'";
         $result = $db->query($sql);
         list($max_prj_id) = $db->fetchRow($result);
         $max_prj_id++;
         $sql = "INSERT INTO ".XOCP_PREFIX."prj_projects (org_id,prj_id,prj_nm,created,modified)"
              . " VALUES('$prj_ses_org_id','$max_prj_id','noname$max_prj_id',now(),now())";
         $db->query($sql);
         $hprj_id  = new XocpFormHidden("prj_id", $max_prj_id);
      }


      $prj_nm   = new XocpFormText(_PRJ_PROJECTNAME, "prj_nm", 40, 100, "$prj_nm");
      $description = new XocpFormTextArea(_PRJ_PROJECTDESCRIPTION, "description",$description);
      $priority_cd+=0;
      $priority   = new XocpFormRadio(_PRJ_PROJECTPRIORITY, "priority_cd",$priority_cd);
      $priority->addOption("0",_PRJ_HIGHPRIORITY);
      $priority->addOption("1",_PRJ_MEDIUMPRIORITY);
      $priority->addOption("2",_PRJ_LOWPRIORITY);
      
      if($par_prj_nm != "") {
         $parent_txt = "<b>$par_prj_nm<br/>$par_org_nm</b><br/>";
      } else {
         $parent_txt = "<b>No Parent Project</b><br/>";
      }
      $parent   = new XocpFormLabel("", $parent_txt);
      $editparentbutton = new XocpFormButton("", "editparentproject", _EDIT, "submit");
      $deleteparentbutton = new XocpFormButton("", "deleteparentproject", _DELETE, "submit");
      $elementtray_parent = new XocpFormElementTray(_PRJ_PARENTPROJECT,"");
      $elementtray_parent->addElement($parent);
      $elementtray_parent->addElement($editparentbutton);
      $elementtray_parent->addElement($deleteparentbutton);
      
      $sql = "SELECT phase_set,phase_nm FROM ".XOCP_PREFIX."prj_phase_code"
           . " ORDER BY phase_set";
      $result = $db->query($sql);
      if($db->getRowsNum($result)>0) {
         $selectphase   = new XocpFormSelect("", "phase_set",$phase_set);
         while(list($phase_setx,$phase_nmx)=$db->fetchRow($result)) {
            $selectphase->addOption($phase_setx,$phase_nmx);
         }
      } else {
         $selectphase = new XocpFormLabel("",_PRJ_NO_PHASE_DEFINED);
      }
//      $editphasebutton = new XocpFormButton("", "editphase", _EDIT, "submit");
      $elementtray_phase = new XocpFormElementTray(_PRJ_PROJECTPHASE);
      $elementtray_phase->addElement($selectphase);
//      $elementtray_phase->addElement($editphasebutton);


      $sql = "SELECT curency_cd,curency_nm FROM ".XOCP_PREFIX."sys_curency_code"
           . " ORDER BY curency_cd";
      $result = $db->query($sql);
      if($db->getRowsNum($result)>0) {
         $selectcurency   = new XocpFormSelect(_PRJ_BASECURENCY, "curency_cd",$base_cur);
         while(list($curency_cd,$curency_nm)=$db->fetchRow($result)) {
            $selectcurency->addOption($curency_cd,$curency_nm);
         }
      } else {
         $selectcurency = new XocpFormLabel(_PRJ_BASECURENCY,_PRJ_NO_CURENCY_DEFINED);
      }


      $sql = "SELECT a.org_nm,c.org_id,c.org_nm from ".XOCP_PREFIX."orgs a"
           . " LEFT JOIN ".XOCP_PREFIX."prj_sublink b USING (org_id)"
           . " LEFT JOIN ".XOCP_PREFIX."orgs c ON c.org_id=b.sub_id"
           . " WHERE a.org_id = '$prj_ses_org_id' and b.prj_id = '$prj_ses_prj_id'"
           . " ORDER BY c.org_nm";
      $result = $db->query($sql);
      $c = $db->getRowsNum($result);
      if($c > 0) {
         while(list($org_nmx,$sub_id,$sub_nm) = $db->fetchRow($result)) {
            $subarray[$sub_id] = $sub_nm;
         }
      }
      
      $elementtray_subs = new XocpFormElementTray(_PRJ_ALLOWEDSUBLIST,"");
      if(is_array($subarray)) {
         reset($subarray);
         $n = 0;
         foreach($subarray as $sub_id=>$sub_nm) {
            if(empty($sub_nm)) continue;
            $ckbname = "sub$n";
            $xckb = new XocpFormCheckBox("",$ckbname);
            $xckb->addOption($sub_id,"<b>$sub_nm</b>");
            $elementtray_subs->addElement($xckb);
            $elementtray_subs->addElement(new XocpFormLabel("","<br/>"));
            $n++;
         }
      }

      if($n>0) {
         $delete_sub = new XocpFormButton("", "deletesub", _DELETE, "submit");
         $elementtray_subs->addElement($delete_sub);
         $elementtray_subs->addElement(new XocpFormLabel("","<br/>"));
      } else {
         $nosub = new XocpFormLabel("","<b>No organization allowed sub</b>");
         $elementtray_subs->addElement($nosub);
         $elementtray_subs->addElement(new XocpFormLabel("","<br/>"));
      }
      
      $elementtray_subs->addElement(new XocpFormLabel("","Select Organization"));
      $elementtray_subs->addElement(new XocpFormLabel("","<br/>"));

      $hidden_n = new XocpFormHidden("n",$n);
      
      $add_button = new XocpFormButton("", "addsub", _ADD, "submit");
      $selectsub = new XocpFormSelect("","addsub_id");
      $sql = "SELECT org_id,org_nm FROM ".XOCP_PREFIX."orgs"
           . " ORDER BY org_nm";
      $result = $db->query($sql);
      if($db->getRowsNum($result)>0) {
         while(list($org_id,$org_nm)=$db->fetchRow($result)) {
            $selectsub->addOption($org_id,$org_nm);
         }
      }
      
      $elementtray_subs->addElement($selectsub);
      $elementtray_subs->addElement(new XocpFormLabel("","<br/>"));
      $elementtray_subs->addElement($add_button);














      $submit_button = new XocpFormButton("", "saveproject", _SAVE, "submit");
      $reset_button = new XocpFormButton("", "resetproject", _RESET, "reset");

      $elementtray_buttons = new XocpFormElementTray("");
      $elementtray_buttons->addElement($submit_button);
      $elementtray_buttons->addElement($reset_button);

      $cancel_button = new XocpFormButton("", "cancelsaveproject", _CANCEL, "submit");
      $elementtray_buttons->addElement($cancel_button);

      if($prj_id>0) {
         $delete_button = new XocpFormButton("", "deleteproject", _DELETE, "submit");
         $elementtray_buttons->addElement($delete_button);
      }

      $hidden = new XocpFormHidden("X_project",$catch_id);

      $form->addElement($hprj_id);
      $form->addElement($prj_nm);
      $form->addElement($description);
      $form->addElement($priority);
      $form->addElement($elementtray_parent);
      $form->addElement($elementtray_phase);
      $form->addElement($selectcurency);

      $form->addElement($elementtray_subs);
      $form->addElement($hidden_n);


      $form->addElement($hidden);
      $form->addElement($elementtray_buttons);

      return $form->render();
      
   }
   
   function saveProject() {
      global $prj_ses_org_id,$HTTP_POST_VARS;
      $db =& Database::getInstance();
      $prj_id = $HTTP_POST_VARS["prj_id"];
      $prj_nm = $HTTP_POST_VARS["prj_nm"];
      if(trim($prj_nm) == "") $prj_nm = "noname$prj_id";
      $description = $HTTP_POST_VARS["description"];
      $priority_cd = $HTTP_POST_VARS["priority_cd"];
      $phase_set = $HTTP_POST_VARS["phase_set"];
      $base_cur = $HTTP_POST_VARS["curency_cd"];
      $sql = "UPDATE ".XOCP_PREFIX."prj_projects SET"
           . " prj_nm = '$prj_nm',"
           . " description = '$description',"
           . " priority_cd = '$priority_cd',"
           . " phase_set = '$phase_set',"
           . " base_cur = '$base_cur',"
           . " modified = now()"
           . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_id'";
      $db->query($sql);
      return $prj_id;
   }

   function show() {
      global $prj_ses_org_id,$prj_ses_prj_id,$HTTP_GET_VARS,$HTTP_POST_VARS,$xocp_page_id;
      switch ($this->catch) {
         case "7":
            $db =& Database::getInstance();
            if ($HTTP_GET_VARS["prj_id"] != "") {
               $prj_ses_prj_id = $HTTP_GET_VARS["prj_id"];
               $ret = $this->showPrj();
               $ret .= "<br />" .$this->editProjectForm($prj_ses_prj_id,7);
            } elseif ($HTTP_GET_VARS["ch"] == "y") {
               $prj_ses_prj_id = 0;
               $ret = "<br />".$this->formSelectPrj();
            } elseif ($HTTP_GET_VARS["addnewprojectbutton"] != "") {
               $ret = $this->showPrj();
               $ret .= "<br />" .$this->editProjectForm(0,7);
            } elseif ($HTTP_GET_VARS["selectproject"] != "") {
               $prj_id = $HTTP_GET_VARS["x"];
               $prj_ses_prj_id = $prj_id;
               $ret = $this->showPrj();
               $ret .= "<br />" .$this->editProjectForm($prj_ses_prj_id,7);
            } elseif ($HTTP_GET_VARS["editproject"] != "") {
               $prj_id = $HTTP_GET_VARS["x"];
               $prj_ses_prj_id = $prj_id;
               $ret = $this->showPrj();
               $ret .= "<br />" .$this->editProjectForm($prj_id,7);
            } elseif ($HTTP_POST_VARS["editparentproject"] != "") {
               $prj_ses_prj_id = $this->saveProject();
               $ret = $this->showPrj();
               $ret .= "<br />" .$this->formSelectOrg();
            } elseif ($HTTP_POST_VARS["deleteparentproject"] != "") {
               $prj_ses_prj_id = $this->saveProject();
               $sql = "UPDATE ".XOCP_PREFIX."prj_projects SET"
                    . " par_org_id = '0' AND par_prj_id = '0'"
                    . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id'";
               $db->query($sql);
               $ret = $this->showPrj();
               $ret .= "<br />" .$this->editProjectForm($prj_ses_prj_id,7);
            } elseif ($HTTP_GET_VARS["selectparentorg"] != "") {
               $org_id = $HTTP_GET_VARS["x"];
               $ret = $this->showPrj();
               $ret .= "<br />" .$this->formSelectParentPrj($org_id);
            } elseif ($HTTP_GET_VARS["selectparentproject"] != "") {
               $par_org_id = $HTTP_GET_VARS["x"];
               $par_prj_id = $HTTP_GET_VARS["y"];
               $sql = "UPDATE ".XOCP_PREFIX."prj_projects SET"
                    . " par_org_id = '$par_org_id',"
                    . " par_prj_id = '$par_prj_id',"
                    . " modified = now()"
                    . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id'";
               $db->query($sql);
               $ret = $this->showPrj();
               $ret .= "<br />" .$this->editProjectForm($prj_ses_prj_id,7);
            } elseif ($HTTP_POST_VARS["saveproject"] != "") {
               $prj_id = $this->saveProject();
               $prj_ses_prj_id = $prj_id;
               $ret = $this->showPrj();
               $ret .= "<br />" .$this->editProjectForm($prj_id,7);
            } elseif ($HTTP_POST_VARS["cancelsaveproject"] != "") {
               $prj_id = $HTTP_POST_VARS["prj_id"];
               if($HTTP_POST_VARS["edit"] != "y") {
                  $sql = "DELETE FROM ".XOCP_PREFIX."prj_projects"
                       . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_id'";
                  $db->query($sql);
                  $prj_ses_prj_id = 0;
                  $ret = "<br />".$this->formSelectPrj();
               } else {
                  $ret = $this->showPrj();
                  $ret .= "<br />" .$this->editProjectForm($prj_ses_prj_id,7);
               }
            } elseif ($HTTP_POST_VARS["deleteproject"] != "") {
               $prj_id = $HTTP_POST_VARS["prj_id"];
               $sql = "DELETE FROM ".XOCP_PREFIX."prj_projects"
                    . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_id'";
               $db->query($sql);
               $prj_ses_prj_id = 0;
               $ret = "<br />".$this->formSelectPrj()."<br/><br/>"._PRJ_PROJECTDELETED;










            } else if(!empty($HTTP_POST_VARS["addsub"])) {
               $sql = "INSERT INTO ".XOCP_PREFIX."prj_sublink (org_id,prj_id,sub_id)"
                    . " VALUES ('$prj_ses_org_id','$prj_ses_prj_id','".$HTTP_POST_VARS["addsub_id"]."')";
               $db->query($sql);
               $ret = $this->showPrj();
               $ret .= "<br />" .$this->editProjectForm($prj_ses_prj_id,7);
            } else if(!empty($HTTP_POST_VARS["deletesub"])) {
               $n = $HTTP_POST_VARS["n"];
               if($n>0) {
                  for($i=0;$i<$n;$i++) {
                     $sub_id = $HTTP_POST_VARS["sub$i"];
                     if($sub_id != '') {
                        $sql = "DELETE FROM ".XOCP_PREFIX."prj_sublink"
                             . " WHERE org_id = '$prj_ses_org_id' AND prj_id = '$prj_ses_prj_id' AND sub_id = '$sub_id'";
                        $db->query($sql);
                     }
                  }
               }
               $ret = $this->showPrj();
               $ret .= "<br />" .$this->editProjectForm($prj_ses_prj_id,7);









            } else {
               if($prj_ses_org_id>0) {
                  if (!session_is_registered("prj_ses_prj_id")) {
                     session_register("prj_ses_prj_id");
                     $prj_ses_prj_id = "0";
                  }
                  if($prj_ses_prj_id == "0") {
                     $ret = "<br />".$this->formSelectPrj();
                  } else {
                     $ret = $this->showPrj();
                     $ret .= "<br />" .$this->editProjectForm($prj_ses_prj_id,7);
                  }
               }
            }
            break;
         default:
            if($prj_ses_org_id>0) {
               if (!session_is_registered("prj_ses_prj_id")) {
                  session_register("prj_ses_prj_id");
                  $prj_ses_prj_id = "0";
               }
               if($prj_ses_prj_id == "0") {
                  $ret = "<br />".$this->formSelectPrj();
               } else {
                  $ret = $this->showPrj();
                  $ret .= "<br />" .$this->editProjectForm($prj_ses_prj_id,7);
               }
            }
            break;
      }
      return $ret;
   }
}

} // PROJECT_EDITPROJECT_DEFINED
?>