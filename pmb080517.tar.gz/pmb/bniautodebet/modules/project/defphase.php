<?php
//--------------------------------------------------------------------//
// Filename : modules/project/defphase.php                            //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2003-01-16                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('PRJ_DEFPHASE_DEFINED') ) {
   define('PRJ_DEFPHASE_DEFINED', TRUE);

include(XOCP_DOC_ROOT."/modules/project/forms.php");

class _project_DefPhase extends XocpBlock {
   var $width = "100%";
   
   function browse($f = NULL) {
      global $HTTP_GET_VARS;
      
         $db = Database::getInstance();
         $sql = "SELECT phase_set,phase_nm,description from ".XOCP_PREFIX."prj_phase_code"
              . " ORDER BY phase_set";
         $result = $db->query($sql);
         $found = $db->getRowsNum($result);
         if($found > 0) {
            $dp = new XocpDataPage();
            $dp->setPageSize(0);
            while($row=$db->fetchRow($result)) {
               $dp->addData($row);
            }
            $dp->reset();
         }

      $xurl = XOCP_SERVER_SUBDIR."/index.php?X_project=3";

      $addbuttonform = project_phaseaddbuttonform();
      $addbutton = $addbuttonform->render();
      $htable = new XocpSimpleTable();
      $sno = $htable->addRow(_SYS_GROUP_GROUPLIST." : $found "._FOUND,$addbutton);
      $htable->setCellAlign($sno,array("","right"));
      $htable->setWidth("100%");

      $ftable = new XocpSimpleTable();
      $sno = $ftable->addRow($addbutton);
      $ftable->setCellAlign($sno,array("right"));
      $ftable->setWidth("100%");

      $table = new XocpTable(1);
      $table->setWidth("100%");
      $hno = $table->addHeader($htable->render());
      $fno = $table->addFooter($ftable->render());
      
      
      if($found > 0) {
         $no = 1;
         $data = $dp->retrieve();
         foreach($data as $x) {
            list($phase_set,$phase_nm,$desc) = $x;
            $rno = $table->addRow("$phase_set. <b><a href=$xurl&edit=y&x=$phase_set".">$phase_nm</a></b><br/>$desc");
            $no++;
         }
      }

      return $table->render();

   }
   
   function main() {
      global $ses_ind_org;
      switch($this->catch) {
         case "3" :
            global $HTTP_POST_VARS,$HTTP_GET_VARS;
            if($HTTP_POST_VARS["addnewphasebutton"] != "") {
               $form = project_addphaseform(3);
               $ret .= $form->render();
               break;
            } else if($HTTP_GET_VARS["edit"] == "y") {
               $form = project_editphaseform($HTTP_GET_VARS["x"],3);
               $ret .= $form->render();
               break;
            } else if(!empty($HTTP_POST_VARS["newphase"])) {
               $db =& Database::getInstance();
               $phase_nm = trim($HTTP_POST_VARS["phase_nm"]);
               $description = trim($HTTP_POST_VARS["description"]);
               $sql = "INSERT INTO ".XOCP_PREFIX."prj_phase_code(phase_set,phase_nm,description)"
                    . " VALUES (NULL,'$phase_nm','$description')";
               $db->query($sql);
               $ret .= $this->browse();
               break;
            } else if(!empty($HTTP_POST_VARS["updatephase"])) {
               $db =& Database::getInstance();
               $phase_set = trim($HTTP_POST_VARS["phase_set"]);
               $phase_nm = trim($HTTP_POST_VARS["phase_nm"]);
               $description = trim($HTTP_POST_VARS["description"]);
               $sql = "UPDATE ".XOCP_PREFIX."prj_phase_code SET description = '$description',"
                    . "phase_nm = '$phase_nm'"
                    . " WHERE phase_set = '$phase_set'";
               $db->query($sql);
               $ret .= $this->browse();
               break;
            } else if (!empty($HTTP_POST_VARS["deletephase"])) {
               $db =& Database::getInstance();
               $phase_set = trim($HTTP_POST_VARS["phase_set"]);
               $sql = "DELETE FROM ".XOCP_PREFIX."prj_phase_code WHERE phase_set = '$phase_set'";
               $db->query($sql);
               $ret .= $this->browse();
               break;
            }

         default : 
            $ret .= $this->browse();
      }
      
      return "<b>" . _SYS_GROUP_PGROUPADMIN . "</b><br/><br/>" . $ret;
      
   }
   
}

} // PRJ_DEFPHASE_DEFINED
?>