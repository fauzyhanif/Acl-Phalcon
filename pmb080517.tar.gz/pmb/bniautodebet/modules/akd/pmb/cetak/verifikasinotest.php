<?php
//--------------------------------------------------------------------//
// Filename : modules/akd/pmb/cetak/varifikasinotest.php              //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-13                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//
if ( !defined('AKD_PMBCETAK_VERIFIKASINOTEST_DEFINED') ) {
   define('AKD_PMBCETAK_VERIFIKASINOTEST_DEFINED', TRUE);


include_once(XOCP_DOC_ROOT."/modules/akd/modconsts.php");

class _akd_PMBVerifikasiNotest extends XocpBlock {
   var $catchvar = _AKD_CATCH_VAR;
   var $blockID = _AKD_PMBCETAK_VERIFIKASINOTEST_BLOCK;
   var $width = "100%";
   
   
   function searchForm() {
      global $HTTP_GET_VARS;
      
      $sno_testx = $HTTP_GET_VARS["sno_testx"];
      $spinx = $HTTP_GET_VARS["spinx"];
      $org_id = XOCP_ORGANIZATION_ID;
      $thn_akd = "2003";
      $pmb_ses_id = "2";
      $jalur = "1";
      
      $db = &Database::getInstance();
      

      $form = new XocpThemeForm("Pencatatan Penjualan Nomor Tes","sf","index.php","get");
      
      $form->addElement(new XocpFormText("Nomor Tes","sno_testx",30,15));
      $form->addElement(new XocpFormText("P I N","spinx",30,4));
      $form->addElement(new XocpFormButton("","searchnotest","Rekam","submit"));
      $form->addElement($this->varForm());
      $this->html->setBodyOnload(" onload=\"document.sf.sno_testx.focus();\"");
      
      $table = new XocpTable(1);
      $table->setWidth("100%");
      $hrow = $table->addHeader($form->render());
      $table->setCellAlign($hrow,"center");
      $table->setColSpan($hrow,9);

      if ($sno_testx != "") {
         $sql = "SELECT a.cetakform"
              . " FROM ".XOCP_PREFIX."akd_pmb_cmhs a, ".XOCP_PREFIX."users b"
              . " WHERE a.no_test_riil = b.user_nm and a.org_id = '$org_id' AND a.thn_akd = '$thn_akd' AND a.pmb_ses_id = '$pmb_ses_id'"
              . " and a.jalur = '$jalur' AND concat(a.jalur,a.pmb_ses_id,a.kelompok_cd,a.no_test) = '$sno_testx' and b.pwd1 = '$spinx'";
         $result = $db->query($sql);

         if($db->getRowsNum($result) > 0) {
            $sql = "UPDATE ".XOCP_PREFIX."akd_pmb_cmhs SET cetakform = '1',tgljual = '2003-06-26' WHERE no_test_riil = '$sno_testx'";
            $db->query($sql);
            $form->setComment("Nomor Tes $sno_testx berhasil direkam");
         } else {
            $this->html->setBodyOnLoad("onload='alert(\"Nomor Tes tidak ada!\");'");
            $form->setComment("Nomor Tes $sno_testx tidak ditemukan");
         }
      }
      
      return $form->render();
   }

   function main() {
      global $HTTP_POST_VARS,$HTTP_GET_VARS;
      
      $org_id = XOCP_ORGANIZATION_ID;
      $thn_akd = "2003";
      $pmb_ses_id = "1";

      $db =& Database::getInstance();

      switch($this->catch) {
         case _AKD_PMBCETAK_VERIFIKASINOTEST_BLOCK:
            if ($HTTP_GET_VARS["sno_testx"] != '') {
               $ret = $this->searchForm();
            } else {
               $ret = $this->searchForm();
            }
            break;
         default :
            $ret = $this->searchForm();
            break;
      }
      return $ret;
   }

}


} // AKD_PMBCETAK_VERIFIKASONOTEST_DEFINED
?>