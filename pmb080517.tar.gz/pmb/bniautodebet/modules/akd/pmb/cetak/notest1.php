<?php
//--------------------------------------------------------------------//
// Filename : modules/akd/pmb/cetak/notest.php                        //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-13                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//
if ( !defined('AKD_PMBCETAK_NOTEST_DEFINED') ) {
   define('AKD_PMBCETAK_NOTEST_DEFINED', TRUE);
   
//   define("XOCP_CONFIG_INCLUDED",1);

include_once("/var/www/html/config.php");
include_once(XOCP_DOC_ROOT."/modules/akd/modconsts.php");

class _akd_PMBCetakNotest extends XocpBlock {
   var $width = "100%";
   var $catchvar = _AKD_CATCH_VAR;
   var $blockID = _AKD_PMBCETAK_NOTEST_BLOCK;
   var $jscript;
                
   function displaySelection(&$params) {
      $db =& Database::getInstance();
      $org_id = $params["org_id"];
      $thn_akd = $params["thn_akd"];
      $pmb_ses_id = $params["pmb_ses_id"];
      $jalur = $params["jalur"];
      $arr_no_test = $params["no_test"];
              
      $form = new XocpThemeForm(_AKD_PMBCETAK_NOTEST_TITLE,"fnotest","index.php","post");
      $hidden_kelompok = new XocpFormHidden("kelompok_cd","");
      $form->addElement($hidden_kelompok);
      $form->addElement($this->varForm());
      
      $sql1 = "SELECT kelompok_cd,kelompok_nm FROM ".XOCP_PREFIX
            . "akd_pmb_ses_kelompok WHERE org_id = '$org_id' "
            . "AND thn_akd = '$thn_akd' AND pmb_ses_id = '$pmb_ses_id' "
            . "ORDER BY kelompok_cd";
      $result1 = $db->query($sql1);
      while ($row1 = $db->fetchRow($result1)) {
         list($kelompok_cd,$kelompok_nm) = $row1;
         $arr_no_test["$kelompok_cd"]["kelompok_cd"] = $kelompok_cd;
         $arr_no_test["$kelompok_cd"]["kelompok_nm"] = $kelompok_nm;
         if ($arr_no_test["$kelompok_cd"]["print"]) {
            $script =
"<script language='JScript'>
var data = new Array(";
            for ($i = 0; $i < $arr_no_test["$kelompok_cd"]["range"]; $i++) {
               $sql = "SELECT MAX(no_test) FROM ".XOCP_PREFIX."akd_pmb_cmhs"
                    . " WHERE pmb_ses_id = '$pmb_ses_id'"
                    . " AND kelompok_cd = '$kelompok_cd'"
                    . " AND jalur = '$jalur'"
                    . " AND thn_akd = '$thn_akd'"
                    . " AND org_id = '$org_id'";
               $result = $db->query($sql);
               list($no_test_max) = $db->fetchRow($result);
               $no_test_max++;
               $no_test_max = sprintf("%04d",$no_test_max);
               $pin = substr(uniqid(rand()),0,4);
               $user_nm = $jalur.$pmb_ses_id.$kelompok_cd.$no_test_max;
               $nomor = $jalur.$pmb_ses_id.$kelompok_cd.$no_test_max;

               //$sql = "INSERT INTO ".XOCP_PREFIX."persons (ext_id) VALUES ('$user_nm')";
               //$result = $db->query($sql);
               //$person_id = $db->getInsertId();

               $sql = "INSERT INTO ".XOCP_PREFIX."users (user_nm,pwd0,pwd1,status_cd)"
                    . " VALUES ('$user_nm',md5('$pin'),'$pin','active')";
               $result = $db->query($sql);
               $user_id = $db->getInsertId();

               $sql = "INSERT INTO ".XOCP_PREFIX."akd_pmb_cmhs"
                    . " (org_id,thn_akd,jalur,pmb_ses_id,kelompok_cd,no_test,pin,"
                    . "no_test_riil,cetakform,tgljual)"
                    . " VALUES ('$org_id','$thn_akd','$jalur'"
                    . ",'$pmb_ses_id','$kelompok_cd','$no_test_max','$pin','$nomor',1,NOW())";
               $db->query($sql);

               $sql = "INSERT INTO ".XOCP_PREFIX."user_pgroup (user_id,pgroup_id)"
                    . " VALUES ('$user_id','4')";
               $result = $db->query($sql);
               $script .= "\"$nomor\",\"$pin\",";
            }
            $script = substr($script,0,-1).");\n</script>";
            $arr_no_test["$kelompok_cd"]["no_test"] = $nomor;
            $arr_no_test["$kelompok_cd"]["print"] = FALSE;

            $this->html->addScript($script);
            $this->html->addScript($this->jscript);
            //$this->html->setBodyOnLoad("onload='print(\"$thn_akd/".($thn_akd + 1)."\",\"$pmb_ses_id\",\"".sprintf("%-11s",$kelompok_nm)."\",\"$nomor\",\"$pin\",\"".sprintf("%-17s",sql2ind2(date("Y-m-d")))."\");'");
            //$this->html->setBodyOnLoad("onload='massPrint(\"$thn_akd/".($thn_akd + 1)."\",\"$pmb_ses_id\",\"".sprintf("%-11s",$kelompok_nm)."\",\"".sprintf("%-17s",sql2ind2(date("Y-m-d")))."\");'");
            $this->html->setBodyOnLoad("onload='massPrint(\"$thn_akd/".($thn_akd + 1)."\",\"$pmb_ses_id\",\"".sprintf("%-11s",$kelompok_nm)."\",\"".sprintf("%-17s","   ")."\");'");
         }
         if ($arr_no_test["$kelompok_cd"]["no_test"] == "") {
            $arr_no_test["$kelompok_cd"]["no_test"] = _AKD_PMBCETAK_NOTEST_LASTTESTNONONE;
         }
         if ($arr_no_test["$kelompok_cd"]["range"] == "") {
            $arr_no_test["$kelompok_cd"]["range"] = 1;
         }
         $msg = _AKD_PMBCETAK_NOTEST_LASTTESTNO.$arr_no_test["$kelompok_cd"]["no_test"];
         $text = new XocpFormText("","range_".$kelompok_cd,10,10,$arr_no_test["$kelompok_cd"]["range"]);
         //$text->setExtra("onblur='document.fnotest.button_$kelompok_cd.blur();'");
         $label = new XocpFormLabel("",$msg."<br />"._AKD_PMBCETAK_NOTEST_COUNTTESTNO.$text->render()."<br />");
         $button = new XocpFormButton("","button_".$kelompok_cd,_AKD_PMBCETAK_NOTEST_CETAK,"submit");
         $button->setExtra("onclick='document.fnotest.kelompok_cd.value=\"$kelompok_cd\";'");
         $elementtray = new XocpFormElementTray($kelompok_nm,"<br />");
         $elementtray->addElement($label);
         $elementtray->addElement($button);
         $form->addElement($elementtray);
      }
      $params["no_test"] = $arr_no_test;
      
      return $form->render();
   }
   
   function main() {
      global $HTTP_POST_VARS,$HTTP_GET_VARS,$sesv_akd_pmb_cetak_notest_params;
      $db =& Database::getInstance();

      $this->jscript =
'<script language=\'JScript\'>
function repChar(s,num) {
   var t,i;
   t = "";
   for (i = 0; i < num; i++) {
      t = t + s;
   }
   return t;
}

function print(thn_akd,pmb_ses_id,kelompok_nm,no_test,pin,tanggal) {
   var fso,prn;
   var ForWriting = 2;
   fso = new ActiveXObject("Scripting.FileSystemObject");
   prn = fso.OpenTextFile("\\prn",ForWriting,true);
   // Init printer
   prn.Write(String.fromCharCode(27,64));
   // Set printing style - draft
   prn.Write(String.fromCharCode(27,120,0));
   // Set printing style - condensed
   prn.Write(String.fromCharCode(27,33,4));
   // Set page length
   prn.Write(String.fromCharCode(27,67,22));
   // Set left margin
   prn.Write(String.fromCharCode(27,108,0));
   // Set right margin
   prn.Write(String.fromCharCode(27,81,160));
   prn.Write("           YAYASAN KEJUANGAN PANGLIMA BESAR SUDIRMAN                     ");
   // Set printing style - 12 cpi, emphasized
   prn.Write(String.fromCharCode(27,33,9));
   prn.Write("PERHATIAN");
   // Set printing style - condensed
   prn.Write(String.fromCharCode(27,33,4));
   prn.Write(repChar(String.fromCharCode(27,8),75));
   prn.WriteLine("                                                              _______________________________________________________________");
   prn.WriteLine("           UNIVERSITAS PEMBANGUNAN NASIONAL \'VETERAN\'");
   prn.Write("                      J O G J A K A R T A                                ");
   // Set printing style - 12 cpi, emphasized
   prn.Write(String.fromCharCode(27,33,9));
   prn.Write("1. Tunjukkan KARTU PEMBELIAN ini pada saat");
   // Set printing style - condensed
   prn.Write(String.fromCharCode(27,33,4));
   prn.Write(repChar(String.fromCharCode(27,8),160));
   prn.WriteLine("________________________________________________________________");
   prn.Write("PMB - " + thn_akd + " GEL. " + pmb_ses_id + "                           KARTU PEMBELIAN         ");
   // Set printing style - 12 cpi, emphasized
   prn.Write(String.fromCharCode(27,33,9));
   prn.Write("   mengembalikan formulir pendaftaran.");
   // Set printing style - condensed
   prn.Write(String.fromCharCode(27,33,4));
   prn.WriteLine("");
   prn.WriteLine("");
   prn.Write("Saudara telah membeli formulir pendaftaran dengan NOMOR TES,             ");
   // Set printing style - 12 cpi, emphasized
   prn.Write(String.fromCharCode(27,33,9));
   prn.Write("2. NOMOR TES tersebut harus Saudara isikan");
   // Set printing style - condensed
   prn.Write(String.fromCharCode(27,33,4));
   prn.Write(repChar(String.fromCharCode(27,8),160));
   prn.WriteLine("");
   prn.Write("PIN, dan KELOMPOK sebagai berikut:                                       ");
   // Set printing style - 12 cpi, emphasized
   prn.Write(String.fromCharCode(27,33,9));
   prn.Write("   pada formulir pendaftaran (scan form).");
   // Set printing style - condensed
   prn.Write(String.fromCharCode(27,33,4));
   prn.Write(repChar(String.fromCharCode(27,8),160));
   prn.WriteLine("");
   prn.WriteLine("");

   // Set printing style - 12 cpi, emphasized
   prn.Write(String.fromCharCode(27,33,9));
   prn.WriteLine("   NOMOR TES  : " + no_test + "     KELOMPOK               3. NOMOR TES dan PIN tersebut dapat Saudara");
   prn.WriteLine("   P I N      : " + pin + "        " + kelompok_nm + "               gunakan untuk mengakses data pendaftaran");
   // Set printing style - condensed
   prn.Write(String.fromCharCode(27,33,4));
   prn.Write("                                                                         ");
   // Set printing style - 12 cpi, emphasized
   prn.Write(String.fromCharCode(27,33,9));
   prn.Write("   Saudara melalui Internet.");
   // Set printing style - condensed
   prn.Write(String.fromCharCode(27,33,4));
   prn.Write(repChar(String.fromCharCode(27,8),160));
   prn.WriteLine("");
   prn.WriteLine("Ingatlah kedua nomor tersebut (simpan kartu ini dengan baik).");
   prn.Write("                                                                         ");
   // Set printing style - 12 cpi, emphasized
   prn.Write(String.fromCharCode(27,33,9));
   prn.Write("4. Perhatikan KELOMPOK formulir Saudara.");
   // Set printing style - condensed
   prn.Write(String.fromCharCode(27,33,4));
   prn.Write(repChar(String.fromCharCode(27,8),160));
   prn.WriteLine("");

   prn.Write("                                                                         ");
   // Set printing style - 12 cpi, emphasized
   prn.Write(String.fromCharCode(27,33,9));
   prn.Write("   Pilihan jurusan harus sesuai dengan");
   // Set printing style - condensed
   prn.Write(String.fromCharCode(27,33,4));
   prn.Write(repChar(String.fromCharCode(27,8),160));
   prn.WriteLine("");
   prn.Write("                                  Jogjakarta, " + tanggal + "          ");
   // Set printing style - 12 cpi, emphasized
   prn.Write(String.fromCharCode(27,33,9));
   prn.Write("   kelompoknya. Jika tidak sesuai maka tidak");
   // Set printing style - condensed
   prn.Write(String.fromCharCode(27,33,4));
   prn.Write(repChar(String.fromCharCode(27,8),160));
   prn.WriteLine("");
   prn.Write("                                  Petugas Pendaftar                      ");
   // Set printing style - 12 cpi, emphasized
   prn.Write(String.fromCharCode(27,33,9));
   prn.Write("   akan diproses.");
   // Set printing style - condensed
   prn.Write(String.fromCharCode(27,33,4));
   prn.Write(repChar(String.fromCharCode(27,8),160));
   prn.WriteLine("");
   prn.WriteLine("        Cap");
   prn.WriteLine("        UPN");
   prn.WriteLine("                                  ________________________");
   prn.Write(String.fromCharCode(27,12));
}

function massPrint(thn_akd,pmb_ses_id,kelompok_nm,tanggal) {
   var i;
   for (i = 0; i < data.length - 1; i = i + 2) {
      print(thn_akd,pmb_ses_id,kelompok_nm,data[i],data[i + 1],tanggal);
   }
}
</script>';
      switch ($this->catch) {
         case _AKD_PMBCETAK_NOTEST_BLOCK:
           if ($HTTP_POST_VARS["kelompok_cd"] != "") {
              $kelompok_cd = $HTTP_POST_VARS["kelompok_cd"];
              if (is_numeric($HTTP_POST_VARS["range_".$kelompok_cd])) {
                 $sesv_akd_pmb_cetak_notest_params["no_test"]["$kelompok_cd"]["range"] = $HTTP_POST_VARS["range_".$kelompok_cd];
              } else {
                 $sesv_akd_pmb_cetak_notest_params["no_test"]["$kelompok_cd"]["range"] = "1";
              }
              $sesv_akd_pmb_cetak_notest_params["no_test"]["$kelompok_cd"]["print"] = TRUE;
              $ret = $this->displaySelection($sesv_akd_pmb_cetak_notest_params);
           } else {
              $ret = $this->displaySelection($sesv_akd_pmb_cetak_notest_params);
           }
           break;
         default:
           if (!session_is_registered("sesv_akd_pmb_cetak_notest_params")) {
              session_register("sesv_akd_pmb_cetak_notest_params");
              $sesv_akd_pmb_cetak_notest_params = array();
              
              $sesv_akd_pmb_cetak_notest_params["org_id"] = "1";
              $sesv_akd_pmb_cetak_notest_params["thn_akd"] = "2003";
              $sesv_akd_pmb_cetak_notest_params["pmb_ses_id"] = "2";
              $sesv_akd_pmb_cetak_notest_params["jalur"] = "1";
              $sesv_akd_pmb_cetak_notest_params["no_test"] = array();
           }
           $ret = $this->displaySelection($sesv_akd_pmb_cetak_notest_params);
           break;
      }
      return $ret;
   }
  
}
 
} // AKD_PMBCETAK_NOTEST_DEFINED
?>