<?php
//--------------------------------------------------------------------//
// Filename : modules/akd/pmb/cetak/suratlulus.php                    //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-13                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//
if ( !defined('AKD_PMBCETAK_SURATLULUS_DEFINED') ) {
   define('AKD_PMBCETAK_SURATLULUS_DEFINED', TRUE);


include_once(XOCP_DOC_ROOT."/modules/akd/modconsts.php");

class _akd_PMBCetakLulus extends XocpBlock {
   var $catchvar = _AKD_CATCH_VAR;
   var $blockID = _AKD_PMBCETAK_SURATLULUS_BLOCK;
   var $width = "100%";

   function printForm() {
      global $HTTP_POST_VARS;
      $org_id = XOCP_ORGANIZATION_ID;
      $thn_akd = "2003";
      $pmb_ses_id = "2";
      
      $ps_id_lls = $HTTP_POST_VARS["ps_id_lls"];
      $status_lls = $HTTP_POST_VARS["status_lls"];
      $notestx = $HTTP_POST_VARS["notestx"];
      $startp = $HTTP_POST_VARS["startp"];
      $stopp = $HTTP_POST_VARS["stopp"];
      $pages = $HTTP_POST_VARS["pages"];
      
      if($status_lls == '') {
         $status_lls = "REGULER";
      }

      $db = &Database::getInstance();
      $sql = "SELECT ps_id,ps_ext_id,nama_ps,nama_fak,jmlmhs,akreditasi FROM ".XOCP_PREFIX."akd_ps"
           . " ORDER BY ps_id";
      $result = $db->query($sql);
      while(list($ps_id,$ps_ext_id,$nama_ps,$nama_fak,$jmlmhs,$akreditasi)=$db->fetchRow($result)) {
         $ps[$ps_id] = "$ps_ext_id - $nama_ps";
      }
      
////////////////////////////////////////////////////////////////////////////////      
      $form = new XocpThemeForm("CETAK SURAT TANDA LULUS","printform",XOCP_SERVER_SUBDIR."/index.php","post");
      $form->setTheme(1);
      $this->html->setBodyOnload(" onload=\"document.printform.startp.focus();\"");

      $fpages = new XocpFormText("Halaman","pages",30,100,$pages);
      $fnotestx = new XocpFormText("Nomor Test","notestx",30,100,$notestx);
      $fstart = new XocpFormText("Mulai Halaman","startp",30,100,$startp);
      $fstop = new XocpFormText("Sampai Halaman","stopp",30,100,$stopp);
      $fps_id = new XocpFormSelect("Program Studi","ps_id_lls",$ps_id_lls);
      $fps_id->addOptionArray($ps);

      
      $buttontray = new XocpFormElementTray("");
      $submit_button = new XocpFormButton("","docetak",_PRINT,"submit");
      $buttontray->addElement($submit_button);
      
      $form->addElement($fnotestx);
      $form->addElement($fstart);
      $form->addElement($fstop);
      $form->addElement($fps_id);
      $form->addElement($buttontray);
      $form->addElement($this->varForm());
      
////////////////////////////////////////////////////////////////////////////////      
      return $form->render();
      
   }
   
   function cetak() {
      $db = &Database::getInstance();
   
      global $HTTP_POST_VARS;
      $org_id = XOCP_ORGANIZATION_ID;
      $thn_akd = "2003";
      $pmb_ses_id = "2";
            
      $ps_id_lls = $HTTP_POST_VARS["ps_id_lls"];
      $status_lls = $HTTP_POST_VARS["status_lls"];
      $notestx = trim($HTTP_POST_VARS["notestx"]);
      $startp = $HTTP_POST_VARS["startp"];
      $stopp = $HTTP_POST_VARS["stopp"];
      $pages = $HTTP_POST_VARS["pages"];
      
//      if($pages != '') {
//         $options = "-o page-ranges=$pages";
//      }
      
/* ///////////////// UPDATE DANA PS 3
      $sql = "select notest,dpp from fp3";
      $result = $db->query($sql);
      while(list($notest,$dpp)=$db->fetchRow($result)) {
         $sql = "update xocp_akd_pmb_cmhs set dana_ps3 = '$dpp' where no_test_riil = '$notest'";
         $db->query($sql);
      }
*/
      if($notestx != '') {
         $qnotest = "and a.no_test_riil = '$notestx'";
      } else {
         $qnotest = "";
      }
      
      $filename = XOCP_DOC_ROOT."/tmp/prn" . uniqid(rand());
      
      if($status_lls == "REGULER") {
         $qps_id_lls = "d.ps_id = '$ps_id_lls'";
         $jps_id = "d.ps_id";
      } elseif ($status_lls == "PBUD") {
         $qps_id_lls = "a.ps_id_lls = '$ps_id_lls'";
         $jps_id = "a.ps_id_lls";
      } elseif ($status_lls == "PBUD3TL") {
         $qps_id_lls = "a.ps_id_lls = '$ps_id_lls'";
         $jps_id = "a.ps_id_lls";
         $qpbud3 = "and a.status_lls = 'PBUD3TL'";
      }
      
      $sql = "select concat(a.jalur,a.pmb_ses_id,a.kelompok_cd,a.no_test) as notest,
             a.no_test_riil,
             a.nama_cmhs,
             a.golongan_cd as go,
             b.nama_ps,
             b.nama_fak,
             c.kode_byr as kk,
             c.nama_byr,
             c.jml_uang,
             c.periode,
             c.unit,
             c.unit_paket,
             a.dana_ps1,
             a.dana_ps2,
             a.dana_ps3,
             a.ps_id_lls,
             a.pilihanke,
             a.status_lls
        from xocp_akd_pmb_cmhs a
         left join xocp_akd_ps b on b.ps_id = a.ps_id_lls
         left join spp c on c.jur = b.ps_ext_id
             and c.golongan_cd = a.golongan_cd
             and c.pmb_ses_id = a.pmb_ses_id
         where a.ps_id_lls = '$ps_id_lls'
            and a.pmb_ses_id = '$pmb_ses_id'
            and a.thn_akd = '$thn_akd'
            and a.org_id = '$org_id'
             $qnotest
         order by notest";

      $result = $db->query($sql);
      if($db->getRowsNum($result)>0 && $fd = fopen($filename,"w+")) {
         while(list($notest,
                    $no_test_riil,
                    $nama_cmhs,
                    $golongan_cd,
                    $nama_ps,
                    $nama_fak,
                    $kode_byr,
                    $nama_byr,
                    $jml_uang,
                    $periode,
                    $unit,
                    $unit_paket,
                    $dana_ps[1],
                    $dana_ps[2],
                    $dana_ps[3],
                    $ps_id,
                    $pilihanke,
                    $status_lls)=$db->fetchRow($result)) {
            $arrjml_uang[$notest][$kode_byr] = $jml_uang;
            $arrunit_paket[$notest][$kode_byr] = $unit_paket;
            $arrnama_ps[$notest] = $nama_ps;
            $arrnama_fak[$notest] = $nama_fak;
            $arrgolongan_cd[$notest] = $golongan_cd;
            $arrnama_cmhs[$notest] = $nama_cmhs;
            $arrnotest[$notest] = "y";
            $dppsukarela[$notest] = $dana_ps[$pilihanke];
            $notestriil[$notest] = $no_test_riil;
            $arrstatus_lls[$notest] = $status_lls;
         }
         
         
         if(is_array($arrnotest)) {
            reset($arrnotest);
            $i=0;
            foreach($arrnotest as $notest => $v) {
               $i++;
               if($i < $startp || $i > $stopp) continue;
               
               $status_lls = $arrstatus_lls[$notest];
               
               $DPP = $arrjml_uang[$notest]["50011"]
                    + $arrjml_uang[$notest]["50012"]
                    + $arrjml_uang[$notest]["50013"];
               if($status_lls == "REGULER") {
                  $DPP = $dppsukarela[$notest];
               }
               if($status_lls == "DISPENSASI") {
                  $DPP = $dppsukarela[$notest];
               }
               $SPPT = $arrjml_uang[$notest]["50021"]
                     + $arrjml_uang[$notest]["50022"]
                     + $arrjml_uang[$notest]["50023"];
               $SPPV = ($arrjml_uang[$notest]["50031"] * $arrunit_paket[$notest]["50031"])
                     + ($arrjml_uang[$notest]["50032"] * $arrunit_paket[$notest]["50032"]);
               $SPPT1 = $SPPT/2;
               $SPPT2 = $SPPT1;
               $DPP1  = $DPP/2;
               $DPP2  = $DPP1 * 0.8;
               $DPP3  = $DPP1 * 0.2;
               $SPPV1 = ($arrjml_uang[$notest]["50031"] * $arrunit_paket[$notest]["50031"]);
               $SPPV2 = ($arrjml_uang[$notest]["50032"] * $arrunit_paket[$notest]["50032"]);
               
               $NAMACMHS = $arrnama_cmhs[$notest];
               $NOTEST = $notest;
               $GOLONGAN = $arrgolongan_cd[$notest];
               $JURUSAN = $arrnama_ps[$notest];
               $FAKULTAS = $arrnama_fak[$notest];
               $ANGSURAN1 = $DPP1 + $SPPT1 + $SPPV1;
               $ANGSURAN2 = $DPP2 + $SPPT2 + $SPPV2;
               $JML = $DPP + $SPPT + $SPPV;
               
               $DPP = sprintf("%10s",number_format($DPP,0,",","."));
               $SPPT = sprintf("%10s",number_format($SPPT,0,",","."));
               $SPPV = sprintf("%10s",number_format($SPPV,0,",","."));
               $SPPT1 = sprintf("%10s",number_format($SPPT1,0,",","."));
               $SPPT2 = sprintf("%10s",number_format($SPPT2,0,",","."));
               $DPP1 = sprintf("%10s",number_format($DPP1,0,",","."));
               $DPP2 = sprintf("%10s",number_format($DPP2,0,",","."));
               $DPP3 = sprintf("%10s",number_format($DPP3,0,",","."));
               $SPPV1 = sprintf("%10s",number_format($SPPV1,0,",","."));
               $SPPV2 = sprintf("%10s",number_format($SPPV2,0,",","."));
               $ANGSURAN1 = sprintf("%10s",number_format($ANGSURAN1,0,",","."));
               $ANGSURAN2 = sprintf("%10s",number_format($ANGSURAN2,0,",","."));
               $JML = sprintf("%10s",number_format($JML,0,",","."));
               
               
               $lpout = "
 
 
 
 
 
 
 
 
 
                                                             
 
 
 
 
                 2003/2004                              II (dua)
 
                                    $NAMACMHS
                                    $NOTEST
                                    $GOLONGAN
                                    $JURUSAN
                                    $FAKULTAS
 
 
 
 
                                    29 Juli s.d 8 Agustus 2003
 
 
 
 
 
 
 
 
 
 
 
                                   Angsuran 1 (sem gasal) 29/7/2003
                                   DPP I   Rp $DPP1     s.d
             DPP*)   Rp $DPP SPP     Rp $SPPT1  8/8/2003
             SPP**)  Rp $SPPT SPPVar  Rp $SPPV1
             SPPVar  Rp $SPPV         -------------
                     -------------         Rp $ANGSURAN1
             Jumlah  Rp $JML Angsuran 2 (sem genap) 15/12/2003
                                   DPP II  Rp $DPP2     s.d
                                   SPP     Rp $SPPT2  16/1/2004
                                   SPPVar  Rp $SPPV2
                                           -------------
                                           Rp $ANGSURAN2
                                   Angsuran 3 (sem gasal) Sem. Gasal
                                   DPP III Rp $DPP3  TA. 2004/2005
 
 
 
 
 
 
 
                                                          27 Juli 2003
 
 
 
 


 
 
$i



";
               fwrite($fd,$lpout);
               //if($i>=2) break;
            }
            
            fclose($fd);
         }
         
         system("lpr -l $filename > /dev/null");
//       system("cat $filename > /dev/lp0");





      
      }
      
   }


   function main() {
      global $HTTP_POST_VARS,$HTTP_GET_VARS;
      
      $db =& Database::getInstance();

      switch($this->catch) {
         case _AKD_PMBCETAK_SURATLULUS_BLOCK:
            if($HTTP_POST_VARS["docetak"] != '') {
               $this->cetak();
            
               $ret = $this->printForm();
            } else {
               $ret = $this->printForm();
            }
            break;
         default :
            $ret = $this->printForm();
      }



      
      return $ret;
   }

}


} // AKD_PMBCETAK_SURATLULUS_DEFINED
?>