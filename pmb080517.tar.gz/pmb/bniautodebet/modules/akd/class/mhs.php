<?php
//--------------------------------------------------------------------//
// Filename : modules/akd/class/mhs.php                               //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-13                                              //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//
if ( !defined('AKD_CLASS_MHS_DEFINED') ) {
   define('AKD_CLASS_MHS_DEFINED', TRUE);

class _akd_cmhs {
   var $org_id;
   var $thn_akd;
   var $jalur;
   var $pmb_ses_id;
   var $kelompok_cd;
   var $no_test;
   var $no_test_riil;
   var $nama_cmhs;
   var $golongan_cd;
   var $ps_id1;
   var $ps_id2;
   var $ps_id3;
   var $dana_ps1;
   var $dana_ps2;
   var $dana_ps3;
   var $ps_id_lls;
   var $status_lls;
   var $pilihanke;
   var $tablename;
   var $nama_ps;
   var $nama_fak;

   function load($org_id,$thn_akd,$no_test_riil) {
      $this->org_id = $org_id;
      $this->thn_akd = $thn_akd;
      $this->no_test_riil = $no_test_riil;
      return $this->unserialize();
   }

   function reload() {
      return $this->unserialize();
   }

   function unserialize() {
      $db =& Database::getInstance();
      $sql = "SELECT a.jalur,a.pmb_ses_id,a.kelompok_cd,a.no_test,a.nama_cmhs,"
           . "a.golongan_cd,a.ps_id1,a.ps_id2,a.ps_id3,a.dana_ps1,a.dana_ps2,a.dana_ps3,"
           . "a.ps_id_lls,a.status_lls,a.pilihanke,b.nama_ps,b.nama_fak"
           . " FROM ".XOCP_PREFIX."akd_pmb_cmhs a"
           . " LEFT JOIN ".XOCP_PREFIX."akd_ps b ON b.org_id = a.org_id"
           . " AND b.ps_id = a.ps_id_lls"
           . " WHERE a.org_id = '".$this->org_id."'"
           . " AND a.thn_akd = '".$this->thn_akd."'"
           . " AND a.no_test_riil = '".$this->no_test_riil."'";
      $result = $db->query($sql);
      if($db->getRowsNum($result) == 1) {
         list($this->jalur,$this->pmb_ses_id,$this->kelompok_cd,$this->no_test,
              $this->nama_cmhs,$this->golongan_cd,$this->ps_id1,$this->ps_id2,
              $this->ps_id3,$this->dana_ps1,$this->dana_ps2,$this->dana_ps3,
              $this->ps_id_lls,$this->status_lls,$this->pilihanke,
              $this->nama_ps,$this->nama_fak)=$db->fetchRow($result);
         return TRUE;
      } else {
         return FALSE;
      }
   }

   function getDPP() {
      $dpp = "dana_ps" . $this->pilihanke;
      return array("5001",$this->$dpp);
   }

   function serialize() {

   }

   function parseTargetRule($target_rule) {
      list($thn_akd,$pmb_ses_id) = explode("/",$target_rule);
      return array($thn_akd,$pmb_ses_id);
   }

   function isTarget($target_rule) {
      // syntax
      // -*,(2003)/1         artinya: cmhs thn 2003 gelombang 1

      $arrtarget = explode(",",$target_rule);
      $counttarget = count($arrtarget);
      for($i=$counttarget-1;$i>=0;$i--) {
         $ctarget = $arrtarget[$i];

         if($ctarget[0] == '-') {
            $mode_negatif = 1;
            $ctarget = substr($ctarget,1);
         } else $mode_negatif = 0;

         list($ctarget,$pmb_ses_id) = explode("/",$ctarget);
         if($pmb_ses_id != '' && $this->pmb_ses_id != $pmb_ses_id) {
            $result = -1;
            return $result;
         }

         if($ctarget[0] == '(') {
            $mode_angkatan = 1;
            $ctarget = substr($ctarget,1,-1);
         } else $mode_angkatan = 0;

         $batas = explode("..",$ctarget);

         $result = 0;

         if(count($batas)==2) {
            if($mode_angkatan == 1) {
               if($this->thn_akd >= $batas[0] && $this->thn_akd <= $batas[1]) {
                  if($mode_negatif == 1) {
                     $result = -1;
                     break;
                  } else {
                     $result = 1;
                     break;
                  }
               }
            } else {
               if($this->no_test_riil >= $batas[0] && $this->no_test_riil <= $batas[1]) {
                  if($mode_negatif == 1) {
                     $result = -1;
                     break;
                  } else {
                     $result = 1;
                     break;
                  }
               }
            }
         } else {
            if($mode_angkatan == 1) {
               if($this->thn_akd == $ctarget) {
                  if($mode_negatif == 1) {
                     $result = -1;
                     break;
                  } else {
                     $result = 1;
                     break;
                  }
               }
            } else {
               if($this->no_test_riil == $ctarget) {
                  if($mode_negatif == 1) {
                     $result = -1;
                     break;
                  } else {
                     $result = 1;
                     break;
                  }
               } elseif ($ctarget == "*") {
                  if($mode_negatif == 1) {
                     $result = -1;
                     break;
                  } else {
                     $result = 1;
                     break;
                  }
               }
            }
         }
      } // for loop

      return $result;

   }
}


class _akd_mhs {
   var $org_id;
   var $psmhs_id;
   var $nomhs;
   var $nama_mhs;
   var $nama_ps;
   var $nama_fak;
   var $dpp;
   var $nomor_test;
   var $angkatan;
   var $golongan_cd;


   function load($nomor_test) {
      $org_id = XOCP_ORGANIZATION;
      $this->org_id = $org_id;
      $this->nomor_test = $nomor_test;
      return $this->unserialize();
   }

   function reload() {
      return $this->unserialize();
   }

   function unserialize() {
      $db =& Database::getInstance();

      $sql = "SELECT a.nama_mhs,a.nomhs,a.psmhs_id,a.angkatan,"
           . " a.golongan_cd,a.dpp,b.nama_ps,b.nama_fak"
           . " FROM ".XOCP_PREFIX."akd_mhs a"
           . " LEFT JOIN ".XOCP_PREFIX."akd_ps b ON b.ps_id = a.psmhs_id"
           . " WHERE a.nomor_test = '".$this->nomor_test."'"
           . " LIMIT 100";
      $result = $db->query($sql);
      if($db->getRowsNum($result) == 1) {
         list($this->nama_mhs,$this->nomhs,$this->psmhs_id,$this->angkatan,
              $this->golongan_cd,$this->dpp,$this->nama_ps,$this->nama_fak)=$db->fetchRow($result);
         return TRUE;
      } else {
         return FALSE;
      }
   }

   function getDPP() {
      return array("5001",$this->dpp);
   }

   function serialize() {

   }

   function parseTargetRule($target_rule) {
      list($thn_akd,$pmb_ses_id) = explode("/",$target_rule);
      return array($thn_akd,$pmb_ses_id);
   }

   function isTarget($target_rule) {
      // syntax
      // -*,(2003)/1         artinya: cmhs thn 2003 gelombang 1

      $arrtarget = explode(",",$target_rule);
      $counttarget = count($arrtarget);
      for($i=$counttarget-1;$i>=0;$i--) {
         $ctarget = $arrtarget[$i];

         if($ctarget[0] == '-') {
            $mode_negatif = 1;
            $ctarget = substr($ctarget,1);
         } else $mode_negatif = 0;

         list($ctarget,$pmb_ses_id) = explode("/",$ctarget);
         if($pmb_ses_id != '' && $this->pmb_ses_id != $pmb_ses_id) {
            //$result = -1;
            //return $result;
         }

         if($ctarget[0] == '(') {
            $mode_angkatan = 1;
            $ctarget = substr($ctarget,1,-1);
         } else $mode_angkatan = 0;

         $batas = explode("..",$ctarget);

         $result = 0;

         if(count($batas)==2) {
            if($mode_angkatan == 1) {
               if($this->angkatan >= $batas[0] && $this->angkatan <= $batas[1]) {
                  if($mode_negatif == 1) {
                     $result = -1;
                     break;
                  } else {
                     $result = 1;
                     break;
                  }
               }
            } else {
               if($this->nomor_test >= $batas[0] && $this->nomor_test <= $batas[1]) {
                  if($mode_negatif == 1) {
                     $result = -1;
                     break;
                  } else {
                     $result = 1;
                     break;
                  }
               }
            }
         } else {
            if($mode_angkatan == 1) {
               if($this->angkatan == $ctarget) {
                  if($mode_negatif == 1) {
                     $result = -1;
                     break;
                  } else {
                     $result = 1;
                     break;
                  }
               }
            } else {
               if($this->nomor_test == $ctarget) {
                  if($mode_negatif == 1) {
                     $result = -1;
                     break;
                  } else {
                     $result = 1;
                     break;
                  }
               } elseif ($ctarget == "*") {
                  if($mode_negatif == 1) {
                     $result = -1;
                     break;
                  } else {
                     $result = 1;
                     break;
                  }
               }
            }
         }
      } // for loop

      return $result;

   }
}


} // AKD_CLASS_MHS_DEFINED

?>