<?php
//--------------------------------------------------------------------//
// Filename : include/functions.php                                   //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-13                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined('XOCP_FUNCTIONS_DEFINED') ) {
   define('XOCP_FUNCTIONS_DEFINED', TRUE);

   // ################## Various functions from here ################

   function fromsqldate($sqldate) {
      ereg( "([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $sqldate, $regs );
      return  "$regs[3]-$regs[2]-$regs[1]";
   }

   function sql2ind($sqldate) {
      global $xocp_vars;
      $bulan = $xocp_vars['month_year'];
      ereg( "([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $sqldate, $regs );
      list ($full,$thn,$bln,$tgl) = $regs;
      $bln += 0;
      $tgl += 0;
      $thn += 0;
      if($thn == 0 || $tgl == 0 || $bln == 0) return "";
      return  "$tgl $bulan[$bln] $thn";
   }

   function sql2ind2($sqldate) {
      global $xocp_vars;
      $bulan = $xocp_vars['month_year'];
      ereg( "([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $sqldate, $regs );
      list ($full,$thn,$bln,$tgl) = $regs;
      $bln += 0;
      $bln = $bln == 0 ? "" : $bln;
      $tgl += 0;
      $tgl = $tgl == 0 ? "" : $tgl;
      $thn += 0;
      $thn = $thn == 0 ? "" : $thn;
      return trim("$tgl $bulan[$bln] $thn");
   }

   function debugit($cmd) {
      error_log("$cmd\n",3,XOCP_DOC_ROOT."/tmp/phplog1");
   }

   function mylog_secure($cmd) {
      error_log("$cmd\n",3,XOCP_DOC_ROOT."/tmp/phplog_secure");
   }

   function dumpit($var) {
      ob_start();
      print_r($var);
      debugit(ob_get_contents());
      ob_end_clean();
   }
   
   function catchVar($module) {
      global $HTTP_GET_VARS,$HTTP_POST_VARS,$HTTP_COOKIE_VARS,$HTTP_SESSION_VARS;
      global $xocp_page_id;

      foreach($HTTP_GET_VARS as $key => $val) {
         $v = explode("_",$key);
         if($v[0] == "X") {
            array_shift($v);
            $m_nm = implode("_",$v);
            if($m_nm == $module) {
               return $val;
            } else {
               return NULL;
            }
         } elseif ($v[0] == "XP") {
            array_shift($v);
            array_shift($v);
            $m_nm = implode("_",$v);
            if($m_nm == $module) {
               return $val;
            } else {
               return NULL;
            }
         }
      }

      foreach($HTTP_POST_VARS as $key => $val) {
         $v = explode("_",$key);
         if($v[0] == "X") {
            array_shift($v);
            $m_nm = implode("_",$v);
            if($m_nm == $module) {
               return $val;
            } else {
               return NULL;
            }
         } elseif ($v[0] == "XP") {
            array_shift($v);
            array_shift($v);
            $m_nm = implode("_",$v);
            if($m_nm == $module) {
               return $val;
            } else {
               return NULL;
            }
         }
      }
   }

   function catchPage() {
      global $HTTP_GET_VARS,$HTTP_POST_VARS,$HTTP_COOKIE_VARS,$HTTP_SESSION_VARS;
      global $xocp_page_id,$xocp_user,$xocp_groupname;

      foreach($HTTP_GET_VARS as $key => $val) {
         $v = explode("_",$key);
         if ($v[0] == "XP") {
            $xocp_page_id = $v[1];
            return;
         } elseif($v[0] == "XG") {
            $xocp_page_id = $val;
            $xocp_user->setVar("pgroup_id",$v[1]);
            $xocp_user->storeGroup();
            return;
         }
      }

      foreach($HTTP_POST_VARS as $key => $val) {
         $v = explode("_",$key);
         if ($v[0] == "XP") {
            $xocp_page_id = $v[1];
            return;
         } elseif($v[0] == "XG") {
            $xocp_page_id = $val;
            $xocp_user->setVar("pgroup_id",$v[1]);
            $xocp_user->storeGroup();
            return;
         }
      }
   }

   /*
    * Function to display formatted times in user timezone
    */
   function formatTimestamp($time, $format="l", $timeoffset="") {
      global $xocpConfig, $xocp_user;
      if ( $timeoffset == "" ) {
         if ( $xocp_user ) {
            $timeoffset = $xocp_user->getVar("timezone_offset");
         } else {
            $timeoffset = $xocpConfig['default_TZ'];
         }
      }
      $usertimestamp = $time + ($timeoffset - $xocpConfig['server_TZ'])*3600;
      if ( $format == "s" ) {
         $datestring = _SHORTDATESTRING;
      } elseif ( $format == "m" ) {
         $datestring = _MEDIUMDATESTRING;
      } elseif ( $format == "l" ) {
         $datestring = _DATESTRING;
      } elseif ( $format == "mysql" ) {
         $datestring = "Y-m-d H:i:s";
      } elseif ( $format != "" ) {
         $datestring = $format;
      } else {
         $datestring = _DATESTRING;
      }
      $datetime = date($datestring, $usertimestamp);
      $datetime = ucfirst($datetime);
      return $datetime;
   }

   /*
    * Function to calculate server timestamp from user entered time (timestamp)
    */
   function userTimeToServerTime($timestamp, $userTZ=NULL){
      global $xocpConfig;
      if ( !isset($userTZ) ) {
         $userTZ = $xocpConfig['default_TZ'];
      }
      $offset = $userTZ - $xocpConfig['server_TZ'];
      $timestamp = $timestamp - ($offset * 3600);
      return $timestamp;
   }


   function makePass() {
      $makepass="";
      $syllables = array("er","in","tia","wol","fe","pre","vet","jo","nes","al","len","son","cha","ir","ler","bo","ok","tio","nar","sim","ple","bla","ten","toe","cho","co","lat","spe","ak","er","po","co","lor","pen","cil","li","ght","wh","at","the","he","ck","is","mam","bo","no","fi","ve","any","way","pol","iti","cs","ra","dio","sou","rce","sea","rch","pa","per","com","bo","sp","eak","st","fi","rst","gr","oup","boy","ea","gle","tr","ail","bi","ble","brb","pri","dee","kay","en","be","se");
      srand((double)microtime()*1000000);
      for ($count=1;$count<=4;$count++) {
         if (rand()%10 == 1) {
            $makepass .= sprintf("%0.0f",(rand()%50)+1);
         } else {
            $makepass .= sprintf("%s",$syllables[rand()%62]);
         }
      }
      return $makepass;
   }

   function checkIp($ip){
      global $xocpBadIps;
      if ( !empty($xocpBadIps) ) {
         foreach ($xocpBadIps as $xbi) {
            if ( !empty($xbi) && preg_match("/".$xbi."/", $ip)) {
               return false;
            }
         }
      }
      return true;
   }

   function checkEmail($email){
      if (!$email || !eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+([\.][a-z0-9-]+)+$",$email)){
         return false;
      }
      return true;
   }

   function formatURL($url){
      if (($url != "") && (!(eregi('(^http[s]*:[/]+)(.*)', $url)))){
         $url = "http://" . $url;
      }
      return $url;
   }

   /*
   * Prints allowed html tags on this site
   */
   function get_allowed_html(){
      global $xocpConfig;
      $allowed = str_replace(">","> ",$xocpConfig['allowed_html']);
      return htmlspecialchars($allowed);
   }


   /*
   * Just a simple wrap to php mail() function
   */
   function xocp_mail($to, $subject, $message, $headers=""){
      global $xocpConfig;
      if ( $headers == "" ) {
         $headers = "From: ".$xocpConfig['sitename']." <".$xocpConfig['adminmail'].">\n";
         $headers .= "X-Mailer: PHP/".phpversion()."\n";
      }
      mail($to, $subject, $message, $headers);
   }

   /*
    * Function to display banners in all pages
    */
   function showbanner() {
      global $xocp_db, $xocpConfig, $REMOTE_ADDR;
      $bresult = $xocp_db->query("SELECT COUNT(*) FROM ".$xocp_db->prefix("banner")."");
      list ($numrows) = $xocp_db->fetchRow($bresult);
      if ( $numrows > 1 ) {
         $numrows = $numrows-1;
         mt_srand((double)microtime()*1000000);
         $bannum = mt_rand(0, $numrows);
      } else {
         $bannum = 0;
      }
      if ( $numrows > 0 ) {
         $bresult = $xocp_db->query("SELECT * FROM ".$xocp_db->prefix("banner")."",1,$bannum);
         list ($bid, $cid, $imptotal, $impmade, $clicks, $imageurl, $clickurl, $date) = $xocp_db->fetchRow($bresult);
         if ( $xocpConfig['my_ip']==$REMOTE_ADDR ) {
            // EMPTY
         } else {
            $xocp_db->queryF("UPDATE ".$xocp_db->prefix("banner")." SET impmade=impmade+1 WHERE bid=$bid");
         }
         /* Check if this impression is the last one and print the banner */
         if ( $imptotal == $impmade ) {
            $newid = $xocp_db->genId($xocp_db->prefix("bannerfinish")."_bid_seq");
            $xocp_db->queryF("INSERT INTO ".$xocp_db->prefix("bannerfinish")." (bid, cid, impressions, clicks, datestart, dateend) VALUES ($newid, $cid, $impmade, $clicks, $date, ".time().")");
            $xocp_db->queryF("DELETE FROM ".$xocp_db->prefix("banner")." WHERE bid=".$bid."");
         }
         echo "<div><a href='".XOCP_URL."/banners.php?op=click&amp;bid=$bid' target='_blank'><img src='$imageurl' alt='' /></a></div>";
      }
   }



   /*
    * Function to get a user selected theme file
    */
   function getTheme($theme=""){
      global $xocpConfig, $xocp_db, $xocp_user;
      $themedir = XOCP_DOC_ROOT."/themes";
      if ( !isset($theme) || trim($theme) == "" ) {
         if ( is_object($xocp_user) && get_class($xocp_user) == "xocpuser") {
            $theme = $xocp_user->getVar("theme");
            if ( isset($theme) && $theme != "" ) {
               if ( file_exists($themedir."/".$theme."/theme.php") ) {
                  return $theme;
               }
            } else {
               return $xocpConfig['default_theme'];
            }
         } else {
            return $xocpConfig['default_theme'];
         }
      } else {
         $theme = trim($theme);
         if ( file_exists($themedir/$theme/theme.php) ) {
            return $theme;
         }
      }
      return $xocpConfig['default_theme'];
   }

   /*
    * Function to get css file for a certain theme
    */
   function getcss($whatdir) {
      global $xocpConfig, $HTTP_USER_AGENT;
      if(ereg('MSIE',$HTTP_USER_AGENT) && !ereg('Opera',$HTTP_USER_AGENT)){
         $str_css = "style.css";
      }else{
         $str_css = "styleNN.css";
      }
      $themedir = XOCP_DOC_ROOT."/themes";
      $filepath = "$themedir/$whatdir/style/$str_css";
      $default = "$themedir/$whatdir/style/style.css";
      if ( file_exists($filepath) ) {
      //need to change to absolute path for inclusion from modules
         $whatcss = "themes/$whatdir/style/$str_css";
      } elseif ( file_exists($default) ) {
         $whatcss = "themes/$whatdir/style/style.css";
      } else {
         $whatcss = "";
      }
      return $whatcss;
   }

   /*
    * Function to display a message encouraging users
    * to use web standards browser
    */
   function waspInfo() {
      return "<p class='ahem'><small>This site will look MUCH better in a browser that supports <a title='The Web Standards Project&apos;s BROWSER UPGRADE initiative.' href='http://www.webstandards.org/upgrade/'>web standards</a>, but its content is accessible to any browser or Internet device.</small></p>";
   }

   function avatarExists($uid){
      global $xocpConfig;
      // recommend not to change this
      $allowed_ext = array("gif", "jpeg", "jpg", "png");
      foreach($allowed_ext as $ext){
         if ( file_exists(XOCP_DOC_ROOT."/images/avatar/users/".$uid.".".$ext ) ) {
            return "users/".$uid.".".$ext;
         }
      }
      return false;
   }

   function &getMailer(){
      if ( class_exists("XoopsMailerLocal") ) {
         return new XoopsMailerLocal();
      } else {
         return new XoopsMailer();
      }
   }




} // XOCP_FUNCTIONS_DEFINED
?>