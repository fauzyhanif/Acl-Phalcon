<?php
//--------------------------------------------------------------------//
// Filename : config.php                                              //
// Software : XOCP - X Open Community Portal                          //
// Version  : 0.1                                                     //
// Date     : 2002-11-09                                              //
// Author   : (anybody)                                               //
// License  : Public Domain                                           //
//                                                                    //
// You may use and modify this software as you wish. Share and Enjoy! //
//--------------------------------------------------------------------//

if ( !defined("XOCP_CONFIG_INCLUDED") ) {

//   ini_set("session.auto_start",0);
//   session_unset();
//   session_destroy();

   define("XOCP_CONFIG_INCLUDED",TRUE);

   // Portal ID
   define("XOCP_PORTAL_ID",1);

   // Organization ID (default)
   define("XOCP_ORGANIZATION_ID",1);
   
   // Version
   define("XOCP_VERSION","XOCP 1.0");
   
   // XOCP Physical Path
   // Physical path to your main XOCP directory WITHOUT trailing slash
   define("XOCP_DOC_ROOT","/var/www/html/bniautodebet");

   // XOCP Server Subdir
   // Subdir to your main XOCP directory WITHOUT trailing slash
   define("XOCP_SERVER_SUBDIR","/bniautodebet");

   // XOCP Virtual Path (URL)
   // Virtual path to your main XOCP directory WITHOUT trailing slash
   define("XOCP_URL", "http://www.pmb.upnyk.ac.id".XOCP_SERVER_SUBDIR);
   
   define("XOCP_SESSION_SAVEPATH",XOCP_DOC_ROOT."/cache/session");
   define("XOCP_SESSION_TMPDATA",XOCP_DOC_ROOT."/cache/tmpdata");
   
   define("XOCP_PAGE_CACHEDIR",XOCP_DOC_ROOT."/cache/pages/");

   // Database
   // Choose the database to be used
   $xocpConfig['database'] = "mysql";

   // Table Prefix
   // This prefix will be added to all new tables created to avoid name conflict in the database.
   define("XOCP_PREFIX", "xocp_");

   // Database Hostname
   // Hostname of the database server. If you are unsure, 'localhost' works in most cases.
   $xocpConfig['dbhost'] = "localhost";

   // Database Username
   // Your database user account on the host
   $xocpConfig['dbuname'] = "root";

   // Database Password
   // Password for your database user account
   $xocpConfig['dbpass'] = "";

   // Database Name
   // The name of database on the host. The installer will attempt to create the database if not exist
   $xocpConfig['dbname'] = "bniautodebet";

   // Use persistent connection? (Yes=1 No=0)
   // Default is 'Yes'. Choose 'Yes' if you are unsure.
   $xocpConfig['db_pconnect'] = 1;

   // Site name
   $xocpConfig['sitename'] = "PMB - UPN Veteran Yogyakarta";

   // Slogan for your site
   $xocpConfig['slogan'] = "XOCP Site";

   // Admin mail address
   $xocpConfig['adminmail'] = "adiet@192.168.1.17";

   // Default language
   $xocpConfig['language'] = "indonesian";

   // Module for your start page without php extension
   $xocpConfig['startpage'] = "guest";

   // Default theme
   $xocpConfig['default_theme'] = "green";



   include(XOCP_DOC_ROOT."/include/common.php");
}

?>